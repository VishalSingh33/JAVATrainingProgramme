// package com.zyapaar.userservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;
// import java.util.Set;
// import javax.validation.ConstraintViolation;
// import javax.validation.Validator;
// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.userservice.dto.EntityRegistrationDto;
// import com.zyapaar.userservice.dto.UserCompanyRegistrationDto;
// import com.zyapaar.userservice.dto.UserRegistrationDto;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.service.ManageCompanyService;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.web.multipart.MultipartFile;

// /**
//  * CompanyRegistrationController Tests class
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class CompanyRegistrationControllerTests {
  
//   @InjectMocks
//   CompanyRegistrationController companyRegistrationController;
//   @Mock
//   ManageCompanyService companyService;
//   @Mock
//   UserCompanyRegistrationDto userCompanyRegistrationDto;
//   @Mock
//   UserRegistrationDto userRegistrationDto;
//   @Mock
//   EntityRegistrationDto companyRegistrationDto;
//   @Mock
//   MultipartFile multipartFile;
//   @Mock
//   ResponseEntity<Response> responseEntity;
//   @Mock
//   Validator validator;
//   @Mock
//   Set<ConstraintViolation<UserCompanyRegistrationDto>> violations;

//   @Test
//   @DisplayName("Test case for Valid Status And Message")
//   void createUser_shouldReturnValidStatusAndHeader() throws JsonProcessingException, Exception {
//     when(companyService.createComapny(isA(UserCompanyRegistrationDto.class),isA(MultipartFile.class),
//         isA(MultipartFile.class), anyString())).thenReturn(responseEntity);
//     when(userCompanyRegistrationDto.getUser()).thenReturn(userRegistrationDto);
    
//     when(userCompanyRegistrationDto.getCompany()).thenReturn(companyRegistrationDto);
//     when(validator.validate(isA(UserCompanyRegistrationDto.class))).thenReturn(violations);
//     when(violations.isEmpty()).thenReturn(true);

//     ResponseEntity<Response> result = companyRegistrationController
//         .createComapny("123456", userCompanyRegistrationDto,multipartFile,multipartFile);

//     assertNotNull(result);
//     assertEquals(responseEntity, result);
//   }

// }
