// package com.zyapaar.userservice.producer;

// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.mock;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeUnit;
// import java.util.concurrent.TimeoutException;

// import com.zyapaar.serde.CompanyIndustryAvro;
// import com.zyapaar.serde.EntityRegistrationAvro;
// import com.zyapaar.serde.IndustryUsersAvro;
// import com.zyapaar.serde.ProductUsersAvro;
// import com.zyapaar.serde.SignUpPhaseOneAvro;
// import com.zyapaar.serde.SignUpStatusAvro;
// import com.zyapaar.serde.UserIndustryAvro;
// import com.zyapaar.serde.UserRegistrationAvro;
// import com.zyapaar.userservice.dto.SignUpOTPDto;
// import com.zyapaar.userservice.dto.UserRegistrationDto;
// import com.zyapaar.userservice.mapper.UserMapper;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.properties.B2bProperties.Topic;

// import org.apache.kafka.clients.producer.ProducerRecord;
// import org.apache.kafka.clients.producer.RecordMetadata;
// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.kafka.core.KafkaTemplate;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.util.concurrent.ListenableFuture;

// /**
//  * UserRegistrationProducer Test class
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// class UserRegistrationProducerTests {

//   @Mock
//   UserRegistrationProducer userRegistrationProducer;
//   private KafkaTemplate<String, SignUpPhaseOneAvro> signUpPhaseOneTemplate;
//   private KafkaTemplate<String, EntityRegistrationAvro> companyRegistrationTemplate;
//   private KafkaTemplate<String, UserRegistrationAvro> userRegistrationTemplate;
//   private B2bProperties b2bProperties;
//   private UserMapper userMapper;
//   private KafkaTemplate<String, UserIndustryAvro> userIndustryTemplate;
//   private KafkaTemplate<String, IndustryUsersAvro> industryUserTemplate;
//   private KafkaTemplate<String, CompanyIndustryAvro> companyIndustryTemplate;

//   @BeforeEach
//   void setup() {
//     signUpPhaseOneTemplate = mock(KafkaTemplate.class);
//     companyRegistrationTemplate = mock(KafkaTemplate.class);
//     userRegistrationTemplate = mock(KafkaTemplate.class);
//     b2bProperties = mock(B2bProperties.class);
//     userMapper = mock(UserMapper.class);
//     userIndustryTemplate = mock(KafkaTemplate.class);
//     industryUserTemplate = mock(KafkaTemplate.class);
//     companyIndustryTemplate = mock(KafkaTemplate.class);

//     userRegistrationProducer = new UserRegistrationProducer(signUpPhaseOneTemplate,
//         companyRegistrationTemplate, userRegistrationTemplate, b2bProperties,
//         userMapper, industryUserTemplate, userIndustryTemplate, companyIndustryTemplate);
//   }

//   @Mock
//   ProducerRecord producerRecord;
//   @Mock
//   ListenableFuture<SendResult<String, SignUpPhaseOneAvro>> futureSignUp;
//   @Mock
//   ListenableFuture<SendResult<String, UserRegistrationAvro>> futureUser;
//   @Mock
//   ListenableFuture<SendResult<String, EntityRegistrationAvro>> futureCompany;
//   @Mock
//   ListenableFuture<SendResult<String, ProductUsersAvro>> futureProduct;
//   @Mock
//   ListenableFuture<SendResult<String, UserIndustryAvro>> futureUserInd;
//   @Mock
//   SignUpStatusAvro signUpStatusAvro;
//   @Mock
//   RecordMetadata recordMetadata;
//   @Mock
//   UserRegistrationDto userRegistrationDto;
//   @Mock
//   UserRegistrationAvro userRegistrationAvro;
//   @Mock
//   EntityRegistrationAvro EntityRegistrationAvro;
//   @Mock
//   UserIndustryAvro userIndustryAvro;
//   @Mock
//   ProductUsersAvro productUsersAvro;
//   @Mock
//   SendResult<String, UserRegistrationAvro> sendResultUser;
//   @Mock
//   SendResult<String, SignUpPhaseOneAvro> sendResultSignUpPhaseOneAvro;
//   @Mock
//   SendResult<String, EntityRegistrationAvro> sendResultCompany;
//   @Mock
//   SignUpPhaseOneAvro signUpPhaseOneAvro;
//   @Mock
//   SignUpOTPDto signUpOTPDto;
//   @Mock
//   Topic topic;

//   @Test
//   @DisplayName("signupPhaseOne producer test")
//   void signupPhaseOne_shouldProduceDataInTopic() throws InterruptedException, ExecutionException,
//       TimeoutException {
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getSignupPhaseOne()).thenReturn("value");
//     when(userMapper.signUpOTPDtoToSignUpPhaseOneAvro(
//         isA(SignUpOTPDto.class), isA(SignUpStatusAvro.class))).thenReturn(signUpPhaseOneAvro);
//     when(signUpOTPDto.getMobileNo()).thenReturn("value");
//     when(signUpPhaseOneTemplate.send(isA(ProducerRecord.class))).thenReturn(futureSignUp);
//     when(futureSignUp.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendResultSignUpPhaseOneAvro);

//     SendResult<String, SignUpPhaseOneAvro> actual = userRegistrationProducer.signupPhaseOne(
//         signUpOTPDto, SignUpStatusAvro.FULL);
//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("company producer test")
//   void createCompany() throws InterruptedException, ExecutionException,
//       TimeoutException {
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getCompanyRegistration()).thenReturn("value");
//     when(EntityRegistrationAvro.getId()).thenReturn("value");
//     when(companyRegistrationTemplate.send(isA(ProducerRecord.class))).thenReturn(futureCompany);
//     when(futureCompany.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendResultCompany);
//     when(sendResultCompany.getRecordMetadata()).thenReturn(recordMetadata);

//     boolean actual = userRegistrationProducer.createCompany(EntityRegistrationAvro);
//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("company producer return false test")
//   void createCompany_return_false() throws InterruptedException, ExecutionException,
//       TimeoutException {
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getCompanyRegistration()).thenReturn("value");
//     when(EntityRegistrationAvro.getId()).thenReturn("value");
//     when(companyRegistrationTemplate.send(isA(ProducerRecord.class))).thenReturn(futureCompany);
//     when(futureCompany.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendResultCompany);
//     when(sendResultCompany.getRecordMetadata()).thenReturn(null);

//     boolean actual = userRegistrationProducer.createCompany(EntityRegistrationAvro);
//     assertFalse(actual);
//   }

//   @Test
//   @DisplayName("create user")
//   void createUser() throws InterruptedException, ExecutionException, TimeoutException {
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getUserRegistration()).thenReturn("value");
//     when(userRegistrationAvro.getId()).thenReturn("value");

//     when(userRegistrationTemplate.send(isA(ProducerRecord.class))).thenReturn(futureUser);
//     when(futureUser.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendResultUser);
//     when(sendResultUser.getRecordMetadata()).thenReturn(recordMetadata);

//     boolean actual = userRegistrationProducer
//         .createUser(userRegistrationAvro);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("create user return false")
//   void createUser_return_false() throws InterruptedException, ExecutionException, TimeoutException {
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getUserRegistration()).thenReturn("value");
//     when(userRegistrationAvro.getId()).thenReturn("value");

//     when(userRegistrationTemplate.send(isA(ProducerRecord.class))).thenReturn(futureUser);
//     when(futureUser.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendResultUser);
//     when(sendResultUser.getRecordMetadata()).thenReturn(null);

//     boolean actual = userRegistrationProducer.createUser(userRegistrationAvro);

//     assertFalse(actual);
//   }

//   @Test
//   @DisplayName("producerUserIndustryList")
//   void producerUserIndustryList() {

//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getUsersWiseIndustry()).thenReturn("value");

//     when(userIndustryTemplate.send(isA(ProducerRecord.class))).thenReturn(futureUserInd);

//     userRegistrationProducer.producerUserIndustryList(userIndustryAvro);

//     verify(userIndustryTemplate, times(1)).send(isA(ProducerRecord.class));

//   }
// }
