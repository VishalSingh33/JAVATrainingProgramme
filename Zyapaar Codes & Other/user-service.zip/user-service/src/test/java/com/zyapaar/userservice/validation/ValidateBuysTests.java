// package com.zyapaar.userservice.validation;

// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.Iterator;
// import java.util.List;

// import javax.validation.ConstraintValidatorContext;
// import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext;

// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.validation.ValidateBuys.Validators;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Buys Product validations test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class ValidateBuysTests {

//   @InjectMocks
//   Validators validators;
//   @Mock
//   ValidateBuys validateProducts;
//   @Mock
//   ConstraintValidatorContext context;
//   @Mock
//   ConstraintValidatorContext.ConstraintViolationBuilder contextBuilder;
//   @Mock
//   NodeBuilderCustomizableContext nodeBuilderCustomizableContext;
//   @Mock
//   List<String> producList;
//   @Mock
//   Iterator<String> iterator;

//   @Test
//   @DisplayName("validate product is size zero")
//   void isValid_is_size_zero() {

//     List<String> list = new ArrayList<>();
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     Boolean actual = validators.isValid(list, context);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("validate product is null")
//   void isValid_is_null() {

//     List<String> list = null;
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     Boolean actual = validators.isValid(list, context);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("validate product is valid")
//   void isValid_is_valid() {

//     List<String> list = new ArrayList<>();
//     list.add("K00006822-S00000232");
//     list.add("k00006822-s00000232");

//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     Boolean actual = validators.isValid(list, context);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("validate product is not valid")
//   void isValid_is_not_valid() {

//     List<String> list = new ArrayList<>();
//     list.add("asdf");
//     list.add("1234");

//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     Boolean actual = validators.isValid(list, context);

//     assertFalse(actual);
//   }
// }
