package com.zyapaar.userservice.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyapaar.userservice.dto.UserRegistrationDto;
import com.zyapaar.userservice.properties.B2bProperties;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

/**
 * StringToUserRegistrationDtoConverter test
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = {B2bProperties.class})
public class StringToUserRegistrationDtoConverterTests {
  
  @InjectMocks StringToUserRegistrationDtoConverter converter;

  @Mock ObjectMapper objectMapper;

  @Mock
  UserRegistrationDto userDto;

  @Test
  @DisplayName("convert method test")
  void convert() throws JsonMappingException, JsonProcessingException{
    when(objectMapper.readValue(anyString(),eq(UserRegistrationDto.class))).thenReturn(userDto);

    UserRegistrationDto dto = converter.convert("source");

    assertEquals(userDto, dto);
  }
}
