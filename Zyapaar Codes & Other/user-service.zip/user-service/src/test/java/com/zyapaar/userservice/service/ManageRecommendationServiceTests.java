// package com.zyapaar.userservice.service;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.Date;
// import java.util.Iterator;
// import java.util.List;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;

// import com.zyapaar.commons.dto.NotificationStatus;
// import com.zyapaar.commons.dto.NotificationTypes;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.serde.NotificationEventAvro;
// import com.zyapaar.userservice.dao.ManageRecommendationDao;
// import com.zyapaar.userservice.dto.RecommendationListDto;
// import com.zyapaar.userservice.dto.RecommendationStatus;
// import com.zyapaar.userservice.dto.UserRecommendationDto;
// import com.zyapaar.userservice.mapper.NotificationMapper;
// import com.zyapaar.userservice.mapper.UserRecommendationMapper;
// import com.zyapaar.userservice.model.UserRecommendation;
// import com.zyapaar.userservice.producer.NotificationProducer;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.properties.B2bProperties.Topic;

// /**
//  * recommendation service test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageRecommendationServiceTests {
  
//   @InjectMocks
//   ManageRecommendationService manageRecommendationService;
//   @Mock
//   UserRecommendationMapper userRecommendationMapper;
//   @Mock
//   UserRecommendation userRecommendation;
//   @Mock
//   UserRecommendationDto userRecommendationDto; 
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   List<RecommendationListDto> recommendationListDtos;
//   @Mock
//   ManageRecommendationDao recommendationDao;
//   @Mock
//   RecommendationListDto recommendationListDto;
//   @Mock
//   Iterator<RecommendationListDto> iterator;
//   @Mock
//   NotificationMapper notificationMapper;
//   @Mock
//   NotificationEventAvro notificationEventAvro;
//   @Mock
//   NotificationProducer notificationProducer;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   Topic topic;

//   @Test
//   @DisplayName("add User Recommendation ASK status")
//   void addUserRecommendation_ASK_test(){

//     when(userRecommendationDto.getStatus()).thenReturn(RecommendationStatus.ASK);
//     when(userRecommendationMapper.toCustomUserRecommendation(isA(UserRecommendationDto.class), 
//         anyString(), isA(Date.class), isA(Date.class))).thenReturn(userRecommendation);
//     when(recommendationDao.addUserRecommendation(isA(UserRecommendation.class)))
//         .thenReturn(userRecommendation);

//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getRecommendationEvent()).thenReturn("value");

//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(userRecommendationDto.getTo()).thenReturn("value");
//     when(notificationMapper.buildNotificationEvent(anyString(), anyString(), anyString(), 
//         isA(NotificationTypes.class), anyString(), isA(NotificationStatus.class)))
//         .thenReturn(notificationEventAvro);

//     doNothing().when(notificationProducer).produceNotificationEvent(isA(NotificationEventAvro.class), anyString());

//     manageRecommendationService.addUserRecommendation("userId", userRecommendationDto);

//     verify(recommendationDao, times(1)).addUserRecommendation(isA(UserRecommendation.class));
//   }

//   @Test
//   @DisplayName("add User Recommendation PANDING new status")
//   void addUserRecommendation_PANDING_new_test(){

//     when(userRecommendationDto.getStatus()).thenReturn(RecommendationStatus.PANDING);
//     when(userRecommendationDto.getId()).thenReturn(null);
//     when(userRecommendationMapper.toUserRecommendation(isA(UserRecommendationDto.class), 
//         anyString(), isA(Date.class), isA(Date.class))).thenReturn(userRecommendation);
//     when(recommendationDao.addUserRecommendation(isA(UserRecommendation.class)))
//         .thenReturn(userRecommendation);
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getRecommendationEvent()).thenReturn("value");

//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(userRecommendationDto.getTo()).thenReturn("value");
//     when(notificationMapper.buildNotificationEvent(anyString(), anyString(), anyString(), 
//         isA(NotificationTypes.class), anyString(), isA(NotificationStatus.class)))
//         .thenReturn(notificationEventAvro);

//     doNothing().when(notificationProducer).produceNotificationEvent(isA(NotificationEventAvro.class), anyString());
    

//     manageRecommendationService.addUserRecommendation("userId", userRecommendationDto);

//     verify(recommendationDao, times(1)).addUserRecommendation(isA(UserRecommendation.class));
//   }

//   @Test
//   @DisplayName("add User Recommendation PANDING OLD status")
//   void addUserRecommendation_PANDING_old_test(){

//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(recommendationDao.getUserRecommendation(anyString())).thenReturn(userRecommendation);
//     when(userRecommendation.getCreatedOn()).thenReturn(new Date());
//     when(userRecommendationDto.getStatus()).thenReturn(RecommendationStatus.PANDING);
//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(userRecommendationMapper.toUserRecommendation(isA(UserRecommendationDto.class), 
//         anyString(), isA(Date.class), isA(Date.class))).thenReturn(userRecommendation);
//     doNothing().when(recommendationDao).updateUserRecommendation(isA(UserRecommendation.class));
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getRecommendationEvent()).thenReturn("value");

//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(userRecommendationDto.getTo()).thenReturn("value");
//     when(notificationMapper.buildNotificationEvent(anyString(), anyString(), anyString(), 
//         isA(NotificationTypes.class), anyString(), isA(NotificationStatus.class)))
//         .thenReturn(notificationEventAvro);

//     doNothing().when(notificationProducer).produceNotificationEvent(isA(NotificationEventAvro.class), anyString());


//     manageRecommendationService.addUserRecommendation("userId", userRecommendationDto);

//     verify(recommendationDao, times(1)).updateUserRecommendation(isA(UserRecommendation.class));
//   }

//   @Test
//   @DisplayName("add User Recommendation OTHER status")
//   void addUserRecommendation_OTHER_test(){

//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(recommendationDao.getUserRecommendation(anyString())).thenReturn(userRecommendation);
//     when(userRecommendation.getCreatedOn()).thenReturn(new Date());
//     when(userRecommendationDto.getStatus()).thenReturn(RecommendationStatus.ACCEPT);
//     when(userRecommendationMapper.toUserRecommendation(isA(UserRecommendationDto.class), 
//         anyString(), isA(Date.class), isA(Date.class))).thenReturn(userRecommendation);
//     doNothing().when(recommendationDao).updateUserRecommendation(isA(UserRecommendation.class));

//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getRecommendationEvent()).thenReturn("value");

//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(userRecommendationDto.getTo()).thenReturn("value");
//     when(notificationMapper.buildNotificationEvent(anyString(), anyString(), anyString(), 
//         isA(NotificationTypes.class), anyString(), isA(NotificationStatus.class)))
//         .thenReturn(notificationEventAvro);

//     doNothing().when(notificationProducer).produceNotificationEvent(isA(NotificationEventAvro.class), anyString());


//     manageRecommendationService.addUserRecommendation("userId", userRecommendationDto);

//     verify(recommendationDao, times(1)).updateUserRecommendation(isA(UserRecommendation.class));
//   }



//   @Test
//   @DisplayName("get Recommend Ask list test")
//   void getRecommendAsk(){
    
//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(recommendationDao.getUserRecommendation(anyString())).thenReturn(userRecommendation);
//     when(userRecommendation.getCreatedOn()).thenReturn(new Date());
//     when(recommendationDao.getRecommendAsk(anyString(), isA(ListingRequest.class)))
//         .thenReturn(recommendationListDtos);
//     when(recommendationListDtos.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(recommendationListDto);
//     when(recommendationListDto.getCreatedOn()).thenReturn(new Date());

//     when(listingRequest.getPage()).thenReturn(1);

//     ListingResponse actual = manageRecommendationService.getRecommendAsk("userId",listingRequest);

//     assertNotNull(actual);
//     assertEquals(recommendationListDtos, actual.getContent());
//   }

//   @Test
//   @DisplayName("get Recommend Pending list test")
//   void getRecommendPending(){
    
//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(recommendationDao.getUserRecommendation(anyString())).thenReturn(userRecommendation);
//     when(userRecommendation.getCreatedOn()).thenReturn(new Date());
//     when(recommendationDao.getRecommendPendingOrReceived(anyString(), isA(ListingRequest.class), 
//         anyString())).thenReturn(recommendationListDtos);
//     when(listingRequest.getPage()).thenReturn(1);
//     when(recommendationListDtos.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(recommendationListDto);
//     when(recommendationListDto.getCreatedOn()).thenReturn(new Date());
//     ListingResponse actual = manageRecommendationService.getRecommendPending("userId",listingRequest);

//     assertNotNull(actual);
//     assertEquals(recommendationListDtos, actual.getContent());
//   }

//   @Test
//   @DisplayName("get Recommend Given list test")
//   void getRecommendGiven(){
    
//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(recommendationDao.getUserRecommendation(anyString())).thenReturn(userRecommendation);
//     when(userRecommendation.getCreatedOn()).thenReturn(new Date());
//     when(recommendationDao.getRecommendGiven(anyString(), isA(ListingRequest.class), anyString()))
//         .thenReturn(recommendationListDtos);
//     when(listingRequest.getPage()).thenReturn(1);
//     when(recommendationListDtos.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(recommendationListDto);
//     when(recommendationListDto.getCreatedOn()).thenReturn(new Date());
//     ListingResponse actual = manageRecommendationService.getRecommendGiven("userId",listingRequest);

//     assertNotNull(actual);
//     assertEquals(recommendationListDtos, actual.getContent());
//   }

//   @Test
//   @DisplayName("get Recommend Received list test")
//   void getRecommendReceived(){
    
//     when(userRecommendationDto.getId()).thenReturn("value");
//     when(recommendationDao.getUserRecommendation(anyString())).thenReturn(userRecommendation);
//     when(userRecommendation.getCreatedOn()).thenReturn(new Date());
//     when(recommendationDao.getRecommendPendingOrReceived(anyString(), isA(ListingRequest.class), 
//         anyString())).thenReturn(recommendationListDtos);
//     when(listingRequest.getPage()).thenReturn(1);
//     when(recommendationListDtos.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(recommendationListDto);
//     when(recommendationListDto.getCreatedOn()).thenReturn(new Date());
//     ListingResponse actual = manageRecommendationService.getRecommendReceived("userId",listingRequest);

//     assertNotNull(actual);
//     assertEquals(recommendationListDtos, actual.getContent());
//   }
// }
