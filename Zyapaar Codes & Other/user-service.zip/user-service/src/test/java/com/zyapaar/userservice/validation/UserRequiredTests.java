// package com.zyapaar.userservice.validation;

// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.Mockito.when;

// import javax.validation.ConstraintValidatorContext;

// import com.zyapaar.serde.SignUpStatusAvro;
// import com.zyapaar.userservice.consumer.StateStores;
// import com.zyapaar.userservice.dto.EntityRegistrationDto;
// import com.zyapaar.userservice.dto.UserCompanyRegistrationDto;
// import com.zyapaar.userservice.dto.UserRegistrationDto;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.validation.UserRequired.Validators;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;

// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class UserRequiredTests {

//   @InjectMocks
//   Validators validators;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   ConstraintValidatorContext context;
//   @Mock
//   UserCompanyRegistrationDto userCompanyRegistrationDto;
//   @Mock
//   UserRegistrationDto userRegistrationDto;
//   @Mock
//   EntityRegistrationDto companyRegistrationDto;
//   @Mock
//   SignUpStatusAvro signUpStatusAvro;

//   @Test
//   @DisplayName("isValid true case")
//   void isValid_true_case() {

//     when(userCompanyRegistrationDto.getCompany()).thenReturn(companyRegistrationDto);
//     when(companyRegistrationDto.getUserMobile()).thenReturn("value");
//     when(stateStores.userStatus(anyString())).thenReturn(SignUpStatusAvro.PHASE1);
//     when(userCompanyRegistrationDto.getUser()).thenReturn(userRegistrationDto);

//     Boolean actual = validators.isValid(userCompanyRegistrationDto, context);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("isValid false case")
//   void isValid_false_case() {

//     userRegistrationDto = new UserRegistrationDto();
//     when(userCompanyRegistrationDto.getCompany()).thenReturn(companyRegistrationDto);
//     when(companyRegistrationDto.getUserMobile()).thenReturn("value");
//     when(stateStores.userStatus(anyString())).thenReturn(SignUpStatusAvro.PHASE1);
//     when(userCompanyRegistrationDto.getUser()).thenReturn(null);

//     Boolean actual = validators.isValid(userCompanyRegistrationDto, context);

//     assertFalse(actual);
//   }

//   @Test
//   @DisplayName("isValid true case2")
//   void isValid_true_case_2() {

//     when(userCompanyRegistrationDto.getCompany()).thenReturn(companyRegistrationDto);
//     when(companyRegistrationDto.getUserMobile()).thenReturn("value");
//     when(stateStores.userStatus(anyString())).thenReturn(SignUpStatusAvro.NEW);

//     Boolean actual = validators.isValid(userCompanyRegistrationDto, context);

//     assertTrue(actual);
//   }
// }
