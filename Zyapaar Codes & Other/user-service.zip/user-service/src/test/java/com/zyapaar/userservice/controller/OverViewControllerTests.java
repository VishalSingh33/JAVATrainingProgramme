// package com.zyapaar.userservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.Mockito.when;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.userservice.dto.UserOverViewData;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.service.OverViewService;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Over view controller test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class OverViewControllerTests {

//   @InjectMocks
//   OverViewController overViewController;
//   @Mock
//   OverViewService overViewService;
//   @Mock
//   UserOverViewData userOverViewData;

//   @Test
//   @DisplayName("getUserOverView test")
//   void getUserOverView(){

//     when(overViewService.getUserOverView(anyString())).thenReturn(userOverViewData);

//     ResponseEntity<Response> actual = overViewController.getUserOverView("userId");

//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(userOverViewData, actual.getBody().getData());
//   }


// }
