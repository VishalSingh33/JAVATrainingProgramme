// package com.zyapaar.userservice.service;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import com.zyapaar.serde.UserOverviewAvro;
// import com.zyapaar.userservice.consumer.StateStores;
// import com.zyapaar.userservice.dto.UserOverViewData;
// import com.zyapaar.userservice.mapper.UserOverViewMapper;
// import com.zyapaar.userservice.properties.B2bProperties;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Over view service test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class ManageOverViewServiceTests {

//   @InjectMocks
//   ManageOverViewService manageOverViewService;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   UserOverViewMapper userOverViewMapper;
//   @Mock
//   UserOverviewAvro userOverviewAvro;
//   @Mock
//   UserOverViewData userOverViewData;

//   @Test
//   @DisplayName("getUserOverView")
//   void getUserOverView(){

//     when(stateStores.getUserOverviewData(anyString())).thenReturn(userOverviewAvro);
//     when(userOverViewMapper.toUserOverViewData(isA(UserOverviewAvro.class)))
//         .thenReturn(userOverViewData);

//     UserOverViewData actual = manageOverViewService.getUserOverView("userId");

//     assertEquals(userOverViewData, actual);
//   }

// }
