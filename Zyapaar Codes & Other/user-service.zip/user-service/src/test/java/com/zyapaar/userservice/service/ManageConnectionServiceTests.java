// package com.zyapaar.userservice.service;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.anyInt;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;
// import java.util.Iterator;
// import java.util.List;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
// import com.zyapaar.serde.ConnectionRequestAvro;
// import com.zyapaar.serde.UserConnectionAvro;
// import com.zyapaar.serde.UserOverviewAvro;
// import com.zyapaar.serde.UserRegistrationAvro;
// import com.zyapaar.userservice.consumer.StateStores;
// import com.zyapaar.userservice.dao.UserConnectionDao;
// import com.zyapaar.userservice.dao.UserDao;
// import com.zyapaar.userservice.dto.ConnectionRequestDto;
// import com.zyapaar.userservice.dto.ConnectionRequestListingDto;
// import com.zyapaar.userservice.dto.ConnectionStatus;
// import com.zyapaar.userservice.dto.Datas;
// import com.zyapaar.userservice.dto.RequestType;
// import com.zyapaar.userservice.dto.UserList;
// import com.zyapaar.userservice.dto.UserPersonalDto;
// import com.zyapaar.userservice.mapper.ConnectionMapper;
// import com.zyapaar.userservice.mapper.NotificationMapper;
// import com.zyapaar.userservice.mapper.UserMapper;
// import com.zyapaar.userservice.model.User;
// import com.zyapaar.userservice.model.UserConnection;
// import com.zyapaar.userservice.model.UserConnectionRequest;
// import com.zyapaar.userservice.producer.ConnectionProducer;
// import com.zyapaar.userservice.producer.NotificationProducer;
// import com.zyapaar.userservice.producer.OverviewProducer;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.properties.B2bProperties.Topic;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.data.domain.Pageable;
// import org.springframework.data.domain.Slice;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * connection service test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageConnectionServiceTests {

//   @InjectMocks
//   ManageConnectionService manageConnectionService;
//   @Mock
//   ConnectionMapper connectionMapper;
//   @Mock
//   ConnectionProducer connectionProducer;
//   @Mock
//   ConnectionRequestDto connectionDto;
//   @Mock
//   ConnectionRequestAvro connectionAvro;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   Slice<UserConnectionRequest> slice;
//   @Mock
//   List<UserConnectionRequest> connections;
//   @Mock
//   List<ConnectionRequestListingDto> listingDtos;
//   @Mock
//   UserConnectionRequest userConnection;
//   @Mock
//   Iterator<UserConnectionRequest> iterator;
//   @Mock
//   UserPersonalDto userPersonalDto;
//   @Mock
//   ConnectionRequestListingDto connectionRequestListingDto;
//   @Mock
//   Pageable pageable;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   ConnectionStatus connectionStatus;
//   @Mock
//   UserConnectionDao userConnectionDao;
//   @Mock
//   NotificationProducer notificationProducer;
//   @Mock
//   NotificationMapper notificationMapper;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   List<UserList> userLists;
//   @Mock
//   RequestType requestType;
//   @Mock
//   UserConnectionAvro userConnectionAvro;
//   @Mock
//   List<CharSequence> charSequences;
//   @Mock
//   List<Datas> datas;
//   @Mock
//   UserOverviewAvro userOverviewAvro;
//   @Mock
//   OverviewProducer overviewProducer;
//   @Mock
//   SendResult<String, UserOverviewAvro> result;
//   @Mock
//   UserRegistrationAvro userRegistrationAvro;
//   @Mock
//   UserMapper userMapper;
//   @Mock
//   User user;
//   @Mock
//   List<String> strings;
//   @Mock
//   List<User> users;
//   @Mock
//   UserDao userDao;
//   @Mock
//   Topic topic;

//   @Test
//   @DisplayName("create connection request return true case")
//   void createConnectionRequest_return_true() 
//       throws InterruptedException, ExecutionException, TimeoutException {

//     when(userConnectionDao.isUserConnected(anyString(), anyString())).thenReturn(false);
//     when(userConnectionDao.connectionRequestExist(anyString(), anyString())).thenReturn(false);

//     when(userDao.getUsers(anyString(), anyString())).thenReturn(users);
//     when(users.isEmpty()).thenReturn(false);
//     when(users.get(anyInt())).thenReturn(user);
//     when(users.size()).thenReturn(12);
//     when(user.getId()).thenReturn("value");

//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getUserConnectionRequestEvent()).thenReturn("value");

//     when(user.getFullName()).thenReturn("value");
//     when(connectionMapper.toConnectionAvro(isA(ConnectionRequestDto.class), anyString(), anyString(), 
//         anyLong(), anyLong())).thenReturn(connectionAvro);
//     when(connectionProducer.connectionRequestProcess(isA(ConnectionRequestAvro.class))).thenReturn(true);
//     when(topic.getUserConnectionRequestEvent()).thenReturn("value");

//     Boolean actual = manageConnectionService.createConnectionRequest("12313111", "1233111", connectionDto);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("create connection request return true case")
//   void createConnectionRequest_return_true_id() 
//       throws InterruptedException, ExecutionException, TimeoutException {

//     when(userConnectionDao.isUserConnected(anyString(), anyString())).thenReturn(false);
//     when(userConnectionDao.connectionRequestExist(anyString(), anyString())).thenReturn(false);

//     when(userDao.getUsers(anyString(), anyString())).thenReturn(users);
//     when(users.isEmpty()).thenReturn(false);
//     when(users.get(anyInt())).thenReturn(user);
//     when(users.size()).thenReturn(12);
//     when(user.getId()).thenReturn("value");

//     when(user.getFullName()).thenReturn("value");
//     when(connectionDto.getId()).thenReturn("value");
//     when(connectionMapper.toConnectionAvro(isA(ConnectionRequestDto.class), anyString(), anyString(), 
//         anyLong(), anyLong())).thenReturn(connectionAvro);
//     when(connectionProducer.connectionRequestProcess(isA(ConnectionRequestAvro.class))).thenReturn(true);
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getUserConnectionRequestEvent()).thenReturn("value");
//     Boolean actual = manageConnectionService.createConnectionRequest("12314654544", "45546546544", connectionDto);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("update connection request status 4 return true case")
//   void updateConnectionRequest_status4_return_true() 
//       throws InterruptedException, ExecutionException, TimeoutException {

//     when(userDao.getUsers(anyString(), anyString())).thenReturn(users);
//     when(users.isEmpty()).thenReturn(false);
//     when(users.get(anyInt())).thenReturn(user);
//     when(users.size()).thenReturn(12);
//     when(user.getId()).thenReturn("value");

//     when(userConnectionDao.requestExistByIdInitiateStatus(anyString())).thenReturn(true);
//     when(connectionMapper.toConnectionAvro(isA(ConnectionRequestDto.class), anyString(), anyString(), 
//         anyLong(), anyLong())).thenReturn(connectionAvro);
//     when(connectionDto.getId()).thenReturn("value");
//     when(connectionDto.getStatus()).thenReturn(ConnectionStatus.ACCEPT);
//     doNothing().when(userConnectionDao).save(isA(UserConnection.class));
//     when(connectionProducer.connectionRequestProcess(isA(ConnectionRequestAvro.class))).thenReturn(true);
//     when(stateStores.getUserConnection(anyString())).thenReturn(userConnectionAvro);
//     when(userConnectionAvro.getUserIds()).thenReturn(charSequences);
//     doNothing().when(connectionProducer).userConnectionProducer(isA(UserConnectionAvro.class));
//     when(stateStores.getUserOverviewData(anyString())).thenReturn(userOverviewAvro);
//     when(userOverviewAvro.getConnections()).thenReturn(1L);
//     when(overviewProducer.produceUserOverView(isA(UserOverviewAvro.class))).thenReturn(result);
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getUserConnectionRequestEvent()).thenReturn("value");
//     Boolean actual = manageConnectionService.updateConnectionRequestStatus("userId", "toUserId", connectionDto);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("update connection request status 5 return true case")
//   void updateConnectionRequest_status5_return_true() 
//       throws InterruptedException, ExecutionException, TimeoutException {
    
//     when(connectionDto.getId()).thenReturn("value");
//     when(userConnectionDao.requestExistByIdInitiateStatus(anyString())).thenReturn(true);
//     when(connectionMapper.toConnectionAvro(isA(ConnectionRequestDto.class), anyString(), anyString(), 
//         anyLong(), anyLong())).thenReturn(connectionAvro);
//     when(connectionDto.getStatus()).thenReturn(ConnectionStatus.REMOVE);
//     doNothing().when(userConnectionDao).delete(anyString());
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getUserConnectionRequestEvent()).thenReturn("value");
//     when(connectionProducer.connectionRequestProcess(isA(ConnectionRequestAvro.class))).thenReturn(true);

//     Boolean actual = manageConnectionService.updateConnectionRequestStatus("userId", "toUserId", connectionDto);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("update connection request not found")
//   void updateConnectionRequest_resource_not_found()
//       throws InterruptedException, ExecutionException, TimeoutException {
        
//     when(connectionDto.getId()).thenReturn("value");
//     when(userConnectionDao.requestExistByIdInitiateStatus(anyString())).thenReturn(false);

//     assertThrows(ResourceNotFoundException.class,
//         () -> manageConnectionService.updateConnectionRequestStatus("userId", "fromUserId", connectionDto));
//   }

//   @Test
//   @DisplayName("get connection request received list test")
//   void getConnectionReceivedRequestList(){

//     when(userDao.getUsers(anyString(), anyString())).thenReturn(users);
//     when(users.get(anyInt())).thenReturn(user);
//     when(users.isEmpty()).thenReturn(false);
//     when(users.size()).thenReturn(12);
//     when(user.getId()).thenReturn("value");

//     when(userDao.getConnectionReceivedRequestList(anyString(), isA(ListingRequest.class))).thenReturn(slice);
//     when(slice.getContent()).thenReturn(connections);
//     when(connections.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(userConnection);
//     when(userConnection.getFromUserId()).thenReturn("value");
//     when(userMapper.userRegistrationAvroToUserPersonalDto(isA(UserRegistrationAvro.class)))
//         .thenReturn(userPersonalDto);
//     when(userConnection.getCreatedOn()).thenReturn(123456798L);
//     when(connectionMapper.toConnectionRequestListingDto(isA(UserConnectionRequest.class), 
//         isA(UserPersonalDto.class), anyString())).thenReturn(connectionRequestListingDto);
//     when(slice.getPageable()).thenReturn(pageable);
//     when(pageable.getPageNumber()).thenReturn(1);

//     ListingResponse actual =  manageConnectionService.getConnectionRequestList("userId", listingRequest, RequestType.RECEIVED);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("get connection request received list test")
//   void getConnectionSentRequestList(){

//     when(userDao.getUsers(anyString(), anyString())).thenReturn(users);
//     when(users.get(anyInt())).thenReturn(user);
//     when(users.isEmpty()).thenReturn(false);
//     when(users.size()).thenReturn(12);
//     when(user.getId()).thenReturn("value");

//     when(userDao.getConnectionSentRequestList(anyString(), isA(ListingRequest.class))).thenReturn(slice);
//     when(slice.getContent()).thenReturn(connections);
//     when(connections.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(userConnection);
//     when(userConnection.getFromUserId()).thenReturn("value");
//     when(userMapper.userRegistrationAvroToUserPersonalDto(isA(UserRegistrationAvro.class)))
//         .thenReturn(userPersonalDto);
//     when(userConnection.getCreatedOn()).thenReturn(123456798L);
//     when(connectionMapper.toConnectionRequestListingDto(isA(UserConnectionRequest.class), isA(UserPersonalDto.class), anyString())).thenReturn(connectionRequestListingDto);
//     when(slice.getPageable()).thenReturn(pageable);
//     when(pageable.getPageNumber()).thenReturn(1);

//     ListingResponse actual =  manageConnectionService.getConnectionRequestList("userId", listingRequest, RequestType.SENT);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("getConnectionList with all connection")
//   void getConnectionListAllCOnnection() {

//     when(listingRequest.getPage()).thenReturn(1);
//     when(userConnectionDao.getConnectionList(anyString(), anyInt())).thenReturn(userLists);

//     ListingResponse actual = manageConnectionService.getConnectionList("userId", listingRequest, "ALL", "id");
//     assertNotNull(actual);

//   }

//   @Test
//   @DisplayName("getConnectionList with industry Id connection")
//   void getConnectionListIndustryConnection() {

//     when(listingRequest.getPage()).thenReturn(1);
//     when(userConnectionDao.getIndustryWiseConnectionList(anyString(), anyInt(), anyString()))
//         .thenReturn(userLists);

//     ListingResponse actual = manageConnectionService.getConnectionList("userId", listingRequest, 
//         "S00000142", "id");
//     assertNotNull(actual);

//   }

//   @Test
//   @DisplayName("getUserIndustryList")
//   void getUserIndustryList(){
//     when(userConnectionDao.getUserIndustryList(anyString(), anyInt())).thenReturn(datas);
//     when(listingRequest.getPage()).thenReturn(1);

//     ListingResponse actual = manageConnectionService.getUserIndustryList("userId", listingRequest);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("getUserConnectionsCount")
//   void getUserConnectionsCount(){

//     when(stateStores.getUserOverviewData(anyString())).thenReturn(userOverviewAvro);
//     when(userOverviewAvro.getConnections()).thenReturn(20L);

//     Long actual = manageConnectionService.getUserConnectionsCount("userId");

//     assertNotNull(actual);
//     assertEquals(20L, actual);
//   }

// }
