// package com.zyapaar.userservice.producer;

// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeUnit;
// import java.util.concurrent.TimeoutException;

// import com.zyapaar.serde.ConnectionRequestAvro;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.properties.B2bProperties.Topic;

// import org.apache.kafka.clients.producer.ProducerRecord;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.kafka.core.KafkaTemplate;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.util.concurrent.SettableListenableFuture;

// /**
//  * connection producer tests
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class MenageConnectionProducerTests {

//   @InjectMocks
//   MenageConnectionProducer menageConnectionProducer;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   KafkaTemplate<String, ConnectionRequestAvro> kafkaTemplate;
//   @Mock
//   ProducerRecord<String, ConnectionRequestAvro> producerRecord;
//   @Mock
//   Topic topic;
//   @Mock
//   ConnectionRequestAvro connectionAvro;
//   @Mock
//   SettableListenableFuture<SendResult<String, ConnectionRequestAvro>> futureConnection;
//   @Mock
//   SendResult<String, ConnectionRequestAvro> sendResult;

//   @Test
//   @DisplayName("create connection request return true case")
//   void createConnectionRequest_return_true() 
//       throws InterruptedException, ExecutionException, TimeoutException {

//     when(connectionAvro.getId()).thenReturn("value");
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getConnectionRequest()).thenReturn("value");
//     when(kafkaTemplate.send(isA(ProducerRecord.class))).thenReturn(futureConnection);
//     when(futureConnection.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendResult);
        
//     Boolean actual = menageConnectionProducer.connectionRequestProcess(connectionAvro);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("create connection request return fasle case")
//   void createConnectionRequest_return_false() 
//       throws InterruptedException, ExecutionException, TimeoutException {

//     when(connectionAvro.getId()).thenReturn("value");
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getConnectionRequest()).thenReturn("value");
//     when(kafkaTemplate.send(isA(ProducerRecord.class))).thenReturn(futureConnection);
//     when(futureConnection.get(anyLong(), isA(TimeUnit.class))).thenReturn(null);
        
//     Boolean actual = menageConnectionProducer.connectionRequestProcess(connectionAvro);

//     assertFalse(actual);
//   }
// }
