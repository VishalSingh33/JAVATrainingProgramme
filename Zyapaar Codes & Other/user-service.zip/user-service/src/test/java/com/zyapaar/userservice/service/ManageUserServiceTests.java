// package com.zyapaar.userservice.service;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyBoolean;
// import static org.mockito.ArgumentMatchers.anyInt;
// import static org.mockito.ArgumentMatchers.anyList;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;

// import java.io.IOException;
// import java.util.ArrayList;
// import java.util.List;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import org.apache.kafka.clients.producer.RecordMetadata;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.web.multipart.MultipartFile;
// import org.springframework.web.reactive.function.client.WebClient;
// import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
// import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
// import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
// import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

// import com.zyapaar.commons.dto.NotificationContent;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.FileUploadResponse;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.serde.SignUpPhaseOneAvro;
// import com.zyapaar.serde.SignUpStatusAvro;
// import com.zyapaar.serde.UserConnectionAvro;
// import com.zyapaar.serde.UserOverviewAvro;
// import com.zyapaar.serde.UserRegistrationAvro;
// import com.zyapaar.userservice.consumer.StateStores;
// import com.zyapaar.userservice.dao.CompanyDao;
// import com.zyapaar.userservice.dao.CompanyInviteDao;
// import com.zyapaar.userservice.dao.FollowerDao;
// import com.zyapaar.userservice.dao.NotificationSettingDao;
// import com.zyapaar.userservice.dao.UserConnectionDao;
// import com.zyapaar.userservice.dao.UserDao;
// import com.zyapaar.userservice.dto.ProfileViewer;
// import com.zyapaar.userservice.dto.SignUpOTPDto;
// import com.zyapaar.userservice.dto.UserData;
// import com.zyapaar.userservice.dto.UserDetails;
// import com.zyapaar.userservice.dto.UserDto;
// import com.zyapaar.userservice.dto.UserPersonalDetails;
// import com.zyapaar.userservice.dto.UserPersonalDto;
// import com.zyapaar.userservice.dto.UserRegistrationDto;
// import com.zyapaar.userservice.mapper.NotificationMapper;
// import com.zyapaar.userservice.mapper.UserMapper;
// import com.zyapaar.userservice.model.Company;
// import com.zyapaar.userservice.model.CompanyInviteRequest;
// import com.zyapaar.userservice.model.NotificationSettingV2;
// import com.zyapaar.userservice.model.User;
// import com.zyapaar.userservice.producer.ConnectionProducer;
// import com.zyapaar.userservice.producer.NotificationProducer;
// import com.zyapaar.userservice.producer.OverviewProducer;
// import com.zyapaar.userservice.producer.Producer;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.properties.B2bProperties.Api;
// import com.zyapaar.userservice.properties.B2bProperties.Topic;

// import reactor.core.publisher.Mono;

// /**
//  * ManageUserService Test class
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageUserServiceTests {

//   @InjectMocks
//   ManageUserService manageUserService;

//   @Mock
//   Producer producer;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   UserDao userDao;
//   @Mock
//   UserMapper userMapper;
//   @Mock
//   NotificationMapper notificationMapper;
//   @Mock
//   NotificationProducer notificationProducer;
//   @Mock
//   Api api;
//   @Mock
//   FileUploadResponse fileUploadResponse; 
//   @Mock
//   WebClient webClientMock;
//   @Mock
//   WebClient.Builder builder;
//   @Mock
//   RequestBodyUriSpec requestBodyUriSpec;
//   @Mock
//   RequestBodySpec requestBodySpec;
//   @Mock
//   RequestHeadersSpec requestHeadersSpec;
//   @Mock
//   ResponseSpec responseSpec;
//   @Mock
//   Mono<FileUploadResponse> monoFileUploadResponse;
//   @Mock
//   MultipartFile multipartImage;
//   @Mock
//   UserRegistrationDto userRegistrationDto;
//   @Mock
//   UserRegistrationAvro userRegistrationAvro;
//   @Mock
//   SendResult<String, UserRegistrationAvro> sendResult;
//   @Mock
//   SendResult<String, SignUpPhaseOneAvro> sendResultSignUpAvro;
//   @Mock
//   RecordMetadata recordMetadata;
//   @Mock
//   UserPersonalDto userPersonalDto;
//   @Mock
//   UserData userData;
//   @Mock
//   List<ProfileViewer> profileViewers;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   CompanyInviteDao companyInviteDao;
//   @Mock
//   UserDto userDto;
//   @Mock
//   CompanyInviteRequest companyInviteRequest;
//   @Mock
//   UserPersonalDetails userPersonalDetails;
//   @Mock
//   NotificationContent notificationContent;
//   @Mock
//   OverviewProducer overviewProducer;
//   @Mock
//   UserOverviewAvro userOverviewAvro;
//   @Mock
//   SendResult<String, UserOverviewAvro> result;
//   @Mock
//   ConnectionProducer connectionProducer;
//   @Mock
//   UserConnectionDao userConnectionDao;
//   @Mock
//   FollowerDao followerDao;
//   @Mock
//   UserDetails userDetails;
//   @Mock
//   User user;
//   @Mock
//   Company company;
//   @Mock
//   CompanyDao companyDao;
//   @Mock
//   NotificationSettingDao settingDao;
//   @Mock
//   NotificationSettingV2 setting;
//   @Mock
//   List<String> chrLst;
//   @Mock
//   List<User> users;
//   @Mock
//   Topic topic;

//   @Test
//   @DisplayName("update user sucess method tets")
//   void createUser_return_true() throws InterruptedException, ExecutionException, TimeoutException, 
//       IOException {

//     List<String> chrLst = new ArrayList<>();
//     chrLst.add("1");
//     chrLst.add("2");
//     chrLst.add("4");

//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(user.getCompanies()).thenReturn(chrLst);
//     when(user.getMobileNo()).thenReturn("value");

//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getUserProfileUpload()).thenReturn("value");
//     when(multipartImage.getOriginalFilename()).thenReturn("value");
//     when(multipartImage.getBytes()).thenReturn(new byte[] { 0 });
//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.bodyToMono(FileUploadResponse.class)).thenReturn(monoFileUploadResponse);
//     when(monoFileUploadResponse.block()).thenReturn(fileUploadResponse);
//     when(fileUploadResponse.getFileUrl()).thenReturn("value");
//     when(userRegistrationDto.getMobileNo()).thenReturn("value");

//     when(userMapper.toUserRegistrationAvroWithStirgnCompanies(
//         isA(UserRegistrationDto.class), anyString(), anyList(), anyBoolean()))
//       .thenReturn(userRegistrationAvro);

//     when(producer.createUser(isA(UserRegistrationAvro.class))).thenReturn(true);

//     Boolean actual = manageUserService.updateUser(userRegistrationDto, "userId", multipartImage);
//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("update user fail method tets")
//   void createUser_return_false() throws InterruptedException, ExecutionException, TimeoutException, 
//       IOException {

//     List<String> chrLst = new ArrayList<>();
//     chrLst.add("1");
//     chrLst.add("2");
//     chrLst.add("4");

//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(user.getMobileNo()).thenReturn("value");
//     when(user.getCompanies()).thenReturn(chrLst);
//     when(userMapper.toUserRegistrationAvroWithStirgnCompanies(
//         isA(UserRegistrationDto.class), anyString(), anyList(), anyBoolean()))
//       .thenReturn(userRegistrationAvro);
//     when(producer.createUser(isA(UserRegistrationAvro.class))).thenReturn(false);

//     Boolean actual = manageUserService.updateUser(userRegistrationDto, "userId", null);
//     assertFalse(actual);

//   }

//   @Test
//   @DisplayName("get user private profile data")
//   void getUserData() throws InterruptedException, ExecutionException, TimeoutException{

//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getProfileViewEvent()).thenReturn("value");
//     when(userDao.isUserExist(anyString())).thenReturn(true);
//     when(stateStores.getUserOverviewData(anyString())).thenReturn(userOverviewAvro);
//     when(userOverviewAvro.getViews()).thenReturn(11L);
//     when(overviewProducer.produceUserOverView(isA(UserOverviewAvro.class))).thenReturn(result);
//     when(userConnectionDao.isUserConnected(anyString(), anyString())).thenReturn(false);
//     when(userConnectionDao.existByFromUserIdAndToUserId(anyString(), anyString())).thenReturn(false);
//     when(followerDao.isFollow(anyString(), anyString())).thenReturn(true);
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(user.getCompanies()).thenReturn(chrLst);
//     when(chrLst.size()).thenReturn(12);
//     when(chrLst.get(anyInt())).thenReturn("1");
//     when(companyDao.getCompany(anyString())).thenReturn(company);
//     when(company.getName()).thenReturn("value");
//     when(userMapper.userToUserPersonalDetails(isA(User.class))).thenReturn(userPersonalDetails);
//     when(setting.getNetworkProfile()).thenReturn("2");
//     when(userDao.getUsers(anyString(), anyString())).thenReturn(users);
//     when(users.get(anyInt())).thenReturn(user);
//     when(user.getId()).thenReturn("value");

//     UserPersonalDetails actual = manageUserService.getUserData("userId", "id");

//     assertNotNull(actual);
//     assertEquals(userPersonalDetails, actual);
//   }

//   @Test
//   @DisplayName("get user data id is null")
//   void getUserData_with_idIsNull() throws InterruptedException, ExecutionException, TimeoutException{

//     when(userDao.isUserExist(anyString())).thenReturn(true);
//     when(setting.getNetworkProfile()).thenReturn("1");
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(user.getFullName()).thenReturn("value");
//     when(userConnectionDao.isUserConnected(anyString(), anyString())).thenReturn(true);
//     when(userConnectionDao.existByFromUserIdAndToUserId(anyString(), anyString())).thenReturn(false);
//     when(followerDao.isFollow(anyString(), anyString())).thenReturn(true);
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(user.getCompanies()).thenReturn(chrLst);
//     when(chrLst.size()).thenReturn(12);
//     when(chrLst.get(anyInt())).thenReturn("1");
//     when(companyDao.getCompany(anyString())).thenReturn(company);
//     when(company.getName()).thenReturn("value");
//     when(userMapper.userToUserPersonalDetails(isA(User.class))).thenReturn(userPersonalDetails);
//     when(setting.getNetworkProfile()).thenReturn("2");
//     when(userDao.getUsers(anyString(), anyString())).thenReturn(users);
//     when(users.get(anyInt())).thenReturn(user);
//     when(user.getId()).thenReturn("value");

//     UserPersonalDetails actual = manageUserService.getUserData("userId", "userId");

//     assertNotNull(actual);
//     assertEquals(userPersonalDetails, actual);
//   }

//   @Test
//   @DisplayName("get user data")
//   void getUserDataForEdit(){

//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(userMapper.userToUserData(isA(User.class))).thenReturn(userData);

//     UserData actual = manageUserService.getUserDataForEdit("id");

//     assertNotNull(actual);
//     assertEquals(userData, actual);
//   }

//   @Test
//   @DisplayName("getProfileViewer")
//   void getProfileViewer(){

//     when(userDao.getProfileViewer(anyString(), isA(ListingRequest.class))).thenReturn(profileViewers);
//     when(listingRequest.getPage()).thenReturn(1);

//     ListingResponse actual = manageUserService.getProfileViewer("userId", listingRequest);

//     assertEquals(profileViewers, actual.getContent());
//   }

//   @Test
//   @DisplayName("addUser sucess test")
//   void addUser_sucess() throws IOException, InterruptedException, ExecutionException, TimeoutException{

//     when(b2bProperties.getApi()).thenReturn(api);
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getTeamRequestEvent()).thenReturn("value");
//     when(api.getUserProfileUpload()).thenReturn("value");
//     when(multipartImage.getOriginalFilename()).thenReturn("value");
//     when(multipartImage.getBytes()).thenReturn(new byte[] { 0 });
//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.bodyToMono(FileUploadResponse.class)).thenReturn(monoFileUploadResponse);
//     when(monoFileUploadResponse.block()).thenReturn(fileUploadResponse);
//     when(fileUploadResponse.getFileUrl()).thenReturn("value");

//     when(userMapper.userDtoToUserRegistrationAvro(isA(UserDto.class), anyString(), anyString(), anyBoolean()))
//         .thenReturn(userRegistrationAvro);
  
//     when(companyDao.getCompanyId(anyString())).thenReturn(company);
//     when(company.getId()).thenReturn("value");
//     when(producer.createUser(isA(UserRegistrationAvro.class))).thenReturn(true);
//     when(userDto.getIdentityNumber()).thenReturn("value");
//     when(userDto.getMobileNo()).thenReturn("value");
//     when(overviewProducer.produceUserOverView(isA(UserOverviewAvro.class))).thenReturn(result);
//     doNothing().when(connectionProducer).userConnectionProducer(isA(UserConnectionAvro.class));

//     when(companyInviteDao.addNewRequest(isA(CompanyInviteRequest.class)))
//         .thenReturn(companyInviteRequest);
//     when(producer.signupPhaseOne(isA(SignUpOTPDto.class), isA(SignUpStatusAvro.class)))
//         .thenReturn(sendResultSignUpAvro);
    
//     Boolean actual = manageUserService.addUser(userDto, multipartImage);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("addUser fail test")
//   void addUser_fail() throws IOException, InterruptedException, ExecutionException, TimeoutException{

//     when(userMapper.userDtoToUserRegistrationAvro(isA(UserDto.class), anyString(), any(), anyBoolean()))
//         .thenReturn(userRegistrationAvro);

//     when(producer.createUser(isA(UserRegistrationAvro.class))).thenReturn(false);
    
//     Boolean actual = manageUserService.addUser(userDto, null);

//     assertFalse(actual);
//   }

//   @Test
//   @DisplayName("getUserPersonalData test")
//   void getUserPersonalData(){

//     List<String> chrLst = new ArrayList<>();
//     chrLst.add("1");

//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(userMapper.toUserDetails(isA(User.class))).thenReturn(userDetails);
//     when(user.getCompanies()).thenReturn(chrLst);
//     when(companyDao.getCompany(anyString())).thenReturn(company);
//     when(company.getName()).thenReturn("value");

//     UserDetails actual = manageUserService.getUserPersonalData("userId");

//     assertEquals(userDetails, actual);
//   }

// }
