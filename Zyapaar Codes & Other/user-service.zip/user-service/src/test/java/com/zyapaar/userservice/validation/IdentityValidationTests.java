// package com.zyapaar.userservice.validation;

// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import javax.validation.ConstraintValidatorContext;
// import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext;

// import com.zyapaar.userservice.component.IdentityComponent;
// import com.zyapaar.userservice.dao.CompanyDao;
// import com.zyapaar.userservice.dto.EntityRegistrationDto;
// import com.zyapaar.userservice.dto.VerifiedBy;
// import com.zyapaar.userservice.mapper.IdentityMapper;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.request.IdentityValidationDto;
// import com.zyapaar.userservice.validation.IdentityValidation.Validators;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.test.util.ReflectionTestUtils;

// /**
//  * Identity validations test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class IdentityValidationTests {

//   @InjectMocks
//   Validators validators;

//   @Mock
//   IdentityValidation identityValidation;

//   @Mock
//   ConstraintValidatorContext context;

//   @Mock
//   EntityRegistrationDto companyRegistrationDto;

//   @Mock
//   ConstraintValidatorContext.ConstraintViolationBuilder contextBuilder;

//   @Mock
//   NodeBuilderCustomizableContext nodeBuilderCustomizableContext;
//   @Mock
//   IdentityMapper identityMapper;
//   @Mock
//   IdentityValidationDto identityValidationDto;
//   @Mock
//   IdentityComponent identityComponent;
//   @Mock
//   CompanyDao companyDao;


//   @Test
//   @DisplayName("isValid GSTIN true case")
//   void isValid_gstin_true_case() {

//     when(companyDao.isIdentityRegisterWithUserId(anyString(), anyString())).thenReturn(false);
//     when(companyRegistrationDto.getVerifiedBy()).thenReturn(VerifiedBy.GSTIN);
//     when(companyRegistrationDto.getIdentityNumber()).thenReturn("24AADCI6126P1ZB");
//     when(identityMapper.toIdentityValidationDto(isA(EntityRegistrationDto.class)))
//         .thenReturn(identityValidationDto);
//     when(identityComponent.isIdentityValid(isA(IdentityValidationDto.class))).thenReturn(true);


//     Boolean actual = validators.isValid(companyRegistrationDto, context);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("isValid PAN true case")
//   void isValid_pan_true_case() {
//     when(companyDao.isIdentityRegisterWithUserId(anyString(), anyString())).thenReturn(false);
//     when(companyRegistrationDto.getVerifiedBy()).thenReturn(VerifiedBy.PAN);
//     when(companyRegistrationDto.getIdentityNumber()).thenReturn("AADCI6126P");

//     when(identityMapper.toIdentityValidationDto(isA(EntityRegistrationDto.class)))
//         .thenReturn(identityValidationDto);
//     when(identityComponent.isIdentityValid(isA(IdentityValidationDto.class))).thenReturn(true);
//     Boolean actual = validators.isValid(companyRegistrationDto, context);

//     assertTrue(actual);
//   }

//   @Test
//   @DisplayName("isValid PAN false case")
//   void isValid_pan_false_case() {

//     when(companyDao.isIdentityRegisterWithUserId(anyString(), anyString())).thenReturn(false);
//     when(companyRegistrationDto.getVerifiedBy()).thenReturn(VerifiedBy.PAN);
//     when(companyRegistrationDto.getIdentityNumber()).thenReturn("AADCI6126P");
//     when(companyRegistrationDto.getUserId()).thenReturn("value");
//     when(companyDao.isIdentityUsed(anyString())).thenReturn(true);
//     ReflectionTestUtils.setField(validators, "identityNumber", "identityNumber");
//     when(identityMapper.toIdentityValidationDto(isA(EntityRegistrationDto.class)))
//         .thenReturn(identityValidationDto);
//     when(identityComponent.isIdentityValid(isA(IdentityValidationDto.class))).thenReturn(true);
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);
//     Boolean actual = validators.isValid(companyRegistrationDto, context);

//     assertFalse(actual);
//   }

//   @Test
//   @DisplayName("isValid GSTIN regex fail case")
//   void isValid_gstin_regex_fail_case() {
//     when(companyDao.isIdentityRegisterWithUserId(anyString(), anyString())).thenReturn(false);
//     when(companyRegistrationDto.getVerifiedBy()).thenReturn(VerifiedBy.GSTIN);
//     when(companyRegistrationDto.getIdentityNumber()).thenReturn("24AADCI6126P1Z");
//     ReflectionTestUtils.setField(validators, "identityNumber", "identityNumber");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);
//     Boolean actual = validators.isValid(companyRegistrationDto, context);

//     assertFalse(actual);
//   }

//   @Test
//   @DisplayName("isValid PAN regex fail case")
//   void isValid_pan_regex_fail_case() {
//     when(companyDao.isIdentityRegisterWithUserId(anyString(), anyString())).thenReturn(false);
//     when(companyRegistrationDto.getVerifiedBy()).thenReturn(VerifiedBy.PAN);
//     when(companyRegistrationDto.getIdentityNumber()).thenReturn("AADCI6126");
//     ReflectionTestUtils.setField(validators, "identityNumber", "identityNumber");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);
//     Boolean actual = validators.isValid(companyRegistrationDto, context);

//     assertFalse(actual);
//   }

//   @Test
//   @DisplayName("isValid Udyod adhar regex fail case")
//   void isValid_udyog_adhar_regex_fail_case() {
//     when(companyDao.isIdentityRegisterWithUserId(anyString(), anyString())).thenReturn(false);
//     when(companyRegistrationDto.getVerifiedBy()).thenReturn(VerifiedBy.UDYOG_ADHAR);
//     when(companyRegistrationDto.getIdentityNumber()).thenReturn("AADCI6126");
//     ReflectionTestUtils.setField(validators, "identityNumber", "identityNumber");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);
//     Boolean actual = validators.isValid(companyRegistrationDto, context);

//     assertFalse(actual);
//   }

//   @Test
//   @DisplayName("isValid Udyam adhar regex fail case")
//   void isValid_udyam_adhar_regex_fail_case() {
//     when(companyDao.isIdentityRegisterWithUserId(anyString(), anyString())).thenReturn(false);
//     when(companyRegistrationDto.getVerifiedBy()).thenReturn(VerifiedBy.UDYAM_ADHAR);
//     when(companyRegistrationDto.getIdentityNumber()).thenReturn("AADCI6126");
//     ReflectionTestUtils.setField(validators, "identityNumber", "identityNumber");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);
//     Boolean actual = validators.isValid(companyRegistrationDto, context);

//     assertFalse(actual);
//   }

//   @Test
//   @DisplayName("isValid identity registered  case")
//   void isValid_identity_registered_case() {

//     when(companyRegistrationDto.getVerifiedBy()).thenReturn(VerifiedBy.PAN);
//     when(companyRegistrationDto.getIdentityNumber()).thenReturn("AADCI6126P");
//     when(companyRegistrationDto.getUserId()).thenReturn("value");
//     ReflectionTestUtils.setField(validators, "identityNumber", "identityNumber");
//     when(identityMapper.toIdentityValidationDto(isA(EntityRegistrationDto.class)))
//         .thenReturn(identityValidationDto);
//     when(identityComponent.isIdentityValid(isA(IdentityValidationDto.class))).thenReturn(true);
//     when(companyDao.isIdentityUsed(anyString())).thenReturn(true);
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);
//     Boolean actual = validators.isValid(companyRegistrationDto, context);

//     assertFalse(actual);
//   }
// }
