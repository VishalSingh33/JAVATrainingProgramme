// package com.zyapaar.userservice.validation;

// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.Mockito.when;

// import javax.validation.ConstraintValidatorContext;
// import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext;

// import com.zyapaar.userservice.dto.RecommendationStatus;
// import com.zyapaar.userservice.dto.UserRecommendationDto;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.validation.RecommendationValidation.Validators;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.test.util.ReflectionTestUtils;

// /**
//  * Recommendation validation test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class RecommendationValidationTests {

//   @InjectMocks
//   Validators validators;

//   @Mock
//   UserRecommendationDto recommendationDto;

//   @Mock
//   ConstraintValidatorContext context;

//   @Mock
//   ConstraintValidatorContext.ConstraintViolationBuilder contextBuilder;

//   @Mock
//   NodeBuilderCustomizableContext nodeBuilderCustomizableContext;

//   String srt = new StringBuffer("1 I have made a simple demo project for my students but I a"+
//   "not able o recognize this error following are the classes please let me know hat I am missing.I"+
//   "nterface 1 I have made a simple demo project for my students but I am not able o recognize this"+
//   " error following are the classes please let me know hat I am missing.Interface 1 I have made a "+
//   "simple demo project for my students but I am not able o recognize this error following are the "+
//   "classes please let me know hat I am missing.Interface 1 I have made a simple demo project for m"+
//   "y students but I am not able o recognize this error following are the classes please let me kno"+
//   "w hat I am missing.Interface ").toString();

//   @Test
//   @DisplayName("message null validation")
//   void messageNullValidation(){

//     when(recommendationDto.getStatus()).thenReturn(RecommendationStatus.ASK);
//     when(recommendationDto.getMessage()).thenReturn(null);
//     ReflectionTestUtils.setField(validators, "message", "message");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     assertFalse(validators.isValid(recommendationDto, context));

//   }

//   @Test
//   @DisplayName("message length min validation")
//   void messageLengthMinValidation(){
    
//     when(recommendationDto.getStatus()).thenReturn(RecommendationStatus.ASK);
//     when(recommendationDto.getMessage()).thenReturn("asd");
//     ReflectionTestUtils.setField(validators, "message", "message");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     assertFalse(validators.isValid(recommendationDto, context));

//   }

//   @Test
//   @DisplayName("message length max validation")
//   void messageLengthMaxValidation(){

//     when(recommendationDto.getStatus()).thenReturn(RecommendationStatus.ASK);
//     when(recommendationDto.getMessage()).thenReturn(srt);
//     ReflectionTestUtils.setField(validators, "message", "message");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     assertFalse(validators.isValid(recommendationDto, context));

//   }

//   @Test
//   @DisplayName("recommendation null validation")
//   void recommendationNullValidation(){

//     when(recommendationDto.getStatus()).thenReturn(RecommendationStatus.PANDING);
//     when(recommendationDto.getRecommendation()).thenReturn(null);
//     ReflectionTestUtils.setField(validators, "recommendation", "recommendation");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     assertFalse(validators.isValid(recommendationDto, context));

//   }

//   @Test
//   @DisplayName("recommendation length min validation")
//   void recommendationLengthMinValidation(){

//     when(recommendationDto.getStatus()).thenReturn(RecommendationStatus.PANDING);
//     when(recommendationDto.getRecommendation()).thenReturn("null");
//     ReflectionTestUtils.setField(validators, "recommendation", "recommendation");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     assertFalse(validators.isValid(recommendationDto, context));

//   }

//   @Test
//   @DisplayName("recommendation length max validation")
//   void recommendationLengthMaxValidation(){

//     when(recommendationDto.getStatus()).thenReturn(RecommendationStatus.PANDING);
//     when(recommendationDto.getRecommendation()).thenReturn(srt);
//     ReflectionTestUtils.setField(validators, "recommendation", "recommendation");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     assertFalse(validators.isValid(recommendationDto, context));
//   }

// }
