package com.zyapaar.userservice.component;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.when;

import com.zyapaar.userservice.properties.B2bProperties;
import com.zyapaar.userservice.properties.B2bProperties.Api;
import com.zyapaar.userservice.request.IdentityValidationDto;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

import reactor.core.publisher.Mono;

/**
 * Identity validation test
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = {B2bProperties.class})
public class IdentityComponentTests {
  
  @InjectMocks
  IdentityComponent identityComponent;
  @Mock
  B2bProperties b2bProperties;
  @Mock
  Api api;
  @Mock
  WebClient.Builder webClientBuilder;
  @Mock
  IdentityValidationDto identityValidationDto;
  @Mock
  WebClient webClient;
  @Mock
  RequestBodyUriSpec requestBodyUriSpec;
  @Mock
  RequestBodySpec requestBodySpec;
  @Mock
  RequestHeadersSpec requestHeadersSpec;
  @Mock
  ResponseSpec responseSpec;
  @Mock
  Mono<ResponseEntity<Void>> mono;
  @Mock
  ResponseEntity<Void> responseEntity;
  
  @Test
  @DisplayName("isIdentityValid")
  void isIdentityValid(){

    when(b2bProperties.getApi()).thenReturn(api);
    when(api.getIdentityValidation()).thenReturn("value");
    when(webClientBuilder.build()).thenReturn(webClient);
    when(webClient.post()).thenReturn(requestBodyUriSpec);
    when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
    when(requestBodySpec.bodyValue(isA(IdentityValidationDto.class))).thenReturn(requestHeadersSpec);
    when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
    when(responseSpec.toBodilessEntity()).thenReturn(mono);
    when(mono.block()).thenReturn(responseEntity);

    assertTrue(identityComponent.isIdentityValid(identityValidationDto));
  }


}
