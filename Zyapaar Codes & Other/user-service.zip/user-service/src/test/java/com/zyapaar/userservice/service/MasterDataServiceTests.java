// package com.zyapaar.userservice.service;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertNull;
// import static org.mockito.ArgumentMatchers.anyList;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.List;

// import com.zyapaar.userservice.consumer.StateStores;
// import com.zyapaar.userservice.dao.DesignationDao;
// import com.zyapaar.userservice.dao.MasterDataDao;
// import com.zyapaar.userservice.dto.Country;
// import com.zyapaar.userservice.dto.Designations;
// import com.zyapaar.userservice.dto.State;
// import com.zyapaar.userservice.dto.TypeDto;
// import com.zyapaar.userservice.mapper.DesignationMapper;
// import com.zyapaar.userservice.mapper.MasterDataMapper;
// import com.zyapaar.userservice.model.States;
// import com.zyapaar.userservice.model.UserDesignation;
// import com.zyapaar.userservice.properties.B2bProperties;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Master data service test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class MasterDataServiceTests {

//   @InjectMocks
//   MasterDataService masterDataService;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   List<Country> countries;
//   @Mock
//   List<State> states;
//   @Mock
//   List<TypeDto> typeDtos;
//   @Mock
//   List<UserDesignation> designations;
//   @Mock
//   List<Designations> desList;
//   @Mock
//   DesignationMapper designationMapper;
//   @Mock
//   DesignationDao designationDao;
//   @Mock
//   MasterDataDao masterDataDao;
//   @Mock
//   List<States> states2;
//   @Mock
//   MasterDataMapper masterDataMapper;

//   @Test
//   @DisplayName("get country list")
//   void getCountryList() {
//     List<Country> actual = masterDataService.getCountryList();

//     assertNull(actual);
//   }

//   @Test
//   @DisplayName("get state list")
//   void getStateList() {
//     when(masterDataDao.getStates(anyString())).thenReturn(states2);
//     when(masterDataMapper.toStates(anyList())).thenReturn(states);
//     List<State> actual = masterDataService.getStateList("countryId");

//     assertNotNull(actual);
//     assertEquals(states, actual);
//   }

//   @Test
//   @DisplayName("get business type list")
//   void getBusinessTypeList() {
//     List<TypeDto> actual = masterDataService.getBusinessTypeList();

//     assertNull(actual);
//   }

//   @Test
//   @DisplayName("get firm type list")
//   void getFirmTypeList() {
//     List<TypeDto> actual = masterDataService.getFirmTypeList();

//     assertNull(actual);
//   }

//   @Test
//   @DisplayName("get user designations")
//   void getDesignations() {

//     when(designationDao.getDesignations()).thenReturn(designations);
//     when(designationMapper.toDesignations(isA(List.class))).thenReturn(desList);

//     List<Designations> actual = masterDataService.getDesignations();

//     assertEquals(desList, actual);
//   }

// }
