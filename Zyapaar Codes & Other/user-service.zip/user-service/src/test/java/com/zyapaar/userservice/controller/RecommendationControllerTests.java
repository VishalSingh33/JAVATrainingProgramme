// package com.zyapaar.userservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.userservice.dto.UserRecommendationDto;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.service.RecommendationService;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Recommendation controller test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class RecommendationControllerTests {
  
//   @InjectMocks
//   ManageRecommendationController recommendationController;
//   @Mock
//   RecommendationService recommendationService;
//   @Mock
//   UserRecommendationDto recommendationDto;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   ListingRequest listingRequest;
  
//   @Test
//   @DisplayName("user recommendation test")
//   void userRecommendation(){
    
//     doNothing().when(recommendationService).addUserRecommendation(anyString(), 
//         isA(UserRecommendationDto.class));

//     ResponseEntity<Response> actual = recommendationController.userRecommendation("userId", 
//         recommendationDto);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//   }

//   @Test
//   @DisplayName("get Recommend Asked test")
//   void getRecommendAsk(){

//     when(recommendationService.getRecommendAsk(anyString(), isA(ListingRequest.class)))
//         .thenReturn(listingResponse);

//     ResponseEntity<Response> actual = recommendationController.getRecommendAsk("userId", 
//         listingRequest);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());
//   }

//   @Test
//   @DisplayName("get Recommend Pending test")
//   void getRecommendPending(){
    
//     when(recommendationService.getRecommendPending(anyString(), isA(ListingRequest.class)))
//         .thenReturn(listingResponse);

//     ResponseEntity<Response> actual = recommendationController.getRecommendPending("userId", 
//         listingRequest);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());
//   }

//   @Test
//   @DisplayName("get Recommend Given test")
//   void getRecommendGiven(){

//     when(recommendationService.getRecommendGiven(anyString(), isA(ListingRequest.class)))
//         .thenReturn(listingResponse);

//     ResponseEntity<Response> actual = recommendationController.getRecommendGiven("id", "userId", 
//         listingRequest);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());
//   }

//   @Test
//   @DisplayName("get Recommend Received test")
//   void getRecommendReceived(){
    
//     when(recommendationService.getRecommendReceived(anyString(), isA(ListingRequest.class)))
//         .thenReturn(listingResponse);

//     ResponseEntity<Response> actual = recommendationController.getRecommendReceived("id", "userId", 
//         listingRequest);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());
//   }
// }
