// package com.zyapaar.userservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.userservice.dto.ConnectionRequestDto;
// import com.zyapaar.userservice.dto.RequestType;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.service.ConnectionService;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * connection controller test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class ConnectionControllerTests {

//   @InjectMocks
//   ManageConnectionController connectionController;
//   @Mock
//   ConnectionService connectionService;
//   @Mock
//   ConnectionRequestDto connectionDto;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   RequestType requestType;

//   @Test
//   @DisplayName("createConnectionRequest method return ok status")
//   void createConnectionRequest_OK() throws InterruptedException, ExecutionException, TimeoutException {

//     when(connectionService.createConnectionRequest(anyString(), anyString(), isA(ConnectionRequestDto.class)))
//         .thenReturn(true);

//     ResponseEntity<Response> actual = connectionController.createConnectionRequest(
//         "userId", "toUserId", connectionDto);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals("connection request send sucess", actual.getBody().getMessage());
//   }

//   @Test
//   @DisplayName("createConnectionRequest method return ISE status")
//   void createConnectionRequest_ISE() throws InterruptedException, ExecutionException, TimeoutException {

//     when(connectionService.createConnectionRequest(anyString(), anyString(), isA(ConnectionRequestDto.class)))
//         .thenReturn(false);

//     ResponseEntity<Response> actual = connectionController.createConnectionRequest(
//         "userId", "toUserId", connectionDto);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual.getStatusCode());
//     assertEquals("something went wrong", actual.getBody().getMessage());
//   }

//   @Test
//   @DisplayName("update connection request status sucess case")
//   void createConnectionRequest_sucess() throws InterruptedException, ExecutionException, TimeoutException {

//     when(connectionService.updateConnectionRequestStatus(anyString(), anyString(), isA(ConnectionRequestDto.class)))
//         .thenReturn(true);

//     ResponseEntity<Response> actual = connectionController.updateConnectionRequestStatus("userId", "toUserId",
//         connectionDto);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals("connection request processed sucess", actual.getBody().getMessage());

//   }

//   @Test
//   @DisplayName("update connection request status fail case")
//   void createConnectionRequest_fail() throws InterruptedException, ExecutionException, TimeoutException {

//     when(connectionService.updateConnectionRequestStatus(anyString(), anyString(), isA(ConnectionRequestDto.class)))
//         .thenReturn(false);

//     ResponseEntity<Response> actual = connectionController.updateConnectionRequestStatus(
//         "userId", "toUserId", connectionDto);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual.getStatusCode());
//     assertEquals("something went wrong", actual.getBody().getMessage());
//   }

//   @Test
//   @DisplayName("get connection request list test")
//   void getConnectionRequestList() {

//     when(connectionService.getConnectionRequestList(anyString(), isA(ListingRequest.class), isA(RequestType.class)))
//         .thenReturn(listingResponse);

//     ResponseEntity<Response> actual = connectionController.getConnectionRequestList("userId", requestType,
//         listingRequest);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());

//   }

//   @Test
//   @DisplayName("get connection list test")
//   void getConnectionList() {

//     when(connectionService.getConnectionList(anyString(), isA(ListingRequest.class), anyString(), anyString()))
//         .thenReturn(listingResponse);

//     ResponseEntity<Response> actual = connectionController.getConnectionList("userId", "ALL", "id", listingRequest);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());

//   }

//   @Test
//   @DisplayName("getUserIndustryList")
//   void getUserIndustryList(){

//     when(connectionService.getUserIndustryList(anyString(), isA(ListingRequest.class)))
//         .thenReturn(listingResponse);

//     ResponseEntity<Response> actual = connectionController.getUserIndustryList("userId", listingRequest);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());

//   }

//   @Test
//   @DisplayName("getUserConnectionsCount test")
//   void getUserConnectionsCount(){

//     when(connectionService.getUserConnectionsCount(anyString())).thenReturn(20L);

//     ResponseEntity<Response> actual = connectionController.getUserConnectionsCount("userId");

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(20L, actual.getBody().getData());

//   }

// }
