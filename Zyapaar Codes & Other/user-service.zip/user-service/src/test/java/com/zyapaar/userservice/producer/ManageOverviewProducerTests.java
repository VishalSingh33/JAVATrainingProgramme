// package com.zyapaar.userservice.producer;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeUnit;
// import java.util.concurrent.TimeoutException;

// import com.zyapaar.serde.UserOverviewAvro;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.properties.B2bProperties.Topic;

// import org.apache.kafka.clients.producer.ProducerRecord;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.kafka.core.KafkaTemplate;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.util.concurrent.SettableListenableFuture;

// /**
//  * Manage overview producer
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class ManageOverviewProducerTests {

//   @InjectMocks
//   ManageOverviewProducer manageOverviewProducer;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   KafkaTemplate<String, UserOverviewAvro> kafkaTemplate;
//   @Mock
//   Topic topic;
//   @Mock
//   SendResult<String, UserOverviewAvro> sendResult;
//   @Mock
//   UserOverviewAvro userOverviewAvro;
//   @Mock
//   SettableListenableFuture<SendResult<String, UserOverviewAvro>> listenableFuture;

//   @Test
//   @DisplayName("produceUserOverView")
//   void produceUserOverView() throws InterruptedException, ExecutionException, TimeoutException {

//     when(userOverviewAvro.getUserId()).thenReturn("value");
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getUserOverview()).thenReturn("value");
//     when(kafkaTemplate.send(isA(ProducerRecord.class))).thenReturn(listenableFuture);

//     when(listenableFuture.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendResult);
//     SendResult<String, UserOverviewAvro> actual = manageOverviewProducer.produceUserOverView(
//         userOverviewAvro);

//     assertNotNull(actual);
//     assertEquals(sendResult, actual);
//   }

// }