// package com.zyapaar.userservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.io.IOException;
// import java.util.Set;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import javax.validation.ConstraintViolation;
// import javax.validation.Validator;

// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.userservice.dto.UserData;
// import com.zyapaar.userservice.dto.UserDetails;
// import com.zyapaar.userservice.dto.UserDto;
// import com.zyapaar.userservice.dto.UserPersonalDetails;
// import com.zyapaar.userservice.dto.UserRegistrationDto;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.service.UserService;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.web.multipart.MultipartFile;

// /**
//  * UserRegistrationController Tests class
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class UserControllerTests {

//   @InjectMocks
//   ManageUserController userController;
//   @Mock
//   UserService userService;
//   @Mock
//   UserRegistrationDto userRegistrationDto;
//   @Mock
//   UserPersonalDetails userPersonalDetails;
//   @Mock
//   MultipartFile multipartFile;
//   @Mock
//   UserData userData;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   UserDto userDto;
//   @Mock
//   UserDetails userDetails;
//   @Mock
//   Validator validator;
//   @Mock
//   Set<ConstraintViolation<UserRegistrationDto>> violations;

//   @Test
//   @DisplayName("userpersonal test")
//   void userPersonal_case() throws InterruptedException, ExecutionException, TimeoutException{

//     when(userService.getUserData(anyString(), anyString())).thenReturn(userPersonalDetails);
    
//     ResponseEntity<Response> actual = userController.userpersonal("userId","id");

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(userPersonalDetails, actual.getBody().getData());

//   }

//   @Test
//   @DisplayName("update user sucess case")
//   void updateUser_createcase() throws InterruptedException, ExecutionException, TimeoutException, 
//       IOException{

//     when(userService.updateUser(isA(UserRegistrationDto.class), anyString(), isA(MultipartFile.class)))
//         .thenReturn(true);
//     when(validator.validate(isA(UserRegistrationDto.class))).thenReturn(violations);
//     when(violations.isEmpty()).thenReturn(true);

//     ResponseEntity<Response> result = userController
//         .updateUser("123456", userRegistrationDto,  multipartFile);

//     assertNotNull(result);
//     assertEquals(HttpStatus.OK, result.getStatusCode());
//     assertEquals("user updated successfully", result.getBody().getMessage());
//   }

//   @Test
//   @DisplayName("update user failear case")
//   void updateUser_servererror() throws InterruptedException, ExecutionException, TimeoutException, 
//       IOException{

//     when(userService.updateUser(isA(UserRegistrationDto.class), anyString(), isA(MultipartFile.class)))
//         .thenReturn(false);
//     when(validator.validate(isA(UserRegistrationDto.class))).thenReturn(violations);
//     when(violations.isEmpty()).thenReturn(true);
//     ResponseEntity<Response> result = userController
//         .updateUser("123456", userRegistrationDto,  multipartFile);

//     assertNotNull(result);
//     assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
//     assertEquals("User is not updated", result.getBody().getMessage());
//   }

//   @Test
//   @DisplayName("user data test")
//   void userData() throws InterruptedException, ExecutionException, TimeoutException{
//     when(userService.getUserDataForEdit(anyString())).thenReturn(userData);

//     ResponseEntity<Response> actual = userController.userData("udarId");

//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(userData, actual.getBody().getData());
//   }

//   @Test
//   @DisplayName("getProfileViewer")
//   void getProfileViewer(){
//     when(userService.getProfileViewer(anyString(), isA(ListingRequest.class)))
//         .thenReturn(listingResponse);
    
//     ResponseEntity<Response> actual = userController.getProfileViewer("userId", listingRequest);

//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());
//   }

//   @Test
//   @DisplayName("addUser sucess")
//   void addUser_sucess() throws IOException, InterruptedException, ExecutionException, TimeoutException{

//     when(userService.addUser(isA(UserDto.class), isA(MultipartFile.class))).thenReturn(true);
    
//     ResponseEntity<Response> actual = userController.addUser(userDto, multipartFile);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.CREATED, actual.getStatusCode());
//   }

//   @Test
//   @DisplayName("addUser fail")
//   void addUser_fail() throws IOException, InterruptedException, ExecutionException, TimeoutException{

//     when(userService.addUser(isA(UserDto.class), isA(MultipartFile.class))).thenReturn(false);
    
//     ResponseEntity<Response> actual = userController.addUser(userDto, multipartFile);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual.getStatusCode());
//   }

//   @Test
//   @DisplayName("userPersonalData test")
//   void userPersonalData(){

//     when(userService.getUserPersonalData(anyString())).thenReturn(userDetails);

//     ResponseEntity<Response> actual = userController.userPersonalData("userId");
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(userDetails, actual.getBody().getData());
//   }

// }
