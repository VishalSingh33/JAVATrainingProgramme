// package com.zyapaar.userservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.JsonMappingException;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.userservice.dto.SignUpOTPDto;
// import com.zyapaar.userservice.dto.SignUpOTPVerifyDto;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.service.SignUpService;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * SignUpController Tests class
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class SignUpControllerTests {
  
//   @InjectMocks
//   SignUpController signUpController;
//   @Mock
//   SignUpService signUpService;
//   @Mock
//   Response response;
//   @Mock
//   SignUpOTPDto signUpOTPDto;
//   @Mock
//   SignUpOTPVerifyDto signUpOTPVerifyDto; 

//   @Test
//   @DisplayName("sign up otp")
//   void signupOtp() throws JsonMappingException, JsonProcessingException, 
//       InterruptedException, ExecutionException, TimeoutException {

//     when(signUpService.signupPhaseOne(isA(SignUpOTPDto.class))).thenReturn(response);
//     when(signUpOTPDto.getMobileNo()).thenReturn("value");

//     ResponseEntity<Response> result = signUpController.signupOtp(signUpOTPDto);

//     assertNotNull(result);
//     assertEquals(HttpStatus.OK, result.getStatusCode());
//   }

//   @Test
//   @DisplayName("verify sign up otp")
//   void signUpOtpVerify() throws JsonMappingException, JsonProcessingException, 
//       InterruptedException, ExecutionException, TimeoutException {

//     when(signUpService.signUpOtpVerify(isA(SignUpOTPVerifyDto.class))).thenReturn(response);
//     when(signUpOTPVerifyDto.getMobileNo()).thenReturn("value");

//     ResponseEntity<Response> result = signUpController.signupOtpVerify(signUpOTPVerifyDto);

//     assertNotNull(result);
//     assertEquals(HttpStatus.OK, result.getStatusCode());
//   }
// }
