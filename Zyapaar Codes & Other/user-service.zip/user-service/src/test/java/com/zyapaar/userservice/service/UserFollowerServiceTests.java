// package com.zyapaar.userservice.service;

// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.anyInt;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;
// import java.util.List;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.exceptionhandler.custom.OperationNotAllowedException;
// import com.zyapaar.serde.UserFollowEventAvro;
// import com.zyapaar.userservice.dao.FollowerDao;
// import com.zyapaar.userservice.dto.FollowEnum;
// import com.zyapaar.userservice.dto.UserList;
// import com.zyapaar.userservice.producer.ConnectionProducer;
// import com.zyapaar.userservice.properties.B2bProperties;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * User follower service test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class UserFollowerServiceTests {

//   @InjectMocks
//   UserFollowerService userFollowerService;
//   @Mock
//   ConnectionProducer connectionProducer;
//   @Mock
//   FollowerDao followerDao;
//   @Mock
//   List<UserList> userLists;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   ListingResponse listingResponse;

//   @Test
//   @DisplayName("follow sucess")
//   void followSucess(){

//     when(followerDao.isFollow(anyString(), anyString())).thenReturn(false);
//     doNothing().when(connectionProducer).userFollowEventProduce(isA(UserFollowEventAvro.class));

//     userFollowerService.follow("userId", "id");

//     verify(followerDao, times(1)).isFollow(anyString(), anyString());
//   }

//   @Test
//   @DisplayName("follow fail")
//   void followFail(){

//     when(followerDao.isFollow(anyString(), anyString())).thenReturn(true);

//     assertThrows(OperationNotAllowedException.class, 
//         () -> userFollowerService.follow("userId", "id"));

//   }

//   @Test
//   @DisplayName("unfollow sucess")
//   void unFollowSucess(){

//     when(followerDao.isFollow(anyString(), anyString())).thenReturn(true);
//     doNothing().when(connectionProducer).userFollowEventProduce(isA(UserFollowEventAvro.class));

//     userFollowerService.unfollow("userId", "id");

//     verify(followerDao, times(1)).isFollow(anyString(), anyString());
//   }

//   @Test
//   @DisplayName("unfollow fail")
//   void unFollowFail(){

//     when(followerDao.isFollow(anyString(), anyString())).thenReturn(false);

//     assertThrows(OperationNotAllowedException.class, 
//         () -> userFollowerService.unfollow("userId", "id"));

//   }

//   @Test
//   @DisplayName("getFollowyList")
//   void getFollowyList(){

//     when(listingRequest.getPage()).thenReturn(1);
//     when(followerDao.getFollowyList(anyString(), isA(FollowEnum.class), anyInt()))
//         .thenReturn(userLists);
    
//     ListingResponse actual = userFollowerService.getFollowyList("userId", "id", FollowEnum.FOLLOWER,
//         listingRequest);
//     assertNotNull(actual);

//   }

// }
