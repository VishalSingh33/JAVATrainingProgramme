// package com.zyapaar.userservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.Mockito.when;

// import java.util.List;

// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.userservice.dto.Country;
// import com.zyapaar.userservice.dto.Designations;
// import com.zyapaar.userservice.dto.State;
// import com.zyapaar.userservice.dto.TypeDto;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.service.DataService;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;

// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class MasterDataControllerTests {

//   @InjectMocks
//   MasterDataController masterDataController;

//   @Mock
//   DataService dataService;

//   @Mock
//   List<Country> countries;

//   @Mock
//   List<State> states;

//   @Mock
//   List<TypeDto> typeDtos;

//   @Mock
//   List<Designations> designations;

//   @Test
//   @DisplayName("get country list")
//   void getCountryList() {

//     when(dataService.getCountryList()).thenReturn(countries);

//     ResponseEntity<Response> response = masterDataController.getCountryList();

//     assertNotNull(response);
//     assertEquals(HttpStatus.OK, response.getStatusCode());
//     assertEquals(countries, response.getBody().getData());
//   }

//   @Test
//   @DisplayName("get country wise states list")
//   void getStateList(){

//     when(dataService.getStateList(anyString())).thenReturn(states);

//     ResponseEntity<Response> response = masterDataController.getStateList("countryId");
  
//     assertNotNull(response);
//     assertEquals(HttpStatus.OK, response.getStatusCode());
//     assertEquals(states, response.getBody().getData());
//   }

//   @Test
//   @DisplayName("get BusinessType list")
//   void getBusinessTypeList(){
    
//     when(dataService.getBusinessTypeList()).thenReturn(typeDtos);

//     ResponseEntity<Response> response = masterDataController.getBusinessTypeList();
  
//     assertNotNull(response);
//     assertEquals(HttpStatus.OK, response.getStatusCode());
//     assertEquals(typeDtos, response.getBody().getData());
//   }

//   @Test
//   @DisplayName("get FirmType list")
//   void getFirmTypeList(){
    
//     when(dataService.getFirmTypeList()).thenReturn(typeDtos);

//     ResponseEntity<Response> response = masterDataController.getFirmTypeList();
  
//     assertNotNull(response);
//     assertEquals(HttpStatus.OK, response.getStatusCode());
//     assertEquals(typeDtos, response.getBody().getData());
//   }

//   @Test
//   @DisplayName("get user designations test")
//   void designations(){
//     when(dataService.getDesignations()).thenReturn(designations);

//     ResponseEntity<Response> actual = masterDataController.getDesignations();
    
//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(designations, actual.getBody().getData());
//   }
// }
