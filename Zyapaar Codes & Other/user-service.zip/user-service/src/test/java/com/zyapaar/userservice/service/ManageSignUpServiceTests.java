// package com.zyapaar.userservice.service;

// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertNull;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.JsonMappingException;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.utils.TokenProvider;
// import com.zyapaar.serde.SignUpStatusAvro;
// import com.zyapaar.userservice.consumer.StateStores;
// import com.zyapaar.userservice.dao.UserDao;
// import com.zyapaar.userservice.dto.SignUpOTPDto;
// import com.zyapaar.userservice.dto.SignUpOTPVerifyDto;
// import com.zyapaar.userservice.dto.api.RequestOtpDto;
// import com.zyapaar.userservice.model.User;
// import com.zyapaar.userservice.producer.UserRegistrationProducer;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.properties.B2bProperties.Api;

// import org.junit.jupiter.api.AfterEach;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockedStatic;
// import org.mockito.Mockito;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.MediaType;
// import org.springframework.http.ReactiveHttpOutputMessage;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.web.reactive.function.BodyInserter;
// import org.springframework.web.reactive.function.BodyInserters;
// import org.springframework.web.reactive.function.client.WebClient;
// import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
// import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
// import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
// import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

// import reactor.core.publisher.Mono;

// /**
//  * ManageSignUpService Test class
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageSignUpServiceTests {

//   @InjectMocks
//   ManageSignUpService manageSignUpService;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   UserRegistrationProducer userRegistrationProducer; 
//   @Mock
//   TokenProvider tokenProvider;
//   @Mock
//   WebClient webClientMock;
//   @Mock
//   WebClient.Builder builder;
//   @Mock
//   Api api;
//   @Mock
//   RequestBodyUriSpec requestBodyUriSpec;
//   @Mock
//   RequestBodySpec requestBodySpec;
//   @Mock
//   RequestHeadersSpec requestHeadersSpec;
//   @Mock
//   ResponseSpec responseSpec;
//   @Mock
//   Mono<Response> monoResponse;
//   @Mock
//   Mono<ResponseEntity<Response>> monoResponseEntity;
//   @Mock
//   BodyInserter<RequestOtpDto, ReactiveHttpOutputMessage> bodyInserter;
//   @Mock
//   UserDao userDao;
//   @Mock
//   User user;

//   Response response;
//   RequestOtpDto requestOtpDto;
//   SignUpOTPDto signUpOTPDto;
//   SignUpOTPVerifyDto signUpOTPVerifyDto;
//   SignUpStatusAvro signUpStatusAvro;
//   MockedStatic<BodyInserters> bodyInsertersMockedStatic = Mockito.mockStatic(BodyInserters.class);

//   @AfterEach
//   void setDown(){
//     bodyInsertersMockedStatic.close();
//   }

//   @Test
//   @DisplayName("signupPhaseOne method SignUpStatusAvro status not null testing")
//   void signupPhaseOne() throws JsonMappingException, JsonProcessingException, InterruptedException, 
//       ExecutionException, TimeoutException {
    
//     signUpOTPDto = new SignUpOTPDto("8888888888");
//     response = new Response();

//     when(builder.filter(any())).thenReturn(builder);
//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getNotificationsOtp()).thenReturn("asd");
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.contentType(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.accept(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
//     bodyInsertersMockedStatic.when(() -> BodyInserters.fromValue(RequestOtpDto.class))
//         .thenReturn(bodyInserter);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.bodyToMono(Response.class)).thenReturn(monoResponse);
//     when(monoResponse.block()).thenReturn(response);
//     when(stateStores.userStatus(anyString())).thenReturn(SignUpStatusAvro.NEW);

//     Response response = manageSignUpService.signupPhaseOne(signUpOTPDto);
//     assertNotNull(response);
//     assertNotNull(response.getData());
//   }

//   @Test
//   @DisplayName("signupPhaseOne method SignUpStatusAvro status not null testing")
//   void signupPhaseOne_SignUpStatusAvro_not_null() throws JsonMappingException, JsonProcessingException, InterruptedException, 
//       ExecutionException, TimeoutException {
    
//     signUpOTPDto = new SignUpOTPDto("8888888888");
//     response = new Response();

//     when(builder.filter(any())).thenReturn(builder);
//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getNotificationsOtp()).thenReturn("asd");
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.contentType(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.accept(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
//     bodyInsertersMockedStatic.when(() -> BodyInserters.fromValue(RequestOtpDto.class))
//         .thenReturn(bodyInserter);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.bodyToMono(Response.class)).thenReturn(monoResponse);
//     when(monoResponse.block()).thenReturn(response);
//     when(stateStores.userStatus(anyString())).thenReturn(null);

//     Response response = manageSignUpService.signupPhaseOne(signUpOTPDto);
//     assertNotNull(response);
//     assertNotNull(response.getData());
//   }

//   @Test
//   @DisplayName("signUpOtpVerify for signupstatus new method testing")
//   void signUpOtpVerify_signUpStatusNew() throws JsonMappingException, JsonProcessingException,
//        InterruptedException, ExecutionException, TimeoutException {
    
//     signUpOTPVerifyDto = new SignUpOTPVerifyDto();
//     signUpOTPVerifyDto.setMobileNo("1234567890");
//     signUpOTPVerifyDto.setOtp("123456");
//     response = new Response();

//     ResponseEntity<Response> responseEntity = new ResponseEntity(null, HttpStatus.OK); 

//     when(builder.filter(any())).thenReturn(builder);
//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getNotificationsOtpVerify()).thenReturn("asd");
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.contentType(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.accept(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
//     bodyInsertersMockedStatic.when(() -> BodyInserters.fromValue(SignUpOTPVerifyDto.class))
//         .thenReturn(bodyInserter);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.toEntity(Response.class)).thenReturn(monoResponseEntity);
//     when(monoResponseEntity.block()).thenReturn(responseEntity);


//     when(stateStores.userStatus(anyString())).thenReturn(SignUpStatusAvro.NEW);

//     Response response = manageSignUpService.signUpOtpVerify(signUpOTPVerifyDto);
//     assertNotNull(response);
//     assertNotNull(response.getData());
//   }

//   @Test
//   @DisplayName("signUpOtpVerify for signupstatus PHASE1 method testing")
//   void signUpOtpVerify_signUpStatusPHASE1() throws JsonMappingException, JsonProcessingException,
//       InterruptedException, ExecutionException, TimeoutException {
    
//     signUpOTPVerifyDto = new SignUpOTPVerifyDto();
//     signUpOTPVerifyDto.setMobileNo("1234567890");
//     signUpOTPVerifyDto.setOtp("123456");
//     response = new Response();

//     ResponseEntity<Response> responseEntity = new ResponseEntity(null, HttpStatus.OK); 
//     when(builder.filter(any())).thenReturn(builder);
//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getNotificationsOtpVerify()).thenReturn("asd");
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.contentType(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.accept(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
//     bodyInsertersMockedStatic.when(() -> BodyInserters.fromValue(SignUpOTPVerifyDto.class))
//         .thenReturn(bodyInserter);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.toEntity(Response.class)).thenReturn(monoResponseEntity);
//     when(monoResponseEntity.block()).thenReturn(responseEntity);

//     when(stateStores.userStatus(anyString())).thenReturn(SignUpStatusAvro.PHASE1);
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(user.getId()).thenReturn("value");

//     Response response = manageSignUpService.signUpOtpVerify(signUpOTPVerifyDto);
//     assertNotNull(response);
//     assertNotNull(response.getData());
//   }

//   @Test
//   @DisplayName("signUpOtpVerify for not respons method testing")
//   void signUpOtpVerify_signUpStatusNotResponse() throws JsonMappingException, 
//       JsonProcessingException, InterruptedException, ExecutionException, TimeoutException {
    
//     signUpOTPVerifyDto = new SignUpOTPVerifyDto();
//     signUpOTPVerifyDto.setMobileNo("1234567890");
//     signUpOTPVerifyDto.setOtp("123456");
//     response = new Response();

//     ResponseEntity<Response> responseEntity = new ResponseEntity(null, HttpStatus.BAD_REQUEST); 
//     when(builder.filter(any())).thenReturn(builder);
//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getNotificationsOtpVerify()).thenReturn("asd");
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.contentType(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.accept(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
//     bodyInsertersMockedStatic.when(() -> BodyInserters.fromValue(SignUpOTPVerifyDto.class))
//         .thenReturn(bodyInserter);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.toEntity(Response.class)).thenReturn(monoResponseEntity);
//     when(monoResponseEntity.block()).thenReturn(responseEntity);

//     Response response = manageSignUpService.signUpOtpVerify(signUpOTPVerifyDto);
//     assertNull(response);
//   }

//   @Test
//   @DisplayName("signUpOtpVerify for signupstatus FULL method testing")
//   void signUpOtpVerify_signUpStatusFULL() throws JsonMappingException, JsonProcessingException,
//       InterruptedException, ExecutionException, TimeoutException {
    
//     signUpOTPVerifyDto = new SignUpOTPVerifyDto();
//     signUpOTPVerifyDto.setMobileNo("1234567890");
//     signUpOTPVerifyDto.setOtp("123456");
//     response = new Response();

//     ResponseEntity<Response> responseEntity = new ResponseEntity(null, HttpStatus.CREATED); 
//     when(builder.filter(any())).thenReturn(builder);
//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getNotificationsOtpVerify()).thenReturn("asd");
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.contentType(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.accept(isA(MediaType.class))).thenReturn(requestBodySpec);
//     when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
//     bodyInsertersMockedStatic.when(() -> BodyInserters.fromValue(SignUpOTPVerifyDto.class))
//         .thenReturn(bodyInserter);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.toEntity(Response.class)).thenReturn(monoResponseEntity);
//     when(monoResponseEntity.block()).thenReturn(responseEntity);

//     Response response = manageSignUpService.signUpOtpVerify(signUpOTPVerifyDto);
//     assertNull(response);
//   }
// }
