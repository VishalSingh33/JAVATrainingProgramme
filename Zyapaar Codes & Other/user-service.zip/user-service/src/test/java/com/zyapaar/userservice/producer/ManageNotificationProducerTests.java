package com.zyapaar.userservice.producer;

import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.util.concurrent.SettableListenableFuture;

import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.userservice.properties.B2bProperties;

/**
 * manage notification producer
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = { B2bProperties.class })
public class ManageNotificationProducerTests {

  @InjectMocks
  ManageNotificationProducer manageNotificationProducer;
  @Mock
  NotificationEventAvro notificationAvro;
  @Mock
  KafkaTemplate<String, NotificationEventAvro> kafkaTemplateEvent;
  @Mock
  ProducerRecord<String, NotificationEventAvro> producerRecordEvent;
  @Mock
  SettableListenableFuture<SendResult<String, NotificationEventAvro>> futureNotificationEvent;
  @Mock
  NotificationEventAvro notificationEventAvro;

  @Test
  @DisplayName("produceEmailNotification")
  void produceNotification() {

    when(notificationAvro.getId()).thenReturn("value");
    when(kafkaTemplateEvent.send(isA(ProducerRecord.class))).thenReturn(futureNotificationEvent);

    manageNotificationProducer.produceNotificationEvent(notificationAvro, "topic");

    verify(kafkaTemplateEvent, times(1)).send(isA(ProducerRecord.class));
  }

}
