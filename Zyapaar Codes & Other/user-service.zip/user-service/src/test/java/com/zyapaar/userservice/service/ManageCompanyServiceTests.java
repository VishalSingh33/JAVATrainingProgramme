// package com.zyapaar.userservice.service;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyBoolean;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;
// import java.io.IOException;
// import java.util.ArrayList;
// import java.util.Iterator;
// import java.util.List;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.response.FileUploadResponse;
// import com.zyapaar.commons.utils.TokenProvider;
// import com.zyapaar.serde.EntityRegistrationAvro;
// import com.zyapaar.serde.IndustryUsersAvro;
// import com.zyapaar.serde.ProductUsersAvro;
// import com.zyapaar.serde.UserConnectionAvro;
// import com.zyapaar.serde.UserEntryAvro;
// import com.zyapaar.serde.UserOverviewAvro;
// import com.zyapaar.serde.UserRegistrationAvro;
// import com.zyapaar.userservice.consumer.StateStores;
// import com.zyapaar.userservice.dao.CompanyInviteDao;
// import com.zyapaar.userservice.dto.EntityRegistrationDto;
// import com.zyapaar.userservice.dto.UserCompanyRegistrationDto;
// import com.zyapaar.userservice.dto.UserRegistrationDto;
// import com.zyapaar.userservice.mapper.EntityMapper;
// import com.zyapaar.userservice.mapper.UserMapper;
// import com.zyapaar.userservice.model.CompanyInvite;
// import com.zyapaar.userservice.producer.ConnectionProducer;
// import com.zyapaar.userservice.producer.NotificationProducer;
// import com.zyapaar.userservice.producer.OverviewProducer;
// import com.zyapaar.userservice.producer.UserRegistrationProducer;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.properties.B2bProperties.Api;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.web.multipart.MultipartFile;
// import org.springframework.web.reactive.function.client.WebClient;
// import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
// import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
// import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
// import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
// import reactor.core.publisher.Mono;

// /**
//  * ManageCompanyService Test class
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class ManageCompanyServiceTests {

//   @InjectMocks
//   ManageCompanyService manageCompanyService;
//   @Mock
//   UserRegistrationProducer userRegistrationProducer;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   Api api;
//   @Mock
//   UserMapper userMapper;
//   @Mock
//   EntityMapper entityMapper;
//   @Mock
//   FileUploadResponse fileUploadResponse;
//   @Mock
//   UserRegistrationAvro userRegistrationAvro;
//   @Mock
//   EntityRegistrationAvro EntityRegistrationAvro;
//   @Mock
//   WebClient webClientMock;
//   @Mock
//   WebClient.Builder builder;
//   @Mock
//   RequestBodyUriSpec requestBodyUriSpec;
//   @Mock
//   RequestBodySpec requestBodySpec;
//   @Mock
//   RequestHeadersSpec requestHeadersSpec;
//   @Mock
//   ResponseSpec responseSpec;
//   @Mock
//   Mono<FileUploadResponse> monoFileUploadResponse;
//   @Mock
//   MultipartFile multipartImage;
//   @Mock
//   TokenProvider tokenProvider;
//   @Mock
//   UserCompanyRegistrationDto userCompanyRegistrationDto;
//   @Mock
//   UserRegistrationDto userRegistrationDto;
//   @Mock
//   EntityRegistrationDto companyRegistrationDto;
//   @Mock
//   List<String> list;
//   @Mock
//   Iterator<String> iterator;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   ProductUsersAvro productUsersAvro;
//   @Mock
//   UserEntryAvro userEntryAvro;
//   @Mock
//   List<UserEntryAvro> entryAvros;
//   @Mock
//   List<CharSequence> charSequences;
//   @Mock
//   Iterator<CharSequence> iterator2;
//   @Mock
//   CompanyInviteDao companyInviteDao;
//   @Mock
//   CompanyInvite companyInvite;
//   @Mock
//   OverviewProducer overviewProducer;
//   @Mock
//   SendResult<String, UserOverviewAvro> sendResult;
//   @Mock
//   IndustryUsersAvro industryUsersAvro;
//   @Mock
//   ConnectionProducer connectionProducer;
//   @Mock
//   UserConnectionAvro userConnectionAvro;
//   @Mock
//   NotificationProducer notificationProducer;
  
//   @Test
//   @DisplayName("create company method sucess tets")
//   void createComapny() throws InterruptedException, ExecutionException, TimeoutException, IOException {

//     List<String> salesList = new ArrayList<>();
//     salesList.add("K00006822-S00000232");
//     salesList.add("K00006822-S00000232");
//     salesList.add("K00006822-S00000232");
//     List<String> buysList = new ArrayList<>();
//     buysList.add("K00006822-S00000232");
//     buysList.add("K00006822-S00000232");
//     buysList.add("K00006822-S00000232");

//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getCompanyLogoUpload()).thenReturn("value");
//     when(api.getUserProfileUpload()).thenReturn("value");
//     when(multipartImage.getOriginalFilename()).thenReturn("value");
//     when(multipartImage.getBytes()).thenReturn(new byte[] { 0 });
//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.bodyToMono(FileUploadResponse.class)).thenReturn(monoFileUploadResponse);
//     when(monoFileUploadResponse.block()).thenReturn(fileUploadResponse);
//     when(fileUploadResponse.getFileUrl()).thenReturn("value");

//     when(userCompanyRegistrationDto.getUser()).thenReturn(userRegistrationDto);
//     when(userCompanyRegistrationDto.getCompany()).thenReturn(companyRegistrationDto);

//     when(companyRegistrationDto.getDesignation()).thenReturn("value");
//     when(companyRegistrationDto.getBuys()).thenReturn(buysList);
//     when(companyRegistrationDto.getSales()).thenReturn(salesList);

//     when(userMapper.userRegistrationDtoToUserRegistrationAvro(
//         isA(UserRegistrationDto.class), anyString(), anyString(), anyString(), anyBoolean()))
//             .thenReturn(userRegistrationAvro);
//     when(entityMapper.companyRegistrationDtoToCompanyRegistrationAvro(
//         isA(EntityRegistrationDto.class), anyString(), anyString(), anyString(), anyBoolean()))
//             .thenReturn(EntityRegistrationAvro);
//     when(userRegistrationProducer.createCompany(isA(EntityRegistrationAvro.class))).thenReturn(true);
//     when(userRegistrationProducer.createUser(isA(UserRegistrationAvro.class))).thenReturn(true);
//     when(userRegistrationAvro.getId()).thenReturn("value");

//     when(productUsersAvro.getUsers()).thenReturn(entryAvros);
//     when(overviewProducer.produceUserOverView(isA(UserOverviewAvro.class))).thenReturn(sendResult);
//     when(companyInviteDao.addNewCompanyTeamMember(isA(CompanyInvite.class))).thenReturn(companyInvite);

//     when(tokenProvider.createToken(anyString(), anyString())).thenReturn("value");
//     doNothing().when(connectionProducer).userConnectionProducer(isA(UserConnectionAvro.class));

//     ResponseEntity<Response> result = manageCompanyService.createComapny(userCompanyRegistrationDto, multipartImage,
//         multipartImage, "userId");

//     assertNotNull(result);
//     assertEquals(HttpStatus.CREATED, result.getStatusCode());
//     assertEquals("Company created successfully", result.getBody().getMessage());
//     assertEquals("value", result.getBody().getData());
//   }

//   @Test
//   @DisplayName("create company method fail tets")
//   void createComapnyFailCase() throws InterruptedException, ExecutionException, TimeoutException,
//       IOException {

//     when(userCompanyRegistrationDto.getUser()).thenReturn(userRegistrationDto);
//     when(userCompanyRegistrationDto.getCompany()).thenReturn(companyRegistrationDto);
//     when(companyRegistrationDto.getDesignation()).thenReturn("value");

//     List<String> lst = new ArrayList<>();
//     lst.add("1");
//     lst.add("2");
//     lst.add("3");

//     List<CharSequence> chrLst = new ArrayList<>();
//     chrLst.add("1");
//     chrLst.add("2");
//     chrLst.add("4");
//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getCompanyLogoUpload()).thenReturn("value");
//     when(api.getUserProfileUpload()).thenReturn("value");
//     when(productUsersAvro.getUsers()).thenReturn(entryAvros);

//     when(companyRegistrationDto.getUserMobile()).thenReturn("value");
//     when(companyRegistrationDto.getDesignation()).thenReturn("value");

//     when(userMapper.userRegistrationDtoToUserRegistrationAvro(
//         isA(UserRegistrationDto.class), anyString(), anyString(), anyString(), anyBoolean()))
//             .thenReturn(userRegistrationAvro);
//     when(entityMapper.companyRegistrationDtoToCompanyRegistrationAvro(
//         isA(EntityRegistrationDto.class), anyString(), anyString(), anyString(), anyBoolean()))
//             .thenReturn(EntityRegistrationAvro);
//     when(userRegistrationProducer.createCompany(isA(EntityRegistrationAvro.class))).thenReturn(false);

//     ResponseEntity<Response> result = manageCompanyService.createComapny(userCompanyRegistrationDto, null, null,
//         "userId");

//     assertNotNull(result);
//     assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
//     assertEquals("Error during company creation", result.getBody().getMessage());
//   }

// }
