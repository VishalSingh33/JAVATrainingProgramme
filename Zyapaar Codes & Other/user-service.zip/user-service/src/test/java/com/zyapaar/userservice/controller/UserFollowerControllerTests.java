package com.zyapaar.userservice.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.userservice.dto.FollowEnum;
import com.zyapaar.userservice.properties.B2bProperties;
import com.zyapaar.userservice.service.FollowerService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;

/**
 * User follower controller test
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = { B2bProperties.class })
public class UserFollowerControllerTests {

  @InjectMocks
  ManageFollowerController userFollowerController;
  @Mock
  FollowerService followerService;
  @Mock
  ListingRequest listingRequest;
  @Mock
  ListingResponse listingResponse;

  @Test
  @DisplayName("follow")
  void follow() {

    doNothing().when(followerService).follow(anyString(), anyString());

    ResponseEntity<Response> actual = userFollowerController.follow("userId", "id");

    assertNotNull(actual);
    assertEquals(HttpStatus.OK, actual.getStatusCode());
  }

  @Test
  @DisplayName("unFollow")
  void unFollow() {

    doNothing().when(followerService).unfollow(anyString(), anyString());

    ResponseEntity<Response> actual = userFollowerController.unFollow("userId", "id");

    assertNotNull(actual);
    assertEquals(HttpStatus.OK, actual.getStatusCode());
  }

  @Test
  @DisplayName("getFollowyList")
  void getFollowyList(){

    when(followerService.getFollowyList(anyString(), anyString(), isA(FollowEnum.class), 
        isA(ListingRequest.class))).thenReturn(listingResponse);
    
    ResponseEntity<Response> actual = userFollowerController
        .getFollowyList("userId", FollowEnum.FOLLOWER, "id", listingRequest);

    assertNotNull(actual);
    assertEquals(HttpStatus.OK, actual.getStatusCode());
    assertEquals(listingResponse, actual.getBody().getData());
  }

}
