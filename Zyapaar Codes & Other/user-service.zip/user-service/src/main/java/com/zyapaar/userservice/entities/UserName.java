package com.zyapaar.userservice.entities;

import java.time.OffsetDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user_name")
public class UserName {
  
    @Id
    @NotNull
    @Column(name = "id", nullable = false, length = 19)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY,optional = true,targetEntity = UserEntity.class)   
    @PrimaryKeyJoinColumn(name = "user_id",referencedColumnName = "id")
    private UserEntity user;
    
    @Column(name = "user_name")
    private String userName; 

    @Column(name = "default_value")
    private Boolean defaultValue;

    @NotNull
	@Column(name="created_by",nullable = false,length = 19)
	private String createdBy;

	@NotNull
	@Column(name="created_on",nullable = false)
	private OffsetDateTime createdOn;

    @Column(name="updated_by")
	private String updatedBy;

	@Column(name="updated_on")
	private OffsetDateTime updatedOn;

}
