package com.zyapaar.userservice.entities;

import org.springframework.stereotype.Component;

@Component
public interface IIndustryCount {

  String getId();
  Long getCount();
  String getName();
  
}
