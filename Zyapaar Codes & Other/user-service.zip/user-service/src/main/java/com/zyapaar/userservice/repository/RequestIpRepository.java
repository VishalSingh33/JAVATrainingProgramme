package com.zyapaar.userservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.zyapaar.userservice.entities.RequestIpAddress;

@Repository
public interface RequestIpRepository extends JpaRepository<RequestIpAddress,String>{

	@Modifying
	@Query( nativeQuery = true, 
		value = "UPDATE request_ip_address"
			+" SET reference_id = :userId WHERE phone_number = :phoneNumber")
  void updateRefernceId(String userId, String phoneNumber);

}
