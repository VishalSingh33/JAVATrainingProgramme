package com.zyapaar.userservice.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SignUpOTPVerifyDto {
  
  @NotBlank(message = "Please enter OTP")
  @Pattern(regexp = "(\\d{6})", message = "Please enter valid OTP")
  String otp;

  String mobileNo;
}
