package com.zyapaar.userservice.dto;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class UserBasicDetailDto {
  
  private String id;
  private String name;
  private String img;
  private String designation;
  private String cover;

}
