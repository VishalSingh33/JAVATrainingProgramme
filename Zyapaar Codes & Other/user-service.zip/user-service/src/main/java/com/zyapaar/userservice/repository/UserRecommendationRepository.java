package com.zyapaar.userservice.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Pageable;
import com.zyapaar.userservice.entities.UserRecommendation;

@Repository
public interface UserRecommendationRepository extends JpaRepository<UserRecommendation,String> {
  
  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_recommendation WHERE from_id=:userId AND status=:status"
  ) 
  List<UserRecommendation> getRecommendPending(String userId, Pageable requestedPage,
    String status); //to,map recommendation  // PENDING

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_recommendation WHERE to_id=:userId AND status='ask'"
  ) 
  List<UserRecommendation> getRecommendAsk(String userId, Pageable requestedPage); //map msg //ASK

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_recommendation WHERE to_id=:id AND status=:status"
  )
  List<UserRecommendation> getRecommendGiven(String id, Pageable request,
    String status); //from ,map recommendation  //ACCEPT

  @Query(
  nativeQuery = true,
  value = "SELECT * FROM user_recommendation WHERE from_id=:userId AND status=:status"
  ) 
  List<UserRecommendation> getRecommendReceived(String userId, Pageable requestedPage,
      String status); //Done  //ACCEPT

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_recommendation WHERE (from_id=:id OR to_id=:id) and status=:status"
  )
  List<UserRecommendation> findByUserId(String id, String status, Pageable requestedPage);
} 
