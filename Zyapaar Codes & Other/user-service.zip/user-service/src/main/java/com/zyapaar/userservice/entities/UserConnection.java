package com.zyapaar.userservice.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.OffsetDateTime;

/**
 * The persistent class for the user_connection database table.
 * 
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="user_connection")
public class UserConnection {

    @Id
    @NotNull
    @Column(name = "id",nullable = false,length = 19)
    private String id;

    @NotNull
    @Column(name="created_by",nullable = false,length = 19)
    private String createdBy;

    @NotNull
    @Column(name="created_on",nullable = false)
    private OffsetDateTime createdOn;

    @Column(name = "status")
    private String status;

    @Column(name="updated_by",length = 19)
    private String updatedBy;

    @Column(name="updated_on")
    private OffsetDateTime updatedOn;

    @Column(name = "message")
    private String message;
    
    //bi-directional many-to-one association to User
    @ManyToOne(targetEntity = UserEntity.class, optional = true)
    @JoinColumn(name="from_user_id")
    private UserEntity user1;

    //bi-directional many-to-one association to User
    @ManyToOne(targetEntity = UserEntity.class, optional = true)
    @JoinColumn(name="to_user_id")
    private UserEntity user2;

   
}