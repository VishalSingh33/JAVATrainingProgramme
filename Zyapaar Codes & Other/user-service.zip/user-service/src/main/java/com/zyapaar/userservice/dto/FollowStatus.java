package com.zyapaar.userservice.dto;

public enum FollowStatus {
  ACTIVE,
  INACTIVE;
}
