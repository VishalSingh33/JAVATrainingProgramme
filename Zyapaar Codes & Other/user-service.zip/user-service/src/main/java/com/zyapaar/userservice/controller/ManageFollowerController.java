package com.zyapaar.userservice.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.userservice.dto.FollowEnum;
import com.zyapaar.userservice.repository.UserRepository;
import com.zyapaar.userservice.service.FollowerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * User follower controller
 * 
 * @author Uday Halpara
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class ManageFollowerController implements UserFollowerController {
  
  private final FollowerService followerService;
  private final UserRepository userRepository;

  public ResponseEntity<Response> follow(String userId, String id) {
    log.info("[follow] I {} wants to follow you {}",userId,id);
    
    followerService.follow(userId, id);
    return ResponseEntity.ok(Response.builder().message("You have successfully followed user").build());
  }

  public ResponseEntity<Response> unFollow(String userId, String id) {
    log.info("[follow] I {} wants to UnFollow you {}",userId,id);
    
    followerService.unfollow(userId, id);
    return ResponseEntity.ok(Response.builder().message("You have successfully unfollowed user").build());
  }
  
  public ResponseEntity<Response> getFollowyList(String userId, FollowEnum followType, String id, ListingRequest listingRequest) {
    log.info("[getFollowyList] follow listing {} for {}, {}", userId, followType,listingRequest);

    userRepository.findById(userId)
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId));

    ListingResponse listingResponse = followerService.getFollowyList(userId, id, followType,listingRequest);
     
    return ResponseEntity.ok(Response.builder().data(listingResponse)
      .message("Data found").build());
    
  }
}

