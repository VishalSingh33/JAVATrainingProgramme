package com.zyapaar.userservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="user_overview")
public class UserOverView {
  
  @Id
  @NotNull
  @Column(name = "id", nullable = false, length = 19)
  private String id;

  @NotNull
  @Column(name = "user_id")
  private String userId;

  @Column(name = "connections")
  private Long connections;

  @Column(name = "views")
  private Long views;

  @Column(name = "followings")
  private Long followings;

  @Column(name = "followers")
  private Long followers;

}
