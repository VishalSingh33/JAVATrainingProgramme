package com.zyapaar.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * notification model
 * 
 * @author Uday Halpara
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Notification {

  private String id;
  private Activity activity;
  private Object content;
  private Long createdOn;
  private String userId;
  private String ageOfNotification;

}
