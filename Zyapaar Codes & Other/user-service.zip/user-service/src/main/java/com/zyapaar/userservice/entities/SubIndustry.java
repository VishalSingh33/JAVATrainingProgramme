package com.zyapaar.userservice.entities;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.OffsetDateTime;
import java.util.List;

@Entity
@Table(name = "sub_industry")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubIndustry {

    @Id
    @NotNull
    @Column(name = "id", nullable = false, length = 19)
    private String id;

    //bi-directional many-to-one association to Product
    @ManyToOne(fetch = FetchType.LAZY,optional = true,targetEntity = Product.class)
    @PrimaryKeyJoinColumn(name = "product_id",referencedColumnName = "id")
    private Product product;

    @Column(name = "name")
    private String name;

    @NotNull
    @Column(name = "created_on", nullable = false)
    private OffsetDateTime createdOn;

    @NotNull
    @Column(name = "created_by", nullable = false, length = 19)
    private String createdBy;

    @Column(name = "updated_on")
    private OffsetDateTime updatedOn;

    @Column(name = "updated_by", length = 19)
    private String updatedBy;

    //bi-directional many-to-one association to Keyword
    @OneToMany(targetEntity=Keyword.class, mappedBy="subIndustry", fetch=FetchType.LAZY,
        cascade = {CascadeType.PERSIST,CascadeType.MERGE})
    private List<Keyword> keyword;

   
}
