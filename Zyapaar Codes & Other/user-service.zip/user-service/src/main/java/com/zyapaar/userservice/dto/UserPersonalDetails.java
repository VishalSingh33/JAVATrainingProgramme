package com.zyapaar.userservice.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * User personal details
 * 
 * @author Uday Halpara
 * @author Shreya Shah
 * @author Neel Shah
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserPersonalDetails {

  private String id; //user,entity,connection,follower
  private String name;
  private String firstName;
  private String lastName;
  private String profileTitle;
  private String profileImg;
  private String aboutUs;
  private String emailId;
  private String mobileNo;
  private String entityName;  
  private List<String> companies; 
  private Boolean isConnected; 
  private UserProfileConnectionStatus connectionStatus;  //new added
  private String requestId;  //new
  private Boolean isRequested;
  private Boolean isFollowing;
  private Boolean isLocked;  //public/private
  private Long followingCount; 
  private Long followerCount; 
  private Long connection; //users count
  private Boolean isHide;
  private String cover;
  private String userName;
  private Boolean isBlocked;

}
