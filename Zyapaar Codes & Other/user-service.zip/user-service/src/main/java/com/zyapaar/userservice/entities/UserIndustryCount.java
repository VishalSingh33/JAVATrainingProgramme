package com.zyapaar.userservice.entities;

import java.util.Map;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import com.vladmihalcea.hibernate.type.json.JsonType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "industry_wise_connecion_count")
@TypeDef(name = "map", typeClass = JsonType.class)
public class UserIndustryCount {
  
  @Id
  private String id;
  
  @Column(name = "industry_count", columnDefinition = "text[]")
  @Type(type = "map")
  private Map<String, IndustryCount> industryCount;
}
