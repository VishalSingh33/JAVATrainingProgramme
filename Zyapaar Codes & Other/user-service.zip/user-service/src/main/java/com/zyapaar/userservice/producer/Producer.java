package com.zyapaar.userservice.producer;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
// import org.springframework.kafka.support.SendResult;
// import com.zyapaar.serde.SignUpPhaseOneAvro;
// import com.zyapaar.serde.SignUpStatusAvro;
// import com.zyapaar.userservice.dto.SignUpOTPDto;

/**
 * It is used for the kafka producer
 * 
 * @author CHiRAG RATHOD
 */
public interface Producer {

  // SendResult<String, SignUpPhaseOneAvro> signupPhaseOne(
  //     SignUpOTPDto signUpPhaseOneDto, SignUpStatusAvro signUpStatusAvro)
  //     throws InterruptedException, ExecutionException, TimeoutException;

  void updateMobileNo(String mobileNo, String mobileNo2, String status) 
    throws InterruptedException, ExecutionException, TimeoutException;

}
