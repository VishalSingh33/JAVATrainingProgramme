package com.zyapaar.userservice.entities;

import java.time.OffsetDateTime;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import com.vladmihalcea.hibernate.type.array.ListArrayType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity                             
@Table(name = "user_industry")
@TypeDef(name = "list-array",typeClass = ListArrayType.class)  //add onetomanny in userentity
public class UserIndustry{

  @Id
  @NotNull
  @Column(name = "id", nullable = false, length = 19)
  private String id;

  @ManyToOne(targetEntity = UserEntity.class,optional = true) 
	@JoinColumn(name="user_id")
	private UserEntity user;
  
  @NotNull
  @Column(name = "created_on", nullable = false)
  private OffsetDateTime createdOn;

  @Column(name = "updated_on")
  private OffsetDateTime updatedOn;

  @NotNull
  @Column(name = "created_by", nullable = false, length = 19)
  private String createdBy;

  @Column(name = "updated_by", length = 19)
  private String updatedBy;

  @Column(name = "keyword_buys_id",columnDefinition = "text[]")
  @Type(type = "list-array")
  private List<String> keywordBuys;  

  @NotNull
  @Column(name = "keyword_sells_id",columnDefinition = "text[]")
  @Type(type = "list-array")
  private List<String> keywordSells; 

  @NotNull
  @Type(type = "list-array")
  @Column(name = "keyword_buys_sells_id",columnDefinition = "text[]")
  private List<String> keywordBuysSells;
}
