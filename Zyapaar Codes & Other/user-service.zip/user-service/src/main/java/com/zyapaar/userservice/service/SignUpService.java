// package com.zyapaar.userservice.service;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;
// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.JsonMappingException;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.userservice.dto.SignUpOTPDto;
// import com.zyapaar.userservice.dto.SignUpOTPVerifyDto;

// public interface SignUpService {

//   Response signupPhaseOne(SignUpOTPDto signUpPhaseOneDto)
//       throws InterruptedException, ExecutionException, TimeoutException, JsonMappingException, JsonProcessingException;

//   Response signUpOtpVerify(SignUpOTPVerifyDto otpVerifyDto)
//       throws InterruptedException, ExecutionException, TimeoutException;

// }
