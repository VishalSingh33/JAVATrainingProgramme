package com.zyapaar.userservice.mapper;

import java.time.OffsetDateTime;
import java.util.List;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.NullValueCheckStrategy;
import com.zyapaar.userservice.dto.CreateConnectionRequestDto;
import com.zyapaar.userservice.dto.ConnectionRequestListingDto;
import com.zyapaar.userservice.dto.ConnectionStatus;
import com.zyapaar.userservice.dto.UserList;
import com.zyapaar.userservice.dto.UserPersonalDto;
import com.zyapaar.userservice.entities.UserConnection;
import com.zyapaar.userservice.entities.UserEntity;

@Mapper
public interface UserConnectionMapper {

  @Mapping(target = "id",source = "id")
  @Mapping(target = "createdBy",source = "userId")
  @Mapping(target = "createdOn",source = "offsetDateTime")
  @Mapping(target = "status",source = "status")     //INITIATE
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "updatedOn",source = "offsetDateTime")
  @Mapping(target = "message",source = "connectionDto.message",nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "user1",source = "userEntityExistsFrom") //FROM
  @Mapping(target = "user2",source = "userEntityExistsTo") //TO
  UserConnection toUserConnectionFromConnectionDto(String id, OffsetDateTime offsetDateTime,
      String userId, String toUserId, CreateConnectionRequestDto connectionDto,
      UserEntity userEntityExistsFrom, UserEntity userEntityExistsTo, String status);
     
  @Mapping(target = "id",source = "userConnection.id")
  @Mapping(target = "createdBy",source = "userConnection.createdBy")
  @Mapping(target = "createdOn",source = "userConnection.createdOn")
  @Mapping(target = "status",source = "status")
  @Mapping(target = "updatedBy",source = "fromUserId") 
  @Mapping(target = "updatedOn",source = "offsetDateTime") 
  @Mapping(target = "message",source = "userConnection.message")
  @Mapping(target = "user1",source = "userConnection.user1")
  @Mapping(target = "user2",source = "userConnection.user2")
  UserConnection toUserConnectionFromOldData(UserConnection userConnection, OffsetDateTime offsetDateTime,
     String fromUserId, String status);
//used in accept and remove connection

  @Mapping(target = "userProfile", source = "personalDto.profileImg")
  @Mapping(target = "userDesignation", source = "personalDto.profileTitle")
  @Mapping(target = "userName", source = "personalDto.name")
  @Mapping(target = "id", source = "userConnection.id")
  @Mapping(target = "message", source = "userConnection.message", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "status",source = "userConnection.status")
  @Mapping(target = "createdOn",source = "userConnection.createdOn")
  @Mapping(target = "updatedOn",source = "userConnection.updatedOn")
  @Mapping(target = "ageOfRequest",source = "ageOfRequest")
  @Mapping(target = "toUserId",source = "userId")
  @Mapping(target = "fromUserId",source = "personalDto.id")
  ConnectionRequestListingDto toConnectionRequestListingDtoReceivedList(UserConnection userConnection, 
    UserPersonalDto personalDto, String ageOfRequest,String userId);

  @Mapping(target = "id",source = "userConnection.id")
  @Mapping(target = "fromUserId",source = "userId")
  @Mapping(target = "toUserId",source = "personalDto.id") // check
  @Mapping(target = "status",source = "userConnection.status") 
  @Mapping(target = "message",source = "userConnection.message",nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "ageOfRequest",source = "ageOfRequest")
  @Mapping(target = "createdOn",source = "userConnection.createdOn")
  @Mapping(target = "updatedOn",source = "userConnection.updatedOn")
  @Mapping(target = "userProfile",source = "personalDto.profileImg")
  @Mapping(target = "userName",source = "personalDto.name")
  @Mapping(target = "userDesignation",source = "personalDto.profileTitle")
  ConnectionRequestListingDto toConnectionRequestListingDtoSentList(UserConnection userConnection,
    UserPersonalDto personalDto, String ageOfRequest, String userId);

  @Mapping(target = "id",source = "users.id")
  @Mapping(target = "name",source = "users.fullName")
  @Mapping(target = "img",source = "users.img")
  @Mapping(target = "designation",source = "users.title")
  @Named("toUserListDto")
  UserList FromUserEntityToUserListDto(UserEntity users);

  @IterableMapping(qualifiedByName = "toUserListDto")
  List<UserList> FromUserEntityToUserListDto(List<UserEntity> users);

  @Mapping(target = "id",source = "u.id")
  @Mapping(target = "name",source = "u.fullName")
  @Mapping(target = "img",source = "u.img")
  @Mapping(target = "designation",source = "u.title")
  @Named("userdata")
  UserList toUserListDto(UserEntity u);

  @IterableMapping(qualifiedByName = "userdata")
  List<UserList> toUserListDto(List<UserEntity> u); //getUserwiseIndustryList

  default String map(ConnectionStatus value) {
    return value.connectionStatus();
  }

}
  

  
  // @Mapping(target = "userProfile", source = "userPersonalDto.profileImg")
  // @Mapping(target = "userDesignation", source = "userPersonalDto.profileTitle")
  // @Mapping(target = "userName", source = "userPersonalDto.name")
  // @Mapping(target = "id", source = "userConnection.id")
  // @Mapping(target = "message", source = "userConnection.message", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // ConnectionRequestListingDto toConnectionRequestListingDto(UserConnectionRequest userConnection,
  //     UserPersonalDto userPersonalDto, String ageOfRequest);

