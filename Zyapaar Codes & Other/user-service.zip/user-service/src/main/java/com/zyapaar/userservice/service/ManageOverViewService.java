package com.zyapaar.userservice.service;

import org.springframework.stereotype.Service;
import com.zyapaar.userservice.dto.UserOverViewDto;
import com.zyapaar.userservice.entities.UserOverView;
import com.zyapaar.userservice.mapper.UserOverViewMapper;
import com.zyapaar.userservice.repository.UserOverViewRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Manage over view service
 * 
 * @author Uday Halpara
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageOverViewService implements OverViewService {

  private final UserOverViewMapper userOverViewMapper;
  private final UserOverViewRepository userOverViewRepository;

  @Override
  public UserOverViewDto getUserOverView(String userId) {

    log.info("[getUserOverView] get user over view data by userId : {}", userId);

    UserOverView userOverView = userOverViewRepository.findByUserId(userId);

    return userOverViewMapper.toUserOverViewData(userOverView);
  }

}
