package com.zyapaar.userservice.entities;

import java.time.OffsetDateTime;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import com.vladmihalcea.hibernate.type.array.ListArrayType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@Table(name="user_wise_connection")
@TypeDef(
  name = "list-array",
  typeClass = ListArrayType.class
)
public class UserWiseConnection {
  
  @Id
  private String id;
  
  @Column(name = "user_ids", columnDefinition = "text[]")
  @Type(type = "list-array")
  private List<String> userIds;

  @Column(name="created_by")
  private String createdBy;

  @Column(name="created_on")
  private OffsetDateTime createdOn;
  
  @Column(name="updated_by")
  private String updatedBy;

  @Column(name="updated_on")
  private OffsetDateTime updatedOn;
  
}
