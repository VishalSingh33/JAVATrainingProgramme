package com.zyapaar.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Industry list dto
 * 
 * @author Uday Halpara
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IndustriesData {
  
  private String subIndustryID;   //Changed,before subindustryID
  private String subIndustry;   //changed before Capital 'S'

}

