// package com.zyapaar.userservice.service;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;
// import com.zyapaar.exceptionhandler.custom.BadRequestException;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.MediaType;
// import org.springframework.http.ResponseEntity;
// import org.springframework.stereotype.Service;
// import org.springframework.util.ObjectUtils;
// import org.springframework.web.reactive.function.BodyInserters;
// import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
// import org.springframework.web.reactive.function.client.WebClient;
// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.JsonMappingException;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.utils.TokenProvider;
// import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
// import com.zyapaar.serde.SignUpStatusAvro;
// import com.zyapaar.userservice.dto.ResponseDto;
// import com.zyapaar.userservice.dto.Roles;
// import com.zyapaar.userservice.dto.SignOtpResponseDto;
// import com.zyapaar.userservice.dto.SignUpOTPDto;
// import com.zyapaar.userservice.dto.SignUpOTPVerifyDto;
// import com.zyapaar.userservice.dto.UserBasicDetailDto;
// import com.zyapaar.userservice.dto.api.RequestOtpDto;
// import com.zyapaar.userservice.entities.UserEntity;
// import com.zyapaar.userservice.producer.Producer;
// import com.zyapaar.userservice.properties.B2bProperties;
// import com.zyapaar.userservice.repository.SignupStatusRepository;
// import com.zyapaar.userservice.repository.UserRepository;
// import lombok.RequiredArgsConstructor;
// import lombok.extern.slf4j.Slf4j;
// import reactor.core.publisher.Mono;

// /**
//  * It is used to manage the user data
//  * 
//  * @author CHiRAG RATHOD
//  */
// @Slf4j
// @Service
// @RequiredArgsConstructor
// public class ManageSignUpService implements SignUpService {
  
//   private final B2bProperties b2bProperties;
//   private final TokenProvider tokenProvider;
//   private final WebClient.Builder webClientBuilder;
//   private final UserRepository userRepository;
//   private final Producer producer;
//   private final SignupStatusRepository signupStatusRepository;

//   @Override
//   public Response signupPhaseOne(SignUpOTPDto signUpPhaseOneDto)
//       throws InterruptedException, ExecutionException, TimeoutException, JsonMappingException, JsonProcessingException {
    
//     log.info("[signupPhaseOne] send OTP to respected user");
    
//     Response response = webClientBuilder
//         .filter(logRequest())
//         .build()
//         .post()
//         .uri(b2bProperties.getApi().getNotificationsOtp())
//         .contentType(MediaType.APPLICATION_JSON)
//         .accept(MediaType.APPLICATION_JSON)
//         .header("Z-AUTH-USERID", signUpPhaseOneDto.getMobileNo())
//         .body(BodyInserters.fromValue(new RequestOtpDto(signUpPhaseOneDto.getMobileNo())))
//         .retrieve()
//         // .onStatus(Predicate.not(HttpStatus::is2xxSuccessful), clientResponse -> { 
//         //   return clientResponse.createException().flatMap(Mono::error);
//         // })
//         .bodyToMono(Response.class)
//         .block();

//     log.info("[signupPhaseOne] Response of the created OTP request: {}", response);

//     //SignUpStatusAvro is enum.
//     String status = signupStatusRepository.findByMobileNo(signUpPhaseOneDto.getMobileNo())
//       .orElse(null);

//     log.info("[signupPhaseOne] user status : {}", status);
    
//     if(status == null || SignUpStatusAvro.DEACTIVATE.toString().equalsIgnoreCase(status)) {
//       producer.signupPhaseOne(signUpPhaseOneDto, SignUpStatusAvro.NEW);
//     } 

//     response.setData(new SignOtpResponseDto(signUpPhaseOneDto.getMobileNo()));
//     return response;
//   }

//   @Override
//   public Response signUpOtpVerify(SignUpOTPVerifyDto otpVerifyDto) 
//       throws InterruptedException, ExecutionException, TimeoutException {
    
//     log.info("[signUpOtpVerify] verify the requested OTP");

//     ResponseEntity<Response> response = webClientBuilder
//         .filter(logRequest())
//         .build()
//         .post()
//         .uri(b2bProperties.getApi().getNotificationsOtpVerify())
//         .contentType(MediaType.APPLICATION_JSON)
//         .accept(MediaType.APPLICATION_JSON)
//         .header("Z-AUTH-USERID", otpVerifyDto.getMobileNo())
//         .body(BodyInserters.fromValue(otpVerifyDto))
//         .retrieve()
//         .toEntity(Response.class).block();

//     log.info("[signUpOtpVerify] Response of the verified OTP request: {}", response);
    
//     if(!HttpStatus.OK.equals(response.getStatusCode()))
//       return null;

//     log.info("[signUpOtpVerify] OTP verification successfully");
//     String status = signupStatusRepository.findByMobileNo(otpVerifyDto.getMobileNo())
//       .orElseThrow(() -> new ResourceNotFoundException("user", "mobile no", otpVerifyDto.getMobileNo()));

//     ResponseDto responseDto = null;

//     log.info("[signUpOtpVerify] check user registration status: {}", status);

//     if(SignUpStatusAvro.NEW.toString().equals(status) || SignUpStatusAvro.SIGNUP.toString().equals(status)) {
//       if(SignUpStatusAvro.NEW.toString().equals(status)) {
//         status = SignUpStatusAvro.SIGNUP.name().toString();
//         producer.signupPhaseOne(new SignUpOTPDto(otpVerifyDto.getMobileNo()), SignUpStatusAvro.SIGNUP); 
//       }
      
//       responseDto = phaseOneToken(otpVerifyDto.getMobileNo(), Roles.ROLE_SIGNUP, status, null);
//     } else {
//       UserEntity user = userRepository.findByMobileNumber(otpVerifyDto.getMobileNo());

//       if(ObjectUtils.isEmpty(user)) {
//         log.info("[signUpOtpVerify] User is not found with mobile no : {}", otpVerifyDto.getMobileNo());
//         throw new BadRequestException("Invalid user found");
//       }

//       responseDto = phaseOneToken(user.getId(), Roles.ROLE_USER, status, user);
//     }

//     return Response.builder().data(responseDto).build();
//   }

//   private ResponseDto phaseOneToken(String userId, Roles roleSignup, String status, UserEntity user) {
//     log.info("[phaseOneToken] to phase one token");
    
//     String token = tokenProvider.createToken(userId, roleSignup.role());

//     UserBasicDetailDto dto = null;

//     if(!ObjectUtils.isEmpty(user)) {
//       dto = UserBasicDetailDto.builder().id(user.getId()).name(user.getFullName()).build();
//     }

//     return ResponseDto.builder()
//       .token(token)
//       .flag(status)
//       .createUser(true)
//       .user(dto)
//       .build();
//   }

//   private static ExchangeFilterFunction logRequest() {
//     return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
//         log.info("[ExchangeFilterFunction] request info method");
//         log.info("Request: {} {} {}", clientRequest.method(), 
//         clientRequest.url(), clientRequest.body());

//         clientRequest.headers().forEach(
//           (name, values) -> values.forEach(value -> log.info("{}={}", name, value)));
//         return Mono.just(clientRequest);
//     });
//   }
// }
