package com.zyapaar.userservice.dto;

import javax.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SignUpOTPDto {

  @Pattern(
    regexp = "^([9876]{1})(\\d{1})(\\d{8})",
    message = "Please Enter Valid Mobile Number"
  )
  private String mobileNo;
}
