package com.zyapaar.userservice.dto;

import org.springframework.stereotype.Component;

@Component
public interface IProfileViewerResponse {
  
  String getId();
  String getName();
  String getDesignation();
  String getImg();
  String getCover();
}
