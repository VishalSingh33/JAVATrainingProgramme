package com.zyapaar.userservice.service;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.serde.SignUpStatusAvro;
import com.zyapaar.userservice.dto.MigrationUser;
import com.zyapaar.userservice.dto.NotificationSettingDto;
import com.zyapaar.userservice.dto.RequestStatus;
import com.zyapaar.userservice.entities.Country;
import com.zyapaar.userservice.entities.Entities;
import com.zyapaar.userservice.entities.EntityInvite;
import com.zyapaar.userservice.entities.NotificationSetting;
import com.zyapaar.userservice.entities.SignupStatus;
import com.zyapaar.userservice.entities.StateEntity;
import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserFollower;
import com.zyapaar.userservice.entities.UserIndustry;
import com.zyapaar.userservice.entities.UserOverView;
import com.zyapaar.userservice.entities.UserWiseConnection;
import com.zyapaar.userservice.mapper.MigrationMapper;
import com.zyapaar.userservice.mapper.NotificationSettingMapper;
import com.zyapaar.userservice.mapper.UserFollowerMapper;
import com.zyapaar.userservice.mapper.UserIndustryMapper;
import com.zyapaar.userservice.mapper.UserOverViewMapper;
import com.zyapaar.userservice.repository.CompanyInviteRepository;
import com.zyapaar.userservice.repository.CompanyRepository;
import com.zyapaar.userservice.repository.CountryRepository;
import com.zyapaar.userservice.repository.NotificationSettingRepository;
import com.zyapaar.userservice.repository.SignupStatusRepository;
import com.zyapaar.userservice.repository.StateRepository;
import com.zyapaar.userservice.repository.UserFollowerRepository;
import com.zyapaar.userservice.repository.UserIndustryRepository;
import com.zyapaar.userservice.repository.UserOverViewRepository;
import com.zyapaar.userservice.repository.UserRepository;
import com.zyapaar.userservice.repository.UserWiseConnectionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class ManageMigrationUserService implements MigrationUserService {

  private final MigrationMapper migrationMapper;
  private final UserIndustryMapper userIndustryMapper;
  private final UserIndustryRepository userIndustryRepository;
  private final SignupStatusRepository signupStatusRepository;
  private final NotificationSettingRepository notificationSettingsRepository;
  private final NotificationSettingMapper notificationSettingMapper;
  private final UserOverViewMapper userOverViewMapper;
  private final UserOverViewRepository userOverViewRepository;
  private final UserWiseConnectionRepository userWiseConnectionRepository;
  private final UserRepository userRepository;
  private final StateRepository stateRepository;
  private final CountryRepository countryRepository;
  private final CompanyRepository companyRepository;
  private final CompanyInviteRepository companyInviteRepository;
  private final UserFollowerMapper userFollowerMapper;
  private final UserFollowerRepository userFollowerRepository;

  @Override
  @Transactional(rollbackFor = Exception.class)
  public void migrationCreateUser(MigrationUser migrationUser) {

    OffsetDateTime offsetDateTime = new Date().toInstant().atOffset(ZoneOffset.UTC);

    String userId = migrationUser.getUserId();
    UserEntity userEntity = migrationMapper.updateUser(migrationUser, offsetDateTime);

    Set<String> sellsList = migrationUser.getSales();
    Set<String> allIdsOfSells =
        sellsList.stream().map(entry -> entry.split("-")[1]).collect(Collectors.toSet());

    Set<String> buysList = migrationUser.getBuys();
    Set<String> allIdsOfBuys = Collections.emptySet();
    if (!Objects.isNull(buysList)) {
      allIdsOfBuys =
          buysList.stream().map(entry -> entry.split("-")[1]).collect(Collectors.toSet());
    }

    Set<String> allIdsOfBuysSells = addTwoSets(allIdsOfBuys, allIdsOfSells);

    UserIndustry userIndustry = userIndustryMapper.toUserIndustryFromRegistrationDtoMigration(
        SequenceGenerator.getInstance().nextId(), offsetDateTime, userEntity, userEntity.getId(),
        allIdsOfSells, allIdsOfBuys, allIdsOfBuysSells);

    SignupStatus signupStatus = new SignupStatus();
    signupStatus.setMobileNo(migrationUser.getMobileNo());
    signupStatus.setStatus(SignUpStatusAvro.FULL.toString());
    log.info("[createUser] Status updated successfully to 'REG' in SignupStatus");

    UserFollower userFollower = userFollowerMapper.toUserFollowerFromUser(userId,offsetDateTime,0L);
   
    NotificationSettingDto notificationSettingDto = NotificationSettingDto.builder()
        .commentEmail(true)
        .commentMentionEmail(true)
        .commentMentionPush(true)
        .commentPush(true)
        .commentReactionEmail(true)
        .commentReactionPush(true)
        .commentReplyEmail(true)
        .commentReplyPush(true)
        .connectionEmail(true)
        .connectionPush(true)
        .groupEmail(true)
        .groupPush(true)
        .isEmailVerified(false) ///
        .messageEmail(true)
        .messagePush(true)
        .networkProfile("1")
        .pageEmail(true)
        .pagePush(true)
        .postDelivery("1")
        .postMentionEmail(true)
        .postMentionPush(true)
        .postReactionEmail(true)
        .postReactionPush(true)
        .postShareEmail(true)
        .postSharePush(true)
        .profileViewEmail(true)
        .profileViewPush(true)
        .recommendationEmail(true)
        .recommendationPush(true)
        .teamEmail(true)
        .teamPush(true).build();

    NotificationSetting notificationSetting = notificationSettingMapper
        .toNotificationSettingFromUser(notificationSettingDto, migrationUser.getEmailId(), userId);

    UserOverView userOverView = userOverViewMapper
        .toUserOverViewFromUserEntity(SequenceGenerator.getInstance().nextId(), userId, 0L);

    UserWiseConnection userWiseConnection =
        UserWiseConnection.builder().id(userEntity.getId()).userIds(Collections.emptyList())
            .createdOn(offsetDateTime).createdBy(userEntity.getId())
            .updatedBy(userEntity.getId()).updatedOn(offsetDateTime).build();

    Country country = getCountry(migrationUser.getCountry()); // id

    StateEntity state = null;
    if (!ObjectUtils.isEmpty(migrationUser.getState()))
      state = getStates(migrationUser.getState());

    Entities entities = migrationMapper.toEntities(migrationUser, migrationUser.getCompanyId(), userEntity, offsetDateTime, userId, country,
      state, buysList, sellsList);  //K-s

    EntityInvite entityInvite = migrationMapper.toEntityInvite(migrationUser, userEntity, offsetDateTime, entities, 
      RequestStatus.ACCEPT.status(),true, userId);
    log.info("Data saved in EntityInvite: {}", entityInvite);

    try {
      userRepository.save(userEntity);
      userIndustryRepository.save(userIndustry);
      signupStatusRepository.save(signupStatus);
      notificationSettingsRepository.save(notificationSetting);
      userOverViewRepository.save(userOverView);
      userWiseConnectionRepository.save(userWiseConnection);
      companyRepository.save(entities);
      companyInviteRepository.save(entityInvite);
      userFollowerRepository.save(userFollower);

      // return phaseOneToken(userId, Roles.ROLE_USER, signupStatus.getStatus(), userEntity);
    } catch (Exception exception) {
      log.info("[migrationCreateUser] DTO: {}", migrationUser);
      throw new BadRequestException("Error occured while saving User data", exception);
    }
  }

  public static Set<String> addTwoSets(Set<String> allIdsOfBuys, Set<String> allIdsOfSells) {
    Set<String> allIdsOfBuysSells = new HashSet<String>(allIdsOfSells);
    if (!ObjectUtils.isEmpty(allIdsOfBuys))
      allIdsOfBuysSells.addAll(allIdsOfBuys);
    return allIdsOfBuysSells;
  }


  private StateEntity getStates(String stateId) {
    return stateRepository.findById(stateId)
      .orElseThrow(() -> new ResourceNotFoundException("state", "id", stateId));
  }

  private Country getCountry(String countryId) {
    Country country = countryRepository.findById(countryId)
      .orElseThrow(() -> new ResourceNotFoundException("country", "id", countryId));
    return country;
  }

}
