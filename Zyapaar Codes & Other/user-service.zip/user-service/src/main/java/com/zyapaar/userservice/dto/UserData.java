package com.zyapaar.userservice.dto;

import lombok.Data;

/**
 * User data model
 * 
 * @author Uday Halpara
 */
@Data
public class UserData {
  
  private String id;
  private String firstName;
  private String lastName;
  private String profileTitle;
  private String profileImg;
  private String aboutUs;
  private String emailId;
  private String mobileNo;
}
