package com.zyapaar.userservice.mapper;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.springframework.util.ObjectUtils;
import com.zyapaar.userservice.dto.RegistrationDto;
import com.zyapaar.userservice.dto.UserBasicDetailDto;
import com.zyapaar.userservice.dto.UserData;
import com.zyapaar.userservice.dto.UserDetails;
import com.zyapaar.userservice.dto.UserList;
import com.zyapaar.userservice.dto.UserPersonalDetails;
import com.zyapaar.userservice.dto.UserPersonalDto;
import com.zyapaar.userservice.dto.UserRegistrationDto;
import com.zyapaar.userservice.entities.Entities;
import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserFollower;
import com.zyapaar.userservice.entities.UserName;

@Mapper
public interface UserMapper {
  
  @Mapping(target = "profileImg", source = "details.profileImg", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "emailId", source = "details.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  UserDetails toUserDetails(UserPersonalDetails details);

  @Mapping(target = "id",source = "userEntity.id")
  @Mapping(target = "emailId", source = "userEntity.emailId")	
  @Mapping(target = "name", source = "userEntity.fullName")
  @Mapping(target = "profileTitle", source = "userEntity.title")
  @Mapping(target = "profileImg", source = "userEntity.img")
  @Mapping(target = "entityId", source = "user.id")
  @Mapping(target = "entityName", source = "user.name")
  @Mapping(target = "cover",source = "userEntity.cover")
  UserDetails toUserDetails(UserEntity userEntity, Entities user);


  @Mapping(target = "id", source = "u.id")
  @Mapping(target = "name", source = "u.fullName")
  @Mapping(target = "emailId", source = "u.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "profileTitle", source = "u.title")
  @Mapping(target = "profileImg", source = "u.img")
  @Mapping(target = "aboutUs", source = "u.aboutUs")
  @Mapping(target = "mobileNo", source = "u.mobileNo")
  UserPersonalDto userToUserPersonalDto(UserEntity u); //FromUser

  @Mapping(target = "id", source = "user.id")
  @Mapping(target = "emailId", source = "user.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "name", source = "user.fullName")
  @Mapping(target = "profileTitle", source = "user.title") //added
  @Mapping(target = "profileImg", source = "user.img") //added
  @Mapping(target = "entityName", expression = "java(getEntityName(entities))")
  @Mapping(target = "connection", source = "connectionCount")
  @Mapping(target = "followingCount", source = "followings")
  @Mapping(target = "followerCount", source = "followers")
  UserPersonalDetails userToUserPersonalDetails(UserEntity user, Entities entities, Long connectionCount, Long followers, Long followings); 
   //aboutUs,id,isHide,mobileNo are auto set//

  default String getEntityName(Entities entities) {
    if(!ObjectUtils.isEmpty(entities))
      return entities.getName();
    
    return null;
  }


  void updateUserPersonalDetails(UserFollower userFollower,@MappingTarget UserPersonalDetails details);

  @Mapping(target = "entityName", ignore = true)
  @Mapping(target = "aboutUs", ignore = true)
  @Mapping(target = "emailId", ignore = true)
  @Mapping(target = "mobileNo", ignore = true)
  @Mapping(source = "user.fullName", target = "name")
  @Mapping(target = "isHide", source = "isHide")
  @Mapping(target = "isFollowing",constant = "false") 
  @Mapping(target = "profileImg",source = "user.img")
  @Mapping(target = "profileTitle",source = "user.title")
  @Mapping(target = "cover",source = "user.cover")
  UserPersonalDetails userToUserPersonalLockedDetails(UserEntity user, boolean isHide);


  @Mapping(target = "emailId", source = "user.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "id", source = "user.id",nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS) //extra
  @Mapping(target = "firstName", source = "user.firstName")
  @Mapping(target = "lastName", source = "user.lastName")
  @Mapping(target = "profileTitle", source = "user.title")
  @Mapping(target = "profileImg", source = "user.img")
  @Mapping(target = "aboutUs", source = "user.aboutUs")
  @Mapping(target = "mobileNo", source = "user.mobileNo")
  UserData userToUserData(UserEntity user);

  @Mapping(target = "id", source = "userEntity.id")
  @Mapping(target = "name", source = "userEntity.fullName")
  @Mapping(target = "profileTitle", source = "userEntity.title")
  @Mapping(target = "profileImg", source = "userEntity.img")
  @Mapping(target = "aboutUs", source = "userEntity.aboutUs")
  @Mapping(target = "emailId", source = "userEntity.emailId")
  @Mapping(target = "mobileNo", source = "userEntity.mobileNo")
  @Mapping(target = "entityName", source = "entities.name")  //open
  //isConnected,requested,following & locked are null if user want to view itself
  @Mapping(target = "followingCount", expression = "java(getCount(followerCount, true))")
  @Mapping(target = "followerCount", expression = "java(getCount(followerCount, false))")
  @Mapping(target = "isHide", source = "userEntity.isHide")
  @Mapping(target = "companies", expression = "java(getEntities(entities))")
  @Mapping(target = "connection", source = "userConnectionCnt")
  UserPersonalDetails toUserPersonalDetails(UserEntity userEntity, UserFollower followerCount, Entities entities, 
    Long userConnectionCnt,Boolean isConnected,Boolean isRequested,Boolean isFollowing,Boolean isLocked);

  default List<String> getEntities(Entities entities) {
    if(ObjectUtils.isEmpty(entities))
      return null;

    return Collections.singletonList(entities.getId());
  }

  default Long getCount(UserFollower followerCount, boolean isFollowerCount) {
    if(ObjectUtils.isEmpty(followerCount))
      return 0L;
    
    if(isFollowerCount)
      return followerCount.getFollowingCount();
    else {
      return followerCount.getFollowerCount();
    }
  }

  @Mapping(target = "id", source = "userId")
  @Mapping(target = "firstName", source = "registrationDto.firstName")
  @Mapping(target = "lastName", source = "registrationDto.lastName")
  @Mapping(target = "emailId", source = "registrationDto.emailId")
  @Mapping(target = "mobileNo", source = "registrationDto.mobileNo")
  @Mapping(expression = "java(registrationDto.getFirstName() + \" \" + registrationDto.getLastName())", target = "fullName")
  @Mapping(target = "createdOn", source = "offsetDateTime")
  @Mapping(target = "createdBy", source = "userId")
  @Mapping(target = "accountNonExpired", constant = "false")
  @Mapping(target = "accountNonLocked", constant = "false")
  @Mapping(target = "credentialsNonExpired", constant = "false")
  @Mapping(target = "enable", constant = "true")
  @Mapping(target = "role", constant = "user")
  @Mapping(target = "isHide", constant = "false")
  @Mapping(target = "updatedBy", source = "userId")
  @Mapping(target = "updatedOn", source = "offsetDateTime")
  @Mapping(target = "emailVerify",source = "b")
  UserEntity RegistrationDtoToUserEntity(String userId, RegistrationDto registrationDto,
      OffsetDateTime offsetDateTime, boolean b);

  @Mapping(target = "id", source = "userRegistrationDto.userId")
  @Mapping(target = "firstName", source = "userRegistrationDto.firstName")
  @Mapping(target = "lastName", source = "userRegistrationDto.lastName")
  @Mapping(target = "emailId", source = "userRegistrationDto.emailId")
  @Mapping(target = "aboutUs", source = "userRegistrationDto.aboutUs")
  @Mapping(target = "title", source = "userRegistrationDto.profileTitle")
  @Mapping(target = "mobileNo", source = "userRegistrationDto.mobileNo")  //new no is set
  @Mapping(target = "accountNonExpired", source = "user.accountNonExpired")
  @Mapping(target = "accountNonLocked", source = "user.accountNonLocked")
  @Mapping(target = "createdBy", source = "user.createdBy")
  @Mapping(target = "createdOn", source = "user.createdOn")
  @Mapping(target = "credentialsNonExpired", source = "user.credentialsNonExpired")  //mobile,email,about,proTitle
  @Mapping(target = "enable", source = "user.enable")
  @Mapping(expression = "java(userRegistrationDto.getFirstName() + \" \" + userRegistrationDto.getLastName())", target = "fullName")
  @Mapping(target = "img", source = "user.img")
  @Mapping(target = "role", source = "user.role")
  @Mapping(target = "updatedBy", source = "userRegistrationDto.userId")
  @Mapping(target = "updatedOn", source = "offsetDateTime")
  @Mapping(target = "isHide", source = "user.isHide")
  @Mapping(target = "cover",source = "user.cover")
  UserEntity toUserEntityFromDto(UserRegistrationDto userRegistrationDto,UserEntity user, 
    OffsetDateTime offsetDateTime);

  @Mapping(target = "userId", source = "userEntity.id")
  @Mapping(target = "profileTitle", source = "userEntity.title")
  @Mapping(target = "cover",source = "userEntity.cover")
  UserRegistrationDto toUserData(UserEntity userEntity);

  @Mapping(target = "designation", source = "user.title")
  @Mapping(target = "name",source = "user.fullName")
  @Mapping(target = "cover",source = "user.cover")
  UserBasicDetailDto toUserBasicDetailDto(UserEntity user);

  List<UserBasicDetailDto> toUserBasicDetailDto(List<UserEntity> user);

  @Mapping(target = "isHide",source = "isHide")
  @Mapping(target = "isConnected",constant = "false")
  @Mapping(target = "isLocked",constant = "true")
  @Mapping(target = "id",source = "user.id")
  @Mapping(target = "name",source = "user.fullName")
  @Mapping(target = "profileTitle",source = "user.title")
  @Mapping(target = "profileImg",source = "user.img")
  @Mapping(target = "firstName",source = "user.firstName")
  @Mapping(target = "lastName",source = "user.lastName")
  @Mapping(target = "emailId",ignore = true)
  @Mapping(target = "mobileNo",ignore = true)

  UserPersonalDetails toPrivateNotConnectedUserData(UserEntity user, Boolean isHide);

  @Mapping(target = "designation",source = "data.title")
  @Mapping(target = "name",source = "data.fullName")
  UserList toMutualConnectionList(UserEntity data);

  List<UserList> toMutualConnectionList(List<UserEntity> data);

  @Mapping(target = "id",source = "id")
  @Mapping(target = "userName",source = "generatedUserName")
  @Mapping(target = "user",source = "userEntity")
  @Mapping(target = "defaultValue",constant = "true")
  @Mapping(target = "createdBy",source = "userId")
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "createdOn",source = "offsetDateTime")
  @Mapping(target = "updatedOn",source = "offsetDateTime")
  UserName toUserNameResult(String id, String generatedUserName, UserEntity userEntity,
    String userId, OffsetDateTime offsetDateTime);
}
