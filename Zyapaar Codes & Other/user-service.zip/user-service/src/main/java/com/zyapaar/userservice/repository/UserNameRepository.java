package com.zyapaar.userservice.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.userservice.entities.UserName;

@Repository
public interface UserNameRepository extends JpaRepository<UserName,String>{

  @Query(
    nativeQuery = true,
    value = "SELECT user_id FROM user_name WHERE user_name = :lowerCase"
  )
  String findUserIdByName(String lowerCase);

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_name WHERE user_id = :userId"
  )
  Optional<UserName> findByUserId(String userId);
  
}
