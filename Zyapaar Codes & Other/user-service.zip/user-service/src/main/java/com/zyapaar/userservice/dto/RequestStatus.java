package com.zyapaar.userservice.dto;

/**
 * Member request status
 * 
 * @author Uday Halpara
 */
public enum RequestStatus {

  INVITE("invite"),  //1
  JOIN("join"),      //2
  ACCEPT("accept"),  //3
  REJECT("reject"),  //4
  CANCLE("cancle"),  //5
  REMOVE("remove"),  //6
  LEAVE("leave");    //7

  private final String status;

  RequestStatus(String status) {
    this.status = status;
  }

  public String status() {
    return status;
  }
}
