package com.zyapaar.userservice.request;

import com.zyapaar.userservice.dto.VerifiedBy;
import com.zyapaar.userservice.validation.IdentityValidation;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Identity validation Dto
 * 
 * @author Uday Halpara
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@IdentityValidation(identityNumber = "identityNumber")
public class IdentityValidationDto {

  private VerifiedBy identity;
  private String identityNumber;

}

