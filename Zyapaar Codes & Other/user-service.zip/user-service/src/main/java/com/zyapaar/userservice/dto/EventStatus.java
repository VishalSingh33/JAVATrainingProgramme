package com.zyapaar.userservice.dto;

/**
 * Event status enum
 * 
 * @author Uday Halpara
 */
public enum EventStatus {

  FOLLOW("1"),
  UNFOLLOW("2");

  private final String status;

  EventStatus(String status) {
    this.status = status;
  }

  public String eventStatus() {
    return status;
  }
}
