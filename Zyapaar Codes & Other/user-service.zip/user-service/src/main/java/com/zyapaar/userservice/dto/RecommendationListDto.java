package com.zyapaar.userservice.dto;

import java.time.OffsetDateTime;
import lombok.Data;

/**
 * recommendation listing dto
 * 
 * @author Uday Halpara
 */
@Data
public class RecommendationListDto {

  private String id;
  private String userId;
  private String userName;
  private String userProfile;
  private String userDesignation;
  private String message;
  private String recommendation;
  private String createdAt;
  private OffsetDateTime createdOn; //Date

}
