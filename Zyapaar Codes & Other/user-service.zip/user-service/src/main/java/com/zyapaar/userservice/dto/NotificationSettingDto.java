package com.zyapaar.userservice.dto;

import javax.validation.constraints.NotNull;
import org.springframework.stereotype.Component;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Component
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NotificationSettingDto {
  
  private Boolean isEmailVerified;
  private Boolean profileViewPush;
  private Boolean profileViewEmail;
  private Boolean postReactionPush;
  private Boolean postReactionEmail;
  private Boolean commentPush;
  private Boolean commentEmail;
  private Boolean postSharePush;
  private Boolean postShareEmail;
  private Boolean commentReactionPush;
  private Boolean commentReactionEmail;
  private Boolean commentReplyPush;
  private Boolean commentReplyEmail;
  private Boolean postMentionPush;
  private Boolean postMentionEmail;
  private Boolean commentMentionPush;
  private Boolean commentMentionEmail;
  private Boolean teamPush;
  private Boolean teamEmail;
  private Boolean groupPush;
  private Boolean groupEmail;
  private Boolean pagePush;
  private Boolean pageEmail;
  private Boolean connectionPush;
  private Boolean connectionEmail;
  private Boolean messagePush;
  private Boolean messageEmail;
  private Boolean recommendationPush;
  private Boolean recommendationEmail;
  
  @NotNull(message = "Please select profile privacy")
  private String networkProfile;
  
  private String postDelivery;
  
  public static enum NetworkProfile {
    PUBLIC_PROFILE("1"),
    PRIVATE_PROFILE("2");
    private final String networkProfile;
    NetworkProfile(String networkProfile) {
      this.networkProfile = networkProfile;
    }
    public String networkProfile() {
      return networkProfile;
    }
    public static NetworkProfile fromString(String text) {
      for (NetworkProfile b : NetworkProfile.values()) {
        if (b.networkProfile.equalsIgnoreCase(text)) {
          return b;
        }
      }
      return null;
    }
  }
  public static enum PostDelivery {
    ANYONE("1"),
    CONNECTION_ONLY("2");
    private final String postDelivery;
    PostDelivery(String postDelivery) {
      this.postDelivery = postDelivery;
    }
    public String postDelivery() {
      return postDelivery;
    }
    public static PostDelivery fromString(String text) {
      for (PostDelivery b : PostDelivery.values()) {
        if (b.postDelivery.equalsIgnoreCase(text)) {
          return b;
        }
      }
      return null;
    }
  }
}