package com.zyapaar.userservice.repository;

import com.zyapaar.userservice.dto.BlockUserDto;
import com.zyapaar.userservice.dto.IBlockUserDto;
import com.zyapaar.userservice.entities.AllRequest;
import com.zyapaar.userservice.entities.BlockUser;
import com.zyapaar.userservice.entities.UserWiseConnection;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BlockUserRepoistory extends JpaRepository<BlockUser, String>{

	@Query(
    nativeQuery = true,
    value = "  SELECT id FROM block_user WHERE from_user_id= :from "
    + " AND to_user_id= :to AND status='blocked' "
  )
  Optional<String> checkIsBlock(String from, String to);


	@Modifying
	@Query(nativeQuery = true, value = "update user_connection " + 
	"set status  = case status " + 
	"WHEN 'initiate' then 'reject' " + 
	"WHEN 'accept' then 'remove' " + 
	"end where from_user_id = :fromId and to_user_id = :toId ")
	void upadateUserConnection(String fromId, String toId);

	@Modifying
	@Query(nativeQuery = true, value = "update all_request " + 
	"set status  = case status " + 
	"WHEN 'initiate' then 'reject' " + 
	"WHEN 'accept' then 'remove' " + 
	"end where from_user_id = :fromId " )
	void upadateAllRequest(String fromId);

	@Query(nativeQuery= true, 
  value= "select * from all_request ar where from_user_id = :id ")
  List<AllRequest> getAllRequest(String id);

	@Query(nativeQuery= true, 
  value= "select * from user_wise_connection uwc where id = :id ")
  UserWiseConnection getUserWiseConnection(String id);

	@Modifying
	@Query(nativeQuery = true,
	value = " UPDATE block_user  SET status  = 'unblocked' WHERE from_user_id = :from and to_user_id = :to ")
	void getUnblockId(String from, String to);

  @Query(nativeQuery= true, 
  value = " SELECT bu.id ,bu.from_user_id as fromId ,bu.to_user_id as toId, bu.status ,bu.origin ,bu.origin_id as originId ," + 
  " bu.created_on as createdOn ,bu.updated_on as updatedOn , u.user_name as userName, u.img FROM block_user bu " + 
  " INNER JOIN users u ON u.id = bu.from_user_id where bu.from_user_id = :id ")
  List<IBlockUserDto> blockuserList(String id, Pageable pageable);

  @Query(nativeQuery= true, 
  value = " select count(*) from (SELECT bu.id ,bu.from_user_id as fromId ,bu.to_user_id as toId, bu.status ,bu.origin ,bu.origin_id as originId ," + 
  " bu.created_on as createdOn ,bu.updated_on as updatedOn , u.user_name as userName, u.img FROM block_user bu " + 
  " INNER JOIN users u ON u.id = bu.from_user_id where bu.from_user_id = :id ) as a")
  Optional<String> findBlockCount(String id);

  
}
