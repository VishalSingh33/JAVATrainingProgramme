// package com.zyapaar.userservice.controller;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;
// import javax.validation.Valid;
// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.JsonMappingException;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.exceptionhandler.model.ApiError;
// import com.zyapaar.userservice.dto.SignUpOTPDto;
// import com.zyapaar.userservice.dto.SignUpOTPVerifyDto;
// import org.springframework.http.ResponseEntity;
// import org.springframework.validation.annotation.Validated;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import io.swagger.annotations.ApiParam;
// import io.swagger.v3.oas.annotations.Operation;
// import io.swagger.v3.oas.annotations.media.Content;
// import io.swagger.v3.oas.annotations.responses.ApiResponse;
// import io.swagger.v3.oas.annotations.tags.Tag;
// import io.swagger.v3.oas.annotations.media.Schema;

// @RequestMapping("/api/v1.1/")  
// @Validated  
// @Tag(name = "sign-up APIs")
// public interface SignupController {
  
//   @Operation(
//     description = "This signup service works to Signup takes note of user's OTP to be in service",
//     responses = {
//       @ApiResponse(
//         content = @Content(
//           schema = @Schema(implementation = Response.class)
//         ), 
//         responseCode = "200"),
//       @ApiResponse(
//         content = @Content(
//           schema = @Schema(implementation = ApiError.class)
//         ), 
//         responseCode = "400", 
//         description = "Bad request")
//     }
//   ) 
//   @PostMapping("signup/otp")  
//   public ResponseEntity<Response> signupOtp(
//     @ApiParam(
//       value = "The content under SignUpOTP Dto is used to get otp", 
//       required = true) @Valid @RequestBody SignUpOTPDto signUpPhaseOneDto   //In Dto mobileNo should be not null
//   ) throws InterruptedException, ExecutionException, TimeoutException, JsonMappingException, JsonProcessingException;

//   @Operation(
//     description = "This signup api works to Signup takes note of user's OTP verify to be in service", 
//     responses = {
//       @ApiResponse(
//         content = @Content(
//           schema = @Schema(implementation = Response.class)
//         ), 
//         responseCode = "200"),
//       @ApiResponse(
//         content = @Content(
//           schema = @Schema(implementation = ApiError.class)
//         ), 
//         responseCode = "400", 
//         description = "Bad request")
//   })
//   @PostMapping("signup/verify")
//   public ResponseEntity<Response> signupOtpVerify(
//     @ApiParam(
//       value = "The content under SignUpOTPVerify Dto is used to verify otp", 
//       required = true) @Valid @RequestBody SignUpOTPVerifyDto otpVerifyDto    //In Dto mobileNo should be not null
//   ) throws InterruptedException, ExecutionException, TimeoutException;
// }
