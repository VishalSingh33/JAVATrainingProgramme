package com.zyapaar.userservice.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Set;
import java.util.regex.Pattern;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

import lombok.extern.slf4j.Slf4j;

/**
 * Sales Product Set Validation Custom Annotation
 * 
 * @author Uday Halpara
 */
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ValidateSalesSet.Validators.class)
public @interface ValidateSalesSet {
  String message() default "Invalid sales products";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  /**
   * validator class for Sales product
   * 
   * @author Uday Halpara
   */
  @Slf4j
  class Validators implements ConstraintValidator<ValidateSalesSet,  Set<String>> {

    /**
     * Sales product validation checking Method
     */
    @Override
    public boolean isValid( Set<String> products, ConstraintValidatorContext context) {
      log.info("[isValid] validate sales products");
      boolean result = true;
      String template = null;

      if (products != null && products.size() != 0) {
        log.info("[isValid] sales product Set is not null");

        Pattern p = Pattern.compile("[Kk][0-9]{8}[-][Ss][0-9]{8}");
        boolean all = products.stream().allMatch(prod -> p.matcher(prod).matches());

        if (!all) {
          log.info("[isValid] invalid sales product id found");
          template = "Please select valid sales products";
        }
      } else {
        template = "Please select at-least one sales product";
      }
      if (template != null) {
        context.disableDefaultConstraintViolation();
        context
            .buildConstraintViolationWithTemplate(template)
            .addConstraintViolation();
        result = false;
      }
      return result;
    }

  }
}
