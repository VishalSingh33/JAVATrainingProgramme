package com.zyapaar.userservice.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.regex.Pattern;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import com.zyapaar.userservice.dto.RegistrationDto;
import com.zyapaar.userservice.repository.UserRepository;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Mobile number Validation Custom Annotation
 * 
 * @author Uday Halpara
 */
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = MobileNumberRegValidation.Validators.class)
public @interface MobileNumberRegValidation {

  String message() default "Invalid mobile number";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  String mobileNo();

  /**
   * validator class for MobileNumber
   * 
   * @author Uday Halpara
   */
  @Slf4j
  @Component
  @RequiredArgsConstructor
  class Validators implements ConstraintValidator<MobileNumberRegValidation, RegistrationDto> {

    private String mobileNumberField;
    private final UserRepository userRepository;

    @Override
    public void initialize(MobileNumberRegValidation requiredIfChecked) {
      mobileNumberField = requiredIfChecked.mobileNo();
    }

    /**
     * file validation checking Method
     */
    @Override
    public boolean isValid(RegistrationDto registrationDto, ConstraintValidatorContext context) {
      log.info("[isValid] validate mobile number");
      boolean result = true;
      String template = null;
      
      String mobileNumber = registrationDto.getMobileNo();

      if (mobileNumber == null || mobileNumber.length() != 10) {
        template = "Enter a mobile number";
      } else if (!Pattern.compile("^([9876]{1})(\\d{9})").matcher(mobileNumber).matches()) {
        template = "Mobile number is invalid";
      } else if(userRepository.existsByMobileNumber(mobileNumber))  {
        template = "Mobile number already registered with another user";
      }

      if (template != null) {
        context.disableDefaultConstraintViolation();
        context
            .buildConstraintViolationWithTemplate(template)
            .addPropertyNode(mobileNumberField)
            .addConstraintViolation();
        result = false;
      }
      return result;
    }

  }
}
