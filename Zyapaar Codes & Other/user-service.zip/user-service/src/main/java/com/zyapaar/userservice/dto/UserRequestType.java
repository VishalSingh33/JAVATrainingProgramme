package com.zyapaar.userservice.dto;

public enum UserRequestType {
  
  ALL("all"),
  COMPANY("company"),
  USER("user"),
  PAGE("page"),
  GROUP("group");

  private final String status;

  UserRequestType(String status) {
    this.status = status;
  }

  public String status() {
    return status;
  }
}
