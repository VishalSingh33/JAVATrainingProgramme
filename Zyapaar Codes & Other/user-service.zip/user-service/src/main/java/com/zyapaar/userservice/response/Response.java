package com.zyapaar.userservice.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * User to give responses to the user.
 * 
 * @author CHiRAG RATHOD
 */
@AllArgsConstructor
@Getter
public class Response {
  
  private String message;
}
