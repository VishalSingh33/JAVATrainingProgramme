package com.zyapaar.userservice.dto;

/**
 * it is used to define connection status
 * 
 * @author Uday Halpara
 */
public enum ConnectionStatus {

  INITIATE("initiate"),   //1
  REJECT("reject"),    //2
  CANCEL("cancel"),    //3
  ACCEPT("accept"),    //4
  REMOVE("remove");    //5

  private final String connectionStatus;

  ConnectionStatus(String connectionStatus) {
    this.connectionStatus = connectionStatus;
  }

  public String connectionStatus() {
    return connectionStatus;
  }

}
