package com.zyapaar.userservice.mapper;

import java.util.List;
import com.zyapaar.userservice.dto.IndustriesData;
import com.zyapaar.userservice.dto.ProductData;
import com.zyapaar.userservice.dto.StateResponseDto;
import com.zyapaar.userservice.entities.Keyword;
import com.zyapaar.userservice.entities.Product;
import com.zyapaar.userservice.entities.StateEntity;
import com.zyapaar.userservice.entities.SubIndustry;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * Industry mapper
 * 
 * @author Uday Halapra
 */
@Mapper
public interface MasterDataMapper {

  List<IndustriesData> toIndustriesDatas(List<SubIndustry> industries); //

  @Mapping(target = "subIndustryID",source = "industries.id")
  @Mapping(target = "subIndustry",source = "industries.name")
  IndustriesData toIndustriesDatas(SubIndustry industries);

  @Mapping(target = "name",source = "state.stateName")
  StateResponseDto toStates(StateEntity state);

  List<StateResponseDto> toStates(List<StateEntity> states);

  ProductData toProductData(Product products);

  @Mapping(target = "id",source = "list.keywordId")
  @Mapping(target = "keyword",source = "list.name")
  ProductData toProducts(Keyword list); //

  List<ProductData> toProducts(List<Keyword> list); 
}

