package com.zyapaar.userservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.zyapaar.userservice.dto.EntityRegistrationDto;
import com.zyapaar.userservice.request.IdentityValidationDto;

@Mapper
public interface IdentityMapper {
  
  @Mapping(target =  "identity", source = "dto.verifiedBy")
  IdentityValidationDto toIdentityValidationDto(EntityRegistrationDto dto);
}
