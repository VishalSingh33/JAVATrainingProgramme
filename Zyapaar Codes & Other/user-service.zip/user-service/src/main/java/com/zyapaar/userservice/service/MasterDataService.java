package com.zyapaar.userservice.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.zyapaar.userservice.dto.Country;
import com.zyapaar.userservice.dto.Designations;
import com.zyapaar.userservice.dto.IndustriesData;
import com.zyapaar.userservice.dto.ProductData;
import com.zyapaar.userservice.dto.StateResponseDto;
import com.zyapaar.userservice.dto.TypeDto;
import com.zyapaar.userservice.entities.Keyword;
import com.zyapaar.userservice.entities.StateEntity;
import com.zyapaar.userservice.entities.SubIndustry;
import com.zyapaar.userservice.mapper.MasterDataMapper;
import com.zyapaar.userservice.repository.KeywordRepository;
import com.zyapaar.userservice.repository.StateRepository;
import com.zyapaar.userservice.repository.SubIndustryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * master data service
 * 
 * @author Uday Halpara
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class MasterDataService implements DataService {

  private final MasterDataMapper masterDataMapper;
  private final StateRepository stateRepository; //
  private final SubIndustryRepository subIndustryRepository; //
  private final KeywordRepository keywordRepository;

  /**
   * get country list
   * 
   * @return
   */
  @Deprecated
  @Override
  public List<Country> getCountryList() {
    log.info("[getCountryList] get country list");
    return null;
  }

  /**
   * get states list
   * 
   * @param countryId
   * @return
   */
  @Override                    
  public List<StateResponseDto> getStateList(String countryId) {
    log.info("[getStateList] get country wise state list");

    List<StateEntity> data = stateRepository.findByCountryId(countryId);
    
    return masterDataMapper.toStates(data);
  }

  /**
   * BusinessTypes list
   */
  @Deprecated
  @Override
  public List<TypeDto> getBusinessTypeList() {
    log.info("[getBusinessTypeList] get Business type list");
    return null;
  }

  /**
   * FirmTypes list
   */
  @Deprecated
  @Override
  public List<TypeDto> getFirmTypeList() {
    log.info("[getFirmTypeList] get Firm type list");
    return null;
  }

  @Deprecated
  @Override
  public List<Designations> getDesignations() {
    log.info("[getDesignations] get Firm type list");
    // return designationMapper.toDesignations(designationDao.getDesignations());
    return null;
  }

  @Override                     
  public List<IndustriesData> getIndustriesList() {

    log.info("[getIndustriesList] get industries list");

    List<SubIndustry> data = subIndustryRepository.findAll();

    return masterDataMapper.toIndustriesDatas(data);

  }

  @Override                   
  public List<ProductData> getProducts(String keyword) {   

    List<Keyword> list =  keywordRepository.findByNameIgnoreCase(keyword);
    return masterDataMapper.toProducts(list);
   }
 
 }


