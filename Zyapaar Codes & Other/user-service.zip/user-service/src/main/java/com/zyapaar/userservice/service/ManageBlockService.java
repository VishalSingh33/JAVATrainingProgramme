package com.zyapaar.userservice.service;

import com.zyapaar.userservice.dto.*;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.userservice.entities.AllRequest;
import com.zyapaar.userservice.entities.BlockUser;
import com.zyapaar.userservice.entities.UserFollower;
import com.zyapaar.userservice.entities.UserWiseConnection;
import com.zyapaar.userservice.mapper.BlockUserMapper;
import com.zyapaar.userservice.mapper.UserFollowerBlockMapper;
import com.zyapaar.userservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ManageBlockService implements BlockService {

	private final BlockUserRepoistory blockUserRepoistory;
	private final BlockUserMapper blockUserMapper;
	private final UserFollowerBlockMapper userFollowerBlockMapper;
	private final UserRepository userRepository;
	private final UserWiseConnectionRepository userWiseConnectionRepository;
	private final AllRequestRepository allRequestRepository;
	private final UserFollowerRepository userFollowerRepository;
	private final UserOverViewRepository userOverViewRepository;
	private final FollowerRepository followerRepository;

	@Override
	@Transactional(rollbackOn = Exception.class)
	public ResponseEntity<Response> blockUser(String fromUserId, BlockUserDto blockUserDto) {

		 blockUserRepoistory.checkIsBlock(fromUserId, blockUserDto.getToUserId()).ifPresent(status -> {
       throw new BadRequestException("User is already Blocked !!");
     });

		userRepository.findById(fromUserId)
				.orElseThrow(() -> new ResourceNotFoundException("user", "id", fromUserId));

		String id = SequenceGenerator.getInstance().nextId();
		OffsetDateTime offset = new Date().toInstant().atOffset(ZoneOffset.UTC);

		BlockUser blockUser = blockUserMapper.setData(fromUserId, id, offset, blockUserDto);
		
		blockUser.setStatus(BlockedStatus.BLOCKED.status());

		blockUserRepoistory.save(blockUser);
		blockUserRepoistory.upadateUserConnection(fromUserId, blockUserDto.getToUserId());
		// blockUserRepoistory.upadateAllRequest(fromUserId, blockUserDto.getToUserId());

		List<AllRequest> toAllRequest = allRequestRepository.findAll();
		List<AllRequest> filteredAllRequest = toAllRequest.stream()
				.filter(e -> e.getFromUserId().equals(fromUserId)).collect(Collectors.toList());
//				blockUserRepoistory.getAllRequest(fromUserId);
		// for(AllRequest user : toAllRequest)
		filteredAllRequest.forEach(allRequest -> {
			if(allRequest.getToUserId().contains(blockUserDto.getToUserId()))
			{
				if(allRequest.getStatus().equals("accept"))
				{
                  allRequest.setStatus("remove");
				} else if (allRequest.getStatus().equals("initiate")) {
					allRequest.setStatus("reject");
			    }
//				allRequest.getToUserId().remove(blockUserDto.getToUserId());
				allRequestRepository.save(allRequest);
			}
		});

		Optional<UserWiseConnection> fromUserWiseConnection = userWiseConnectionRepository.findById(fromUserId);
		if(fromUserWiseConnection.isPresent())
		{
			fromUserWiseConnection.get().getUserIds().remove(blockUserDto.getToUserId());
			userWiseConnectionRepository.save(fromUserWiseConnection.get());
		}
		Optional<UserWiseConnection> toUserWiseConnection = userWiseConnectionRepository.findById(blockUserDto.getToUserId());
		if(toUserWiseConnection.isPresent())
		{
			toUserWiseConnection.get().getUserIds().remove(fromUserId);
			userWiseConnectionRepository.save(toUserWiseConnection.get());
		}

		// Following-Follower Change
		UserFollower userIdExistsInUserFollower = getUserFollowerById(fromUserId);
    Long userIdExistsInUserFollowerCount = userIdExistsInUserFollower.getFollowingCount();
    if(userIdExistsInUserFollowerCount > 0 )
		{
			userIdExistsInUserFollowerCount--;
		}
    log.info("Following count decreased of userId: {}", fromUserId);
    OffsetDateTime offsetDateTime = new Date().toInstant().atOffset(ZoneOffset.UTC);

		//check here id to replace with fromUserd
    UserFollower decreasedFromUserIdSide = userFollowerBlockMapper.toFollow(fromUserId, offsetDateTime,
        userIdExistsInUserFollowerCount, userIdExistsInUserFollower);
    
    UserFollower idExistsInUserFollower = getUserFollowerById(blockUserDto.getToUserId());
        Long idExistsInUserFollowerCount = idExistsInUserFollower.getFollowerCount();
		if(idExistsInUserFollowerCount > 0 )
		{
			idExistsInUserFollowerCount--;
		}

    log.info("Follower count decreased of id: {} in UserFollower", blockUserDto.getToUserId());
  
    UserFollower decreasedFromIdSide = userFollowerBlockMapper.toFollow(blockUserDto.getToUserId(),
        offsetDateTime, idExistsInUserFollowerCount, idExistsInUserFollower);

      userFollowerRepository.save(decreasedFromUserIdSide);
      userFollowerRepository.save(decreasedFromIdSide);

      log.info("User : {} unfollow to: {}", fromUserId, blockUserDto.getToUserId());
      followerRepository.unFollowUser(FollowStatus.INACTIVE.toString(), fromUserId, blockUserDto.getToUserId());

      userOverViewRepository.decreaseFollowingsCount(fromUserId);
      userOverViewRepository.decreaseFollowersCount(blockUserDto.getToUserId());
    //   log.info("[unfollow] Exception while saving data", exception);

		return ResponseEntity.status(HttpStatus.CREATED)
        .body(Response.builder().message("Block User Fetched").data(blockUser)
            .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
	}

	private UserFollower getUserFollowerById(String id) {
    return userFollowerRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("user", "id", id));
  }

	@Transactional(rollbackOn = Exception.class)
	@Override
	public ResponseEntity<Response> unBlockUser(String fromUserId, BlockUserDto blockUserDto) {

		userRepository.findById(fromUserId)
				.orElseThrow(() -> new ResourceNotFoundException("user", "id", fromUserId));

		blockUserRepoistory.getUnblockId(fromUserId, blockUserDto.getToUserId());
		return ResponseEntity.status(HttpStatus.CREATED)
        .body(Response.builder().message("UnBlocked User")
            .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

	}

	@Override
	public ResponseEntity<Response> blockedUserList(String fromUserId, ListingRequest listingRequest) {
		
		Pageable paging = PageRequest.of(listingRequest.getPage(), 10, Sort.by(Direction.DESC, "created_on") );

		List<IBlockUserDto> blockedUserList = blockUserRepoistory.blockuserList(fromUserId, paging);

		String sizeLength = blockUserRepoistory.findBlockCount(fromUserId).orElseThrow(null);
		
		return ResponseEntity.status(HttpStatus.OK)
			.body(Response.builder().message("Listing Response")
			.data(new ListingResponse(blockedUserList, Integer.parseInt(sizeLength)))
			.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

	}
	
}
