package com.zyapaar.userservice.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import com.zyapaar.userservice.component.IdentityComponent;
import com.zyapaar.userservice.dto.EntityRegistrationDto;
import com.zyapaar.userservice.dto.VerifiedBy;
import com.zyapaar.userservice.mapper.IdentityMapper;
import com.zyapaar.userservice.request.IdentityValidationDto;

import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Identity custom validation
 * 
 * @author UDaY HaLPaRa
 */
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = IdentityValidation.Validators.class)
public @interface IdentityValidation {

  String message()

  default "This field Is Required";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  String identityNumber();

  @Slf4j
  @Component
  @RequiredArgsConstructor
  class Validators implements ConstraintValidator<IdentityValidation, EntityRegistrationDto> {
    private String identityNumber;
    private final IdentityComponent identityComponent;
    private final IdentityMapper identityMapper;
    // private final CompanyDao companyDao;
    // private final CompanyRepository companyRepository;

    @Override
    public void initialize(IdentityValidation requiredIfChecked) {
      identityNumber = requiredIfChecked.identityNumber();
    }

    @Override
    public boolean isValid(EntityRegistrationDto objectToValidate, ConstraintValidatorContext context) {
      log.info("[isValid] validate company identity pan, gstin or udyog/udyam adhar");
      var valid = true;
      String template = null;
      Object identity;
      String identityNumberValue;

      identity = objectToValidate.getVerifiedBy();
      identityNumberValue = objectToValidate.getIdentityNumber().toUpperCase();

      if (identity.equals(VerifiedBy.PAN)
          && !String.valueOf(identityNumberValue)
              .matches("[A-Z]{3}[PCFTGHLABJ]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}")) {

        valid = false;
        template = "Please provide valid PAN number";
      } else if (identity.equals(VerifiedBy.GSTIN)
          && !String.valueOf(identityNumberValue)
              .matches("[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}")) {

        valid = false;
        template = "Please provide valid GSTIN number";
      } else if (identity.equals(VerifiedBy.UDYOG_ADHAR)
          && !String.valueOf(identityNumberValue)
              .matches("[a-zA-Z]{2}[0-9]{2}[a-zA-z][0-9]{7}")) {

        valid = false;
        template = "Please provide valid Udyog adhar number";
      } else if (identity.equals(VerifiedBy.UDYAM_ADHAR)
          && !String.valueOf(identityNumberValue)
              .matches("(UDYAM)[-][A-Za-z]{2}[-][0-9]{2}[-][0-9]{7}")) {

        valid = false;
        template = "Please provide valid Udyam adhar number";
      } else {
        IdentityValidationDto identityValidationDto = identityMapper.toIdentityValidationDto(objectToValidate);
        valid = identityComponent.isIdentityValid(identityValidationDto);
      }
      // if (valid && companyRepository.existsByIdentityNumber(identityNumber)) {
      //   valid = false;
      //   template = "Company is Already registered with us";
      // }

      if (!valid) {
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(template)
            .addPropertyNode(identityNumber)
            .addConstraintViolation();
      }

      return valid;
    }
  }

}
