package com.zyapaar.userservice.service;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.userservice.dto.FollowEnum;

/**
 * Follower service
 * 
 * @author Uday Halpara
 */
public interface FollowerService {

  void follow(String userId, String id);

  void unfollow(String userId, String id);

  ListingResponse getFollowyList(String userId, String id, FollowEnum followType, ListingRequest listingRequest);

}

