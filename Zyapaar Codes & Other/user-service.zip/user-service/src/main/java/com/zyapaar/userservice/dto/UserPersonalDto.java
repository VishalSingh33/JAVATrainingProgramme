package com.zyapaar.userservice.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * dto class for user personal detail.
 */
@Getter
@Setter
public class UserPersonalDto {

  private String id;
  private String name;
  private String profileTitle;
  private String profileImg;
  private String aboutUs;
  private String emailId;
  private String mobileNo;
}
