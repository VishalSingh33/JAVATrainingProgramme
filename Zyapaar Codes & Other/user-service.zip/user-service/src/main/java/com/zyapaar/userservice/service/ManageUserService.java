package com.zyapaar.userservice.service;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.commons.utils.TokenProvider;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.SignUpStatusAvro;
import com.zyapaar.userservice.dto.BlockOrigin;
import com.zyapaar.userservice.dto.BlockedStatus;
import com.zyapaar.userservice.dto.ConnectionStatus;
import com.zyapaar.userservice.dto.IProfileViewerResponse;
import com.zyapaar.userservice.dto.NotificationSettingDto;
import com.zyapaar.userservice.dto.ProfileViewerResponse;
import com.zyapaar.userservice.dto.RegistrationDto;
import com.zyapaar.userservice.dto.ResponseDto;
import com.zyapaar.userservice.dto.Roles;
import com.zyapaar.userservice.dto.UserBasicDetailDto;
import com.zyapaar.userservice.dto.UserDetails;
import com.zyapaar.userservice.dto.UserPersonalDetails;
import com.zyapaar.userservice.dto.UserProfileConnectionStatus;
import com.zyapaar.userservice.dto.UserRegistrationDto;
import com.zyapaar.userservice.entities.Entities;
import com.zyapaar.userservice.entities.NotificationSetting;
import com.zyapaar.userservice.entities.SignupStatus;
import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserFollower;
import com.zyapaar.userservice.entities.UserIndustry;
import com.zyapaar.userservice.entities.UserName;
import com.zyapaar.userservice.entities.UserOverView;
import com.zyapaar.userservice.entities.UserWiseConnection;
import com.zyapaar.userservice.mapper.NotificationMapper;
import com.zyapaar.userservice.mapper.NotificationSettingMapper;
import com.zyapaar.userservice.mapper.UserBlockedMapper;
import com.zyapaar.userservice.mapper.UserFollowerMapper;
import com.zyapaar.userservice.mapper.UserIndustryMapper;
import com.zyapaar.userservice.mapper.UserMapper;
import com.zyapaar.userservice.mapper.UserNameMapper;
import com.zyapaar.userservice.mapper.UserOverViewMapper;
import com.zyapaar.userservice.mapper.UserProfileViewerMapper;
import com.zyapaar.userservice.producer.NotificationProducer;
import com.zyapaar.userservice.producer.Producer;
import com.zyapaar.userservice.properties.B2bProperties;
import com.zyapaar.userservice.repository.BlockUserRepository;
import com.zyapaar.userservice.repository.CompanyRepository;
import com.zyapaar.userservice.repository.FollowerRepository;
import com.zyapaar.userservice.repository.NotificationSettingRepository;
import com.zyapaar.userservice.repository.ProfileViewerRepository;
import com.zyapaar.userservice.repository.RequestIpRepository;
import com.zyapaar.userservice.repository.SignupStatusRepository;
import com.zyapaar.userservice.repository.UserConnectionRepository;
import com.zyapaar.userservice.repository.UserFollowerRepository;
import com.zyapaar.userservice.repository.UserIndustryRepository;
import com.zyapaar.userservice.repository.UserNameRepository;
import com.zyapaar.userservice.repository.UserOverViewRepository;
import com.zyapaar.userservice.repository.UserRepository;
import com.zyapaar.userservice.repository.UserWiseConnectionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class ManageUserService implements UserService {
    
  private final UserRepository userRepository;
  private final UserMapper userMapper;
  private final UserIndustryMapper userIndustryMapper;
  private final UserIndustryRepository userIndustryRepository;
  private final SignupStatusRepository signupStatusRepository;
  private final UserConnectionRepository userConnectionRepository;
  private final UserFollowerRepository userFollowerRepository;
  private final CompanyRepository companyRepository;
  private final NotificationSettingRepository notificationSettingsRepository;
  private final Producer producer;
  private final NotificationProducer notificationProducer;
  private final NotificationMapper notificationMapper;
  private final B2bProperties b2bProperties;
  private final TokenProvider tokenProvider;
  private final UserFollowerMapper userFollowerMapper;
  private final FollowerRepository followerRepository;
  private final NotificationSettingMapper notificationSettingMapper;
  private final UserOverViewMapper userOverViewMapper;
  private final UserOverViewRepository userOverViewRepository;
  private final UserWiseConnectionRepository userWiseConnectionRepository;
  private final ProfileViewerRepository profileViewerRepository;
  private final UserProfileViewerMapper userProfileViewerMapper;
  private final UserNameRepository userNameRepository;
	private final RequestIpRepository requestIpRepository;
  private final UserNameMapper userNameMapper;
  private final UserBlockedMapper userBlockedMapper;
	// private final ReferenceIpMapper referenceIpMapper;
  private final BlockUserRepository blockUserRepository;

  @Transactional(rollbackFor = Exception.class)  
  @Override
  public ResponseDto createUser(String mobileNo, RegistrationDto registrationDto) {
    log.info("[createUser] add new user");
    
    OffsetDateTime offsetDateTime = offsetDateTime();
    String userId = SequenceGenerator.getInstance().nextId();
    
    UserEntity userEntity = userMapper.RegistrationDtoToUserEntity(userId,registrationDto,offsetDateTime,false);
    
    String generatedUserName = userEntity.getFirstName().toLowerCase()+userEntity.getLastName().toLowerCase()+"_"+SequenceGenerator.getInstance().nextId();
    userEntity.setUserName(generatedUserName);

    Set<String> sellsList = registrationDto.getSales();
    Set<String> allIdsOfSells = sellsList.stream().map(entry -> entry.split("-")[1]).collect(Collectors.toSet());

    UserIndustry userIndustry = userIndustryMapper.toUserIndustryFromRegistrationDto(
      SequenceGenerator.getInstance().nextId(), offsetDateTime, userEntity, userId,allIdsOfSells);

    SignupStatus signupStatus = new SignupStatus();
    signupStatus.setMobileNo(mobileNo);
    signupStatus.setStatus(SignUpStatusAvro.REG.toString()); 
    log.info("[createUser] Status updated successfully to 'REG' in SignupStatus");

    UserFollower userFollower = userFollowerMapper.toUserFollowerFromUser(userId,offsetDateTime,0L);
   
    NotificationSettingDto notificationSettingDto = NotificationSettingDto.builder()
    .commentEmail(true)
    .commentMentionEmail(true)
    .commentMentionPush(true)
    .commentPush(true)
    .commentReactionEmail(true)
    .commentReactionPush(true)
    .commentReplyEmail(true)
    .commentReplyPush(true)
    .connectionEmail(true)
    .connectionPush(true)
    .groupEmail(true)
    .groupPush(true)
    .isEmailVerified(false)  //
    .messageEmail(true)
    .messagePush(true)
    .networkProfile("1")
    .pageEmail(true)
    .pagePush(true)
    .postDelivery("1")
    .postMentionEmail(true)
    .postMentionPush(true)
    .postReactionEmail(true)
    .postReactionPush(true)
    .postShareEmail(true)
    .postSharePush(true)
    .profileViewEmail(true)
    .profileViewPush(true)
    .recommendationEmail(true)
    .recommendationPush(true)
    .teamEmail(true)
    .teamPush(true)
    .build();

    NotificationSetting notificationSetting = notificationSettingMapper.toNotificationSettingFromUser(notificationSettingDto,
      registrationDto.getEmailId(),userId);
    
    UserOverView userOverView = userOverViewMapper.toUserOverViewFromUserEntity(SequenceGenerator.getInstance().nextId(),
       userId,0L);

    UserWiseConnection userWiseConnection = UserWiseConnection.builder()
       .id(userEntity.getId())
       .userIds(Collections.emptyList())
       .createdOn(offsetDateTime)
       .createdBy(userEntity.getId())
       .updatedBy(userEntity.getId())
       .updatedOn(offsetDateTime)
       .build(); 

    UserName userName = userMapper.toUserNameResult(SequenceGenerator.getInstance().nextId(),
      generatedUserName,userEntity,userEntity.getId(),offsetDateTime);
    
    try {
      userRepository.save(userEntity);
      userIndustryRepository.save(userIndustry); 
      signupStatusRepository.save(signupStatus);  
      userFollowerRepository.save(userFollower); 
      notificationSettingsRepository.save(notificationSetting);
      userOverViewRepository.save(userOverView);
      userWiseConnectionRepository.save(userWiseConnection);
      userNameRepository.save(userName);

			// after user is created, referenceId and mobileNo will be update dfrom here in RequestIpAdd table
			requestIpRepository.updateRefernceId(userEntity.getId(), userEntity.getMobileNo());
     
      return phaseOneToken(userId, Roles.ROLE_USER, signupStatus.getStatus(), userEntity);
    } 
    catch(Exception exception) {
      log.info("Error while saving User data",exception);
      throw new BadRequestException("Error occured while saving User data",exception);
    }
  }

  private ResponseDto phaseOneToken(String userId, Roles roleSignup, String status, UserEntity user) {
    log.info("[phaseOneToken] to phase one token");
    
    String token = tokenProvider.createToken(userId, roleSignup.role());

    UserBasicDetailDto dto = null;

    if(!ObjectUtils.isEmpty(user)) {
      dto = UserBasicDetailDto.builder().id(user.getId()).name(user.getFullName()).build();
    }

    return ResponseDto.builder()
      .token(token)
      .flag(status)
      .createUser(true)
      .user(dto)
      .build();
  }

  @Override
  public Boolean updateUser(UserRegistrationDto userRegistrationDto, String userId)
    throws InterruptedException, ExecutionException, TimeoutException, IOException {
    log.info("[updateUser] update user with userId: {}", userId);

    UserEntity user = userRepository.findById(userId)
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId));

    if (user.getIsHide() != null && user.getIsHide()) {
      log.info("[updateUser] isHide true"); 
      throw new BadRequestException("Your profile is under review, you can not edit your profile");
    } 
    else {  
      OffsetDateTime offsetDateTime = offsetDateTime();
      UserEntity data = userMapper.toUserEntityFromDto(userRegistrationDto,user,offsetDateTime);

      if(ObjectUtils.isEmpty(user.getEmailId())) {
        data.setEmailVerify(false);
      }
      else if(user.getEmailId().equals(userRegistrationDto.getEmailId())) { //same emailId
        data.setEmailVerify(user.getEmailVerify());
      }
      else {
        data.setEmailVerify(true);  //diff
      }
      if (!user.getMobileNo().equals(userRegistrationDto.getMobileNo())) { 
        Optional<String> signupStatus = signupStatusRepository.findByMobileNo(user.getMobileNo());
        
        try{
          producer.updateMobileNo(user.getMobileNo(), userRegistrationDto.getMobileNo(),signupStatus.get());
        } 
        catch (Exception e) {
          log.info("[updateuser] Error while producing data in Signup",e);
          throw new BadRequestException("Error while producing data in Signup",e);
        }
      }
        try {
          userRepository.save(data);
        } 
        catch (Exception e) {
          log.info("[updateUser] Error while saving data in User {}",e);
          throw new BadRequestException("Error while saving data in User {}",e);
        }
    }
    return true;
  }
 
  @Transactional(rollbackFor = Exception.class)
  @Override   
  public UserPersonalDetails getUserData(String authUserId, String userId)  
      throws InterruptedException, ExecutionException, TimeoutException {
    log.info("[getUserData] check userId passed or not userId : {}, id : {}", authUserId, userId);
    
    Boolean userItSelf = authUserId.equals(userId);  

    userVerification(authUserId);
    UserEntity user = userVerification(userId);

    NotificationSetting setting = notificationSettingsRepository.findByUserId(userId)
      .orElseThrow(() -> new BadRequestException("Invalid request"));
    
    UserPersonalDetails data = new UserPersonalDetails();

    if(!userItSelf 
        && blockUserRepository.isBlockedUser(authUserId, userId, 
            BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin()) ){
      
      data = userBlockedMapper.toUserPersonalDetails(user, true);
      return data;
      
    }
    UserOverView userOverView = userOverViewRepository.findByUserId(userId);
    String connectionStatus = userConnectionRepository.checkConnectionStatus(authUserId, userId).orElse("");

    if(!userItSelf) {
      userOverViewRepository.increaseViewCount(userId);
      createProfileViewNotification(authUserId, userId);
    }

    if((setting.getNetworkProfile().equals("2") //private
        && userConnectionRepository.checkUserConnected(authUserId,userId).isPresent())
        || setting.getNetworkProfile().equals("1")) {
      
      if(!userItSelf && user.getIsHide()) {    //In case user profile is reported
        data = userMapper.userToUserPersonalLockedDetails(user, true);

        Entities entities = null;
        entities = companyRepository.findEntityByUserId(userId);
        if(!ObjectUtils.isEmpty(entities)) {
          data.setCompanies(Collections.singletonList(entities.getId()));
          data.setEntityName(entities.getName());
        }
        data.setIsBlocked(false);
        return data;
      } else {
        boolean checkUserNotInNetwork = ObjectUtils.isEmpty(connectionStatus) || connectionStatus.equals(ConnectionStatus.INITIATE.connectionStatus());

        if(!userItSelf && checkUserNotInNetwork && setting.getNetworkProfile().equals("2")) { ////* */CHECK
          data = userMapper.userToUserPersonalLockedDetails(user, true);
        } else {
          data = toGetCompanyDataByUser(authUserId, userId, user, userOverView);
        }
      } 
      
      data.setConnection(userOverView.getConnections());
      data.setIsRequested(connectionStatus.equalsIgnoreCase(ConnectionStatus.INITIATE.connectionStatus()));
      data.setIsConnected(connectionStatus.equalsIgnoreCase(ConnectionStatus.ACCEPT.connectionStatus())); 
      
      setConnectionStatusAndRequestId(authUserId, userId, data, connectionStatus);

      if(data.getConnectionStatus().equals(UserProfileConnectionStatus.CONNECTED)) {
        data.setIsLocked(false);
      
        data.setCover(user.getCover());
        data.setIsBlocked(false);
        return data;
      }  
    } else if((setting.getNetworkProfile().equals("2") && 
      userConnectionRepository.checkUserConnected(authUserId, userId).isEmpty())) {
        
        data = userMapper.toPrivateNotConnectedUserData(user,user.getIsHide());
        data.setConnection(userOverView.getConnections());
        data.setIsRequested(connectionStatus.equalsIgnoreCase(ConnectionStatus.INITIATE.connectionStatus()));
        if(userItSelf) {
          data = toGetCompanyDataByUser(authUserId, userId, user, userOverView);
        }
        data = setConnectionStatusAndRequestId(authUserId, userId, data, connectionStatus);

        data.setCover(user.getCover());
        data.setIsBlocked(false);
        return data;
    }
    
    data.setCover(user.getCover());
    data.setIsBlocked(false);
    return data;
  }

  private UserEntity userVerification(String userId) {
    UserEntity user = userRepository.findById(userId)
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId));
    return user;
  }

  private UserPersonalDetails toGetCompanyDataByUser(String authUserId, String userId, UserEntity user,
      UserOverView userOverView) {
    Boolean userItSelf = authUserId.equals(userId);

    UserPersonalDetails data;
    Entities entities = null;
    entities = companyRepository.findEntityByUserId(userId);
    NotificationSetting setting = notificationSettingsRepository.findByUserId(userId)
      .orElseThrow(() -> new BadRequestException("Invalid request"));
      
    data = userMapper.userToUserPersonalDetails(user, entities, userOverView.getConnections(),
      userOverView.getFollowers(),userOverView.getFollowings());
    if(!ObjectUtils.isEmpty(entities))
      data.setCompanies(Collections.singletonList(entities.getId()));
    
    if(setting.getNetworkProfile().equals("1")) {
      data.setIsLocked(false);
    }
    else if(setting.getNetworkProfile().equals("2") && userItSelf) {
      data.setIsLocked(false);
    }
    else if(setting.getNetworkProfile().equals("2") && !userItSelf) {
      data.setIsLocked(true);
    }
    if(ObjectUtils.isEmpty(followerRepository.checkIsFollowing(authUserId,userId))) {
    data.setIsFollowing(false);  
    }
    else {
      data.setIsFollowing(true);
    }
    return data;
  }

  private UserPersonalDetails setConnectionStatusAndRequestId(String authUserId, String userId, UserPersonalDetails data,
      String connectionStatus) {

    if(connectionStatus.equals(ConnectionStatus.ACCEPT.connectionStatus())) {
      String id = userConnectionRepository.checkAcceptStatus(authUserId,userId);
      data.setConnectionStatus(UserProfileConnectionStatus.CONNECTED);
      data.setRequestId(id);
      return data;
    }
    else if(connectionStatus.equals(ConnectionStatus.INITIATE.connectionStatus())) {
      String requestIdSent = userConnectionRepository.checkInitiateStatusFromSent(authUserId,userId); // from-> sent
      
      if(!ObjectUtils.isEmpty(requestIdSent)) {
        data.setConnectionStatus(UserProfileConnectionStatus.SENT);
        data.setRequestId(requestIdSent);
        return data;
      }
      else {
        data.setConnectionStatus(UserProfileConnectionStatus.RECEIVED);  //request sent from userId side
        String requestIdReceived = userConnectionRepository.checkInitiateStatusFromReceived(authUserId, userId);
        data.setRequestId(requestIdReceived);
        return data;
      }
    }
    else if(connectionStatus.equals("")) {
      data.setConnectionStatus(UserProfileConnectionStatus.NEW);
      return data;
    }
    return data;
  }

  private void createProfileViewNotification(String authUserId, String userId) 
    throws InterruptedException, ExecutionException, TimeoutException {

    log.info("[createProfileViewNotification] user profile viewed by another user send notification, userID : {}, id: {}", authUserId, userId);

    NotificationEventAvro eventAvro = notificationMapper.buildNotificationEvent(
      userId + "_" + NotificationTypes.PROFILE_VIEW.types(), authUserId, userId, NotificationTypes.PROFILE_VIEW, authUserId);

    notificationProducer.produceNotificationEvent(eventAvro, b2bProperties.getTopic().getProfileViewEvent());
  }
  
  @Override
  public UserDetails getUserPersonalData(String userId) {
    log.info("[getUserPersonalData] get user data with user: {}", userId);

    UserEntity userEntity = userRepository.findById(userId)
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId));

    Entities user = companyRepository.findEntityByUserId(userId);

    return userMapper.toUserDetails(userEntity,user);
  }
  
  @Override
  public UserRegistrationDto getUser(String userId) {
    log.info("[getUser] to get user data by userId");

    UserEntity userEntity = userRepository.findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId));

    return userMapper.toUserData(userEntity);
  }

  @Override
  public ListingResponse getProfileViewer(String userId, ListingRequest request) {
    log.info("[getProfileViewer] get user profile viewer list userId : {}", userId);

    Pageable paging = PageRequest.of(request.getPage(),
      b2bProperties.getPaging().getConnectionSize());
      // , Sort.by(Direction.DESC, "updated_on")); 
    
    List<IProfileViewerResponse> list = 
      profileViewerRepository.getProfileViewer(userId,BlockedStatus.BLOCKED.status(),BlockOrigin.USER.origin(),paging);
    List<ProfileViewerResponse> result = userProfileViewerMapper.toResult(list);

    return new ListingResponse(result, request.getPage());
  }

  @Override
  public void updateUserName(String authUserId, String userName) {

    log.info("[updateUserName] to update userName");

    UserEntity user = userRepository.findById(authUserId)
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", authUserId));

    UserName result = userNameMapper.toResult(SequenceGenerator.getInstance().nextId(), userName, 
      offsetDateTime(), authUserId, user);

    try {
      userNameRepository.save(result);
    } catch (Exception e) {
      log.info("Error while saving data",e);
      throw new BadRequestException("Error while saving data", e);
    }
  }

  private OffsetDateTime offsetDateTime() {
    return new Date().toInstant().atOffset(ZoneOffset.UTC);
  }
}
