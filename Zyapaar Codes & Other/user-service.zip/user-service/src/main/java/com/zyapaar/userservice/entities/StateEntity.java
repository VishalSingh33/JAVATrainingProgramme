package com.zyapaar.userservice.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * The persistent class for the state database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="state")
public class StateEntity {

	@Id
	@NotNull
	@Column(name = "id",nullable = false)
	private String id;

	@Column(name="country_id")
	private String countryId;

	@NotNull
	@Column(name="created_by",nullable = false,length = 19)
	private String createdBy;

	@NotNull
	@Column(name="created_on")
	private OffsetDateTime createdOn;

	@Column(name="state_name")
	private String stateName;

	@Column(name="updated_by",length = 19)
	private String updatedBy;

	@Column(name="updated_on")
	private OffsetDateTime updatedOn;

	// bi-directional many-to-one association to Entity
	@OneToMany(targetEntity=Entities.class, mappedBy="state", fetch=FetchType.LAZY,cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	private List<Entities> entities;



	
}
