package com.zyapaar.userservice.service;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.userservice.dto.RegistrationDto;
import com.zyapaar.userservice.dto.ResponseDto;
import com.zyapaar.userservice.dto.UserDetails;
import com.zyapaar.userservice.dto.UserPersonalDetails;
import com.zyapaar.userservice.dto.UserRegistrationDto;

/**
 * A service class for the user registration
 * 
 * @author CHiRAG RATHOD
 */
public interface UserService {

  ResponseDto createUser(String mobileNo, RegistrationDto registrationDto);

  public Boolean updateUser(UserRegistrationDto userRegistrationDto, String userId)
     throws InterruptedException, ExecutionException, TimeoutException, IOException;

  public UserPersonalDetails getUserData(String userId, String id)
      throws InterruptedException, ExecutionException, TimeoutException;

  public UserDetails getUserPersonalData(String userId);

  UserRegistrationDto getUser(String userId);

  public ListingResponse getProfileViewer(String userId, ListingRequest request);

void updateUserName(String authUserId, String userName);

}
