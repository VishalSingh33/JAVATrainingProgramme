package com.zyapaar.userservice.service;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;
import javax.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.OperationNotAllowedException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.userservice.dto.BlockOrigin;
import com.zyapaar.userservice.dto.BlockedStatus;
import com.zyapaar.userservice.dto.ConnectionRequestListingDto;
import com.zyapaar.userservice.dto.ConnectionStatus;
import com.zyapaar.userservice.dto.CreateConnectionRequestDto;
import com.zyapaar.userservice.dto.RequestStatus;
import com.zyapaar.userservice.dto.RequestType;
import com.zyapaar.userservice.dto.UpdateConnectionRequestDto;
import com.zyapaar.userservice.dto.UserList;
import com.zyapaar.userservice.dto.UserPersonalDto;
import com.zyapaar.userservice.dto.UserRequestType;
import com.zyapaar.userservice.entities.AllRequest;
import com.zyapaar.userservice.entities.IEntityMemberDto;
import com.zyapaar.userservice.entities.IIndustryCount;
import com.zyapaar.userservice.entities.IUserConnectionDto;
import com.zyapaar.userservice.entities.IndustryCount;
import com.zyapaar.userservice.entities.UserConnection;
import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserWiseConnection;
import com.zyapaar.userservice.mapper.AllRequestMapper;
import com.zyapaar.userservice.mapper.UserConnectionMapper;
import com.zyapaar.userservice.mapper.UserIndustryMapper;
import com.zyapaar.userservice.mapper.UserMapper;
import com.zyapaar.userservice.properties.B2bProperties;
import com.zyapaar.userservice.repository.AllRequestRepository;
import com.zyapaar.userservice.repository.BlockUserRepository;
import com.zyapaar.userservice.repository.UserConnectionRepository;
import com.zyapaar.userservice.repository.UserOverViewRepository;
import com.zyapaar.userservice.repository.UserRepository;
import com.zyapaar.userservice.repository.UserWiseConnectionRepository;
import com.zyapaar.userservice.validation.TimeCount;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * connection service
 * 
 * @author Uday Halpara
 */
@Slf4j
@Service
@RequiredArgsConstructor

public class ManageConnectionService implements ConnectionService {
  
  private final B2bProperties b2bProperties;
  private final UserRepository userRepository;
  private final UserConnectionRepository userConnectionRepository;
  private final UserConnectionMapper userConnectionMapper;
  private final UserMapper userMapper;
  private final AllRequestMapper allRequestMapper;
  private final AllRequestRepository allRequestRepository;
  private final UserIndustryMapper userIndustryMapper;
  private final UserOverViewRepository userOverViewRepository;
  private final UserWiseConnectionRepository userWiseConnectionRepository;
  private final BlockUserRepository blockUserRepository;
  
  @Transactional(rollbackFor = Exception.class)
  @Override       
  public Boolean createConnectionRequest(String fromUserId, String toUserId,CreateConnectionRequestDto connectionDto, 
    ConnectionStatus status) throws InterruptedException, ExecutionException, TimeoutException {
    log.info("[createConnectionRequest] create connection request");

    if (fromUserId.equals(toUserId)) {
      log.info("[createConnectionRequest] both same userId, fromUserId: {}, toUserId: {}", fromUserId, toUserId);
      throw new BadRequestException("You can not send request to yourself");
    }

    if(!status.equals(ConnectionStatus.INITIATE))
      throw new BadRequestException("Status should INITIATE");
    
    boolean isRequest = userConnectionRepository.isUserConnectedOrRequestInitiated(fromUserId, toUserId).isEmpty();
      
    if (isRequest) {
      UserEntity userEntityExistsFrom = userRepository.findById(fromUserId)
        .orElseThrow(() -> new ResourceNotFoundException("user", "id", fromUserId));

      UserEntity userEntityExistsTo = userRepository.findById(toUserId)
        .orElseThrow(() -> new ResourceNotFoundException("user", "id", fromUserId));

      if(blockUserRepository.isBlockedUser(fromUserId, toUserId, BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin())){
        
        log.info("[createConnectionRequest] fromUserId: {}, toUserId: {} is blocked", fromUserId, toUserId);
        throw new BadRequestException("User profile is blocked for you");
      }

      UserConnection userConnection = userConnectionMapper.toUserConnectionFromConnectionDto(
        SequenceGenerator.getInstance().nextId(), new Date().toInstant().atOffset(ZoneOffset.UTC), fromUserId, toUserId, 
        connectionDto, userEntityExistsFrom, userEntityExistsTo, ConnectionStatus.INITIATE.connectionStatus());
        
      Set<String> toUserIds = new HashSet<>();
      toUserIds.add(toUserId);

      AllRequest allRequest = allRequestMapper.toCreateRequest(SequenceGenerator.getInstance().nextId(), 
        UserRequestType.USER.status(), ConnectionStatus.INITIATE.connectionStatus(), userConnection.getId(),fromUserId, 
        toUserIds, new Date().toInstant().atOffset(ZoneOffset.UTC),true);

      try {
        userConnectionRepository.save(userConnection);
        allRequestRepository.save(allRequest);

        return true;
      } catch(Exception exception) {
        log.info("Data is not saved in User-Connection");
        throw new BadRequestException("Exception occured while saving Data in User-Connection:{}",exception);
      }
    } else {
      log.info("[createConnectionRequest] user is already requested.");
      throw new BadRequestException("You have already requested");
    }
  }

  @Transactional(rollbackFor = Exception.class) 
  @Override 
  public boolean updateConnectionRequestStatus(String userId, String toUserId, ConnectionStatus status,
    UpdateConnectionRequestDto connectionDto) throws InterruptedException, ExecutionException, TimeoutException {

    log.info("[updateConnectionRequestStatus] connection request to user: {} and from user: {}", userId, toUserId);

    if(status.equals(ConnectionStatus.INITIATE) || status.equals(ConnectionStatus.REMOVE)) {  
      throw new BadRequestException("Invalid status");
    }
    String oldRequest = userConnectionRepository.requestExistsById(connectionDto.getId(), userId, toUserId)
      .orElseThrow(() ->  {
          log.info("User-connection not found with id {}",connectionDto.getId());
          throw new OperationNotAllowedException("");
        }
      );
    
    if(!ObjectUtils.isEmpty(oldRequest)) {
      return updateConnectionRequest(userId, toUserId,connectionDto.getId(), status);
    } else {
      throw new BadRequestException("Request not exist");
    }
  }
  
  private Boolean updateConnectionRequest(String userId, String fromUserId, String id, ConnectionStatus status) {

    if(blockUserRepository.isBlockedUser(fromUserId, userId, BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin())){

      log.info("[updateConnectionRequest] fromUserId: {}, toUserId: {} is blocked", fromUserId, userId);
      throw new BadRequestException("User profile is blocked for you");
    }
    UserConnection userConnection = userConnectionRepository.findByIdAndInitiateStatus(
        id, ConnectionStatus.INITIATE.connectionStatus()
      )
      .orElseThrow(() -> new ResourceNotFoundException("user-connection", "id", id));
    
    AllRequest allRequest = allRequestRepository.findByRequestIdAndInitiateStatus(
      id, ConnectionStatus.INITIATE.connectionStatus()
    )
    .orElseThrow(() -> new ResourceNotFoundException("all-request", "id", id));

    OffsetDateTime offsetDateTime = new Date().toInstant().atOffset(ZoneOffset.UTC);
    
    UserConnection userConnection2 = userConnectionMapper.toUserConnectionFromOldData(userConnection,
      offsetDateTime, fromUserId, status.connectionStatus());
    
    allRequest.setStatus(status.connectionStatus());
    
    allRequest.setIsActive(false);
    
    List<UserWiseConnection> userConnections = null;

    if(status.equals(ConnectionStatus.ACCEPT)) {
      allRequest.setIsActive(true);
      userConnections = generateUserWiseConnections(userConnection2, true);
    }

    try {
      userConnectionRepository.save(userConnection2);
      allRequestRepository.save(allRequest);

      if(status.equals(ConnectionStatus.ACCEPT)) {    // count++ 
        userOverViewRepository.increaseConnectionCount(userId, fromUserId);
        userWiseConnectionRepository.saveAll(userConnections);
      }
      return true;
    } 
    catch (Exception e) {
      log.info("Error while saving data",e);
    }
    return true;
  }

  private List<UserWiseConnection> generateUserWiseConnections(UserConnection userConnection, final boolean isAccept) {
    List<UserWiseConnection> userWiseConnectionList = new ArrayList<>();
    
    userWiseConnectionRepository
      .findByFromAndToUserId(userConnection.getUser1(), userConnection.getUser2())
      .ifPresentOrElse(
        (data) -> {
          List<UserWiseConnection> lData = data
              .stream()
              .filter((d) -> !ObjectUtils.isEmpty(d))
              .map((d) -> {
                if(d.getId().equals(userConnection.getUser1().getId())) {
                  List<String> list = d.getUserIds();
                  if(isAccept) {
                    list.add(userConnection.getUser2().getId());
                  } else {
                    list.remove(userConnection.getUser2().getId());
                  }
                    
                  d.setUserIds(list);
                } else if(d.getId().equals(userConnection.getUser2().getId())) {
                  List<String> list = d.getUserIds();
                  if(isAccept) {
                    list.add(userConnection.getUser1().getId());
                  } else {
                    list.remove(userConnection.getUser1().getId());
                  } 
                  d.setUserIds(list);
                }
                
                return d;
              })
              .collect(Collectors.toList());

            userWiseConnectionList.addAll(lData);
        }, 
        () -> {}
      );
    return userWiseConnectionList;
  }

  @Transactional(rollbackFor = Exception.class)
  @Override 
  public void removeConnection(String userId, String toUserId)
    throws InterruptedException, ExecutionException, TimeoutException {

    log.info("[removeConnection] You:{} want to remove connection with User:{}",userId,toUserId);

    UserConnection userConnection = userConnectionRepository.checkUserConnected(userId, toUserId)
      .orElseThrow(() -> new ResourceNotFoundException("user-connection","id", toUserId));
   
    OffsetDateTime offsetDateTime = new Date().toInstant().atOffset(ZoneOffset.UTC);
     
    UserConnection oldConnectionData = userConnectionMapper.toUserConnectionFromOldData(userConnection,
      offsetDateTime, userId,ConnectionStatus.REMOVE.connectionStatus());
    
    AllRequest allRequest = allRequestRepository.findByRequestId(userConnection.getId())
    .orElseThrow(() -> new ResourceNotFoundException("all-request", "id", userConnection.getId()));

    allRequest.setStatus(ConnectionStatus.REMOVE.connectionStatus());
    allRequest.setIsActive(false);

    userOverViewRepository.decreaseConnectionCount(userId,toUserId);
    
    List<UserWiseConnection> userConnections = generateUserWiseConnections(oldConnectionData, false);
    
    try {
      userConnectionRepository.save(oldConnectionData);
      allRequestRepository.save(allRequest);
      userWiseConnectionRepository.saveAll(userConnections);
    } catch (Exception e) {
      log.info("Error while saving data",e);
      throw new BadRequestException("Error while saving data", e);
    }
  }

  @Override
  public ListingResponse getConnectionRequestList(String userId, ListingRequest request, RequestType type) {
  
    log.info("[getConnectionRequestList] get connection request received list");

    userVerification(userId);
   
    List<ConnectionRequestListingDto> listingDtos = new ArrayList<>();
    Slice<UserConnection> data = null;          
         
    if (type.equals(RequestType.RECEIVED)) {  //findBy=>To  
    log.info("[getConnectionRequestList] get user RECEIVED connection list");

    Pageable paging = PageRequest.of(request.getPage(),
      b2bProperties.getPaging().getConnectionSize(), Sort.by(Direction.DESC, "updated_on"));
    
    data = userConnectionRepository.findByToUserId(userId, ConnectionStatus.INITIATE.connectionStatus(), paging);

      for (UserConnection userConnection : data.getContent())  
      {
        UserPersonalDto personalDto = userMapper.userToUserPersonalDto(
          userRepository.findById(userConnection.getUser1().getId())    //FromUserId (user1)
            .orElseThrow(() -> new ResourceNotFoundException("user", "id", userConnection.getUser1().getId())));
        
        String ageOfRequest = TimeCount.timeFromUpload(userConnection.getCreatedOn());

        listingDtos.add(userConnectionMapper.toConnectionRequestListingDtoReceivedList(userConnection, personalDto,
            ageOfRequest,userId)); 
      }
    } 
    else { // RequestType is SENT
    
      log.info("[getConnectionRequestList] get connection request SENT list");
      
      Pageable paging = PageRequest.of(request.getPage(),
          b2bProperties.getPaging().getConnectionSize(), Sort.by(Direction.DESC, "updated_on"));
  
      data = userConnectionRepository.findByFromUserId(userId, ConnectionStatus.INITIATE.connectionStatus(),
          paging);
        
      for (UserConnection userConnection : data.getContent())  
      {
        UserPersonalDto personalDto = userMapper.userToUserPersonalDto(
          userRepository.findById(userConnection.getUser2().getId())  //To_userId (user2)
            .orElseThrow(() -> new ResourceNotFoundException("user", "id", userConnection.getUser2().getId())));

        String ageOfRequest = TimeCount.timeFromUpload(userConnection.getCreatedOn());

        listingDtos.add(userConnectionMapper.toConnectionRequestListingDtoSentList(userConnection, personalDto,
            ageOfRequest,userId)); 
      }
    }

    return new ListingResponse(listingDtos, data.getPageable().getPageNumber());
  }

  @Override
  public ListingResponse getConnectionList(String userId, ListingRequest request, String industryId, String id) {
    log.info("[getConnectionList] get Connection List");

    if (id != null) {
      userId = id;
    }
    
    if(industryId.equals("ALL")) {   
      log.info("[getConnectionList] In Industry type: ALL");  
      return getUserConnections(userId, request);
    } 
    
    log.info("[getConnectionList] get Industry wise Connections List");
    return findUserConnectionsByIndustry(userId, industryId, request);
  }

  public ListingResponse findUserConnectionsByIndustry(String userId, String industryId, ListingRequest request) {
    log.info("[getUserConnections] get User Connection List");
    
    userVerification(userId);

    Pageable paging = PageRequest.of(request.getPage(), b2bProperties.getPaging().getConnectionSize(),
      Sort.by(Direction.DESC, "updated_on")); 

    return userRepository.findUserConnectionsByIndustry(userId, industryId, 
    RequestStatus.ACCEPT.status(), paging)
      .map((users) -> new ListingResponse(userMapper.toUserBasicDetailDto(users), request.getPage()))
      .get();
  }

  @Override    
  public List<IndustryCount> userConnectionsIndustries(String userId) { 
    log.info("[userConnectionsIndustries] get user wise industry list");

    List<IIndustryCount> data = userWiseConnectionRepository.findIndustryByUser(userId);
    List<IndustryCount> result = new ArrayList<>();
    result.addAll(userIndustryMapper.toResult(data));
    return result;
  
  }

  @Override 
  public Long getAllRequestCount(String userId)  {  //Received
    log.info("[getUserConnectionRequestCount] get user connection request count");

    userVerification(userId);
      
    log.info("Request Count of INITIATE,JOIN,INVITE status by userId:{}",userId);

    return allRequestRepository.allRequestCount(userId);
  }

  @Override 
  public Long getUserConnectionRequestCount(String userId)  {
    log.info("[getUserConnectionRequestCount] get user connection request count");

    userVerification(userId);
      
    log.info("Request Count of INITIATE status by userId:{}",userId);

    return userConnectionRepository.countByUserId(userId); //INITIATE and to_user_id=userId
  }

  @Override 
  public Long getUserConnectionsCount(String userId) { 

    log.info("[getUserConnectionsCount] get user Connections count");
     
    userVerification(userId); 
    return userConnectionRepository.countByUserIdFromOverView(userId); 
    }
    
  @Override
  public ListingResponse getUserConnections(String userId, ListingRequest request) {
    log.info("[getUserConnections] get User Connection List");
    
    userVerification(userId);

    Pageable paging = PageRequest.of(request.getPage(), b2bProperties.getPaging().getConnectionSize(),
      Sort.by(Direction.DESC, "updated_on"));

    return userRepository.findUserConnectionsById(userId,
      paging, RequestStatus.ACCEPT.status())
      .map((users) -> new ListingResponse(userMapper.toUserBasicDetailDto(users), request.getPage()))
      .get();
  }

  @Override
  public ListingResponse getConnectionRequestListByType(String userId, RequestType type,
      UserRequestType userRequestType, @Valid ListingRequest request) {
    log.info("[getConnectionRequestListByType] get connection request list by type");

    if(userRequestType.equals(UserRequestType.ALL)) {

      Pageable paging = pagination(request);
      return allSentReceivedRequestByUser(type, userId, paging);   

    } else if(userRequestType.equals(UserRequestType.USER)) {

      Pageable paging = PageRequest.of(request.getPage(), b2bProperties.getPaging().getConnectionSize(),
      Sort.by(Direction.DESC, "cr.created_on"));  

      return userSentReceivedRequestByUser(type, userId, paging);
    } else if(userRequestType.equals(UserRequestType.COMPANY)) {

      Pageable paging = pagination(request);
      return copmpanySentReceivedRequestByUser(type, userId, paging);

    } else if(userRequestType.equals(UserRequestType.PAGE)) { 
      
      Pageable paging = pagination(request);
      return pageSentReceivedRequestByUser(type, userId, paging);
    }
    
    return new ListingResponse();
  }

  private Pageable pagination(ListingRequest request) {
    Pageable paging = PageRequest.of(request.getPage(), b2bProperties.getPaging().getConnectionSize());
    return paging;
  }

  private ListingResponse pageSentReceivedRequestByUser(RequestType type, String userId, Pageable paging) {
    List<IEntityMemberDto> response = null;

    if(type.equals(RequestType.RECEIVED)) {  //to_id
      response = allRequestRepository.pageReceivedRequests(userId, paging);
    } else if(type.equals(RequestType.SENT)) {  //from_id
      response = allRequestRepository.pageSentRequests(userId, paging);
    }

    return new ListingResponse(response, paging.getPageNumber());
  }

  private ListingResponse allSentReceivedRequestByUser(RequestType type, String userId, Pageable paging) {    
    List<IUserConnectionDto> response = null;

    if(type.equals(RequestType.RECEIVED)) {                       //to_id
      response = allRequestRepository.allReceivedRequestByUser(userId, paging);
    } else if(type.equals(RequestType.SENT)) {                    //from_id
      response = allRequestRepository.allSentRequestByUser(userId, paging);
    }
    return new ListingResponse(response, paging.getPageNumber());
  }

  private ListingResponse userSentReceivedRequestByUser(RequestType type, String userId, Pageable paging) {    
    List<IUserConnectionDto> response = null;

    if(type.equals(RequestType.RECEIVED)) {  //to_id
      response = allRequestRepository.userReceivedRequests(
          userId, ConnectionStatus.INITIATE.connectionStatus(), paging);
    } else if(type.equals(RequestType.SENT)) {  //from_id
      response = allRequestRepository.userSentRequests(
        userId, ConnectionStatus.INITIATE.connectionStatus(), paging);
    }

    return new ListingResponse(response, paging.getPageNumber());
  }

  private ListingResponse copmpanySentReceivedRequestByUser(RequestType type, String userId, Pageable paging) {    
    List<IEntityMemberDto> response = null;

    if(type.equals(RequestType.RECEIVED)) {  //to_id
      response = allRequestRepository.entityReceivedRequests(userId,paging);
    } else if(type.equals(RequestType.SENT)) {  //from_id
      response = allRequestRepository.entitySentRequests(userId,paging);
    }

    return new ListingResponse(response, paging.getPageNumber());
  }

  @Override
  public ListingResponse getMutualConnectedUserList(String userId, String viewerId,
    ListingRequest request) {

    log.info("[getMutualConnectedUserList] to get Mutual Connected User List");

    Pageable paging = PageRequest.of(request.getPage(),b2bProperties.getPaging().getConnectionSize());

    userVerification(userId);
    userVerification(viewerId);
    
    List<String> l1 = findMutualConnection(userId, viewerId);
    List<UserEntity> data = userRepository.findById(l1,paging);
    List<UserList> result = userMapper.toMutualConnectionList(data);

    return new ListingResponse(result, request.getPage());
  }

  @Override
  public Integer getMutualConnectedUserCount(String userId, String viewerId) {
   
    log.info("[getMutualConnectedUserCount] to get Mutual Connected User Count");
    userVerification(userId);
    userVerification(viewerId);
    List<String> l1 = findMutualConnection(userId, viewerId);
    return l1.size();
  }

  private void userVerification(String userId) {
    userRepository.findById(userId)
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId));
  }

  private List<String> findMutualConnection(String userId, String viewerId) {
    List<String> l1 = userWiseConnection(userId);
    List<String> l2 = userWiseConnection(viewerId);

    l1.retainAll(l2);
    log.info("List1 : {}",l1);
    return l1;
  }

  private List<String> userWiseConnection(String userId) {
    UserWiseConnection userWiseConnection = userWiseConnectionRepository.findById(userId).get();
    List<String> l1 = userWiseConnection.getUserIds();
    return l1;
  }

}
