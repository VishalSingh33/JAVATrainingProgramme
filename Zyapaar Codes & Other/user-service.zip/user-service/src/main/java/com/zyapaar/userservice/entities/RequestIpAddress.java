package com.zyapaar.userservice.entities;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "request_ip_address")
public class RequestIpAddress {

	@Id
	@Column(name = "id")
	private String id;

	@Column(name = "reference_id")
	private String referenceId;

	@Column(name = "phone_number")
	private String phoneNumber;
	
	@Column(name = "created_on")
	private OffsetDateTime createdOn;
	
	private String type;
	
	@Column(name = "ip_address")
	private String ipAddress;
	
}
