package com.zyapaar.userservice.controller;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import javax.validation.Valid;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.exceptionhandler.model.ApiError;
import com.zyapaar.userservice.dto.CreateConnectionRequestDto;
import com.zyapaar.userservice.dto.ConnectionStatus;
import com.zyapaar.userservice.dto.RequestType;
import com.zyapaar.userservice.dto.UpdateConnectionRequestDto;
import com.zyapaar.userservice.dto.UserRequestType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
/**
 * connection controller
 * 
 * @author Uday Halpara
 */

@Validated
@RequestMapping("/api/v1.1")
@Tag(name = "Connection APIs") 
public interface ConnectionController {
  /**
   * 
   * @param userId
   * @param toUserId
   * @param connectionDto
   * @return
   * @throws InterruptedException
   * @throws ExecutionException
   * @throws TimeoutException
   */
  @Operation(
    description = "This Connection api works to create Connection Request use Connection service which"
      + " contains model class (ConnectionRequestDto), ConnectionRequestDto has id, message, status",
    responses = {
        @ApiResponse(content = @Content(schema = @Schema(implementation = Response.class)),
            responseCode = "200",description = "connection request send sucess"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "500", description = "something went wrong"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "400", description = "Bad request")
  })
  @PostMapping(value="/connect/{toUserId}/{status}") 
  public ResponseEntity<Response> createConnectionRequest(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
          @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "toUserId to lookup for request", required = true)
          @PathVariable("toUserId") String toUserId,
          @PathVariable("status") ConnectionStatus status,
      @Parameter(description = "The content under ConnectionRequestDto Dto is used to createConnectionRequest",required = true)
          @RequestBody CreateConnectionRequestDto connectionDto)
      throws InterruptedException, ExecutionException, TimeoutException;

  /**
   * 
   * @param userId
   * @param fromUserId
   * @param connectionDto
   * @return
   * @throws InterruptedException
   * @throws ExecutionException
   * @throws TimeoutException
   */
  @Operation(description = "This Connection api works to update Connection Request Status use Connection service"
  + " which contains model class (ConnectionRequestDto), ConnectionRequestDto has id, message, status",
    responses = {
        @ApiResponse(content = @Content(schema = @Schema(implementation = Response.class)),
            responseCode = "200",description = "connection request processed sucess"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "500", description = "something went wrong"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "400", description = "Bad request")
  })
  @PostMapping(value="/connect/action/{toUserId}/{status}")
  public ResponseEntity<Response> updateConnectionRequestStatus(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
          @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "fromUserId to lookup for request", required = true)
          @PathVariable("toUserId") String toUserId,
          @PathVariable("status") ConnectionStatus status,
      @Parameter(description = "The content under ConnectionRequestDto Dto is used to updateConnectionRequestStatus",required = true)
          @Valid @RequestBody UpdateConnectionRequestDto connectionDto) 
      throws InterruptedException, ExecutionException, TimeoutException;


  @PostMapping(value = "/users/connections/{toUserId}/remove")
  public ResponseEntity<Response> removeConnection(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true) @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "toUserId to lookup for request", required = true)
         @PathVariable("toUserId") String toUserId)
      throws InterruptedException, ExecutionException, TimeoutException;

      
  /**
   * 
   * @param userId
   * @param connectionStatus
   * @param request
   * @return
   */
  @Operation(description = "This Connection api works to get Connection RequestList use Connection service which"
  + " contains model class (ListingRequest), ListingRequest has page",
    responses = {
        @ApiResponse(content = @Content(schema = @Schema(implementation = ListingResponse.class)),
            responseCode = "200",description = "connection request processed sucess"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "500", description = "something went wrong"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "400", description = "Bad request")
  })
  @PostMapping(value = "/connection/{type}/{status}")
  public ResponseEntity<Response> getConnectionRequestList(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
          @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "connectionStatus to lookup for getConnectionRequestList", required = true)
        @PathVariable("type") RequestType type ,
        @PathVariable("status") ConnectionStatus status,
      @Parameter(description = "The content under ListingRequest is used to getConnectionRequestList",required = true)
          @Valid @RequestBody ListingRequest request);
  
          
  @PostMapping(value = "/connection/list/{industryId}")
  public ResponseEntity<Response> getConnectionList(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
          @RequestHeader("Z-AUTH-USERID") String userId,
          @RequestParam(name = "userId", required =  false) String id,  //not required
          @PathVariable("industryId") String industryId ,
      @Parameter(description = "The content under ListingRequest is used to getConnectionRequestList",required = true)
          @Valid @RequestBody ListingRequest request);


  @GetMapping(value = "/users/industries")
  public ResponseEntity<Response> userConnectionsIndustries(@RequestHeader("Z-AUTH-USERID") String userId);

  @GetMapping(value = "/users/request/count") 
  public ResponseEntity<Response> getUserConnectionRequestCount(@RequestHeader("Z-AUTH-USERID") String userId);   
  
  @GetMapping(value = "/users/connection/count") //StateStore
  public ResponseEntity<Response> getUserConnectionsCount(@RequestHeader("Z-AUTH-USERID") String userId); 
  

  @PostMapping(value = "/users/connections/{type}/{userRequestType}")
  public ResponseEntity<Response> getConnectionRequestListByType(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
          @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "RequestType is RECEIVED or SENT", required = true)
        @PathVariable("type") RequestType type ,
        @PathVariable("userRequestType") UserRequestType userRequestType,
      @Parameter(description = "The content under ListingRequest is used to getConnectionRequestListByType",
        required = true) @Valid @RequestBody ListingRequest request);

  @GetMapping(value = "/mutual/count/{viewerId}") 
  public ResponseEntity<Response> getMutualConnectionCount(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
        @RequestHeader("Z-AUTH-USERID") String userId,
    @Parameter(description = "viewerId to lookup for request", required = true)
        @PathVariable("viewerId") String viewerId ) 
    throws InterruptedException, ExecutionException, TimeoutException;
      
  @PostMapping(value = "/mutual/list/{viewerId}") 
    public ResponseEntity<Response> getUserMutualConnectionList(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
        @RequestHeader("Z-AUTH-USERID") String userId,
    @Parameter(description = "viewerId to lookup for request", required = true)
        @PathVariable("viewerId") String viewerId,
    @Parameter(description = "The content under ListingRequest is used to getConnectionRequestListByType",
        required = true) @Valid @RequestBody ListingRequest request) 
    throws InterruptedException, ExecutionException, TimeoutException;
           
}