package com.zyapaar.userservice.controller;

import javax.validation.Valid;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.userservice.dto.FollowEnum;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * User follower controller
 * 
 * @author Uday Halpara
 */
@Validated
@RequestMapping("/api/v1.1")  
public interface UserFollowerController {

  @GetMapping(value = "/users/{userId}/follow")
  public ResponseEntity<Response> follow(@RequestHeader("Z-AUTH-USERID") String userId,
      @PathVariable(name = "userId") String id);
  
  @GetMapping(value = "/users/{userId}/unfollow")
  public ResponseEntity<Response> unFollow(@RequestHeader("Z-AUTH-USERID") String userId,
      @PathVariable(name = "userId") String id);
  
  @PostMapping(value = "/users/{userId}/followers/{type}")
  public ResponseEntity<Response> getFollowyList(@RequestHeader("Z-AUTH-USERID") String authUserId,
      @PathVariable(name = "type", required = true) FollowEnum followType,
      @PathVariable(name = "userId") String userId,
      @Valid @RequestBody ListingRequest listingRequest);
}
