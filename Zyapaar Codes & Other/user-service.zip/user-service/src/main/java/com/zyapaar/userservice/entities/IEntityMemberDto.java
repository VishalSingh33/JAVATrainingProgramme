package com.zyapaar.userservice.entities;

import org.springframework.stereotype.Component;

@Component
public interface IEntityMemberDto {

  String getId();
  String getFullName();
  String getLogo();
  String getEntityId();
  String getEntityLogo();
  String getEntityName();
  String getRequestId();
  String getType();
  String getAdmin();
}
