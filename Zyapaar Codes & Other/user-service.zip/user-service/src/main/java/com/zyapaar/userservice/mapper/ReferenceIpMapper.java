package com.zyapaar.userservice.mapper;

import java.time.OffsetDateTime;

import org.mapstruct.Mapper;
import com.zyapaar.userservice.entities.RequestIpAddress;

@Mapper
public interface ReferenceIpMapper {


	RequestIpAddress setData(String id, String referenceId, String phoneNumber, OffsetDateTime createdOn,
			String ipAddress, String type);

}
