package com.zyapaar.userservice.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.userservice.dto.RecommendType;
import com.zyapaar.userservice.dto.RecommendationStatus;
import com.zyapaar.userservice.dto.UserRecommendationDto;
import com.zyapaar.userservice.service.RecommendationService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Recommendation Controller
 * 
 * @author Uday Halpara
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/api/v1.1")
@Tag(name = "Recommendation APIs")
public class ManageRecommendationController implements RecommendationController {
  
  private final RecommendationService recommendationService;

  @Override
  public ResponseEntity<Response> userRecommendation(String userId, RecommendationStatus status,
     UserRecommendationDto recommendationDto) {
    log.info("[userRecommendation] to get user recommendation");
    
    recommendationService.addUserRecommendation(userId, status, recommendationDto); 

    return ResponseEntity.status(HttpStatus.OK)
      .body(
        Response.builder()
          .message("User-Recommendation added sucessfully")
          .build());
  }

  @Override
  public ResponseEntity<Response> getRecommendAskOrPending(String userId, RecommendationStatus status, 
    ListingRequest request) {
    log.info("[getRecommendAsk] get recommendation list with ask or pending status");

    if(status.equals(RecommendationStatus.ASK)) {   //INVITATION RECEIVED in UI
      log.info("[getRecommendAskOrPending] get recommendation with ASK status");

      ListingResponse result = recommendationService.getRecommendAsk(userId, request);
      return ResponseEntity.status(HttpStatus.OK).body(Response.builder().data(result).build());
    } 
    else if(status.equals(RecommendationStatus.PENDING)) {   //RECEIVED in UI
      log.info("[getRecommendAskOrPending] get recommendation with PENDING status");

      ListingResponse result = recommendationService.getRecommendPending(userId, request);
      return ResponseEntity.status(HttpStatus.OK).body(Response.builder().data(result).build());
    } 
    else {
      log.info("[getRecommendAskOrPending] Only ASK or PENDING status are valid");
      throw new BadRequestException("Invalid status");
    }
  }

  @Override
  public ResponseEntity<Response> getRecommendByType(String userId, RecommendType type, String id,
     ListingRequest request) {

    log.info("[getRecommendReceived] get recommendation list with received type");

    ListingResponse result = recommendationService.getRecommendByType(id, request,type);
  
    return ResponseEntity.status(HttpStatus.OK)
      .body(
        Response.builder()
          .data(result)
          .build());
  }
  
 }

