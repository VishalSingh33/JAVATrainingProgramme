package com.zyapaar.userservice.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.userservice.entities.UserConnection;

@Repository
public interface UserConnectionRepository extends JpaRepository<UserConnection,String> {

  @Query(
    nativeQuery = true,
    value = "SELECT id FROM user_connection "
      + " WHERE ((from_user_id=:fromUserId AND to_user_id=:toUserId)"
      + " OR (to_user_id=:fromUserId AND from_user_id=:toUserId)) AND (status='accept' OR status='initiate')"
  )
  Optional<String> isUserConnectedOrRequestInitiated(String fromUserId, String toUserId);
  
  @Query(
    nativeQuery = true,
    value = "SELECT id FROM user_connection" 
      + " WHERE id=:id "
      + " AND ((from_user_id = :userId AND to_user_id = :toUserId)" 
      + " OR (to_user_id = :userId AND from_user_id = :toUserId))" 
      + " AND (status = 'initiate' OR status='accept')"
  )
  Optional<String> requestExistsById(String id, String userId, String toUserId);
  
  @Query(
    nativeQuery = true,
    value = "SELECT status FROM user_connection" 
      +" WHERE (" 
      +" (from_user_id=:userId AND to_user_id=:toUserId) OR (to_user_id=:userId AND from_user_id=:toUserId)" 
      +" ) AND (status='initiate' OR status='accept')"
  )
  Optional<String> checkConnectionStatus(String userId, String toUserId); //INITIATE status

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_connection"
    +" WHERE ((from_user_id=:userId AND to_user_id=:toUserId) OR (to_user_id=:userId AND from_user_id=:toUserId))"
    +" AND status='accept'"
  )
  Optional<UserConnection> checkUserConnected(String userId, String toUserId);

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_connection WHERE to_user_id=:userId AND status=:connectionStatus"
  )
  Slice<UserConnection> findByToUserId(String userId, String connectionStatus, Pageable paging);

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_connection WHERE from_user_id=:userId AND status=:connectionStatus"
  )
  Slice<UserConnection> findByFromUserId(String userId, String connectionStatus, Pageable paging);

  @Query(
    nativeQuery = true,
    value = "SELECT count(id) FROM user_connection WHERE to_user_id=:userId AND status='initiate'"
  )
  Long countByUserId(String userId);  ///

  @Query(
    nativeQuery = true,
    value = "SELECT connections FROM user_overview WHERE user_id= :userId"
  )
  Long countByUserIdFromOverView(String userId); 

  @Query(
    nativeQuery = true,
    value = "(SELECT from_user_id FROM user_connection WHERE to_user_id=:userId AND status='accept')"+
      " UNION (SELECT to_user_id FROM user_connection WHERE from_user_id=:userId AND status='accept')"
  )
  List<String> findByToAndFromAndAcceptedStatus(String userId); //Accept ,to & from both sides


  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_connection WHERE id=:id AND status=:status"
  )
  Optional<UserConnection> findByIdAndInitiateStatus(String id, String status);

  @Query(
    nativeQuery = true,
    value = "SELECT id from user_connection WHERE from_user_id=:authUserId AND to_user_id=:userId"
    + " AND status='initiate'"
  )
  String checkInitiateStatusFromSent(String authUserId, String userId);  //SENT SIDE

  @Query(
    nativeQuery = true,
    value = "SELECT id from user_connection WHERE from_user_id=:userId AND to_user_id=:authUserId"
    + " AND status='initiate'"
  )
  String checkInitiateStatusFromReceived(String authUserId, String userId);  //RECEIVED SIDE

  @Query(
    nativeQuery = true,
    value = "SELECT id from user_connection WHERE from_user_id=:authUserId AND to_user_id=:userId"
    + " AND status='accept'"
  )
  String checkAcceptStatus(String authUserId, String userId);

}
