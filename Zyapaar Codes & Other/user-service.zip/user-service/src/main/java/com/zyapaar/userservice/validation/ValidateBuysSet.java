package com.zyapaar.userservice.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Set;
import java.util.regex.Pattern;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

import lombok.extern.slf4j.Slf4j;

/**
 * Buys Product Set Validation Custom Annotation
 * 
 * @author Uday Halpara
 */
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy =  ValidateBuysSet.Validators.class)
public @interface ValidateBuysSet {
  String message() default "Invalid buys products";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  /**
   * validator class for Buys Product
   * 
   * @author Uday Halpara
   */
  @Slf4j
  class Validators implements ConstraintValidator<ValidateBuysSet, Set<String>> {

    /**
     * file validation checking Method
     */
    @Override
    public boolean isValid(Set<String> products, ConstraintValidatorContext context) {
      log.info("[isValid] validate buys products");
      boolean result = true;
      String template = null;

      if (products != null && products.size() != 0) {
        log.info("[isValid] buys product set is not null");
        
        Pattern p = Pattern.compile("[Kk][0-9]{8}[-][Ss][0-9]{8}");
        boolean all = products.stream().allMatch(prod -> p.matcher(prod).matches());

        if (!all) {
          log.info("[isValid] invalid buys product id found");
          template = "Please select valid buys products";
        }
      }
      if (template != null) {
        context.disableDefaultConstraintViolation();
        context
            .buildConstraintViolationWithTemplate(template)
            .addConstraintViolation();
        result = false;
      }
      return result;
    }

  }
}
