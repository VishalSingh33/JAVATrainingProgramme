package com.zyapaar.userservice.dto;

/**
 * It is used to define firm type
 * 
 * @author CHiRAG RATHOD
 */
public enum EntityType {

  PROPRIETORSHIP(1),
  PARTNERSHIP_LLP(2),
  PUBLIC_LIMITED_COMPANY(3),
  PVT_LIMITED_COMPANY(4),
  TRUST(5),
  SOCIETIES(6),
  ASSOCIATIONS_CLUB(7),
  BANK_FINANCIAL_INSTITUTATION(8),
  EDUCATION_INSTUATION(9),
  GOVERNMENT_PUBLIC_SECTOR_Undertaking(10),
  OTHERS(11);

  private final Integer firmType;

  EntityType(Integer firmType) {
    this.firmType = firmType;
  }

  public Integer firmType() {
    return firmType;
  }

  public static EntityType fromInteger(Integer text) {
    for (EntityType b : EntityType.values()) {
      if (b.firmType == text) {
        return b;
      }
    }
    return null;
  }
}
