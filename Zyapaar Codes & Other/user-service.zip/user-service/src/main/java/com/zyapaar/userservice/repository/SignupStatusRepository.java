package com.zyapaar.userservice.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.userservice.entities.SignupStatus;

@Repository
public interface SignupStatusRepository extends JpaRepository<SignupStatus, String> {

  @Query(
    nativeQuery = true,
    value = "SELECT status FROM signup_status WHERE mobile_no=:mobileNo"
  )
  Optional<String> findByMobileNo(String mobileNo);
  
}
