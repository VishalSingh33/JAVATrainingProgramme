package com.zyapaar.userservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="profile_viewer")
public class ProfileViewer {

  @Id
  @NotNull
  private String id;

  @Column(name ="user_id")
  private String userId; //myId

  @Column(name="origin_id")
  private String originId;

  @Column(name= "created_on")
  private Long createdOn;

  @Column(name= "updated_on")
  private Long updatedOn;
  
}
