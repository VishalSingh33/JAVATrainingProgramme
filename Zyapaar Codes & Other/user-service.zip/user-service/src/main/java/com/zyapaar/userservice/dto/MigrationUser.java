package com.zyapaar.userservice.dto;

import java.util.Set;
import com.zyapaar.userservice.validation.IdentityValidation;
import com.zyapaar.userservice.validation.MobileNumberRegValidation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@IdentityValidation(identityNumber = "identityNumber")
@MobileNumberRegValidation(mobileNo = "mobileNo")
public class MigrationUser {
  
  private String userId;
  private String firstName;
  private String lastName;
  private String emailId;
  private String mobileNo;
  private String profileImg;
  private String companyId;
  private String entityLogo;
  private String designation;
  private String verifiedBy;
  private String name;
  private String type;
  private String natureOfBusiness;
  private String addressLine1;
  private String addressLine2;
  private String firmPincode;
  private String city;
  private String contactNo1;
  private String contactNo2;
  private String email;
  private Set<String> sales;
  private Set<String> buys;
  private String about;
  private String identityNumber;
  private String brandName;
  private String state;
  private String country;
  private String inviteId;

}
