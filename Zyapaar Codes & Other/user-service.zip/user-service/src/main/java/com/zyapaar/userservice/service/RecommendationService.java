package com.zyapaar.userservice.service;

import javax.validation.Valid;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.userservice.dto.RecommendType;
import com.zyapaar.userservice.dto.RecommendationStatus;
import com.zyapaar.userservice.dto.UserRecommendationDto;

/**
 * recommendation Service
 * 
 * @author Uday Halpara
 */
public interface RecommendationService {

  ListingResponse getRecommendAsk(String userId, ListingRequest request);

  ListingResponse getRecommendPending(String userId, ListingRequest request);

  void addUserRecommendation(String userId, RecommendationStatus status,
      @Valid UserRecommendationDto recommendationDto);

  ListingResponse getRecommendByType(String id, @Valid ListingRequest request, RecommendType type);

}
