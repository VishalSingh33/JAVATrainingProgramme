package com.zyapaar.userservice.producer;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.zyapaar.serde.NotificationEventAvro;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Notification producer
 * 
 * @author Uday Halpara
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageNotificationProducer implements NotificationProducer {

  private final KafkaTemplate<String, NotificationEventAvro> notificationEventKafkaTemplate;

  @Override
  public void produceNotificationEvent(NotificationEventAvro eventAvro, String topic) {

    log.info("[produceNotificationEvent] produce Notification event");

    String key = String.valueOf(eventAvro.getId());

    ProducerRecord<String, NotificationEventAvro> producerRecord = new ProducerRecord<>(
        topic, key, eventAvro);

    notificationEventKafkaTemplate.send(producerRecord);

  }

}
