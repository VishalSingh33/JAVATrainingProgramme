package com.zyapaar.userservice.repository;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.userservice.dto.IProfileViewerResponse;
import com.zyapaar.userservice.entities.ProfileViewer;

@Repository
public interface ProfileViewerRepository extends JpaRepository<ProfileViewer, String>{

  @Query(nativeQuery = true, 
    value = "select " + 
    "u.id as id,u.full_name as name,u.title as designation, " + 
    "u.img as img,u.cover as cover " + 
    "from " + 
    "profile_viewer pv " + 
    "inner join users u on " + 
    "pv.origin_id = u.id " + 
    "left join block_user bu on " + 
    "((bu.from_user_id = u.id " + 
    "and bu.to_user_id = :userId) " + 
    "or (bu.to_user_id = u.id " + 
    "and bu.from_user_id = :userId)) " + 
    "and bu.status = :status and bu.origin = :origin " + 
    "where " + 
    "bu.id is null and pv.user_id =:userId " + 
    "order by pv.updated_on desc ")
  List<IProfileViewerResponse> getProfileViewer(String userId, String status, String origin, Pageable paging);
  
}
