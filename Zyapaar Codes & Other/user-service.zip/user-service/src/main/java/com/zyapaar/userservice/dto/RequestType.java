package com.zyapaar.userservice.dto;

/**
 * Request type enum
 * 
 * @author Uday Halpara
 */
public enum RequestType {

  RECEIVED, SENT;

}
