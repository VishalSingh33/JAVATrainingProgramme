package com.zyapaar.userservice.controller;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import javax.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.exceptionhandler.model.ApiError;
import com.zyapaar.userservice.dto.RegistrationDto;
import com.zyapaar.userservice.dto.UserPersonalDetails;
import com.zyapaar.userservice.dto.UserRegistrationDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * user detail controller
 * 
 * @author Shreya Shah
 */
@RequestMapping("/api/v1.1")
@Tag(name = "User APIs")
@Validated
public interface UserController {

  @Operation(
    description = "This User-Registration api works to register user use user-registration service which"
        + "contains model class ( Dto), Dto has  ",
    responses = {
        @ApiResponse(content = @Content(schema = @Schema(implementation = Response.class)),
            responseCode = "200", description = "User Registered Sucessfully"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "400", description = "Bad request")})
  @PostMapping(value = "/users/{mobileNo}/registration")
  public ResponseEntity<Response> userRegistration(@PathVariable("mobileNo") String mobileNo,
      @Parameter(
          description = "The content under UserRecommendation Dto is used to Recommendation for user",
          required = true) @Valid @RequestBody RegistrationDto registrationDto);

  @Operation(description = "This user service works to create user details use user service ",
      responses = {
          @ApiResponse(
              content = @Content(schema = @Schema(implementation = UserPersonalDetails.class)),
              responseCode = "200", description = "created successfully"),
          @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
              responseCode = "400", description = "Bad request"),})
  @GetMapping("/users/{userId}")
  public ResponseEntity<Response> userById(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID",
        required = true) @RequestHeader("Z-AUTH-USERID") String authUserId, // viewerId
    @Parameter(description = "id is the UserId of user whose data need to show",
        required = true) @PathVariable(name = "userId") String userId) // someone id(another user)
    throws InterruptedException, ExecutionException, TimeoutException;


  @GetMapping("/user")
  public ResponseEntity<Response> userOwnDetail(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID",
        required = true) @RequestHeader("Z-AUTH-USERID") String authUserId);

  /**
   * update a user in to the kafka topic.
   * 
   * @param userRegistrationDto
   * @return
   * @throws InterruptedException
   * @throws ExecutionException
   * @throws TimeoutException
   * @throws IOException
   */
  @Operation(description = "This user api works to update user details use user service which"
      + " contains model class (UserPersonalDto), UserPersonalDto has id, name, profileTitle, profileImg,"
      + " aboutUs, emailId, mobileNo",
      responses = {@ApiResponse(responseCode = "200", description = "user updated successfully"),
          @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
              responseCode = "400", description = "User is not updated")})
  @PutMapping(value = "/users")
  public ResponseEntity<Response> updateUser(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID",
        required = true) @RequestHeader("Z-AUTH-USERID") String userId,
    @Parameter(description = "The content under UserRegistration Dto is used to update the user",
        required = true) @Valid @RequestBody UserRegistrationDto userRegistrationDto)
    throws InterruptedException, ExecutionException, TimeoutException, IOException;


  @Operation(description = "This user api works to update user details use user service which"
      + " contains model class (UserPersonalDto), UserPersonalDto has id, name, profileTitle, profileImg,"
      + " aboutUs, emailId, mobileNo",
      responses = {@ApiResponse(responseCode = "200", description = "user updated successfully"),
          @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
              responseCode = "400", description = "User is not updated")})
  @GetMapping(value = "/user/{id}")
  public ResponseEntity<Response> getUserById(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID",
          required = true) @RequestHeader("Z-AUTH-USERID") String authUser,
      @PathVariable("id") String userId)
    throws InterruptedException, ExecutionException, TimeoutException, IOException;

  @PostMapping(value = "/users/view")
  public ResponseEntity<Response> getProfileViewer(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID",
          required = true) @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "The content under ListingRequest  is used to get requets page no.",
          required = true) @Valid @RequestBody ListingRequest request);

 @Operation(description = "This user service works to get the user details by its userName and use user service ",
        responses = {@ApiResponse(content = @Content(schema = @Schema(implementation = UserPersonalDetails.class)),
        responseCode = "200", description = "Created successfully"),
    @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
        responseCode = "400", description = "Bad request"),})
  @GetMapping("/user/data/{userName}")
  public ResponseEntity<Response> userDataByUserName(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID",required = true) 
        @RequestHeader("Z-AUTH-USERID") String authUserId, 
    @Parameter(description = "id is the UserId of user whose data need to show",required = true) 
        @PathVariable(name = "userName") String userName) 
    throws InterruptedException, ExecutionException, TimeoutException,IOException;

    @PutMapping("/user/{userName}")
  public ResponseEntity<Response> updateUserName(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID",required = true) 
        @RequestHeader("Z-AUTH-USERID") String authUserId, 
    @Parameter(description = "id is the UserId of user whose data need to show",required = true) 
        @PathVariable(name = "userName") String userName) 
    throws InterruptedException, ExecutionException, TimeoutException,IOException;
    
}
