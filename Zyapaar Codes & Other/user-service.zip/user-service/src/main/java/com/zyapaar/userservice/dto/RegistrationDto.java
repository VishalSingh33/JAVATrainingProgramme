package com.zyapaar.userservice.dto;

import java.util.Set;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import com.zyapaar.userservice.validation.MobileNumberRegValidation;
import com.zyapaar.userservice.validation.ValidateSalesSet;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@MobileNumberRegValidation(mobileNo = "mobileNo")
public class RegistrationDto {

  @NotBlank(message = "Enter a first name")
  @Size(min = 2, message = "Minimum 2 character require")
  @Size(max = 50, message = "Maximum 50 character allowed")
  private String firstName;
  
  @NotBlank(message = "Enter a last name")
  @Size(min = 2, message = "Minimum 2 character require")
  @Size(max = 50, message = "Maximum 50 character allowed")
  private String lastName;

  @Pattern( 
    regexp = "(^(([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$)*", 
    message = "Please enter valid emailId"
  )
  private String emailId;
 
  private String mobileNo;

  @NotNull
  @ValidateSalesSet
  private Set<String> sales;

}