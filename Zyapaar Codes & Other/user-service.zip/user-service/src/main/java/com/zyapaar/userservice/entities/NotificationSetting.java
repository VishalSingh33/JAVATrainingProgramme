package com.zyapaar.userservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "notification_settings")
public class NotificationSetting {

  @Id
  @NotNull
  private String id;

  @Column(name = "comment_email")
  private Boolean commentEmail;

  @Column(name = "comment_mention_email")
  private Boolean commentMentionEmail;

  @Column(name = "comment_mention_push")
  private Boolean commentMentionPush;

  @Column(name = "comment_push")
  private Boolean commentPush;

  @Column(name = "comment_reaction_email")
  private Boolean commentReactionEmail;

  @Column(name = "comment_reaction_push")
  private Boolean commentReactionPush;

  @Column(name = "comment_reply_email")
  private Boolean commentReplyEmail;

  @Column(name = "comment_reply_push")
  private Boolean commentReplyPush;

  @Column(name = "connection_email")
  private Boolean connectionEmail;

  @Column(name = "connection_push")
  private Boolean connectionPush;

  @Column(name = "email_id")
  private String emailId;

  @Column(name = "group_email")
  private Boolean groupEmail;

  @Column(name = "group_push")
  private Boolean groupPush;

  @Column(name = "is_email_verified")
  private Boolean isEmailVerified;

  @Column(name = "message_email")
  private Boolean messageEmail;

  @Column(name = "message_push")
  private Boolean messagePush;

  @Column(name = "network_profile")
  private String networkProfile;

  @Column(name = "page_email")
  private Boolean pageEmail;

  @Column(name = "page_push")
  private Boolean pagePush;

  @Column(name = "post_delivery")
  private String postDelivery;

  @Column(name = "post_mention_email")
  private Boolean postMentionEmail;

  @Column(name = "post_mention_push")
  private Boolean postMentionPush;

  @Column(name = "post_reaction_email")
  private Boolean postReactionEmail;

  @Column(name = "post_reaction_push")
  private Boolean postReactionPush;

  @Column(name = "post_share_email")
  private Boolean postShareEmail;

  @Column(name = "post_share_push")
  private Boolean postSharePush;

  @Column(name = "profile_view_email")
  private Boolean profileViewEmail;

  @Column(name = "profile_view_push")
  private Boolean profileViewPush;

  @Column(name = "recommendation_email")
  private Boolean recommendationEmail;

  @Column(name = "recommendation_push")
  private Boolean recommendationPush;

  @Column(name = "team_email")
  private Boolean teamEmail;

  @Column(name = "team_push")
  private Boolean teamPush;

  @NotNull
  @Column(name = "user_id")
  private String userId;
}