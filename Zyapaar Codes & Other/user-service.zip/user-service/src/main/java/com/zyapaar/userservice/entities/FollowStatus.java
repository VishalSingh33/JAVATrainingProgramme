package com.zyapaar.userservice.entities;

public enum FollowStatus {
  ACTIVE,
  INACTIVE;
}
