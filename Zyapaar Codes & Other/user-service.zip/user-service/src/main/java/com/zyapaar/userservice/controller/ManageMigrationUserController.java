package com.zyapaar.userservice.controller;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import org.springframework.web.bind.annotation.RestController;
import com.zyapaar.userservice.dto.MigrationUser;
import com.zyapaar.userservice.service.MigrationUserService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@AllArgsConstructor
public class ManageMigrationUserController implements MigrationUserController {

  private final Validator validator;
  private final MigrationUserService userService;

  @Override
  public void migrationCreateUser( MigrationUser migrationUser) 
  {
    log.info("[migrationCreateUser] OLD USER : {}", migrationUser);

    // migrationUser.setUserId(userId);

    Set<ConstraintViolation<MigrationUser>> violations = validator.validate(migrationUser);

    if (!violations.isEmpty()) {
      throw new ConstraintViolationException(violations);
    }

    userService.migrationCreateUser(migrationUser);

    // if (Boolean.TRUE.equals(userService.updateMigrationUser(migrationUser)))  {
    //   return ResponseEntity.status(HttpStatus.OK)
    //     .body(Response.builder().message("User updated successfully").build());
    // } 
    // else {
    //   return ResponseEntity.status(HttpStatus.NOT_MODIFIED)   //Changed status from 500
    //     .body(Response.builder().message("User is not updated").build());
    // }
  }
  
}
