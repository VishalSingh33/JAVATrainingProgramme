package com.zyapaar.userservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.zyapaar.userservice.entities.SubIndustry;

@Repository
public interface SubIndustryRepository extends JpaRepository<SubIndustry,String> {

}
