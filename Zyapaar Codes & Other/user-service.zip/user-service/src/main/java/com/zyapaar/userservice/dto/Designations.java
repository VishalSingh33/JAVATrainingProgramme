package com.zyapaar.userservice.dto;

import lombok.Data;

/**
 * Designation dto
 * 
 * @author Uday Halpara
 */
@Data
public class Designations {
  private String id;
  private String name;
}
