package com.zyapaar.userservice.controller;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.userservice.dto.CreateConnectionRequestDto;
import com.zyapaar.userservice.dto.ConnectionStatus;
import com.zyapaar.userservice.dto.RequestType;
import com.zyapaar.userservice.dto.UpdateConnectionRequestDto;
import com.zyapaar.userservice.dto.UserList;
import com.zyapaar.userservice.dto.UserRequestType;
import com.zyapaar.userservice.entities.IndustryCount;
import com.zyapaar.userservice.service.ConnectionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * connection controller
 * 
 * @author Uday Halpara
 */
@RestController
@Slf4j
@RequiredArgsConstructor
public class ManageConnectionController implements ConnectionController {
  
  private final ConnectionService connectionService;

  @Override
  public ResponseEntity<Response> createConnectionRequest(String fromUserId, String toUserId, ConnectionStatus status, 
    CreateConnectionRequestDto connectionDto) throws InterruptedException, ExecutionException, TimeoutException {

    log.info("[createConnectionRequest] You: {} want to connect/send request with: {}", fromUserId, toUserId);
    
    if(connectionService.createConnectionRequest(fromUserId, toUserId, connectionDto,status)) {
        return ResponseEntity.status(HttpStatus.OK).body(
          Response.builder().message("Connection request sent sucessfully")
          .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
    } else {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
          Response.builder().message("Something went wrong")
          .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
    }
  }

  @Override 
  public ResponseEntity<Response> updateConnectionRequestStatus(String fromUserId, String toUserId, ConnectionStatus status, 
    UpdateConnectionRequestDto connectionDto) throws InterruptedException, ExecutionException, TimeoutException {
   
    log.info("[updateConnectionRequestStatus] update user connection request status");
    
    if(connectionService.updateConnectionRequestStatus(fromUserId, toUserId, status, connectionDto)) {
      return ResponseEntity.status(HttpStatus.OK).body(
        Response.builder()
          .message("connection request processed sucessfully")
          .timestamp(DateTimeUtils.currentDateTimeUTCInString())
          .build());
    } else {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
        Response.builder()
          .message("Connection Request Status not valid")
          .timestamp(DateTimeUtils.currentDateTimeUTCInString())
          .build());
    }
  }

  @Override 
  public ResponseEntity<Response> getConnectionRequestList(String userId, RequestType type,
    ConnectionStatus status, ListingRequest request) {

    log.info("[getConnectionRequestList] get user connection list fir given userid");
    ListingResponse result = connectionService.getConnectionRequestList(userId,request,type);

    return ResponseEntity.ok().body(Response.builder().data(result).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @Override
  public ResponseEntity<Response> getConnectionList(String userId, String id, String industryId, ListingRequest request) {
    log.info("[getConnectionList] get user connection list for given userId");

    ListingResponse result = connectionService.getConnectionList(userId,request,industryId, id);

    return ResponseEntity.ok().body(Response.builder().data(result).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @Override
  public ResponseEntity<Response> userConnectionsIndustries(String userId) {
    log.info("[userConnectionsIndustries] user: {} conections industries", userId);

    List<IndustryCount> userIndustryDto = connectionService.userConnectionsIndustries(userId);

    return ResponseEntity.ok().body(Response.builder().data(userIndustryDto).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @Override
  public ResponseEntity<Response> getUserConnectionRequestCount(String userId) {
    
    log.info("[getUserConnectionRequestCount] get User Connection request Count"); //count of INITIATE
    
    Long count = connectionService.getAllRequestCount(userId);

    return ResponseEntity.ok().body(Response.builder().data(count).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }
  
  @Override
  public ResponseEntity<Response> getUserConnectionsCount(String userId) {

    log.info("[getUserConnectionsCount] get User Connections Count"); //count of ACCEPT
    
    Long count = connectionService.getUserConnectionsCount(userId);

    return ResponseEntity.ok().body(Response.builder().data(count).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @Override
  public ResponseEntity<Response> getConnectionRequestListByType(String userId, RequestType type,
      UserRequestType userRequestType, ListingRequest request) {
    
    ListingResponse result = connectionService.getConnectionRequestListByType(userId,
      type, userRequestType, request);
   
    return ResponseEntity.ok().body(Response.builder().data(result).message("data found")
    .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @Override
  public ResponseEntity<Response> removeConnection(String userId, String toUserId)
    throws InterruptedException, ExecutionException, TimeoutException {

    log.info("You:{} want to remove this user:{}",userId,toUserId);
    connectionService.removeConnection(userId, toUserId);

    return ResponseEntity.status(HttpStatus.OK).body(
      Response.builder().message("connection removed sucessfully")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @Override
  public ResponseEntity<Response> getMutualConnectionCount(String userId, String viewerId)
      throws InterruptedException, ExecutionException, TimeoutException {
   
    log.info("[getMutualConnectionCount] MutualConnection-Count for userId :{} & viewerId :{}",userId,viewerId);
    Integer result = connectionService.getMutualConnectedUserCount(userId,viewerId);

  return ResponseEntity.ok().body(Response.builder().data(result).message("Data found")
    .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @Override
  public ResponseEntity<Response> getUserMutualConnectionList(String userId, String viewerId,
      ListingRequest request) throws InterruptedException, ExecutionException, TimeoutException {
  
      log.info("[getUserMutualConnectionList] MutualConnection-List for userId :{} & viewerId :{}",userId,viewerId);
      ListingResponse result = connectionService.getMutualConnectedUserList(userId,viewerId,request);
  
      return ResponseEntity.ok().body(Response.builder().data(result).message("Data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
    }
}
