package com.zyapaar.userservice.dto;

import java.util.Map;
import com.zyapaar.userservice.entities.IndustryCount;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserIndustryDto {

  private String id;
  private Map<String, IndustryCount> industryCount;
  
}
