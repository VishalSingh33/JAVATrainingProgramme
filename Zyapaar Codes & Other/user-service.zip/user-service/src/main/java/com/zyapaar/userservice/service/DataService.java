package com.zyapaar.userservice.service;

import java.util.List;

import com.zyapaar.userservice.dto.Country;
import com.zyapaar.userservice.dto.Designations;
import com.zyapaar.userservice.dto.IndustriesData;
import com.zyapaar.userservice.dto.ProductData;
import com.zyapaar.userservice.dto.StateResponseDto;
import com.zyapaar.userservice.dto.TypeDto;

/**
 * data service interface
 * 
 * @author Uday Halpara
 */
public interface DataService {

  List<Country> getCountryList();

  List<StateResponseDto> getStateList(String countryId);

  List<TypeDto> getBusinessTypeList();

  List<TypeDto> getFirmTypeList();

  List<Designations> getDesignations();

  List<IndustriesData> getIndustriesList();

  List<ProductData> getProducts(String keyword);
  
}

