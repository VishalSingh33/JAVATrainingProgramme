package com.zyapaar.userservice.entities;

import java.time.OffsetDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "block_user")
@Entity
public class BlockUser {

  @Id
  private String id;

  @Column(name = "from_user_id")
  private String fromUserId;
  
  @Column(name = "to_user_id")
  private String toUserId;

  private String status;

  private String origin;

  @Column(name = "origin_id")
  private String originId;

  @Column(name = "created_on")
  private OffsetDateTime createdOn;

  @Column(name = "updated_on")
  private OffsetDateTime updatedOn;

}
