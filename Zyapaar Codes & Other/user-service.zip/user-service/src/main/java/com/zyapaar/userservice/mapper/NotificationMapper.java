package com.zyapaar.userservice.mapper;

import org.mapstruct.Mapper;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.serde.NotificationEventAvro;

@Mapper
public interface NotificationMapper {
  
  NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor,
    NotificationTypes type, String originId);

  default int map(NotificationTypes value) {
    return value.types();
  }
}
