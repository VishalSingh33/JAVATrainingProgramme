package com.zyapaar.userservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.model.ApiError;
import com.zyapaar.userservice.dto.Country;
import com.zyapaar.userservice.dto.Designations;
import com.zyapaar.userservice.dto.IndustriesData;
import com.zyapaar.userservice.dto.ProductData;
import com.zyapaar.userservice.dto.State;
import com.zyapaar.userservice.dto.StateResponseDto;
import com.zyapaar.userservice.dto.TypeDto;
import com.zyapaar.userservice.service.MasterDataService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


/**
 * master data controller
 * 
 * @author UDaY HaLPaRa
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1.1")
@Tag(name = "master-data APIs") 
@Slf4j
public class MasterDataController {

  private final MasterDataService masterDataService;

  /**
   * countries liting api
   * 
   * @return
   */
  @Operation(description = "This masterData service works to get CountryList use masterData service .", responses = {
      @ApiResponse(content = @Content(array = @ArraySchema(schema = @Schema(implementation = Country.class))), responseCode = "200"),
      @ApiResponse(content = @Content(array = @ArraySchema(schema = @Schema(implementation = ApiError.class))), responseCode = "400", description = "Bad request")
  })
  @GetMapping("/countries")                 // Deprecated Method 
  public ResponseEntity<Response> getCountryList() {
    log.info("[getCountryList] get country list");
    List<Country> list = masterDataService.getCountryList();
    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().data(list).timestamp(DateTimeUtils.currentDateTimeUTCInString())
            .build());
  }

  /**
   * country wise states list
   * 
   * @param countryId
   * @return
   */
  @Operation(description = "This masterData service works to get StateList use masterData service .", responses = {
      @ApiResponse(content = @Content(array = @ArraySchema(schema = @Schema(implementation = State.class))), responseCode = "200"),
      @ApiResponse(content = @Content(array = @ArraySchema(schema = @Schema(implementation = ApiError.class))), responseCode = "400", description = "Bad request")
  })
  @GetMapping("/states/{countryId}")      //*****/
  public ResponseEntity<Response> getStateList(
      @Parameter(description = "countryId to lookup for getStateList", required = true) @PathVariable("countryId") String countryId) {
    log.info("[getStateList] get country wise states list");

    List<StateResponseDto> list = masterDataService.getStateList(countryId);

    if(list.size() != 0){

    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().data(list).timestamp(DateTimeUtils.currentDateTimeUTCInString())
            .build());
    }
    else{
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
        .body(Response.builder().message("Data not found").timestamp(DateTimeUtils.currentDateTimeUTCInString())
            .build());  
    }
}

  /**
   * business types list
   * 
   * @return
   */
    @Operation(description = "This masterData service works to get Business TypeList use masterData service .", responses = {
        @ApiResponse(content = @Content(array = @ArraySchema(schema = @Schema(implementation = TypeDto.class))), responseCode = "200"),
        @ApiResponse(content = @Content(array = @ArraySchema(schema = @Schema(implementation = ApiError.class))), responseCode = "400", description = "Bad request")
    })
    @Deprecated
    @GetMapping("/businesstypes")            // Deprecated Method 
    public ResponseEntity<Response> getBusinessTypeList() {
    log.info("[getBusinessTypeList] get Business type list");
    List<TypeDto> list = masterDataService.getBusinessTypeList();
    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().data(list).timestamp(DateTimeUtils.currentDateTimeUTCInString())
            .build());
    }

// }
  /**
   * firm types list
   * 
   * @return
   */
  @Operation(description = "This masterData api works to get FirmType List use masterData service .", responses = {
      @ApiResponse(content = @Content(array = @ArraySchema(schema = @Schema(implementation = TypeDto.class))), responseCode = "200"),
      @ApiResponse(content = @Content(array = @ArraySchema(schema = @Schema(implementation = ApiError.class))), responseCode = "400", description = "Bad request")
  })
  @Deprecated
  @GetMapping("/firmtypetypes")         // Deprecated Method 
  public ResponseEntity<Response> getFirmTypeList() {
    log.info("[getFirmTypeList] get Firm type list");
    List<TypeDto> list = masterDataService.getFirmTypeList();
    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().data(list).timestamp(DateTimeUtils.currentDateTimeUTCInString())
            .build());
  }

  @Deprecated
  @GetMapping(value = "/designations")      // Deprecated Method 
  public ResponseEntity<Response> getDesignations() {
    List<Designations> list = masterDataService.getDesignations();

    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().data(list).timestamp(DateTimeUtils.currentDateTimeUTCInString())
            .build());
  }

  @GetMapping("/industries")
  public ResponseEntity<Response> getIndustriesList() {
    log.info("[getIndustriesList] get industries list");

    List<IndustriesData> list = masterDataService.getIndustriesList();

    if(list.size() != 0){
        return ResponseEntity.status(HttpStatus.OK)
            .body(Response.builder().data(list).timestamp(DateTimeUtils.currentDateTimeUTCInString())
                .build());
    }
    else{
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
        .body(Response.builder().message("Data not found").timestamp(DateTimeUtils.currentDateTimeUTCInString())
            .build());   
    }

  }
  
  @GetMapping(value = "/searches/products/{keyword}")
  public ResponseEntity<Response> searchKeywords(@PathVariable("keyword") String keyword) {

    List<ProductData> list = masterDataService.getProducts(keyword);

    if(list.size() != 0){
        return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().data(list).timestamp(DateTimeUtils.currentDateTimeUTCInString())
            .build());
    }
    else{
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
        .body(Response.builder().message("Data not found").timestamp(DateTimeUtils.currentDateTimeUTCInString())
            .build());  
    }
 }

}

