package com.zyapaar.userservice.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * Country listing response DTO
 * 
 * @author UDaY HaLPaRa
 */
@Getter
@Setter
public class State {
  private String id;

  private String name;
}
