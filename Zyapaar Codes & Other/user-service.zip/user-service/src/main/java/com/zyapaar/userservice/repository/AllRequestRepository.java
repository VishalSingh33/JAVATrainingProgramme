package com.zyapaar.userservice.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.userservice.entities.AllRequest;
import com.zyapaar.userservice.entities.IEntityMemberDto;
import com.zyapaar.userservice.entities.IUserConnectionDto;

@Repository
public interface AllRequestRepository extends JpaRepository<AllRequest, String>{

  Optional<AllRequest> findByRequestId(String id);
  
  @Query(
    nativeQuery = true,
    value = "SELECT u.id, u.full_name fullName, u.title, u.img logo, ent.entityId, ent.entityLogo, ent.entityName, ent.requestId, ent.type,ent.admin,ent.created_on FROM" 
    +" (SELECT ar.id entityId, ar.id entityLogo, ar.id entityName, ar.to_user_id, ar.request_id requestId, ar.type,null as admin,ar.created_on"
    +" FROM all_request ar"
        +" WHERE ar.from_user_id = :userId AND ar.type = 'user' AND ar.status = 'initiate' AND ar.is_active=true"
    +" UNION ALL" 
      +" SELECT e.id entityId, e.logo entityLogo, e.name entityName, ar.to_user_id, ar.request_id requestId, ar.type,true as admin,ar.created_on"
        +" FROM all_request ar"
        +" INNER JOIN entities e ON e.id = ar.origin_id AND ar.type = 'company' AND ar.status='invite'"
        +" WHERE :userId = ar.from_user_id AND ar.is_active=true"
    +" UNION ALL" 
      +" SELECT p.id entityId, p.logo entityLogo, p.name entityName, ar.to_user_id, ar.request_id requestId, ar.type,true as admin,ar.created_on"
        +" FROM all_request ar"
        +" INNER JOIN pages p on p.id = ar.origin_id AND ar.type = 'page' AND ar.status='invite'"
        +" WHERE :userId = ar.from_user_id AND ar.is_active=true"
    +" ) ent"
      +" INNER JOIN users u ON u.id = ANY(ent.to_user_id)"
	  +" union all"
	    +" SELECT null as id,null as fullName,null as title,null as logo,e.id entityId, e.logo entityLogo, e.name entityName, ar.request_id requestId, ar.type,false as admin,ar.created_on"
        +" FROM all_request ar"
        +" INNER JOIN entities e ON e.id = ar.origin_id AND ar.type = 'company' AND ar.status = 'join'"
        +" WHERE :userId = ar.from_user_id AND ar.is_active=true"
	  +" UNION ALL" 
      +" SELECT null as id,null as fullName,null as title,null as logo,p.id entityId, p.logo entityLogo, p.name entityName, ar.request_id requestId, ar.type,false as admin,ar.created_on"
        +" FROM all_request ar"
        +" INNER JOIN pages p on p.id = ar.origin_id AND ar.type = 'page' AND ar.status='join'"
        +" WHERE :userId = ar.from_user_id AND ar.is_active=true ORDER BY created_on DESC"
  )
  List<IUserConnectionDto> allSentRequestByUser(String userId, Pageable paging);

  @Query(
    nativeQuery = true,
    value = "SELECT u.id, u.full_name fullName, u.title , u.img logo, ent.entityId, ent.entityLogo, ent.entityName, ent.requestId, ent.type,ent.admin,ent.created_on FROM"  
	  + " ("
      + "SELECT ar.id entityId, ar.id entityLogo, ar.id entityName, ar.from_user_id, ar.request_id requestId, ar.type,null as admin,ar.created_on" 
        + " FROM all_request ar" 
        + " WHERE :userId = ANY(ar.to_user_id) AND ar.type = 'user' AND ar.status = 'initiate' AND ar.is_active=true"
      + " UNION ALL "
      + "SELECT e.id entityId, e.logo entityLogo, e.name entityName, ar.from_user_id, ar.request_id requestId, ar.type,true as admin,ar.created_on"
        + " FROM all_request ar" 
        + " INNER JOIN entities e ON e.id = ar.origin_id AND ar.type = 'company' AND ar.status = 'join' AND ar.is_active=true" 
        + " WHERE :userId = ANY(ar.to_user_id)"
    + " UNION ALL "
      + " SELECT e.id entityId, e.logo entityLogo, e.name entityName, ar.from_user_id, ar.request_id requestId, ar.type,false as admin,ar.created_on"
      + " FROM all_request ar" 
      + " INNER JOIN entities e ON e.id = ar.origin_id AND ar.type = 'company' AND ar.status='invite' AND ar.is_active=true" 
      + " WHERE :userId = ANY(ar.to_user_id)"
    + " UNION ALL"
      + " SELECT p.id entityId, p.logo entityLogo, p.name entityName, ar.from_user_id, ar.request_id requestId, ar.type,true as admin,ar.created_on"
        + " FROM all_request ar" 
        + " INNER JOIN pages p on p.id = ar.origin_id AND ar.type = 'page' AND ar.status = 'join' AND ar.is_active=true"
        + " WHERE :userId = ANY(ar.to_user_id)"
      + " UNION ALL"
        + " SELECT p.id entityId, p.logo entityLogo, p.name entityName, ar.from_user_id, ar.request_id requestId, ar.type,false as admin,ar.created_on"
          + " FROM all_request ar" 
          + " INNER JOIN pages p on p.id = ar.origin_id AND ar.type = 'page' AND ar.status='invite' AND ar.is_active=true"
          + " WHERE :userId = ANY(ar.to_user_id)"
    +") ent"
    + " INNER JOIN users u ON u.id = ent.from_user_id ORDER BY created_on DESC"
  )
  List<IUserConnectionDto> allReceivedRequestByUser(String userId, Pageable paging);
  
  @Query(
    nativeQuery = true,
    value = "SELECT u.id, u.full_name fullName, u.img logo, u.title, cr.request_id requestId, cr.type,null as admin"
      + " FROM users u"
      + " INNER JOIN all_request cr ON u.id = cr.from_user_id"
      + " WHERE :userId = ANY(cr.to_user_id) AND cr.status = :status AND type = 'user' AND cr.is_active=true"
  )
  List<IUserConnectionDto> userReceivedRequests(String userId, String status, Pageable paging);

  @Query(
    nativeQuery = true,
    value = "SELECT u.id, u.full_name fullName, u.img logo, u.title, cr.request_id requestId, cr.type,null as admin" 
      + " FROM users u"
      + " INNER JOIN all_request cr ON u.id = ANY(cr.to_user_id)"
      + " WHERE :userId = cr.from_user_id AND cr.status =:status AND type = 'user' AND cr.is_active=true"
  )
  List<IUserConnectionDto> userSentRequests(String userId, String status, Pageable paging);

  @Query(
    nativeQuery = true,
    value = "SELECT u.id, u.full_name fullName, u.img logo, e.id entityId, e.logo entityLogo, e.name entityName, ar.request_id requestId, ar.type, ar.created_on,true as admin FROM all_request ar" 
      + " INNER JOIN users u ON u.id = ar.from_user_id"
      + " INNER JOIN entities e ON e.id = ar.origin_id" 
      + " WHERE :userId = ANY(ar.to_user_id) AND ar.type = 'company' AND ar.status = 'join' AND ar.is_active=true"
      + " UNION ALL SELECT u.id, u.full_name fullName, u.img logo, e.id entityId, e.logo entityLogo, e.name entityName, ar.request_id requestId, ar.type, ar.created_on,false as admin FROM all_request ar" 
      + " INNER JOIN users u ON u.id = ar.from_user_id"
      + " INNER JOIN entities e ON e.id = ar.origin_id" 
      + " WHERE :userId = ANY(ar.to_user_id) AND ar.type = 'company' AND ar.status='invite' AND ar.is_active=true ORDER BY created_on DESC"
  )
  List<IEntityMemberDto> entityReceivedRequests(String userId, Pageable paging);  //invite

  @Query(
    nativeQuery = true,
    value = "SELECT u.id, u.full_name fullName, u.title, u.img logo, ent.entityId, ent.entityLogo, ent.entityName, ent.requestId, ent.type, ent.created_on,ent.admin FROM"  
    +" (SELECT e.id entityId, e.logo entityLogo, e.name entityName, ar.to_user_id, ar.request_id requestId, ar.type, ar.created_on,true as admin"
    +" FROM all_request ar"
    +" INNER JOIN entities e ON e.id = ar.origin_id AND ar.type = 'company' AND ar.status='invite'"
    +" WHERE :userId = ar.from_user_id AND ar.is_active=true"
    +" ) ent"
    +" INNER JOIN users u ON u.id = ANY(ent.to_user_id)"
	  +" union all"
	  +" SELECT null as id,null as fullName,null as title,null as logo,e.id entityId, e.logo entityLogo, e.name entityName, ar.request_id requestId, ar.type, ar.created_on,false as admin"
    +" FROM all_request ar"
    +" INNER JOIN entities e ON e.id = ar.origin_id AND ar.type = 'company' AND ar.status = 'join'"
    +" WHERE :userId = ar.from_user_id AND ar.is_active=true ORDER BY created_on DESC"
  )
  List<IEntityMemberDto> entitySentRequests(String userId, Pageable paging);   //join

  @Query(
    nativeQuery = true,
    value = "SELECT u.id, u.full_name fullName, u.img logo, p.id entityId, p.logo entityLogo, p.name entityName, ar.request_id requestId, ar.type,true as admin,ar.created_on FROM all_request ar" 
      + " INNER JOIN users u ON u.id = ar.from_user_id"
      + " INNER JOIN pages p ON p.id = ar.origin_id" 
      + " WHERE :userId = ANY(ar.to_user_id) AND ar.type = 'page' AND ar.status = 'join' AND ar.is_active=true"
      +" UNION ALL SELECT u.id, u.full_name fullName, u.img logo, p.id entityId, p.logo entityLogo, p.name entityName, ar.request_id requestId, ar.type,false as admin,ar.created_on FROM all_request ar" 
      + " INNER JOIN users u ON u.id = ar.from_user_id"
      + " INNER JOIN pages p ON p.id = ar.origin_id" 
      + " WHERE :userId = ANY(ar.to_user_id) AND ar.type = 'page' AND ar.status='invite' AND ar.is_active=true ORDER BY created_on DESC"
  )
  List<IEntityMemberDto> pageReceivedRequests(String userId, Pageable paging);

  @Query(
    nativeQuery = true,
    value = "SELECT u.id, u.full_name fullName, u.title, u.img logo, ent.entityId, ent.entityLogo, ent.entityName, ent.requestId, ent.type, ent.created_on,ent.admin FROM"  
    +" (SELECT p.id entityId, p.logo entityLogo, p.name entityName, ar.to_user_id, ar.request_id requestId, ar.type, ar.created_on,true as admin"
      +" FROM all_request ar"
      +" INNER JOIN pages p on p.id = ar.origin_id AND ar.type = 'page' AND ar.status='invite'"
      +" WHERE :userId = ar.from_user_id AND ar.is_active=true"
    +" ) ent"
      +" INNER JOIN users u ON u.id = ANY(ent.to_user_id)"
    +" UNION ALL" 
      +" SELECT null as id,null as fullName,null as title,null as logo,p.id entityId, p.logo entityLogo, p.name entityName, ar.request_id requestId, ar.type, ar.created_on,false as admin"
        +" FROM all_request ar"
        +" INNER JOIN pages p on p.id = ar.origin_id AND ar.type = 'page' AND ar.status='join'"
        +" WHERE :userId = ar.from_user_id AND ar.is_active=true ORDER BY created_on DESC"
  )
  List<IEntityMemberDto> pageSentRequests(String userId, Pageable paging);

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM all_request WHERE request_id=:id AND status=:status"
  )
  Optional<AllRequest> findByRequestIdAndInitiateStatus(String id,String status);

  @Query(
    nativeQuery = true,
    value = "SELECT COUNT(id) FROM all_request ar WHERE :userId = ANY(to_user_id) AND is_active = true"
    +" AND (status = 'initiate' OR status = 'join' OR status = 'invite')"
  )
  Long allRequestCount(String userId);  // RECEIVED
}  
