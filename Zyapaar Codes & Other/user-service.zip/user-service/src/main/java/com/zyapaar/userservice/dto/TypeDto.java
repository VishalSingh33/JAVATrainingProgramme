package com.zyapaar.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * types dto class
 * 
 * @author Uday Halpara
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeDto {

  private String value;

  private String label;
}
