package com.zyapaar.userservice.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.OffsetDateTime;


/**
 * The persistent class for the user_follower database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="user_follower")
public class UserFollower {

	@Id
  @NotNull
	@Column(name = "id", nullable = false, length = 19)
	private String id;  //userId pk of user table

  @NotNull
	@Column(name="created_by",nullable = false,length = 19)
	private String createdBy;

  @NotNull
	@Column(name="created_on",nullable = false)
	private OffsetDateTime createdOn;

	@Column(name="follower_count")
	private Long followerCount;

	@Column(name="following_count")
	private Long followingCount;

	@Column(name="updated_by",length = 19)
	private String updatedBy;

	@Column(name="updated_on")
	private OffsetDateTime updatedOn;

	// //bi-directional many-to-one association to Follower
	// @OneToMany(mappedBy="userFollower",targetEntity = Follower.class,fetch=FetchType.LAZY,
  // cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	// private List<Follower> followers;

}
