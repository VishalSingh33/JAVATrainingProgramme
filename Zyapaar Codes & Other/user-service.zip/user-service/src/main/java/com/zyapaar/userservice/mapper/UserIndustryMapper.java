package com.zyapaar.userservice.mapper;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import com.zyapaar.userservice.dto.UserIndustryDto;
import com.zyapaar.userservice.entities.IIndustryCount;
import com.zyapaar.userservice.entities.IndustryCount;
import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserIndustry;
import com.zyapaar.userservice.entities.UserIndustryCount;

@Mapper
public interface UserIndustryMapper {
  
  @Mapping(target = "id",source = "generatedId")
  @Mapping(target = "user",source = "userEntity")
  @Mapping(target = "createdOn",source = "offsetDateTime")
  @Mapping(target = "updatedOn",source = "offsetDateTime") //updated when case of entity update
  @Mapping(target = "createdBy",source = "userId")
  @Mapping(target = "updatedBy",source = "userId")
  UserIndustry toUserBuyIndustry(String generatedId, OffsetDateTime offsetDateTime, UserEntity userEntity,
    String userId, String type);
  
  @Mapping(target = "id",source = "nextId")
  @Mapping(target = "user",source = "userEntity")
  @Mapping(target = "createdOn",source = "offsetDateTime")
  @Mapping(target = "updatedOn",source = "offsetDateTime") //updated when case of entity update
  @Mapping(target = "createdBy",source = "userId")
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "keywordBuys",source = "allIdsOfBuys",nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "keywordSells",source = "allIdsOfSells")
  UserIndustry toUserIndustry(String nextId, OffsetDateTime offsetDateTime, UserEntity userEntity,
    String userId, Set<String> allIdsOfBuys, Set<String> allIdsOfSells);
  
  @Mapping(target = "id",source = "nextId")
  @Mapping(target = "user",source = "userEntity")
  @Mapping(target = "createdOn",source = "offsetDateTime")
  @Mapping(target = "updatedOn",source = "offsetDateTime") //updated when case of entity update
  @Mapping(target = "createdBy",source = "userId")
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "keywordSells",source = "allIdsOfSells")
  @Mapping(target = "keywordBuysSells",source = "allIdsOfSells")
  // @Mapping(target = "keywordBuys",source = "allIdsOfBuys",nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  UserIndustry toUserIndustryFromRegistrationDto(String nextId, OffsetDateTime offsetDateTime,
      UserEntity userEntity, String userId, Set<String> allIdsOfSells);

  default List<String> map(Set<String> allIdsOfSells) {
    return allIdsOfSells.stream().collect(Collectors.toList());
  }

  UserIndustryDto toIndustryList(UserIndustryCount data);

  @Mapping(target = "id",source = "keys")
  IndustryCount toIndustryResult(String keys, String name, Long count);

  IndustryCount toResult(IIndustryCount data);
  
  List<IndustryCount> toResult(List<IIndustryCount> data);

  @Mapping(target = "id",source = "nextId")
  @Mapping(target = "user",source = "userEntity")
  @Mapping(target = "createdOn",source = "offsetDateTime")
  @Mapping(target = "updatedOn",source = "offsetDateTime") //updated when case of entity update
  @Mapping(target = "createdBy",source = "userId")
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "keywordSells",source = "allIdsOfSells")
  @Mapping(target = "keywordBuys",source = "allIdsOfSells")
  @Mapping(target = "keywordBuysSells",source = "allIdsOfBuysSells")
  UserIndustry toUserIndustryFromRegistrationDtoMigration(String nextId, OffsetDateTime offsetDateTime,
      UserEntity userEntity, String userId, Set<String> allIdsOfSells, Set<String> allIdsOfBuys, Set<String> allIdsOfBuysSells);


}
