package com.zyapaar.userservice.dto;

public enum RecommendType {
  
  RECEIVED, GIVEN;
}
