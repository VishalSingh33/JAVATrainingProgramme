package com.zyapaar.userservice.dto;

/**
 * It is used to define business type.
 * 
 * @author CHiRAG RATHOD
 */
public enum NatureOfBusiness {
  
  MANUFACTURING(1),
  TRADER(2),
  SERVICE_PROVIDER(3),
  WORKS_CONTRACT(4),
  FREELANCER(5),
  NON_PROFIT_ORGANIZATION(6),
  OTHERS(7);

  private final Integer nature;

  NatureOfBusiness(Integer nature) {
    this.nature = nature; 
  }

  public Integer nature() {
    return nature;
  }

  public static NatureOfBusiness fromInteger(Integer text) {
    for (NatureOfBusiness b : NatureOfBusiness.values()) {
      if (b.nature == text) {
        return b;
      }
    }
    return null;
  }
}
