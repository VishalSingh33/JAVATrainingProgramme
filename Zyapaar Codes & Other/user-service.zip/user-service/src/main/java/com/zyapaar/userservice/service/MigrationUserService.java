package com.zyapaar.userservice.service;

import com.zyapaar.userservice.dto.MigrationUser;

public interface MigrationUserService {

	void migrationCreateUser(MigrationUser migrationUser);
  
}
