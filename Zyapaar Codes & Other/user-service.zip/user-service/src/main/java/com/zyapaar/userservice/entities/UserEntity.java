package com.zyapaar.userservice.entities;

import java.time.OffsetDateTime;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="users")
public class 	UserEntity {

	@Id
	@NotNull
	@Column(name = "id",nullable = false,length = 19)
	private String id;

	@Column(name="about_us")
	private String aboutUs;

	@Column(name="account_non_expired")
	private Boolean accountNonExpired;

	@Column(name="account_non_locked")
	private Boolean accountNonLocked;

	@NotNull
	@Column(name="created_by",nullable = false,length = 19)
	private String createdBy;

	@NotNull
	@Column(name="created_on",nullable = false)
	private OffsetDateTime createdOn;

	@Column(name="credentials_non_expired")
	private Boolean credentialsNonExpired;

	@Column(name="email_id")
	private String emailId;

	@Column(name = "enable")
	private Boolean enable;  

	@Column(name="first_name")
	private String firstName;

	@Column(name="full_name")
	private String fullName; 

	@Column(name = "img")
	private String img; 

	@Column(name = "cover")
	private String cover; 

	@Column(name="last_name")
	private String lastName;

	@Column(name="mobile_no")
	private String mobileNo;

	@Column(name = "role")
	private String role; 

	@Column(name = "title") 
	private String title;  //As Designation

	@Column(name="updated_by")
	private String updatedBy;

	@Column(name="updated_on")
	private OffsetDateTime updatedOn;

	@Column(name = "is_hide")
	private Boolean isHide;  
	
	@Column(name = "user_name")  //new
	private String userName;

	@Column(name = "email_verify")  //new
	private Boolean emailVerify;  

	//bi-directional many-to-one association to Entity
	@OneToMany(targetEntity=Entities.class, mappedBy="user", fetch=FetchType.LAZY,cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	private List<Entities> entities;

	//bi-directional many-to-one association to EntityInvite
	@OneToMany(targetEntity=EntityInvite.class, mappedBy="user", fetch=FetchType.LAZY,cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	private List<EntityInvite> entityInvite;

	//bi-directional many-to-one association to UserRecommendation
	@OneToMany(targetEntity = UserRecommendation.class,mappedBy="ufrom")
	private List<UserRecommendation> userRecommendations;

	//bi-directional many-to-one association to UserRecommendation
	@OneToMany(targetEntity = UserRecommendation.class,mappedBy="uto")
	private List<UserRecommendation> userRecommendations2;

	//bi-directional many-to-one association to UserConnection
	@OneToMany(targetEntity = UserConnection.class,mappedBy="user1",fetch=FetchType.LAZY,
	cascade = {CascadeType.PERSIST,CascadeType.MERGE}) 	//user1 is for "from_user_id"
	private List<UserConnection> userConnections1; 

	//bi-directional many-to-one association to UserConnection
	@OneToMany(targetEntity = UserConnection.class,mappedBy="user2",fetch=FetchType.LAZY,
	cascade = {CascadeType.PERSIST,CascadeType.MERGE}) 	//user2 is for "to_user_id"
	private List<UserConnection> userConnections2;

	@OneToMany(targetEntity=UserIndustry.class, mappedBy="user", fetch=FetchType.LAZY,cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	private List<UserIndustry> userIndustry;

	@OneToMany(targetEntity=UserName.class, mappedBy="user", fetch=FetchType.LAZY,cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	private List<UserName> userNames;
}

