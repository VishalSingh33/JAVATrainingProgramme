package com.zyapaar.userservice.dto;

/**
 * Notification for enum
 * 
 * @author Uday Halpara
 */
public enum NotificationFor {

	REQUEST(0),
	ACCEPT(1);

	private final Integer status;

	NotificationFor(Integer status) {
		this.status = status;
	}

	public Integer status() {
		return status;
	}

}

