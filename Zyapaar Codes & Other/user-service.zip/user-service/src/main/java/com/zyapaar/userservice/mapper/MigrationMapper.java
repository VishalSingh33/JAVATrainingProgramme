package com.zyapaar.userservice.mapper;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.NullValueCheckStrategy;
import com.zyapaar.userservice.dto.MigrationUser;
import com.zyapaar.userservice.entities.Country;
import com.zyapaar.userservice.entities.Entities;
import com.zyapaar.userservice.entities.EntityInvite;
import com.zyapaar.userservice.entities.StateEntity;
import com.zyapaar.userservice.entities.UserEntity;

@Mapper
public interface MigrationMapper {


  @Mapping(target = "id", source = "migrationUser.userId")
  @Mapping(target = "firstName", source = "migrationUser.firstName")
  @Mapping(target = "lastName", source = "migrationUser.lastName")
  @Mapping(target = "emailId", source = "migrationUser.emailId")
  @Mapping(target = "mobileNo", source = "migrationUser.mobileNo")
  @Mapping(expression = "java(migrationUser.getFirstName() + \" \" + migrationUser.getLastName())",
      target = "fullName")
  @Mapping(target = "createdOn", source = "offsetDateTime")
  @Mapping(target = "createdBy", source = "migrationUser.userId")
  @Mapping(target = "accountNonExpired", constant = "false")
  @Mapping(target = "accountNonLocked", constant = "false")
  @Mapping(target = "credentialsNonExpired", constant = "false")
  @Mapping(target = "enable", constant = "true")
  @Mapping(target = "role", constant = "user")
  @Mapping(target = "isHide", constant = "false")
  @Mapping(target = "updatedBy", source = "migrationUser.userId")
  @Mapping(target = "updatedOn", source = "offsetDateTime")
  @Mapping(target = "emailVerify", constant = "false")
  @Mapping(target = "img", source = "migrationUser.profileImg")
  UserEntity updateUser(MigrationUser migrationUser, OffsetDateTime offsetDateTime);


  @Mapping(target = "country", source = "country")
  @Mapping(target = "id", source = "companyId")
  @Mapping(target = "hide", constant = "false")
  @Mapping(target = "state", source = "state")
  @Mapping(target = "createdBy", source = "userId")
  @Mapping(target = "updatedBy", source = "userId")
  @Mapping(target = "createdOn", source = "offsetDateTime")
  @Mapping(target = "updatedOn", source = "offsetDateTime")
  @Mapping(target = "logo", source = "migrationUser.entityLogo")
  @Mapping(target = "pincode", source = "migrationUser.firmPincode")
  @Mapping(target = "user", source = "user")
  @Mapping(target = "keywordBuys", source = "allIdsOfBuys",
      nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, qualifiedByName = "toList")
  @Mapping(target = "keywordSells", source = "allIdsOfSells", qualifiedByName = "toList")
  Entities toEntities(MigrationUser migrationUser, String companyId, UserEntity user,
      OffsetDateTime offsetDateTime, String userId, Country country, StateEntity state,
      Set<String> allIdsOfBuys, Set<String> allIdsOfSells);


  @Named("toList")
  default List<String> converttoList(Set<String> allIdsOfSells) {
    return Optional.ofNullable(allIdsOfSells).orElseGet(() -> Collections.emptySet()).stream()
        .collect(Collectors.toList());
  }

  @Mapping(target = "id", source = "migrationUser.inviteId")
  @Mapping(target = "createdOn", source = "offsetDateTime")
  @Mapping(target = "createdBy", source = "userId")
  @Mapping(target = "updatedOn", source = "offsetDateTime")
  @Mapping(target = "updatedBy", source = "userId")
  @Mapping(target = "user", source = "user")
  @Mapping(target = "entities", source = "entities")
  @Mapping(target = "isAdmin", source = "b")
  @Mapping(target = "status", source = "status")

  EntityInvite toEntityInvite(MigrationUser migrationUser, UserEntity user,
      OffsetDateTime offsetDateTime, Entities entities, String status, boolean b, String userId);

}
