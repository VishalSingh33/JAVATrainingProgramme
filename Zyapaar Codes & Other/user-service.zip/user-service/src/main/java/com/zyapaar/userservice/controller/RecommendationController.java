package com.zyapaar.userservice.controller;
import javax.validation.Valid;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.exceptionhandler.model.ApiError;
import com.zyapaar.userservice.dto.RecommendType;
import com.zyapaar.userservice.dto.RecommendationStatus;
import com.zyapaar.userservice.dto.UserRecommendationDto;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
/**
 * Recommendation Controller
 * 
 * @author Shreya shah
 */
@Validated
@RequestMapping("/api/v1.1")
@Tag(name = "Recommendation APIs") 
public interface RecommendationController {
  /**
   * 
   * @param userId
   * @param recommendationDto
   * @return
   */
  @Operation(
    description = "This Recommendation api works to userRecommendation use userRecommendation service which"
      + "contains model class (UserRecommendationDto), UserRecommendationDto has id, to, message, status, recommendation",
    responses = {
      @ApiResponse(content = @Content(schema = @Schema(implementation = Response.class)),
        responseCode = "200",description = "User Recommendation added sucess"),
      @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
        responseCode = "400", description = "Bad request")
    }
  )
  @PostMapping(value = "/user/recommendation/{status}")
  public ResponseEntity<Response> userRecommendation(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
         @RequestHeader("Z-AUTH-USERID") String userId,
      @PathVariable("status") RecommendationStatus status,  
      @Parameter(description = "The content under UserRecommendation Dto is used to Recommendation for user", required = true)
         @Valid @RequestBody UserRecommendationDto recommendationDto);
  /**
   * 
   * @param userId
   * @param request
   * @return
   */
  @Operation(
    description = "This Recommendation api works to get RecommendAsk use Recommendation service which",
    responses = {
        @ApiResponse(content = @Content(schema = @Schema(implementation = ListingResponse.class)),
            responseCode = "200",description = "data found"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "400", description = "Bad request")
  })
  @PostMapping(value="/recommends/{status}")  
  public ResponseEntity<Response> getRecommendAskOrPending(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
          @RequestHeader("Z-AUTH-USERID") String userId,
      @PathVariable ("status") RecommendationStatus status,   
      @Parameter(description = "The content under ListingRequest  is used to get requets page no.", required = true)
          @Valid @RequestBody ListingRequest request);
  /**
   * 
   * @param id
   * @param request
   * @return
   */
  @Operation(
    description = "This Recommendation api works to get RecommendGiven use Recommendation service which",
    responses = {
      @ApiResponse(content = @Content(schema = @Schema(implementation = ListingResponse.class)),
          responseCode = "200",description = "data found"),
      @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
          responseCode = "400", description = "Bad request")
  })
  @PostMapping(value="/recommends/{type}/{userId}")   
  public ResponseEntity<Response> getRecommendByType(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
        @RequestHeader("Z-AUTH-USERID") String userId,
    @PathVariable("type") RecommendType type,  //based on RECEIVED or GIVEN
    @Parameter(description = "userId to lookup for user", required = true)
        @PathVariable("userId") String id,
    @Parameter(description = "The content under ListingRequest  is used to get requets page no.", required = true)
        @Valid @RequestBody ListingRequest request);
}