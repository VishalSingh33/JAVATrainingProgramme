package com.zyapaar.userservice.mapper;
import java.time.OffsetDateTime;
import java.util.List;
import javax.validation.constraints.NotNull;
import com.zyapaar.userservice.dto.RecommendationListDto;
import com.zyapaar.userservice.dto.RecommendationStatus;
import com.zyapaar.userservice.dto.UserRecommendationDto;
import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserRecommendation;
import org.mapstruct.IterableMapping;
import com.zyapaar.userservice.validation.TimeCount;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
/**
 * User recommandation mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface UserRecommendationMapper {
  @Mapping(target = "id",source = "recommendationDto.id")
  @Mapping(target = "createdOn",source = "createdOn") 
  @Mapping(target = "updatedOn",source = "updatedOn")
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "createdBy",source = "createdBy")
  @Mapping(target = "message",source = "oldData.message") 
  @Mapping(target = "status",source = "status")
  @Mapping(target = "ufrom",source = "userEntityFrom")
  @Mapping(target = "uto",source = "userEntityTo")     //uto , ufrom
  @Mapping(target = "recommendation",source = "recommendationDto.recommendation")  //before old
  @Mapping(target = "type",source = "oldData.type")
  UserRecommendation toUserRecommendation(UserRecommendation oldData, UserRecommendationDto recommendationDto, String userId,
    OffsetDateTime createdOn, OffsetDateTime updatedOn, String createdBy,
    UserEntity userEntityFrom, UserEntity userEntityTo, String status);

  default String map(RecommendationStatus value) {
    return value.recommendationStatus();
  }
  @Mapping(target = "id",source = "list.id")
  @Mapping(target = "userName",source = "list.ufrom.fullName")
  @Mapping(target = "userProfile",source = "list.ufrom.img" )
  @Mapping(target = "userDesignation",source = "list.ufrom.title" )
  @Mapping(target = "message",source = "list.message" ) //msg is mand for ask
  @Mapping(target = "recommendation",source = "list.recommendation" )
  @Mapping(target = "createdOn",source = "list.createdOn" )
  @Mapping(target = "userId",source = "list.ufrom.id")
  @Named("from")
  RecommendationListDto toRecommendationListDtoFrom(UserRecommendation list);

  @IterableMapping(qualifiedByName = "from")
  List<RecommendationListDto> toRecommendationListDtoFrom(List<UserRecommendation> list);
  
  @Mapping(target = "id",source = "recommendationDto.id")
  @Mapping(target = "createdOn",source = "createdOn")
  @Mapping(target = "createdBy",source = "userId")  
  @Mapping(target = "updatedOn",source = "updatedOn")
  @Mapping(target = "ufrom",source = "userEntityFrom")
  @Mapping(target = "uto",source = "userEntityTo")
  @Mapping(target = "updatedBy",source = "userId")  
  @Mapping(target = "type",source = "give")
  UserRecommendation toUserRecommendation(UserRecommendationDto recommendationDto, String userId,
  OffsetDateTime createdOn, OffsetDateTime updatedOn, UserEntity userEntityTo,
  UserEntity userEntityFrom, String status, String give);


  @Mapping(target = "id",source = "recommendationDto.id")
  @Mapping(target = "createdOn",source = "offsetDateTime")
  @Mapping(target = "createdBy",source = "userId")  
  @Mapping(target = "updatedOn",source = "offsetDateTime")
  @Mapping(target = "ufrom",source = "userEntityFrom")
  @Mapping(target = "uto",source = "userEntityTo")
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "status",source = "status")    //ASK
  @Mapping(target = "message",source = "recommendationDto.message")
  @Mapping(target = "recommendation",source = "recommendationDto.recommendation") //msg,rec,status
  @Mapping(target = "type", source = "request")
  UserRecommendation toCustomUserRecommendation(UserRecommendationDto recommendationDto, //sirfrom,to!
      String userId, OffsetDateTime offsetDateTime, UserEntity userEntityFrom, 
      UserEntity userEntityTo, String status, String request);   //Same mapping of toUserRecommendation
  
  @Mapping(target = "id",source = "recommendationDto.id")
  @Mapping(target = "createdOn",source = "createdOn") 
  @Mapping(target = "updatedOn",source = "offsetDateTime")
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "createdBy",source = "createdBy")
  // @Mapping(target = "message",source = "recommendationDto.message") //old
  @Mapping(target = "status",source = "recommendationStatus")
  @Mapping(target = "ufrom",source = "userEntityFrom")
  @Mapping(target = "uto",source = "userEntityTo")     //uto , ufrom
  UserRecommendation toUserRecommendation(UserRecommendationDto recommendationDto, String userId,
      @NotNull OffsetDateTime createdOn, OffsetDateTime offsetDateTime, @NotNull String createdBy,
      UserEntity userEntityFrom, UserEntity userEntityTo, String recommendationStatus);


  @Mapping(target = "id",source = "user.id")
  @Mapping(target = "userName",source = "user.ufrom.fullName")  //toUser before
  @Mapping(target = "userProfile",source = "user.ufrom.img" )
  @Mapping(target = "userDesignation",source = "user.ufrom.title" )
  @Mapping(target = "message",source = "user.message" ) //msg is mand for ask
  @Mapping(target = "recommendation",source = "user.recommendation" )
  @Mapping(target = "createdOn",source = "user.createdOn" )
  @Mapping(target = "userId",source = "user.ufrom.id")
  @Mapping(target = "createdAt",expression = "java(getCreatedAt(user.getCreatedOn()))")
  RecommendationListDto toFromResultData(UserRecommendation user);


  @Mapping(target = "id",source = "user.id")
  @Mapping(target = "userName",source = "user.uto.fullName")  //toUser before
  @Mapping(target = "userProfile",source = "user.uto.img" )
  @Mapping(target = "userDesignation",source = "user.uto.title" )
  @Mapping(target = "message",source = "user.message" ) //msg is mand for ask
  @Mapping(target = "recommendation",source = "user.recommendation" )
  @Mapping(target = "createdOn",source = "user.createdOn" )
  @Mapping(target = "userId",source = "user.uto.id")
  @Mapping(target = "createdAt",expression = "java(getCreatedAt(user.getCreatedOn()))")
  RecommendationListDto toToResultData(UserRecommendation user);

  default String getCreatedAt(OffsetDateTime value) {
      return TimeCount.timeFromUpload(value);
  }

  @Mapping(target = "id",source = "user.id")
  @Mapping(target = "userName",source = "user.ufrom.fullName")  //toUser before
  @Mapping(target = "userProfile",source = "user.ufrom.img" )
  @Mapping(target = "userDesignation",source = "user.ufrom.title" )
  @Mapping(target = "message",source = "user.message" ) //msg is mand for ask
  @Mapping(target = "recommendation",source = "user.recommendation" )
  @Mapping(target = "createdOn",source = "user.createdOn" )
  @Mapping(target = "userId",source = "user.ufrom.id")
  @Mapping(target = "createdAt",expression = "java(getCreatedAt(user.getCreatedOn()))")
  RecommendationListDto toPendingGive(UserRecommendation user);

  @Mapping(target = "id",source = "user.id")
  @Mapping(target = "userName",source = "user.uto.fullName")  //toUser before
  @Mapping(target = "userProfile",source = "user.uto.img" )
  @Mapping(target = "userDesignation",source = "user.uto.title" )
  @Mapping(target = "message",source = "user.recommendation" ) //msg is mand for ask
  @Mapping(target = "recommendation",source = "user.recommendation" )
  @Mapping(target = "createdOn",source = "user.createdOn" )
  @Mapping(target = "userId",source = "user.uto.id")
  @Mapping(target = "createdAt",expression = "java(getCreatedAt(user.getCreatedOn()))")
  RecommendationListDto toPendingRequest(UserRecommendation user);  


}