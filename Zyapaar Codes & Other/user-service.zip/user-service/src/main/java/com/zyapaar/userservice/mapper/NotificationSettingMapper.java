package com.zyapaar.userservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.zyapaar.userservice.dto.NotificationSettingDto;
import com.zyapaar.userservice.entities.NotificationSetting;

@Mapper
public interface NotificationSettingMapper {

  @Mapping(target = "id",source = "userId")
  @Mapping(target = "emailId",source = "emailId")
  @Mapping(target = "userId",source = "userId")
  NotificationSetting toNotificationSettingFromUser(NotificationSettingDto notificationSettingDto,
    String emailId, String userId);
  
}
