package com.zyapaar.userservice.controller;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.userservice.dto.BlockUserDto;
import com.zyapaar.userservice.service.ManageBlockService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequiredArgsConstructor
public class ManageBlockController implements BlockController {

	private final ManageBlockService manageBlockService;

	@Override
	public ResponseEntity<Response> blockUser(String fromUserId, BlockUserDto blockUserDto) {

		return manageBlockService.blockUser(fromUserId, blockUserDto);
	}

	@Override
	public ResponseEntity<Response> unBlockUser(String fromUserId, BlockUserDto blockUserDto) {

		return manageBlockService.unBlockUser(fromUserId, blockUserDto);
	}

	@Override
	public ResponseEntity<Response> blockedUserList(String fromUserId, ListingRequest listingRequest) {
		
		return manageBlockService.blockedUserList(fromUserId, listingRequest);
	}
	
}
