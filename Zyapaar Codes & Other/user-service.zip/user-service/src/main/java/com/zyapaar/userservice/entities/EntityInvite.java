package com.zyapaar.userservice.entities;

import java.time.OffsetDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/* With length new 
*/

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="entity_invite")
public class EntityInvite {

	  @Id
    @Column(name = "id", nullable = false, length = 19)
    private String id;

    @Column(name = "is_admin")
    private Boolean isAdmin;

		@NotNull
    @Column(name = "created_on", nullable = false)
    private OffsetDateTime createdOn;

		@NotNull
    @Column(name = "created_by", nullable = false)
    private String createdBy;

    @Column(name = "updated_on")
    private OffsetDateTime updatedOn;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "status")
	  private String status;

    @ManyToOne(fetch = FetchType.LAZY,optional = true,targetEntity = UserEntity.class)  //new mapping
    @PrimaryKeyJoinColumn(name = "user_id",referencedColumnName = "id")
    private UserEntity user;

    @ManyToOne(fetch = FetchType.LAZY,optional = true,targetEntity = Entities.class)
    @PrimaryKeyJoinColumn(name = "entities_id",referencedColumnName = "id")   //entity_id
    private Entities entities;

}
