package com.zyapaar.userservice.validation;

import java.time.OffsetDateTime;
import com.zyapaar.commons.utils.DateTimeUtils;

public class TimeCount {
 
  public static String timeFromUpload(OffsetDateTime pastDate) 
  {
    String duration = null;
    Long time = pastDate.toEpochSecond();
    Long now = DateTimeUtils.currentDateTimeUTC();
    long millis = Math.abs(now - time);
    if (millis > 31556952000L) {
      long years = millis / 31556952000L;
      duration = years + " y";
    } else if (millis > 2629800000L) {
      long months = millis / 2629800000L;
      duration = months + " m";
    } else if (millis > 604800016L) {
      long weeks = millis / 604800016L;
      duration = weeks + " w";
    } else if (millis > 86400000L) {
      long days = millis / 86400000L;
      duration = days + " d";
    } else if (millis > 3600000L) {
      long hours = millis / 3600000L;
      duration = hours + " h";
    } else if (millis > 60000L) {
      long minutes = millis / 60000L;
      duration = minutes + " min";
    } else {
      duration = "now";
    }
    return duration;
  }
}
