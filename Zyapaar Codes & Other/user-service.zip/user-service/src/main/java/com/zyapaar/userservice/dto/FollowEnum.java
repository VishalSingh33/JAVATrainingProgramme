package com.zyapaar.userservice.dto;

/**
 * Follow enum
 * 
 * @author Uday Halpara
 */
public enum FollowEnum {

  FOLLOWER,
  FOLLOWING;

}
