package com.zyapaar.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserOverViewDto {
  
  private String userId;
  private Long connections;
  private Long views;
  private Long followers;
  private Long followings;


}
