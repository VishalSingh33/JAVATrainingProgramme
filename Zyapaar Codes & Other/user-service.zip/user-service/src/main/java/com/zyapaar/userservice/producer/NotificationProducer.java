package com.zyapaar.userservice.producer;

import com.zyapaar.serde.NotificationEventAvro;

/**
 * Notification producer
 * 
 * @author Uday Halpara
 */
public interface NotificationProducer {

  void produceNotificationEvent(NotificationEventAvro eventAvro, String topic);
}
