package com.zyapaar.userservice.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.zyapaar.userservice.entities.Keyword;

@Repository
public interface KeywordRepository extends JpaRepository<Keyword,String> {
  
  @Query(
    nativeQuery = true,
    value = "SELECT * FROM pgdb.keyword WHERE name iLIKE ?1||'%'"+
  " ORDER BY (CASE WHEN name =?1 THEN 1 ELSE 2 END), name"
  )
  List<Keyword> findByNameIgnoreCase(@Param("keyword")String keyword);
  // "select * from keyword where lower(name) like ':keyword%' or upper(name) like ':keyword%'")

  @Query(
    nativeQuery = true,
    value = "SELECT id FROM keyword WHERE sub_industry_id=:industryId"
  )
  String findKeywordIdFromSubIndustry(String industryId); 
  
}
