package com.zyapaar.userservice.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.zyapaar.userservice.validation.MobileNumberValidation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * It is used to create a user registration ,validation for Fields
 * 
 * @author CHiRAG RATHOD
 * @author Uday Halpara
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@MobileNumberValidation(mobileNo = "mobileNo")  //checks userId & mobileNo
public class UserRegistrationDto {

  private String userId;

  @NotBlank(message = "Enter a first name")
  @Size(min = 2, message = "Minimum 2 character require")
  @Size(max = 50, message = "Maximum 50 character allowed")
  private String firstName;

  @NotBlank(message = "Enter a last name")
  @Size(min = 2, message = "Minimum 2 character require")
  @Size(max = 50, message = "Maximum 50 character allowed")
  private String lastName;

  private String mobileNo;

  @Pattern(
    regexp = "(^[\\w!#$%&’*+/=?`{|}~^-]+(?:.[\\w!#$%&’*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+.)+([a-zA-Z]{2,6})$)*", 
    message = "Please enter valid emailId"
  )
  private String emailId;

  @Size(max = 500, message = "Maximum 500 character allowed")
  private String aboutUs;

  @Size(max = 250, message = "Maximum 250 character allowed")
  private String profileTitle;

  private String cover;

}
