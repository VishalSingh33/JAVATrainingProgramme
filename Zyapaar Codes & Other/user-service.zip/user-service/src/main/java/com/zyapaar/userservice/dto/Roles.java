package com.zyapaar.userservice.dto;

public enum Roles {
  
  ROLE_SIGNUP("ROLE_SIGNUP"),
  ROLE_USER("ROLE_USER");

  private String role;

  Roles(String role) {
    this.role = role;
  }

  public String role() {
    return role;
  }
}
