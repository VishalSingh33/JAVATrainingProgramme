package com.zyapaar.userservice.mapper;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.zyapaar.userservice.dto.IProfileViewerResponse;
import com.zyapaar.userservice.dto.ProfileViewerResponse;
import com.zyapaar.userservice.dto.UserPersonalDetails;
import com.zyapaar.userservice.entities.UserEntity;

@Mapper
public interface UserProfileViewerMapper {

  @Mapping(target = "id", source = "userId")
  @Mapping(target = "entityName", ignore = true)    //output as null ignore,company is hide
  @Mapping(target = "aboutUs", ignore = true)
  @Mapping(target = "emailId", ignore = true)
  @Mapping(target = "mobileNo", ignore = true)
  @Mapping(target = "name",source = "user.fullName")
  @Mapping(target = "profileTitle", source = "user.title")
  @Mapping(target = "profileImg", source = "user.img")
  UserPersonalDetails userEntityToUserPersonalLockedDetails(UserEntity user, String userId, boolean isLocked, boolean isHide);

  @Mapping(target = "cover",source = "list.cover")
  ProfileViewerResponse toResult(IProfileViewerResponse list);
  
  List<ProfileViewerResponse> toResult(List<IProfileViewerResponse> list);

  // @Mapping(target = "id",source = "userEntity.id")
  // @Mapping(target = "name",source = "userEntity.fullName")
  // @Mapping(target = "img",source = "userEntity.img")
  // @Mapping(target = "designation",source = "userEntity.title")
  // List<ProfileViewer> fromUsertoProfileViewer(UserEntity userEntity); //
  
}
