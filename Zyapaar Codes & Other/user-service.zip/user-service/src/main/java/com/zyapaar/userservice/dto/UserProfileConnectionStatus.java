package com.zyapaar.userservice.dto;

public enum UserProfileConnectionStatus {
  
  NEW,
  CONNECTED,
  RECEIVED,
  SENT;

}
