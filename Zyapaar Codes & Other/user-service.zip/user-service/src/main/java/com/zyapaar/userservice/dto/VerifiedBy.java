package com.zyapaar.userservice.dto;

/**
 * It is used to define type of user verification
 * 
 * @author CHiRAG RATHOD
 */
public enum VerifiedBy {

  GSTIN(1),
  PAN(2),
  UDYAM_ADHAR(3),
  UDYOG_ADHAR(4);

  private final Integer verifiedBy;

  VerifiedBy(Integer verifiedBy) {
    this.verifiedBy = verifiedBy; 
  }

  public Integer verifiedBy() {
    return verifiedBy;
  }
}
