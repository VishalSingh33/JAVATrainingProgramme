package com.zyapaar.userservice.dto;

import lombok.Data;

/**
 * User details
 * 
 * @author Uday Halpara
 */
@Data
public class UserDetails {

  private String id;
  private String firstName;
  private String lastName;
  private String name;
  private String profileTitle;
  private String profileImg;
  private String aboutUs;
  private String emailId;
  private String mobileNo;
  private String entityId;
  private String entityName;
  private String cover;
}
