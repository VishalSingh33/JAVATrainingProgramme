package com.zyapaar.userservice.entities;

import org.springframework.stereotype.Component;

@Component
public interface IUserConnectionDto {

  String getId();
  String getFullName();
  String getLogo();
  String getTitle();
  String getEntityId();
  String getEntityLogo();
  String getEntityName();
  String getRequestId();
  String getType();
  String getAdmin();
}
