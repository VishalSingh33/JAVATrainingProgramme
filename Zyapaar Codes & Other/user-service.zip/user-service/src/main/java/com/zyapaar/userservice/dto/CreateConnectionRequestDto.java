package com.zyapaar.userservice.dto;

import lombok.Data;

/**
 * connection dto
 * 
 * @author Shreya shah
 */
@Data
public class CreateConnectionRequestDto {
  
  private String message;

}
