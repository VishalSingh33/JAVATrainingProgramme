package com.zyapaar.userservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "signup_status")
public class SignupStatus {

  @Id
  @NotNull
  @Column(name = "mobile_no",nullable = false)
  private String mobileNo;

  @NotNull
  @Column(name = "status")
  private String status;
  
}
