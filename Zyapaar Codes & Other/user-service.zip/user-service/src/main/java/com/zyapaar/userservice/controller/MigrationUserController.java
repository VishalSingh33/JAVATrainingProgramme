package com.zyapaar.userservice.controller;

import javax.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.exceptionhandler.model.ApiError;
import com.zyapaar.userservice.dto.MigrationUser;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RequestMapping("/api/v1.1")
public interface MigrationUserController {

  @Operation(
      description = "This User-Registration api works to register user use user-registration service which"
          + "contains model class ( Dto), Dto has  ",
      responses = {
          @ApiResponse(content = @Content(schema = @Schema(implementation = Response.class)),
              responseCode = "200", description = "User Registered Sucessfully"),
          @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
              responseCode = "400", description = "Bad request")})
  @PostMapping(value = "/reg-user-migrate")
  public void migrationCreateUser(
      @Parameter(
          description = "The content under UserRecommendation Dto is used to Recommendation for user",
          required = true) @Valid @RequestBody MigrationUser migrationUser);


  
}
