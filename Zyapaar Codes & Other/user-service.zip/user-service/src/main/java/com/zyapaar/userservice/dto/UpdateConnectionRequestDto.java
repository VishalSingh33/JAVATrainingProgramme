package com.zyapaar.userservice.dto;

import javax.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UpdateConnectionRequestDto {

  @NotBlank
  private String id;
  private String message;

}
