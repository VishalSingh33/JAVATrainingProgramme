package com.zyapaar.userservice.service;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.validation.Valid;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.userservice.dto.RecommendType;
import com.zyapaar.userservice.dto.RecommendationListDto;
import com.zyapaar.userservice.dto.RecommendationStatus;
import com.zyapaar.userservice.dto.UserRecommendationDto;
import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserRecommendation;
import com.zyapaar.userservice.mapper.UserRecommendationMapper;
import com.zyapaar.userservice.repository.UserRecommendationRepository;
import com.zyapaar.userservice.repository.UserRepository;
import com.zyapaar.userservice.validation.TimeCount;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
/**
 * recommendation service
 * 
 * @author Shreya shah
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageRecommendationService implements RecommendationService {
 
  private final UserRecommendationMapper userRecommendationMapper;
  private final UserRecommendationRepository userRecommendationRepository;
  private final UserRepository userRepository;

  @Override         
  public void addUserRecommendation(String userId,RecommendationStatus status, UserRecommendationDto recommendationDto) {
    log.info("[addUserRecommendation] user recommendation process");

    if(userId.equals(recommendationDto.getTo())){
      log.info("[addUserRecommendation] You can not recommend yourself");
      throw new BadRequestException("You can not recommend your self");
    }
    OffsetDateTime offsetDateTime = new Date().toInstant().atOffset(ZoneOffset.UTC);

    if (status.equals(RecommendationStatus.ASK)) {
      log.info("[addUserRecommendation] user recommendation process with ASK status");

      askRecommendation(userId, recommendationDto, offsetDateTime); //save as ASK but not having ID 
    
    } else if (status.equals(RecommendationStatus.PENDING)) {
      log.info("[addUserRecommendation] user recommendation process with PENDING status");
      
      if (ObjectUtils.isEmpty(recommendationDto.getId())) {
        log.info("[addUserRecommendation] save as PENDING but not having Id");
        recommendationGiven(userId, recommendationDto, offsetDateTime,status); //save as PENDING but not having ID(1) 
      } else { 
        log.info("[addUserRecommendation] update as PENDING & having Id");
        recommendationGivenOnAsk(userId, recommendationDto, offsetDateTime,status);//update as PENDING & having ID(2)
      }
    } else { 
      log.info("[addUserRecommendation] update as ACCEPT or DELETE with Id");       
      removeOrAcceptRecommendation(userId, recommendationDto, offsetDateTime, status);//update as ACCEPT OR DELETE
    }
  }
    //ACCEPT or DELETE with id
  private void removeOrAcceptRecommendation(String userId, UserRecommendationDto recommendationDto, 
    OffsetDateTime offsetDateTime, RecommendationStatus status) {
    log.info("[removeOrAcceptRecommendation] to remove or accept");

    UserRecommendation oldData = userRecommendationRepository.findById(recommendationDto.getId())
      .orElseThrow(() -> new ResourceNotFoundException("user-recommendation","id",recommendationDto.getId()));

      UserEntity userEntityTo;
      if(status.recommendationStatus().equalsIgnoreCase("accept")) {
         
        userEntityTo = userRepository.findById(oldData.getUto().getId())
            .orElseThrow(() -> new ResourceNotFoundException("recommand-to", "id", recommendationDto.getTo()));
      } else {
         userEntityTo = userRepository.findById(oldData.getUto().getId())
           .orElseThrow(() -> new ResourceNotFoundException("recommand-to", "id", oldData.getUto().getId()));
      }
      UserEntity userEntityFrom = userRepository.findById(oldData.getUfrom().getId())
          .orElseThrow(() -> new ResourceNotFoundException("recommand from", "id", userId));

      UserRecommendation userRecommendation = userRecommendationMapper.toUserRecommendation(oldData,
        recommendationDto, userId, oldData.getCreatedOn(), offsetDateTime,oldData.getCreatedBy(),
          userEntityFrom,userEntityTo, status.recommendationStatus());

      userRecommendation.setRecommendation(oldData.getRecommendation());
      try {
        userRecommendationRepository.save(userRecommendation);
      } catch(Exception exception){
        log.info("Error while saving data : {} ",exception);
        throw new BadRequestException("Error while saving data in user-recommendation",exception);
      }
    }

    // Pending with ID
  private void recommendationGivenOnAsk(String userId, UserRecommendationDto recommendationDto, 
    OffsetDateTime offsetDateTime, RecommendationStatus status) {
    log.info("[addUserRecommendation] user recommendation process with PENDING status update request");
    log.info("update as PENDING with Id");

    UserRecommendation oldData = userRecommendationRepository.findById(recommendationDto.getId())
      .orElseThrow(() -> new ResourceNotFoundException("recommand", "id", recommendationDto.getId()));

    UserEntity userEntityTo = userRepository.findById(oldData.getUto().getId())
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", oldData.getUto().getId()));

    UserEntity userEntityFrom = userRepository.findById(oldData.getUfrom().getId())
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId));

    UserRecommendation userRecommendation = userRecommendationMapper.toUserRecommendation(recommendationDto,
      userId, oldData.getCreatedOn(), offsetDateTime, oldData.getCreatedBy(),userEntityFrom,
      userEntityTo, status.recommendationStatus());
    
    userRecommendation.setMessage(oldData.getMessage());
    userRecommendation.setType(oldData.getType());

    log.info("[updateUserRecommendation] update user recommendation");
    try {
        userRecommendationRepository.save(userRecommendation);
      } catch(Exception exception) {
        log.info("Error while saving data : {}",exception);
        throw new BadRequestException("Error while saving data in User-Recommendation",exception);
      }
  }
      // Pending not Id  
  private void recommendationGiven(String userId, UserRecommendationDto recommendationDto,OffsetDateTime offsetDateTime, 
      RecommendationStatus status) { 
    log.info("[addUserRecommendation] user recommendation process with pending status add request");
    log.info("PENDING but not having Id");

    recommendationDto.setId(SequenceGenerator.getInstance().nextId());

    UserEntity userEntityTo =userRepository.findById(recommendationDto.getTo())
      .orElseThrow(() -> new ResourceNotFoundException("user","id",recommendationDto.getTo()));

    UserEntity userEntityFrom = userRepository.findById(userId)
      .orElseThrow(() -> new ResourceNotFoundException("user","id",userId));

    UserRecommendation userRecommendation = userRecommendationMapper  
      .toUserRecommendation(recommendationDto, userId, offsetDateTime, offsetDateTime,userEntityTo,
        userEntityFrom, status.recommendationStatus(),"give");

    try {
      userRecommendationRepository.save(userRecommendation);
      log.info("Data saved successfully");
    }
    catch(Exception exception) {
      log.info("Exception while saving data : {} ",exception);
      throw new BadRequestException("Error saving data in user-recommendation{}",exception);
    }
  }
       // ASK not ID   
  private void askRecommendation(String userId, UserRecommendationDto recommendationDto,
     OffsetDateTime offsetDateTime) {
    log.info("[askRecommendation] ASK but not having Id");
    recommendationDto.setId(SequenceGenerator.getInstance().nextId());

    UserEntity userEntityFrom = userRepository.findById(userId)
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId)); 

    UserEntity userEntityTo = userRepository.findById(recommendationDto.getTo())
      .orElseThrow(() -> new ResourceNotFoundException("user", "id", recommendationDto.getTo()));

    UserRecommendation userRecommendation = userRecommendationMapper  
      .toCustomUserRecommendation(recommendationDto,userId,offsetDateTime,userEntityFrom,
        userEntityTo, RecommendationStatus.ASK.recommendationStatus(),"request");
     
      try {
        userRecommendationRepository.save(userRecommendation);
      }
      catch(Exception exception) {
        log.info("Exception while saving data : {} ",exception);
        throw new BadRequestException("Error saving data in User-Recommendation",exception);
      }
  }

  @Override   //INVITATION RECEIVED in UI     //match from and return to
  public ListingResponse getRecommendAsk(String userId, ListingRequest request) {  //invalid status=accept,delete
    log.info("[getRecommendAsk] recommendation list with ask status");

    Pageable requestedPage = PageRequest.of(
      request.getPage(),5, Sort.by(Direction.DESC, "updated_on"));  

    List<UserRecommendation> list = userRecommendationRepository.getRecommendAsk(userId, requestedPage);
    List<RecommendationListDto> result = userRecommendationMapper.toRecommendationListDtoFrom(list); 
   
    for (RecommendationListDto recommendationListDto : result) 
    {
      recommendationListDto.setCreatedAt(TimeCount.timeFromUpload(recommendationListDto.getCreatedOn())); //convert
    }
    return new ListingResponse(result, request.getPage());
  }

  @Override   //RECEIVED in UI  //Match to and return from 
  public ListingResponse getRecommendPending(String userId, ListingRequest request) //Pending
  {
    log.info("[getRecommendPending] recommendation list with panding status");

    Pageable requestedPage = PageRequest.of(request.getPage(),5,  
      Sort.by(Direction.DESC, "updated_on"));  

    List<UserRecommendation> allData = userRecommendationRepository.findByUserId(userId,
      RecommendationStatus.PENDING.recommendationStatus(),requestedPage);  

    List<RecommendationListDto> result = new ArrayList<>();
    for (UserRecommendation user : allData) {
      
      if(user.getType().equals("give") && user.getUto().getId().equals(userId)) {
        result.add(userRecommendationMapper.toPendingGive(user));
      }
      else if(user.getType().equals("request") && user.getUfrom().getId().equals(userId)) {
        result.add(userRecommendationMapper.toPendingRequest(user));
      }
    }
    return new ListingResponse(result, request.getPage());
  }

  @Override
  public ListingResponse getRecommendByType(String id, @Valid ListingRequest request,
      RecommendType type) {
    log.info("[getRecommendByType] to get recommend by type RECEIVED or GIVEN");

    Pageable requestedPage = PageRequest.of(request.getPage(),5,
      Sort.by(Direction.DESC, "updated_on"));

    List<UserRecommendation> allData = userRecommendationRepository.findByUserId(id,
      RecommendationStatus.ACCEPT.recommendationStatus(),requestedPage);
    
    List<RecommendationListDto> result = new ArrayList<>();

    if(type.equals(RecommendType.RECEIVED))  
    {
      log.info("[getRecommendByType] recommendation list with RECEIVED type");
      
      for (UserRecommendation user : allData) {
       
        if(user.getType().equals("give")) {

          if(id.equals(user.getUto().getId())) {
              result.add(userRecommendationMapper.toFromResultData(user));
          }
        }
        else if(user.getType().equals("request")) {

          if(id.equals(user.getUfrom().getId())) {
            result.add(userRecommendationMapper.toToResultData(user));
          }
        }
      }
    }
    else if(type.equals(RecommendType.GIVEN)) 
    {
      log.info("[getRecommendByType] recommendation list with GIVEN type");

      for(UserRecommendation user : allData) {
        
        if(user.getType().equals("give")) {
          
          if(id.equals(user.getUfrom().getId())) {
            result.add(userRecommendationMapper.toToResultData(user));
          }
        }
        else if(user.getType().equals("request")) {
          
          if(id.equals(user.getUto().getId()))
          {
            result.add(userRecommendationMapper.toFromResultData(user));
          }
        }
      }
    }
    return new ListingResponse(result,request.getPage());
  }
}
