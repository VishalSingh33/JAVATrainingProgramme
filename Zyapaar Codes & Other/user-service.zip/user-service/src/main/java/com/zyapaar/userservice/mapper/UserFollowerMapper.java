package com.zyapaar.userservice.mapper;

import java.time.OffsetDateTime;
import java.util.List;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import com.zyapaar.userservice.dto.UserList;
import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserFollower;

@Mapper
public interface UserFollowerMapper {

  @Mapping(target = "id",source = "userId")  //need pre entry of all users in user follower table
  @Mapping(target = "createdBy",source = "UserIdExistsInUserFollower.createdBy")
  @Mapping(target = "createdOn",source = "UserIdExistsInUserFollower.createdOn")
  @Mapping(target = "followerCount",source = "UserIdExistsInUserFollower.followerCount")
  @Mapping(target = "followingCount",source = "Count")
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "updatedOn",source = "offsetDateTime")
  // @Mapping(target = "",source = "")   //same mapping is used for both increase and decrese the count
  UserFollower toFollow(String userId, OffsetDateTime offsetDateTime, Long Count,
      UserFollower UserIdExistsInUserFollower);   //Following Data in UserFollower(from UserId side)

  @Mapping(target = "id",source = "id")
  @Mapping(target = "createdBy",source = "IdExistsInUserFollower.createdBy")
  @Mapping(target = "createdOn",source = "IdExistsInUserFollower.createdOn")
  @Mapping(target = "followerCount",source = "CountOfId")
  @Mapping(target = "followingCount",source = "IdExistsInUserFollower.followingCount")
  @Mapping(target = "updatedBy",source = "id")
  @Mapping(target = "updatedOn",source = "offsetDateTime")
  UserFollower toUserFollowerFromFollower(String id, OffsetDateTime offsetDateTime,
      Long CountOfId, UserFollower IdExistsInUserFollower); //Follower Data in UserFollower(from Id side)

  // @Mapping(target = "id",source = "userEntity.id")
  // @Mapping(target = "name",source = "userEntity.fullName")
  // @Mapping(target = "img",source = "userEntity.img")
  // @Mapping(target = "designation",source = "userEntity.title")
  // @Named("Follower")
  // UserList toUsersFollowerList(UserEntity userEntity);

  // @IterableMapping(qualifiedByName = "Follower")
  // UserList toUsersFollowerList(UserEntity userEntity);

  // @Mapping(target = "id",source = "userEntity.id")
  // @Mapping(target = "name",source = "userEntity.fullName")
  // @Mapping(target = "img",source = "userEntity.img")
  // @Mapping(target = "designation",source = "userEntity.title")
  // @Named("Following")
  // UserList toUserFollwingsList(UserEntity userEntity);

  // @IterableMapping(qualifiedByName = "Following")
  // List<UserList> toUsersFollowingList(List<UserEntity> userEntity);

  @Mapping(target = "id",source = "users.id")
  @Mapping(target = "name",source = "users.fullName")
  @Mapping(target = "img",source = "users.img")
  @Mapping(target = "designation",source = "users.title")
  @Named("follower")
  UserList toUsersFollowerList(UserEntity users);

  @IterableMapping(qualifiedByName = "follower")
  List<UserList> toUsersFollowerList(List<UserEntity> users);

  @Mapping(target = "id",source = "users.id")
  @Mapping(target = "name",source = "users.fullName")
  @Mapping(target = "img",source = "users.img")
  @Mapping(target = "designation",source = "users.title")
  @Named("following")
  UserList toUserFollowingList(UserEntity users);

  @IterableMapping(qualifiedByName = "following")
  List<UserList> toUserFollowingList(List<UserEntity> users);

  @Mapping(target = "id",source = "userId")
  @Mapping(target = "createdBy",source = "userId")
  @Mapping(target = "createdOn",source = "offsetDateTime")
  @Mapping(target = "followerCount",source = "l")
  @Mapping(target = "followingCount",source = "l")
  @Mapping(target = "updatedBy",source = "userId")
  @Mapping(target = "updatedOn",source = "offsetDateTime")
  UserFollower toUserFollowerFromUser(String userId, OffsetDateTime offsetDateTime, long l);

  @Mapping(target = "id",source = "followersList.id")
  @Mapping(target = "name",source = "followersList.fullName")
  @Mapping(target = "img",source = "followersList.img")
  @Mapping(target = "designation",source = "followersList.title")
  @Mapping(target = "cover",source = "followersList.cover")
  UserList toUserListOfFollower(UserEntity followersList);

  List<UserList> toUserListOfFollower(List<UserEntity> followersList);

}
