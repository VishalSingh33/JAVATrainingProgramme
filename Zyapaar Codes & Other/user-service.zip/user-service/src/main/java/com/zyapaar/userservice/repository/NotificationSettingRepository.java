package com.zyapaar.userservice.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.zyapaar.userservice.entities.NotificationSetting;

@Repository
public interface NotificationSettingRepository extends JpaRepository<NotificationSetting,String> {

  Optional<NotificationSetting> findByUserId(String userId);

}
