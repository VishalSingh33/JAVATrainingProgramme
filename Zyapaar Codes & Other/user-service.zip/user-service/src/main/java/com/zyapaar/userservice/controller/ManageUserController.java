package com.zyapaar.userservice.controller;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.userservice.dto.RegistrationDto;
import com.zyapaar.userservice.dto.ResponseDto;
import com.zyapaar.userservice.dto.UserDetails;
import com.zyapaar.userservice.dto.UserPersonalDetails;
import com.zyapaar.userservice.dto.UserRegistrationDto;
import com.zyapaar.userservice.repository.UserNameRepository;
import com.zyapaar.userservice.repository.UserRepository;
import com.zyapaar.userservice.service.UserService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * user detail controller
 * 
 * @author vaibhav porwal
 */
@RestController
@AllArgsConstructor
@Slf4j
public class ManageUserController implements UserController {

  private final UserService userService;
  private final Validator validator;
  private final UserNameRepository userNameRepository;
  private final UserRepository userRepository;

  @Override
  public ResponseEntity<Response> userRegistration(String mobileNo, RegistrationDto registrationDto) {
    log.info("[userRegistration] to register User");
   
    registrationDto.setMobileNo(mobileNo);
    ResponseDto data = userService.createUser(mobileNo, registrationDto); 

    return ResponseEntity.status(HttpStatus.OK)
      .body(Response.builder().data(data).message("User created sucessfully").build());
  }

  @Override          
  public ResponseEntity<Response> userById(String authUserId, String userId)
    throws InterruptedException, ExecutionException, TimeoutException { 
    log.info("[userById] get user personal data userId: {} & id: {}", authUserId, userId);
   
    UserPersonalDetails data = userService.getUserData(authUserId, userId);
    data.setUserName(userRepository.findUserNameById(userId));

    return ResponseEntity.ok().body(Response.builder().data(data).message("Data found successfully")
    .build());
  }

  @Override
  public ResponseEntity<Response> updateUser(String userId, UserRegistrationDto userRegistrationDto) 
    throws InterruptedException, ExecutionException, TimeoutException, IOException 
  {
    log.info("[updateUser] update user data : {}, userDTO", userId, userRegistrationDto);

    userRegistrationDto.setUserId(userId);

    Set<ConstraintViolation<UserRegistrationDto>> violations = validator.validate(userRegistrationDto);

    if (!violations.isEmpty()) {
      throw new ConstraintViolationException(violations);
    }

    if (Boolean.TRUE.equals(userService.updateUser(userRegistrationDto, userId)))  {
      return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().message("User updated successfully").build());
    } 
    else {
      return ResponseEntity.status(HttpStatus.NOT_MODIFIED)   //Changed status from 500
        .body(Response.builder().message("User is not updated").build());
    }
  }

  @Override
  public ResponseEntity<Response> userOwnDetail(String authUserId) {
    log.info("[userOwnDetail] get user personal data userID : {}", authUserId);

    UserDetails data = userService.getUserPersonalData(authUserId);
    return ResponseEntity.ok()
        .body(Response.builder()
        .data(data)
        .message("Data found")
        .build());

  }

  @Override
  public ResponseEntity<Response> getUserById(String authUser, String userId)
      throws InterruptedException, ExecutionException, TimeoutException, IOException {
      log.info("[getUserById] get user data by Id");

      if(authUser.equals(userId)) {
        log.info("get user data by userId");
        UserRegistrationDto data = userService.getUser(userId);

        return ResponseEntity.ok().body(Response.builder().data(data).message("Data found")
          .build());
      }
      else {
        log.info("[getUserById] Invalid user");
        throw new BadRequestException("Invalid user");
      }
  }

  public ResponseEntity<Response> getProfileViewer(String userId, ListingRequest request) {
    log.info("[getProfileViewer] get user data to view user profile userID : ", userId);
    ListingResponse result = userService.getProfileViewer(userId, request);
    
    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().message("data found").data(result).build());
  }

  @Override
  public ResponseEntity<Response> userDataByUserName(String authUserId, String userName)
    throws InterruptedException, ExecutionException, TimeoutException, IOException {
    log.info("[userByUserName] To get User Data By userName authUser: {} & userName: {}", authUserId, userName);
   
    UserPersonalDetails data = userService.getUserData(authUserId, userNameRepository.findUserIdByName(userName.toLowerCase()));

    return ResponseEntity.ok().body(Response.builder()
      .data(data)
      .message("User found successfully")
      .build());
  }

  @Override
  public ResponseEntity<Response> updateUserName(String authUserId, String userName)
      throws InterruptedException, ExecutionException, TimeoutException, IOException {

    log.info("[updateUserName] to update UserName user: {} name: {}",authUserId,userName);

    userService.updateUserName(authUserId,userName);

    return ResponseEntity.ok().body(Response.builder()
      .message("UserName created successfully")
      .build());
  }

}
