// package com.zyapaar.userservice.mapper;

// import com.zyapaar.serde.IndustryAvro;
// import com.zyapaar.serde.ProductNewAvro;
// import com.zyapaar.userservice.dto.IndustriesData;
// // import com.zyapaar.userservice.dto.IndustriesData_old;
// import com.zyapaar.userservice.dto.ProductData;

// import org.mapstruct.Mapper;

// /**
//  * Products mapper
//  * 
//  * @author Uday Halpara
//  */
// @Mapper
// public interface ProductDataMapper {

//   ProductData toProductData(ProductNewAvro productAvro);

//   IndustriesData toIndustriesData(IndustryAvro productNewAvro);

//   default String map(CharSequence value) {
//     return value == null ? null : String.valueOf(value);
//   }
// }
