package com.zyapaar.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * profile viewer dto
 * 
 * @author Uday Halpara
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfileViewerResponse {

  private String id;
  private String name;
  private String designation;
  private String img;
  private String cover;

}
