package com.zyapaar.userservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.zyapaar.userservice.dto.UserPersonalDetails;
import com.zyapaar.userservice.entities.UserEntity;

@Mapper
public interface UserBlockedMapper {


  @Mapping(target = "aboutUs", ignore = true)
  @Mapping(target = "emailId", ignore = true)
  @Mapping(target = "mobileNo", ignore = true)
  @Mapping(target = "entityName", ignore = true)
  @Mapping(target = "isConnected", ignore = true)
  @Mapping(target = "requestId", ignore = true)
  @Mapping(target = "isRequested", ignore = true)
  @Mapping(target = "isFollowing", ignore = true)
  @Mapping(target = "isLocked", ignore = true)
  @Mapping(target = "followingCount", ignore = true)
  @Mapping(target = "followerCount", ignore = true)
  @Mapping(target = "isHide", ignore = true)
  @Mapping(target = "companies", ignore = true)
  @Mapping(target = "connectionStatus", ignore = true)
  @Mapping(target = "connection", ignore = true)
  @Mapping(target = "userName", ignore = true)
  @Mapping(target = "name", source = "data.fullName")
  @Mapping(target = "profileTitle", source = "data.title")
  @Mapping(target = "profileImg", source = "data.img")
  UserPersonalDetails toUserPersonalDetails(UserEntity data, boolean isBlocked);
  
}