package com.zyapaar.userservice.dto;

import java.time.OffsetDateTime;
import lombok.Data;

@Data
public class UserConnectionRequestList {
  
  private String id;
  private OffsetDateTime createdOn;
  private OffsetDateTime updatedOn;
  private String fromUserId;
  private String message;
  private String status;
  private String toUserId;
}
