package com.zyapaar.userservice.dto;

/**
 * Recommendation Status
 * 
 * @author Uday Halpara
 */
public enum RecommendationStatus {
  ASK("ask"),           //1
  PENDING("pending"),   //2
  ACCEPT("accept"),    //3
  DELETE("delete");    //4

  private final String recommendationStatus;

  RecommendationStatus(String recommendationStatus) {
    this.recommendationStatus = recommendationStatus;
  }

  public String recommendationStatus() {
    return recommendationStatus;
  }
}
