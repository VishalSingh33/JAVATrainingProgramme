package com.zyapaar.userservice.dto.api;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RequestOtpDto {

  String phoneNumber;
}
