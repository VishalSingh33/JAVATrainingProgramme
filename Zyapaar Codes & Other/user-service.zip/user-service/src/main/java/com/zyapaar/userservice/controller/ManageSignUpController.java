// package com.zyapaar.userservice.controller;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RestController;
// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.JsonMappingException;
// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.userservice.dto.SignUpOTPDto;
// import com.zyapaar.userservice.dto.SignUpOTPVerifyDto;
// import com.zyapaar.userservice.service.ManageSignUpService;
// import lombok.RequiredArgsConstructor;
// import lombok.extern.slf4j.Slf4j;

// @RestController
// @RequiredArgsConstructor
// @Slf4j
// public class ManageSignUpController implements SignupController {

//   private final ManageSignUpService manageSignUpService;

//   public ResponseEntity<Response> signupOtp(@RequestBody SignUpOTPDto signUpPhaseOneDto)
//       throws InterruptedException, ExecutionException, TimeoutException, JsonMappingException, JsonProcessingException {
    
//     log.info("[signupOtp] Request OTP for the mobile no : {}", signUpPhaseOneDto.getMobileNo());
//     Response response = manageSignUpService.signupPhaseOne(signUpPhaseOneDto);
//     return ResponseEntity.ok().body(response);
//   }

//   public ResponseEntity<Response> signupOtpVerify(@RequestBody SignUpOTPVerifyDto otpVerifyDto)
//       throws InterruptedException, ExecutionException, TimeoutException {
    
//     log.info("[signupOtpVerify] Request OTP verification for mobile no : {}", otpVerifyDto.getMobileNo());
//     Response response = manageSignUpService.signUpOtpVerify(otpVerifyDto);
//     return ResponseEntity.ok().body(response);
//   }
// }

