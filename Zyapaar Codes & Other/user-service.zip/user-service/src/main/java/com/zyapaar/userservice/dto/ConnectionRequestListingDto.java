package com.zyapaar.userservice.dto;

import java.time.OffsetDateTime;
import lombok.Data;

/**
 * connection request listing dao
 * 
 * @author Uday Halpara
 */
@Data
public class ConnectionRequestListingDto {

  private String id;
  private String fromUserId;
  private String toUserId;
  private String status;
  private String message;
  private String ageOfRequest;
  private OffsetDateTime createdOn;
  private OffsetDateTime updatedOn;
  private String userProfile;
  private String userName;
  private String userDesignation;

}
