package com.zyapaar.userservice.mapper;

import org.mapstruct.Mapper;
import com.zyapaar.serde.SignUpPhaseOneAvro;
import com.zyapaar.serde.SignUpStatusAvro;
import com.zyapaar.userservice.dto.SignUpOTPDto;

/**
 * It is used to conevrt one object to other object of user
 * 
 * @author CHiRAG RATHOD
 */
@Mapper
public interface UserSignUpMapper {

  SignUpPhaseOneAvro signUpOTPDtoToSignUpPhaseOneAvro(String mobileNo, String status);

  SignUpPhaseOneAvro signUpOTPDtoToSignUpPhaseOneAvro(SignUpOTPDto signUpOTPDto,
      SignUpStatusAvro status);

  // @Mapping(target = "companies", source = "companies", qualifiedByName = "stringToArray")
  // @Mapping(target = "emailId", source = "userRegistrationDto.emailId")
  // @Mapping(target = "profileImg", source = "profileImg", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // @Mapping(expression = "java(userRegistrationDto.getFirstName() + \" \" + userRegistrationDto.getLastName())", target = "fullName")
  // UserRegistrationAvro userRegistrationDtoToUserRegistrationAvro(UserRegistrationDto userRegistrationDto,
  //     String id, String profileImg, String companies, Boolean isNew);

  // @Mapping(target = "companies", source = "companies", qualifiedByName = "stringToArray")
  // @Mapping(target = "emailId", source = "userRegistrationDto.emailId")
  // @Mapping(target = "profileImg", source = "profileImg", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // @Mapping(expression = "java(userRegistrationDto.getFirstName() + \" \" + userRegistrationDto.getLastName())", target = "fullName")
  // UserRegistrationAvro toUserRegistrationAvro(UserRegistrationDto userRegistrationDto, String id,
  //     String profileImg, String companies);

  // @Mapping(target = "emailId", source = "userRegistrationDto.emailId")
  // @Mapping(expression = "java(userRegistrationDto.getFirstName() + \" \" + userRegistrationDto.getLastName())", target = "fullName")
  // UserRegistrationAvro toUserRegistrationAvroWithCompanies(UserRegistrationDto userRegistrationDto, String id,
  //     List<CharSequence> companies);

  // @Mapping(target = "emailId", source = "userRegistrationDto.emailId")
  // @Mapping(expression = "java(userRegistrationDto.getFirstName() + \" \" + userRegistrationDto.getLastName())", target = "fullName")
  // UserRegistrationAvro toUserRegistrationAvroWithStirgnCompanies(UserRegistrationDto userRegistrationDto, String id,
  //     List<String> companies, Boolean isNew);

  // @Mapping(target = "companies", source = "companies", qualifiedByName = "stringToArray")
  // @Mapping(target = "emailId", source = "userRegistrationDto.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // @Mapping(expression = "java(userRegistrationDto.getFirstName() + \" \" + userRegistrationDto.getLastName())", target = "fullName")
  // UserRegistrationAvro userRegistrationDtoToUserRegistrationAvro(
  //     UserRegistrationDto userRegistrationDto,
  //     String id,
  //     String companies);

  // @Mapping(source = "userRegistrationAvro.fullName", target = "name")
  // @Mapping(target = "emailId", source = "userRegistrationAvro.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // UserPersonalDto userRegistrationAvroToUserPersonalDto(UserRegistrationAvro userRegistrationAvro);

  // @Mapping(source = "user.fullName", target = "name")
  // @Mapping(target = "emailId", source = "user.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // UserPersonalDto userToUserPersonalDto(User user);

  // @Mapping(source = "userRegistrationAvro.fullName", target = "name")
  // @Mapping(target = "emailId", source = "userRegistrationAvro.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // UserPersonalDetails userRegistrationAvroToUserPersonalDetails(UserRegistrationAvro userRegistrationAvro,
  //     CharSequence entityName);

  // @Mapping(target = "emailId", source = "user.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // @Mapping(source = "user.fullName", target = "name")
  // UserPersonalDetails userToUserPersonalDetails(User user);

  // List<InitialUser> userToInitialUser(List<User> user);

  // @Mapping(target = "emailId", source = "emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // @Mapping(target = "dateTime", source = "_insertedTS")
  // InitialUser userToInitialUser(User user);

  // @Mapping(target = "entityName", ignore = true)
  // @Mapping(target = "aboutUs", ignore = true)
  // @Mapping(target = "emailId", ignore = true)
  // @Mapping(target = "mobileNo", ignore = true)
  // @Mapping(source = "user.fullName", target = "name")
  // UserPersonalDetails userToUserPersonalLockedDetails(User user);

  // @Mapping(target = "emailId", source = "registrationAvro.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // UserData toUserData(UserRegistrationAvro registrationAvro);

  // @Mapping(target = "emailId", source = "user.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // UserData userToUserData(User user);

  // UserProfileViewer toUserProfileViewer(String id, String userId, String viewerId,
  //     Long createdOn, Long updatedOn);

  // @Mapping(expression = "java(userDto.getFirstName() + \" \" + userDto.getLastName())", target = "fullName")
  // @Mapping(target = "emailId", source = "userDto.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // UserRegistrationAvro userDtoToUserRegistrationAvro(UserDto userDto, String id, String profileImg, Boolean isNew);

  // void updateUserPersonalDetails(UserFollower userFollower,@MappingTarget UserPersonalDetails details);
  
  // @Mapping(target = "profileImg", source = "details.profileImg", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // @Mapping(target = "emailId", source = "details.emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // UserDetails toUserDetails(UserPersonalDetails details);

  // @Mapping(target = "emailId", source = "user.emailId")	
  // @Mapping(target = "name", source = "user.fullName")	
  // UserDetails toUserDetails(User user);

  // default CharSequence map(NatureOfBusiness value) {
  //   return value.nature();
  // }

  // default CharSequence map(EntityType value) {
  //   return value.type();
  // }

  // default CharSequence map(VerifiedBy value) {
  //   return value.verifiedBy();
  // }

  // default String map(CharSequence value) {
  //   return value == null ? null : String.valueOf(value);
  // }

  // @Named("stringToArray")
  // default List<CharSequence> stringToArray(String value) {
  //   if (value == null)
  //     return null;
  //   else {
  //     List<CharSequence> list = new ArrayList<>();
  //     list.add(value);
  //     return list;
  //   }
  // }

  // @Named("charSequenceToArray")
  // default List<CharSequence> charSequenceToArray(CharSequence value) {
  //   if (value == null)
  //     return null;
  //   else {
  //     List<CharSequence> list = new ArrayList<>();
  //     list.add(value);
  //     return list;
  //   }
  // }
}
