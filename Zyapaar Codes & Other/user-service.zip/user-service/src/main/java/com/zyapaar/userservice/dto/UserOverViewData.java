package com.zyapaar.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * User over view data
 * 
 * @author Uday Halpara
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserOverViewData {

  private Long connections;
  private Long views;
  private Long postView; //
  private Long following;
  private Long follower;
  private Long post; //
  private long monthlyPost; //
  private long viewOnLastPost;  //
  
}
