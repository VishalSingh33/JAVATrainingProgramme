package com.zyapaar.userservice.validation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

import com.zyapaar.userservice.properties.B2bProperties;

import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * File Validation Custom Annotation
 * 
 * @author Uday Halpara
 */
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy =  ValidateFile.Validators.class)
public @interface ValidateFile {
  String message() default "Invalid image file";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  /**
   * validator class for File Validation
   * 
   * @author Uday Halpara
   */
  @Slf4j
  @RequiredArgsConstructor
  class Validators implements ConstraintValidator<ValidateFile, MultipartFile> {
    private final B2bProperties b2bProperties;

    /**
     * file validation checking Method
     */
    @Override
    public boolean isValid(MultipartFile file, ConstraintValidatorContext context) {
      log.info("[isValid] validate file");
      boolean result = true;
      String template = null;

      if(file != null){
        if (file.isEmpty() || file.getSize() == 0) {
          log.info("[isValid] file not found");
          template = "Please upload File";
        } else if (isImage(StringUtils.getFilenameExtension(file.getOriginalFilename()))) {
          log.info("[isValid] Image file found");
          if (file.getSize() > b2bProperties.getSize().getImage()) {
            log.info("[isValid] Image file size exceeds");
            template = 
            "Attachment size exceeds the allowable limit for IMAGE! (2MB) ";
          }
        } else {
          log.info("[isValid] Invalid file found");
          template = "Please Attach Valid Media Type File";
        }
      }
      if (template != null) {
        context.disableDefaultConstraintViolation();
        context
          .buildConstraintViolationWithTemplate(template)
          .addConstraintViolation();
        result = false;
      }
      return result;
    }

    /**
     * Check for the valid IMAGE type
     * @param contentType {@link String}
     * @return {@link Boolean}
     */
    private boolean isImage(String contentType) {
      return contentType.equalsIgnoreCase("png")
          || contentType.equalsIgnoreCase("jpg")
          || contentType.equalsIgnoreCase("gif")
          || contentType.equalsIgnoreCase("jfif")
          || contentType.equalsIgnoreCase("jpeg");
    }

  }
}
