package com.zyapaar.userservice.mapper;

import java.time.OffsetDateTime;
import java.util.Set;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.zyapaar.userservice.entities.AllRequest;

@Mapper
public interface AllRequestMapper {

  @Mapping(target = "fromUserId",source = "originId")
  @Mapping(target = "originId",source = "originId")
  AllRequest toCreateRequest(String id, String type, String status, String requestId,
    String originId, Set<String> toUserId, OffsetDateTime createdOn, boolean isActive);

  
  
}
