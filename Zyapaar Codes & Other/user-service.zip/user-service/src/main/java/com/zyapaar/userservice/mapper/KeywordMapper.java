package com.zyapaar.userservice.mapper;

import org.mapstruct.Mapper;

@Mapper
public interface KeywordMapper {

  // @Mapping(target = "id",source = "id")
  // @Mapping(target = "name",source = "id")//
  // @Mapping(target = "subIndustry",source = "id")//
  // @Mapping(target = "keywordId",source = "id") //
  // @Mapping(target = "createdOn",source = "offsetDateTime")
  // @Mapping(target = "createdBy",source = "userId")
  // @Mapping(target = "updatedOn",source = "offsetDateTime")
  // @Mapping(target = "updatedBy",source = "userId") //entities map
  // Keyword toKeywordFromEntitiesBuySale(String id, Keyword keywordBuysId, Keyword keywordSalesId,
  //     OffsetDateTime offsetDateTime, String userId, String companyId);

  // @Mapping(target = "id",source = "id")
  // @Mapping(target = "name",source = "id")//
  // @Mapping(target = "subIndustry",source = "id")//
  // @Mapping(target = "keywordId",source = "id") //
  // @Mapping(target = "createdOn",source = "offsetDateTime")
  // @Mapping(target = "createdBy",source = "userId")
  // @Mapping(target = "updatedOn",source = "offsetDateTime")
  // @Mapping(target = "updatedBy",source = "userId") //entities map    
  // Keyword toKeywordFromEntitiesBuys(String id, Keyword keywordBuysId, OffsetDateTime offsetDateTime,
  //     String userId, String companyId);

  // Keyword toKeywordFromEntitiesSales(String id, Keyword keywordSalesId,
  //     OffsetDateTime offsetDateTime, String userId, String companyId);  
  
}
