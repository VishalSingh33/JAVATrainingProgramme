package com.zyapaar.userservice.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The persistent class for the follower database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "follower")
public class Follower {

	@Id
  @NotNull
  @Column(name = "id", nullable = false, length = 19)
	private String id;

	@Column(name="follower_user",length = 19) //userId
	private String followerUser;

	// //bi-directional many-to-one association to UserFollower
	// @ManyToOne(targetEntity = UserFollower.class,optional = true) //fetch = FetchType.LAZY
	// @JoinColumn(name="user_follower_id")
	// private UserFollower userFollower;  //id

	@Column(name = "user_follower_id")
	private String userFollower;
	
	@NotNull
	@Column(name = "status", nullable = false)
	private String status;
}
