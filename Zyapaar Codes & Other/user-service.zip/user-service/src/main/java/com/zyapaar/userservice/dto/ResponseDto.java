package com.zyapaar.userservice.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ResponseDto {
  
  private String token;
  private String flag;
  private Boolean createUser;
  private UserBasicDetailDto user;
}
