package com.zyapaar.userservice.service;

import com.zyapaar.userservice.dto.UserOverViewDto;

/**
 * Over view service
 * 
 * @author Uday Halpara
 */
public interface OverViewService {

  UserOverViewDto getUserOverView(String userId);

}
