package com.zyapaar.userservice.entities;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.OffsetDateTime;
import java.util.List;

/* With length new 
*/

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "country")
public class Country {

    @Id
    @NotNull
    @Column(name = "id", nullable = false, length = 3)
    private String id;

    @Column(name = "country_name", length = 50)
    private String countryName;

    @Column(name = "isd_code", nullable = false, length = 5)
    private String isdCode;

    @Column(name = "iso3", nullable = false, length = 5)
    private String iso3;

    @NotNull
    @Column(name = "created_by", nullable = false, length = 19)
    private String createdBy;

    @Column(name = "updated_by", length = 19)
    private String updatedBy;

    @NotNull
    @Column(name = "created_on", nullable = false)
    private OffsetDateTime createdOn;

    @Column(name = "updated_on")
    private OffsetDateTime updatedOn;

		// bi-directional many-to-one association to Entity
    @OneToMany(targetEntity=Entities.class, mappedBy="country", fetch=FetchType.LAZY,cascade = {CascadeType.PERSIST,CascadeType.MERGE})
    private List<Entities> entities;

}