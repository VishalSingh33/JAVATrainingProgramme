package com.zyapaar.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResponseDtoSignupVerifyOld {
   
  private String token;
  private String flag;
  private Boolean createUser;
  private UserBasicDetailDtoSignupVerifyOld user;

}
