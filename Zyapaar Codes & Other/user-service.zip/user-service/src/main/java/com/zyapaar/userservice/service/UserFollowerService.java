package com.zyapaar.userservice.service;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.OperationNotAllowedException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.userservice.dto.BlockOrigin;
import com.zyapaar.userservice.dto.BlockedStatus;
import com.zyapaar.userservice.dto.FollowEnum;
import com.zyapaar.userservice.dto.UserList;
import com.zyapaar.userservice.entities.FollowStatus;
import com.zyapaar.userservice.entities.Follower;
import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserFollower;
import com.zyapaar.userservice.mapper.FollowerMapper;
import com.zyapaar.userservice.mapper.UserFollowerMapper;
import com.zyapaar.userservice.properties.B2bProperties;
import com.zyapaar.userservice.repository.BlockUserRepository;
import com.zyapaar.userservice.repository.FollowerRepository;
import com.zyapaar.userservice.repository.UserFollowerRepository;
import com.zyapaar.userservice.repository.UserOverViewRepository;
import com.zyapaar.userservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * User follower service
 * 
 * @author Uday Halpara
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserFollowerService implements FollowerService {
  private final UserFollowerRepository userFollowerRepository;
  private final FollowerRepository followerRepository;
  private final UserRepository userRepository;
  private final UserFollowerMapper userFollowerMapper;
  private final FollowerMapper followerMapper;
  private final B2bProperties b2bProperties;
  private final UserOverViewRepository userOverViewRepository;
  private final BlockUserRepository blockUserRepository;

  @Transactional(rollbackFor = Exception.class)
  @Override
  public void follow(String userId, String id) { // user_follower_id (id) ,follower_user(authUserId)
    log.info("You :{} are going to follow :{}", userId, id);

    if(blockUserRepository.isBlockedUser(userId, id, BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin())){

      log.info("[follow] userId1: {}, userId2: {} is blocked", userId, id);
      throw new BadRequestException("User profile is blocked for you");
    }

    followerRepository.checkIsFollowing(userId, id).ifPresent(status -> {
      throw new OperationNotAllowedException("You are already following !!");
    });

    log.info("[follow] Entry in table LIKE follower_user-> authUser AND user_follower_id-> id");
    UserFollower userIdExistsInUserFollower = getUserFollowerById(userId);
    UserFollower idExistsInUserFollower = getUserFollowerById(id);

    Long userIdExistsInUserFollowerCount = userIdExistsInUserFollower.getFollowingCount();
    userIdExistsInUserFollowerCount++;

    OffsetDateTime offsetDateTime = new Date().toInstant().atOffset(ZoneOffset.UTC);

    UserFollower increasedFromUserIdSide = userFollowerMapper.toFollow(userId, offsetDateTime,
        userIdExistsInUserFollowerCount, userIdExistsInUserFollower);

    Long idExistsInUserFollowerCount = idExistsInUserFollower.getFollowerCount();
    idExistsInUserFollowerCount++;

    UserFollower increasedFromIdSide = userFollowerMapper.toUserFollowerFromFollower(id,
        offsetDateTime, idExistsInUserFollowerCount, idExistsInUserFollower);

    Follower followerData = followerMapper.toFollower(SequenceGenerator.getInstance().nextId(),
        id, userId, FollowStatus.ACTIVE.toString());

    try {
      userFollowerRepository.save(increasedFromUserIdSide);
      followerRepository.save(followerData); // From Id Side
      userFollowerRepository.save(increasedFromIdSide);
      userOverViewRepository.increaseFollowingsCount(userId);
      userOverViewRepository.increaseFollowersCount(id);
    } catch (Exception e) {
      log.info("Error while saving Data :{}", e);
      throw new BadRequestException("Error occured while saving data", e);
    }
  } 
  
  @Transactional(rollbackFor = Exception.class)
  @Override
  public void unfollow(String userId, String id) {
    
    log.info("[unfollow] to unfollow the Follower");

    if(blockUserRepository.isBlockedUser(userId, id, BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin())){

      log.info("[unfollow] userId1: {}, userId2: {} is blocked", userId, id);
      throw new BadRequestException("User profile is blocked for you");
    }
    UserFollower userIdExistsInUserFollower = getUserFollowerById(userId);
    Long userIdExistsInUserFollowerCount = userIdExistsInUserFollower.getFollowingCount();
    userIdExistsInUserFollowerCount--;

    log.info("Following count decreased of userId: {}", userId);
    OffsetDateTime offsetDateTime = new Date().toInstant().atOffset(ZoneOffset.UTC);

    UserFollower decreasedFromUserIdSide = userFollowerMapper.toFollow(userId, offsetDateTime,
        userIdExistsInUserFollowerCount, userIdExistsInUserFollower);
    
    UserFollower idExistsInUserFollower = getUserFollowerById(id);
        Long idExistsInUserFollowerCount = idExistsInUserFollower.getFollowerCount();
  
    idExistsInUserFollowerCount--;
    log.info("Follower count decreased of id: {} in UserFollower", id);
  
    UserFollower decreasedFromIdSide = userFollowerMapper.toUserFollowerFromFollower(id,
        offsetDateTime, idExistsInUserFollowerCount, idExistsInUserFollower);

    try {
      userFollowerRepository.save(decreasedFromUserIdSide);
      userFollowerRepository.save(decreasedFromIdSide);

      log.info("User : {} unfollow to: {}", userId, id);
      followerRepository.unFollowUser(FollowStatus.INACTIVE.toString(), userId, id);

      userOverViewRepository.decreaseFollowingsCount(userId);
      userOverViewRepository.decreaseFollowersCount(id);
    } catch(Exception exception) {
      log.info("[unfollow] Exception while saving data", exception);
      throw new BadRequestException("Error while saving data", exception);
    }
  }

  private UserFollower getUserFollowerById(String id) {
    return userFollowerRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("user", "id", id));
  }

  @Override // userId = from tokenid ,id = follower's id //if id is passed null bcoz is not mand then userId is set to id
  public ListingResponse getFollowyList(String userId, String id, FollowEnum followType,
      ListingRequest request) {

    if(userId != id && id != null) { 
      userId = id;
    }
    Pageable paging = PageRequest.of(request.getPage(), b2bProperties.getPaging().getFollowySize(),
        Sort.by(Direction.DESC, "u.updated_on"));

    List<UserList> result = new ArrayList<>();

    if (followType.equals(FollowEnum.FOLLOWER)) {
      List<UserEntity> followersList = userRepository.getFollowerById(userId, paging);

      result = userFollowerMapper.toUserListOfFollower(followersList);
    } else if (followType.equals(FollowEnum.FOLLOWING)) {
      List<UserEntity> followingList = userRepository.getFollowingById(userId, paging);

      result = userFollowerMapper.toUserListOfFollower(followingList);
    } else {
      log.info("[getFollowyList] Invalid Request found for the userId :{}", userId);
      throw new BadRequestException(
          "Invalid request fround for the follow list for userId :" + userId);
    }
    return new ListingResponse(result, request.getPage());
  }
}