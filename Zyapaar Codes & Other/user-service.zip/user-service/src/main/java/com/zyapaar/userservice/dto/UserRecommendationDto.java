package com.zyapaar.userservice.dto;

import javax.validation.constraints.NotNull;
import com.zyapaar.userservice.validation.RecommendationValidation;

import lombok.Data;

/**
 * User Recommendation Dto
 * 
 * @author Uday Halpara
 */
@Data
@RecommendationValidation(
  to = "to",
  message = "message", 
  recommendation = "recommendation"
)
public class UserRecommendationDto {

  private String id;
  private String to;
  private String message; //exists at time of ASK mand for ASK
  @NotNull
  private RecommendationStatus status;
  private String recommendation; //update in "Pending"
}
