package com.zyapaar.userservice.controller;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.userservice.dto.UserOverViewDto;
import com.zyapaar.userservice.service.OverViewService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Over view controller
 * 
 * @author Uday Halpara
 */
@Slf4j
@RestController
@RequestMapping("/api/v1.1") 
@RequiredArgsConstructor
public class OverViewController {

  private final OverViewService overViewService;

  @GetMapping("/users/overview")
  public ResponseEntity<Response> getUserOverView(@RequestHeader("Z-AUTH-USERID") String userId) {

    log.info("[getUserOverView] get user over view with userId : {}", userId);

    UserOverViewDto data = overViewService.getUserOverView(userId);

    return ResponseEntity.status(HttpStatus.OK).body(Response.builder().message("Data found")
      .timestamp(DateTimeUtils.currentDateTimeUTCInString())
      .data(data).build());
  }

}
