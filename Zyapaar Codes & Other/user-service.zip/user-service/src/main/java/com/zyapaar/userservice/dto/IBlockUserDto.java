package com.zyapaar.userservice.dto;

import org.springframework.stereotype.Component;

import java.sql.Timestamp;

@Component
public interface IBlockUserDto {
	 
	String getId();
	String getFromId();
	String getToId();
	String getStatus();
	String getOrigin();
	String getOriginId();
	Timestamp getCreatedOn();
	Timestamp getUpdatedOn();
	String getUserName();
	String getImg();

	

	
}






	  
