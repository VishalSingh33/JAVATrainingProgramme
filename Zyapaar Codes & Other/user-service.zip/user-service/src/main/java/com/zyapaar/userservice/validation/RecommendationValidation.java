package com.zyapaar.userservice.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import org.springframework.util.ObjectUtils;
import com.zyapaar.userservice.dto.RecommendationStatus;
import com.zyapaar.userservice.dto.UserRecommendationDto;

/**
 * Recommandation validation
 * 
 * @author Uday Halpara
 */
@Target({ ElementType.TYPE, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy =  RecommendationValidation.Validators.class)
public @interface RecommendationValidation {

  String to();
  String message();
  String recommendation();
  Class<?>[] groups() default {};
  Class<? extends Payload>[] payload() default {};

  class Validators implements ConstraintValidator<RecommendationValidation, UserRecommendationDto> {
    private String message;
    private String recommendation;
    private String to;
    boolean result = true;

    @Override
    public void initialize(RecommendationValidation requiredIfChecked) {
      message = requiredIfChecked.message();
      recommendation = requiredIfChecked.recommendation();
      to = requiredIfChecked.to();
    }

    @Override
    public boolean isValid(UserRecommendationDto value, ConstraintValidatorContext context) {
      if (value.getStatus().equals(RecommendationStatus.ASK)) {
        validateField(value.getMessage(), context, message);
        validateField(value.getTo(), context, to);
      } else if(value.getStatus().equals(RecommendationStatus.PENDING)) {
        validateField(value.getRecommendation(), context, recommendation);
        validateField(value.getTo(), context, to);
      } else if (value.getStatus().equals(RecommendationStatus.ACCEPT)) {
        validateField(value.getRecommendation(), context, recommendation);
      }

      // if (template != null) {
      //   context.disableDefaultConstraintViolation();

      //   if (isMessage) {
      //     context
      //         .buildConstraintViolationWithTemplate(template)
      //         .addPropertyNode(message)
      //         .addConstraintViolation();
      //   } else {
      //     context
      //         .buildConstraintViolationWithTemplate(template)
      //         .addPropertyNode(recommendation)
      //         .addConstraintViolation();
      //   }

      //   result = false;
      // }

      return result;
    }

    private boolean validateField(String message, ConstraintValidatorContext context, String field) {
      boolean isFieldValid = false;

      if (ObjectUtils.isEmpty(message)) {
        if(field.equalsIgnoreCase("message")) {
          isFieldValid = setConstraints(context, field, "Enter message");
        } else if(field.equalsIgnoreCase("recommendation")) {
          isFieldValid = setConstraints(context, field, "Enter recommendation");
        }
      } else if (message.trim().length() < 10) {
        isFieldValid = setConstraints(context, field, "Minimum 10 character required");
      } else if (message.trim().length() >= 500) {
        isFieldValid = setConstraints(context, field, "Maximum 500 character required");
      }

      return isFieldValid;
    }

    private boolean setConstraints(ConstraintValidatorContext context, String field, String errorMessage) {
      context.disableDefaultConstraintViolation();
      context.buildConstraintViolationWithTemplate(errorMessage)
              .addPropertyNode(field)
              .addConstraintViolation();
      return true;
    }
  }

}
