package com.zyapaar.userservice.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.zyapaar.userservice.entities.StateEntity;

@Repository
public interface StateRepository extends JpaRepository<StateEntity,String>{

  List<StateEntity> findByCountryId(String countryId);
}
