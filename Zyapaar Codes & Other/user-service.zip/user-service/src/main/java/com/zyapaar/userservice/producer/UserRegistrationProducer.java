package com.zyapaar.userservice.producer;

import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

// import com.zyapaar.serde.CompanyIndustryAvro;
// import com.zyapaar.serde.EntityRegistrationAvro;
// import com.zyapaar.serde.IndustryUsersAvro;
import com.zyapaar.serde.SignUpPhaseOneAvro;
import com.zyapaar.serde.SignUpStatusAvro;
// import com.zyapaar.serde.UserIndustryAvro;
// import com.zyapaar.serde.UserRegistrationAvro;
// import com.zyapaar.userservice.dto.SignUpOTPDto;
import com.zyapaar.userservice.mapper.UserSignUpMapper;
import com.zyapaar.userservice.properties.B2bProperties;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
// import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
// import lombok.extern.slf4j.Slf4j;

/**
 * It is used to proced data in the kafka topic.
 * 
 * @author CHiRAG RATHOD
 */
// @Slf4j
@Component
@RequiredArgsConstructor
public class UserRegistrationProducer implements Producer {

  private final KafkaTemplate<String, SignUpPhaseOneAvro> signUpPhaseOneTemplate;
  private final B2bProperties b2bProperties;
  private final UserSignUpMapper userMapper;
//   private final KafkaTemplate<String, EntityRegistrationAvro> companyRegistrationTemplate;
//   private final KafkaTemplate<String, UserRegistrationAvro> userRegistrationTemplate;
//   private final KafkaTemplate<String, IndustryUsersAvro> industryUserTemplate;
  // private final KafkaTemplate<String, UserIndustryAvro> userIndustryTemplate;
//   private final KafkaTemplate<String, CompanyIndustryAvro> companyIndustryTemplate;

  // @Override
  // public SendResult<String, SignUpPhaseOneAvro> signupPhaseOne(SignUpOTPDto signUpOTPDto,
  //     SignUpStatusAvro status) throws InterruptedException, ExecutionException, TimeoutException {
  //   log.info("[signupPhaseOne] sign up phase One");
  //   SignUpPhaseOneAvro signUpPhaseOneAvro =
  //       userMapper.signUpOTPDtoToSignUpPhaseOneAvro(signUpOTPDto, status);

  //   ProducerRecord<String, SignUpPhaseOneAvro> producerRecord =
  //       new ProducerRecord<>(b2bProperties.getTopic().getSignupPhaseOne(), null,
  //           signUpOTPDto.getMobileNo(), signUpPhaseOneAvro, null);

  //   return signUpPhaseOneTemplate.send(producerRecord).get(1, TimeUnit.SECONDS);
  // }

 

  @Override
  public void updateMobileNo(String oldMobileNo, String mobileNo, String status)
      throws InterruptedException, ExecutionException, TimeoutException {

      SignUpPhaseOneAvro signUpPhaseOneAvro = 
        userMapper.signUpOTPDtoToSignUpPhaseOneAvro(oldMobileNo, SignUpStatusAvro.DEACTIVATE.toString());

    ProducerRecord<String, SignUpPhaseOneAvro> producerRecordForOldNo =
        new ProducerRecord<>(b2bProperties.getTopic()
        .getSignupPhaseOne(),
        oldMobileNo, 
        signUpPhaseOneAvro);

    SignUpPhaseOneAvro signUpPhaseOneAvro2 = 
        userMapper.signUpOTPDtoToSignUpPhaseOneAvro(mobileNo, status);

    ProducerRecord<String, SignUpPhaseOneAvro> producerRecordForNewNo =
        new ProducerRecord<>(b2bProperties.getTopic()
        .getSignupPhaseOne(),
        mobileNo,
        signUpPhaseOneAvro2);

    signUpPhaseOneTemplate.send(producerRecordForOldNo);

    signUpPhaseOneTemplate.send(producerRecordForNewNo);

  }

}
