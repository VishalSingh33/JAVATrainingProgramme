package com.zyapaar.userservice.mapper;

import java.time.OffsetDateTime;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.zyapaar.userservice.entities.UserEntity;
import com.zyapaar.userservice.entities.UserName;

@Mapper
public interface UserNameMapper {

    @Mapping(target = "createdBy",source = "userId")
    @Mapping(target = "createdOn",source = "offsetDateTime")
    @Mapping(target = "updatedBy",source = "userId")
    @Mapping(target = "updatedOn",source = "offsetDateTime")
    @Mapping(target = "userName",source = "userName")
    @Mapping(target = "defaultValue",constant = "false")
    @Mapping(target = "id",source = "id")
    @Mapping(target = "user",source = "user")
    UserName toResult(String id, String userName, OffsetDateTime offsetDateTime, String userId, UserEntity user);
    
}
