package com.zyapaar.userservice.repository;

import com.zyapaar.userservice.entities.Country;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CountryRepository extends JpaRepository<Country,String>{

  @Query(nativeQuery = true,value = "select * from country where id=:string")
  Country findDataById(String string);
  
}
