package com.zyapaar.userservice.mapper;

import com.zyapaar.userservice.entities.UserFollower;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import java.time.OffsetDateTime;

@Mapper
public interface UserFollowerBlockMapper {

  @Mapping(target = "id",source = "id")  //need pre entry of all users in user follower table
  @Mapping(target = "createdBy",source = "UserIdExistsInUserFollower.createdBy")
  @Mapping(target = "createdOn",source = "UserIdExistsInUserFollower.createdOn")
  @Mapping(target = "followerCount",source = "UserIdExistsInUserFollower.followerCount")
  @Mapping(target = "followingCount",source = "Count")
  @Mapping(target = "updatedBy",source = "id")
  @Mapping(target = "updatedOn",source = "offsetDateTime")
  // @Mapping(target = "",source = "")   //same mapping is used for both increase and decrese the count
  UserFollower toFollow(String id, OffsetDateTime offsetDateTime, Long Count,
      UserFollower UserIdExistsInUserFollower);   //Following Data in UserFollower(from UserId side)

}
