package com.zyapaar.userservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.zyapaar.userservice.entities.Follower;

@Mapper
public interface FollowerMapper {

  @Mapping(target = "id",source = "nextId")
  @Mapping(target = "userFollower",source = "id") //id
  @Mapping(target = "followerUser",source = "userId")
  @Mapping(target = "status",source = "status")
  Follower toFollower(String nextId, String id, String userId, String status);
  
}
