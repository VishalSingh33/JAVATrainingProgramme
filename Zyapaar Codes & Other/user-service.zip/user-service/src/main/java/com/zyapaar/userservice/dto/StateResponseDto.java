package com.zyapaar.userservice.dto;

import lombok.Data;

@Data
public class StateResponseDto {
  private String id;
  private String name;
}
