package com.zyapaar.userservice.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserConnectionDto {
  private String id;
  private String fullName;
  private String logo;
  private String title;
  private String entityId;
  private String entityLogo;
  private String entityName;
  private String requestId;
  private String type;
}
