package com.zyapaar.userservice.service;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.userservice.dto.BlockUserDto;
import org.springframework.http.ResponseEntity;

public interface BlockService {
	
	 ResponseEntity<Response> blockUser(String fromUserId, BlockUserDto blockUserDto);

	 ResponseEntity<Response> unBlockUser(String fromUserId, BlockUserDto blockUserDto);

	 ResponseEntity<Response> blockedUserList(String fromUserId, ListingRequest listingRequest);

}
