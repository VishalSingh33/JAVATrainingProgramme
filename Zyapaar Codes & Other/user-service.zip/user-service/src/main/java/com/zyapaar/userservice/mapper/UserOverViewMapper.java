package com.zyapaar.userservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.zyapaar.userservice.dto.UserOverViewDto;
import com.zyapaar.userservice.entities.UserOverView;

/**
 * User over view data mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface UserOverViewMapper {

  @Mapping(target = "id",source = "id")
  @Mapping(target = "userId",source = "userId")
  @Mapping(target = "connections",source = "count")
  @Mapping(target = "views",source = "count")
  @Mapping(target = "followings",source = "count") 
  @Mapping(target = "followers",source = "count")
  UserOverView toUserOverViewFromUserEntity(String id, String userId, Long count); // 0L

  UserOverViewDto toUserOverViewData(UserOverView userOverView);

}
