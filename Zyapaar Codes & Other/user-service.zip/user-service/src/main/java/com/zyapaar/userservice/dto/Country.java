package com.zyapaar.userservice.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * Country listing response DTO
 * 
 * @author UDaY HaLPaRa
 */
@Getter
@Setter
public class Country {
  private String id;

  private String name;
}
