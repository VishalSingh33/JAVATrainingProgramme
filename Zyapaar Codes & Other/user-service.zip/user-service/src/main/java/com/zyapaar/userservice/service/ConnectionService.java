package com.zyapaar.userservice.service;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import javax.validation.Valid;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.userservice.dto.CreateConnectionRequestDto;
import com.zyapaar.userservice.dto.ConnectionStatus;
import com.zyapaar.userservice.dto.RequestType;
import com.zyapaar.userservice.dto.UpdateConnectionRequestDto;
import com.zyapaar.userservice.dto.UserList;
import com.zyapaar.userservice.dto.UserRequestType;
import com.zyapaar.userservice.entities.IndustryCount;

/**
 * connection service interface
 * 
 * @author Shreya Shah
 */
public interface ConnectionService { 

  Boolean createConnectionRequest(String userId, String toUserId, CreateConnectionRequestDto connectionDto,
     ConnectionStatus status) throws InterruptedException, ExecutionException, TimeoutException;

  boolean updateConnectionRequestStatus(String userId, String toUserId,
      ConnectionStatus status,UpdateConnectionRequestDto connectionDto) throws InterruptedException, ExecutionException, TimeoutException;

  ListingResponse getConnectionRequestList(String userId, ListingRequest request,
      RequestType type);

  ListingResponse getConnectionList(String userId, ListingRequest request, String industryId, String id);

  List<IndustryCount> userConnectionsIndustries(String userId);

  Long getUserConnectionRequestCount(String userId);

  Long getAllRequestCount(String userId);   //Received

  Long getUserConnectionsCount(String userId);

  ListingResponse getUserConnections(String userId, @Valid ListingRequest request);

  ListingResponse getConnectionRequestListByType(String userId, RequestType type,
      UserRequestType userRequestType, @Valid ListingRequest request);

  void removeConnection(String userId, String toUserId)
    throws InterruptedException, ExecutionException, TimeoutException;

  Integer getMutualConnectedUserCount(String userId, String viewerId);

  ListingResponse getMutualConnectedUserList(String userId, String viewerId,
      ListingRequest request);

}