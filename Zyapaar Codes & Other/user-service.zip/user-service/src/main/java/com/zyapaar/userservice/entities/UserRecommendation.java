package com.zyapaar.userservice.entities;

import java.time.OffsetDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the user_recommendation database table.
 * 
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
// @Getter
// @Setter
@Entity
@Table(name="user_recommendation")
public class UserRecommendation {

    @Id
    @NotNull
    @Column(name = "id", nullable = false, length = 19)
    private String id;

    @NotNull
    @Column(name="created_by",nullable = false,length = 19)
    private String createdBy;

    @NotNull
    @Column(name="created_on", nullable = false)
    private OffsetDateTime createdOn;

    @Column(name = "message")
    private String message;

    @Column(name = "recommendation")
    private String recommendation;

    @Column(name = "status")
    private String status;

    @Column(name="updated_by",length = 19)
    private String updatedBy;

    @Column(name="updated_on")
    private OffsetDateTime updatedOn;

    @Column(name = "type")
    private String type;

    //bi-directional many-to-one association to User
    @ManyToOne(fetch = FetchType.EAGER, optional = true,targetEntity = UserEntity.class)
    @PrimaryKeyJoinColumn(name = "user_id",referencedColumnName = "id")
    @JoinColumn(name = "from_id",referencedColumnName = "id",nullable = false)
    private UserEntity ufrom;

    //bi-directional many-to-one association to User
    @ManyToOne(fetch = FetchType.EAGER, optional = true,targetEntity = UserEntity.class)
    @PrimaryKeyJoinColumn(name = "user_id",referencedColumnName = "id")
    @JoinColumn(name = "to_id",referencedColumnName = "id",nullable = false)
    private UserEntity uto;

    
}
