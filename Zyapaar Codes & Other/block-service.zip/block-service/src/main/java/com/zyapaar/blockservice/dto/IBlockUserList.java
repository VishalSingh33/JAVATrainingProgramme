package com.zyapaar.blockservice.dto;

import org.springframework.stereotype.Component;

@Component
public interface IBlockUserList {

  String getId();
  String getUserId();
  String getUserName();
  String getUserImg();
  String getUserDesignation();
  
}
