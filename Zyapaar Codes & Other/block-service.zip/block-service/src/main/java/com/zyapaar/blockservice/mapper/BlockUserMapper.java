package com.zyapaar.blockservice.mapper;

import com.zyapaar.blockservice.dto.BlockOrigin;
import com.zyapaar.blockservice.dto.BlockUserDto;
import com.zyapaar.blockservice.dto.BlockedStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyapaar.blockservice.entities.BlockUser;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.OffsetDateTime;

/**
 * Spam report mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface BlockUserMapper {

	ObjectMapper objectMapper = new ObjectMapper();

	// @Mapping(target = "updatedOn", source = "createdOn")
	// @Mapping(target = "createdOn", source = "createdOn")
	// @Mapping(target = "originId", source = "blockUserDto.originId")
	// BlockUser setData(String fromUserId, String id, OffsetDateTime createdOn, BlockUserDto
	// blockUserDto);

	default String map(BlockOrigin origin) {
		return origin.origin();
	}

	default String map(BlockedStatus status) {
		return status.status();
	}

	@Mapping(target = "updatedOn", source = "createdOn")
	@Mapping(target = "createdOn", source = "createdOn")
	@Mapping(target = "originId", source = "blockUserDto.originId")
	@Mapping(target = "status", source = "status")
	BlockUser toBlockUser(String id, String fromUserId, BlockUserDto blockUserDto,
			OffsetDateTime createdOn, BlockedStatus status);

	@Mapping(target = "updatedOn", source = "updatedOn")
	@Mapping(target = "createdOn", source = "blockUser.createdOn")
	@Mapping(target = "originId", source = "blockUser.originId")
	@Mapping(target = "status", source = "status")
	BlockUser toUpdateBlockUser(BlockUser blockUser, OffsetDateTime updatedOn, BlockedStatus status);
}
