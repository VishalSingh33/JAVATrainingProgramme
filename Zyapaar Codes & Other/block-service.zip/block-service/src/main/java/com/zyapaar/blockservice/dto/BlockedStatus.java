package com.zyapaar.blockservice.dto;

public enum BlockedStatus {

  BLOCKED("blocked"),
  UNBLOCKED("unblocked");

  private final String status;

  BlockedStatus(String status) {
    this.status = status;
  }

  public String status() {
    return status;
  }
}

