package com.zyapaar.blockservice.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

/**
 * Property class
 * 
 * @author UDaY HaLPaRa
 */
@ConfigurationProperties(prefix = "app")
@Getter
@Component
public class B2bProperties {
  private Api api = new Api();
  private Paging paging = new Paging();

  @Getter
  @Setter
  public static class Api {
    private String removeBlockRequest;

  }

  @Getter
  @Setter
  public static class Paging {

    private Integer blockSize;

  }

}
