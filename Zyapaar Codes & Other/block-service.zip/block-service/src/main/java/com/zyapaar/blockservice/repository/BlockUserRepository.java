package com.zyapaar.blockservice.repository;

import com.zyapaar.blockservice.dto.IBlockUserList;
import com.zyapaar.blockservice.entities.BlockUser;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BlockUserRepository extends JpaRepository<BlockUser, String>{

	@Query(
    nativeQuery = true,
    value = "  SELECT id FROM block_user WHERE from_user_id= :from "
    + " AND to_user_id= :to AND status='blocked' "
  )
  Optional<String> checkIsBlock(String from, String to);


	// @Modifying
	// @Query(nativeQuery = true, value = "update user_connection " + 
	// "set status  = case status " + 
	// "WHEN 'initiate' then 'reject' " + 
	// "WHEN 'accept' then 'remove' " + 
	// "end where from_user_id = :fromId and to_user_id = :toId ")
	// void upadateUserConnection(String fromId, String toId);

	// @Modifying
	// @Query(nativeQuery = true, value = "update all_request " + 
	// "set status  = case status " + 
	// "WHEN 'initiate' then 'reject' " + 
	// "WHEN 'accept' then 'remove' " + 
	// "end where from_user_id = :fromId " )
	// void upadateAllRequest(String fromId);

	// @Query(nativeQuery= true, 
  // value= "select * from all_request ar where from_user_id = :id ")
  // List<AllRequest> getAllRequest(String id);

	// @Query(nativeQuery= true, 
  // value= "select * from user_wise_connection uwc where id = :id ")
  // UserWiseConnection getUserWiseConnection(String id);

	// @Modifying
	// @Query(nativeQuery = true,
	// value = " UPDATE block_user  SET status  = 'unblocked' WHERE from_user_id = :from and to_user_id = :to ")
	// void getUnblockId(String from, String to);

  @Query(nativeQuery= true, 
  value= "select bu.id as id, u.id as userId, " + 
	"u.full_name as userName, u.img as userImg, u.title as userDesignation from block_user bu " + 
	"inner join users u on bu.to_user_id = u.id " + 
	"where bu.from_user_id = :userId and status = :status and origin = :origin " + 
	"order by bu.created_on desc ")
  List<IBlockUserList> blockuserList(String userId, String status, String origin, Pageable pageable);

	@Query(nativeQuery= true, 
	value= " select count(*) from (select * from block_user bu where id = :id) as a")
	Optional<String> findBlockCount(String id);

	@Query(nativeQuery = true, 
    value = "select exists (select bu.status " + 
    "from block_user bu where " + 
    "((bu.from_user_id = :authUserId and bu.to_user_id = :userId) " + 
    "or " + 
    "(bu.from_user_id = :userId and bu.to_user_id = :authUserId)) " + 
    "and bu.status = :status " + 
    "and bu.origin = :origin) ")
  Boolean isBlockedUser(String authUserId, String userId, String status, String origin);


	@Query(nativeQuery = true, 
    value = "select bu.* " + 
		"from block_user bu where " + 
		"((bu.from_user_id = :authUserId and bu.to_user_id = :userId) " + 
		"or " + 
		"(bu.from_user_id = :userId and bu.to_user_id = :authUserId)) " + 
		"and bu.status = :status " + 
		"and bu.origin = :origin ")
	BlockUser findByIds(String authUserId, String userId, String status,String origin);
  

  
}
