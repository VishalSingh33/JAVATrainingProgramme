package com.zyapaar.blockservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RemoveConnection {//change this will require change in userService also

  private String fromUserId;
  private String toUserId;
  
}
