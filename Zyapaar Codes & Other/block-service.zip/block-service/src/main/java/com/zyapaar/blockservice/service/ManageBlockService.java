package com.zyapaar.blockservice.service;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.blockservice.dto.BlockOrigin;
import com.zyapaar.blockservice.dto.IBlockUserList;
import com.zyapaar.blockservice.dto.BlockUserDto;
import com.zyapaar.blockservice.dto.BlockedStatus;
import com.zyapaar.blockservice.dto.RemoveConnection;
import com.zyapaar.blockservice.entities.BlockUser;
import com.zyapaar.blockservice.mapper.BlockUserMapper;
import com.zyapaar.blockservice.properties.B2bProperties;
import com.zyapaar.blockservice.repository.BlockUserRepository;
import com.zyapaar.blockservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.reactive.function.client.WebClient;
import javax.transaction.Transactional;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ManageBlockService implements BlockService {

	private final BlockUserRepository blockUserRepository;
	private final BlockUserMapper blockUserMapper;
	private final B2bProperties b2bProperties;
  private final WebClient.Builder webClientBuilder;
	private final UserRepository userRepository;

	@Override
	@Transactional(rollbackOn = Exception.class)
	public ResponseEntity<Response> blockUser(String fromUserId, BlockUserDto blockUserDto) {

		//  blockUserRepoistory.checkIsBlock(fromUserId, blockUserDto.getToUserId()).ifPresent(status -> {
    //    throw new BadRequestException("User is already Blocked !!");
    //  });

		if(!blockUserDto.getOrigin().equals(BlockOrigin.USER)){

			log.info("[blockUser] origin type wrong, blockUserDto: {}",blockUserDto);
			throw new BadRequestException("Enter valid origin type");
		}

		if(!blockUserDto.getOriginId().equals(fromUserId)){

			log.info("[blockUser] originId!=fromUserId {} != {}", blockUserDto.getOriginId(), fromUserId);
			throw new BadRequestException("Enter valid originId");
		}

		if(blockUserRepository.isBlockedUser(fromUserId, blockUserDto.getToUserId(), BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin())){
        
			log.info("[blockUser] fromUserId: {}, toUserId: {} is blocked", fromUserId, blockUserDto.getToUserId());
			throw new BadRequestException("User profile is blocked for you");
		}
		

		//No need of this as fromUserId is coming from Z-AUTH-USERID rather than that we need to check toUserId
		// userRepository.findById(fromUserId)
		// 		.orElseThrow(() -> new ResourceNotFoundException("user", "id", fromUserId));
		userRepository.findById(blockUserDto.getToUserId())
			.orElseThrow(() -> new ResourceNotFoundException("user", "id", blockUserDto.getToUserId()));

		String id = SequenceGenerator.getInstance().nextId();
		OffsetDateTime offset = new Date().toInstant().atOffset(ZoneOffset.UTC);

		// BlockUser blockUser = blockUserMapper.setData(fromUserId, id, offset, blockUserDto);
		BlockUser blockUser = blockUserMapper.toBlockUser(id, fromUserId, blockUserDto, offset, BlockedStatus.BLOCKED);
		
		// blockUser.setStatus(BlockedStatus.BLOCKED.status());
		RemoveConnection removeConnectionDto = new RemoveConnection(fromUserId, blockUserDto.getToUserId());

		try {
			log.info("[blockUser] calling webClientBuilder");
			webClientBuilder.build()
				.post()
				.uri(b2bProperties.getApi().getRemoveBlockRequest())
				.bodyValue(removeConnectionDto)
				.retrieve()
				.toBodilessEntity()
				.block();
			blockUserRepository.save(blockUser);

			// log.info("[blockUser] response: {}", response.getBody().getMessage());

			return ResponseEntity.status(HttpStatus.CREATED)
        .body(Response.builder().message("Block User Fetched").data(blockUser)
            .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
		} catch (Exception e) {
			
			log.info("[blockUser] Error while saving data: {}",e);
			throw new BadRequestException("Error while saving data");
		}
		
		// blockUserRepository.upadateUserConnection(fromUserId, blockUserDto.getToUserId());
		// blockUserRepoistory.upadateAllRequest(fromUserId, blockUserDto.getToUserId());

// 		List<AllRequest> toAllRequest = allRequestRepository.findAll();
// 		List<AllRequest> filteredAllRequest = toAllRequest.stream()
// 				.filter(e -> e.getFromUserId().equals(fromUserId)).collect(Collectors.toList());
// //				blockUserRepoistory.getAllRequest(fromUserId);
// 		// for(AllRequest user : toAllRequest)
// 		filteredAllRequest.forEach(allRequest -> {
// 			if(allRequest.getToUserId().contains(blockUserDto.getToUserId()))
// 			{
// 				if(allRequest.getStatus().equals("accept"))
// 				{
//                   allRequest.setStatus("remove");
// 				} else if (allRequest.getStatus().equals("initiate")) {
// 					allRequest.setStatus("reject");
// 			    }
// //				allRequest.getToUserId().remove(blockUserDto.getToUserId());
// 				allRequestRepository.save(allRequest);
// 			}
// 		});

// 		Optional<UserWiseConnection> fromUserWiseConnection = userWiseConnectionRepository.findById(fromUserId);
// 		if(fromUserWiseConnection.isPresent())
// 		{
// 			fromUserWiseConnection.get().getUserIds().remove(blockUserDto.getToUserId());
// 			userWiseConnectionRepository.save(fromUserWiseConnection.get());
// 		}
// 		Optional<UserWiseConnection> toUserWiseConnection = userWiseConnectionRepository.findById(blockUserDto.getToUserId());
// 		if(toUserWiseConnection.isPresent())
// 		{
// 			toUserWiseConnection.get().getUserIds().remove(fromUserId);
// 			userWiseConnectionRepository.save(toUserWiseConnection.get());
// 		}

// 		// Following-Follower Change
// 		UserFollower userIdExistsInUserFollower = getUserFollowerById(fromUserId);
//     Long userIdExistsInUserFollowerCount = userIdExistsInUserFollower.getFollowingCount();
//     if(userIdExistsInUserFollowerCount > 0 )
// 		{
// 			userIdExistsInUserFollowerCount--;
// 		}
//     log.info("Following count decreased of userId: {}", fromUserId);
//     OffsetDateTime offsetDateTime = new Date().toInstant().atOffset(ZoneOffset.UTC);

// 		//check here id to replace with fromUserd
//     UserFollower decreasedFromUserIdSide = userFollowerMapper.toFollow(fromUserId, offsetDateTime,
//         userIdExistsInUserFollowerCount, userIdExistsInUserFollower);
    
//     UserFollower idExistsInUserFollower = getUserFollowerById(blockUserDto.getToUserId());
//         Long idExistsInUserFollowerCount = idExistsInUserFollower.getFollowerCount();
// 		if(idExistsInUserFollowerCount > 0 )
// 		{
// 			idExistsInUserFollowerCount--;
// 		}

//     log.info("Follower count decreased of id: {} in UserFollower", blockUserDto.getToUserId());
  
// 		//check here id to replace with blockUserDto.getToUserId()
//     UserFollower decreasedFromIdSide = userFollowerMapper.toFollow(blockUserDto.getToUserId(),
//         offsetDateTime, idExistsInUserFollowerCount, idExistsInUserFollower);

//       userFollowerRepository.save(decreasedFromUserIdSide);
//       userFollowerRepository.save(decreasedFromIdSide);

//       log.info("User : {} unfollow to: {}", fromUserId, blockUserDto.getToUserId());
//       followerRepository.unFollowUser(FollowStatus.INACTIVE.toString(), fromUserId, blockUserDto.getToUserId());

//       userOverViewRepository.decreaseFollowingsCount(fromUserId);
//       userOverViewRepository.decreaseFollowersCount(blockUserDto.getToUserId());
//     //   log.info("[unfollow] Exception while saving data", exception);

		
	}

	// private UserFollower getUserFollowerById(String id) {
  //   return userFollowerRepository.findById(id)
  //       .orElseThrow(() -> new ResourceNotFoundException("user", "id", id));
  // }

	@Transactional(rollbackOn = Exception.class)
	@Override
	public ResponseEntity<Response> unBlockUser(String fromUserId, BlockUserDto blockUserDto) {

		// userRepository.findById(fromUserId)
		// 		.orElseThrow(() -> new ResourceNotFoundException("user", "id", fromUserId));

		if(!blockUserDto.getOrigin().equals(BlockOrigin.USER)){

			log.info("[unBlockUser] origin type wrong, blockUserDto: {}",blockUserDto);
			throw new BadRequestException("Enter valid origin type");
		}

		if(!blockUserDto.getOriginId().equals(fromUserId)){

			log.info("[unBlockUser] originId!=fromUserId {} != {}", blockUserDto.getOriginId(), fromUserId);
			throw new BadRequestException("Enter valid originId");
		}

		BlockUser blockedUser = blockUserRepository.findByIds(fromUserId, blockUserDto.getToUserId(), 
				BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin());

		if(ObjectUtils.isEmpty(blockedUser) || !blockedUser.getFromUserId().equals(fromUserId)){
			// !blockUserRepository.isBlockedUser(fromUserId, blockUserDto.getToUserId(), 
			// 	BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin())

			log.info("[unblockUser] blockedUser: {}", blockedUser);
			log.info("[unBlockUser] fromUserId: {}, toUserId: {} is not blocked", fromUserId, blockUserDto.getToUserId());
			throw new BadRequestException("Invalid ask");
		}

		OffsetDateTime offset = new Date().toInstant().atOffset(ZoneOffset.UTC);

		blockedUser = blockUserMapper.toUpdateBlockUser(blockedUser, offset, 
			BlockedStatus.UNBLOCKED);

		try{
			blockUserRepository.save(blockedUser);
			return ResponseEntity.status(HttpStatus.CREATED)
					.body(Response.builder().message("UnBlocked User")
							.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

		}catch (Exception e){
			log.info("[unblockUser] Error while saving Exception: {}",e);
			throw new BadRequestException("Error while saving");
		}

		// blockUserRepository.getUnblockId(fromUserId, blockUserDto.getToUserId());

	}

	@Override
	public ResponseEntity<Response> blockedUserList(String fromUserId, ListingRequest request) {
		
		Pageable paging = PageRequest.of(request.getPage(), 
				b2bProperties.getPaging().getBlockSize());

		List<IBlockUserList> blockedUserList = blockUserRepository.blockuserList(fromUserId,
				BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), paging);

		// String sizeLength = blockUserRepository.findBlockCount(fromUserId).orElseThrow(null);
		
		return ResponseEntity.status(HttpStatus.OK)
			.body(Response.builder().message("Listing Response")
			.data(new ListingResponse(blockedUserList, request.getPage()))
			.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

	}
	
}
