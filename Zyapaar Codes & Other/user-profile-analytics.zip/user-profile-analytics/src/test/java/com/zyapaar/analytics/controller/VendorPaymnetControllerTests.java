package com.zyapaar.analytics.controller;

import com.zyapaar.analytics.properties.B2bProperties;
import com.zyapaar.analytics.service.ManageVendorPaymentService;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.analytics.request.ListingRequest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;

/**
 * MIS controller test
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = { B2bProperties.class })
public class VendorPaymnetControllerTests {

	@InjectMocks
	ManageVendorPaymentController vendorPaymentController;
	@Mock
	ManageVendorPaymentService vendorPaymentService;
	@Mock
	ListingRequest listingRequest;
	@Mock
	com.zyapaar.commons.request.ListingRequest listingCommonRequest;
	@Mock
	List<String> mobileNo;
	@Mock
	ResponseEntity<Response> response;
	@Mock
	InputStream file; 

	@Test
  @DisplayName("paymentCompleteSummaryInput")
  void paymentCompleteSummaryInput() {
    // when(vendorPaymentService.paymentCompleteSummaryInput());
	}

	// check
	@Test
  @DisplayName("payment")
  void payment() throws Exception  {
		when(vendorPaymentService.payment())
		.thenReturn(response);
    ResponseEntity<Response> actual = vendorPaymentController.payment();
    assertEquals(HttpStatus.OK, actual.getStatusCode());
    assertEquals(response, actual.getBody().getData());
  }

	@Test
  @DisplayName("paymentCompletionFormula")
  void paymentCompletionFormula() {
		when(vendorPaymentService.paymentCompletionFormula( anyString(), isA(ListingRequest.class)))
		.thenReturn(response);
    ResponseEntity<Response> actual = vendorPaymentController.paymentCompletionFormula("authUserId", listingRequest);
    assertEquals(HttpStatus.OK, actual.getStatusCode());
    assertEquals(response, actual.getBody().getData());
  }

	@Test
  @DisplayName("downlaodUserPaymentExcel")
  void downlaodUserPaymentExcel() throws IllegalStateException, IOException {
		when(vendorPaymentService.loadPaymentExcel())
		.thenReturn(file);
    ResponseEntity<InputStreamResource> actual = vendorPaymentController.downlaodUserPaymentExcel();
    assertEquals(HttpStatus.OK, actual.getStatusCode());
    assertEquals(file, actual.getBody().getInputStream());
  }

	@Test
  @DisplayName("getCsvFileData")
  void getCsvFileData() {
		when(vendorPaymentService.getCsvFileData( anyList() , isA(com.zyapaar.commons.request.ListingRequest.class)))
		.thenReturn(response);
    ResponseEntity<Response> actual = vendorPaymentController.getCsvFileData(mobileNo, listingCommonRequest);
    assertEquals(HttpStatus.OK, actual.getStatusCode());
    assertEquals(response, actual.getBody().getData());
  }

}
