package com.zyapaar.analytics.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.booleanThat;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.InputStream;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.analytics.dto.HalfFullRegDto;
import com.zyapaar.analytics.dto.ProfileCompletionFormulaDto;
import com.zyapaar.analytics.entities.ProfileCompleteSummary;
import com.zyapaar.analytics.entities.ProfileCompletionFormula;
import com.zyapaar.analytics.entities.UserEntity;
import com.zyapaar.analytics.entities.UserWiseConnection;
import com.zyapaar.analytics.mapper.ProfileCompletionFormulaMapper;
import com.zyapaar.analytics.mapper.ProfileCsvCompletionMapper;
import com.zyapaar.analytics.mapper.ProfileUsersExcelCompletionMapper;
import com.zyapaar.analytics.mapper.UnfinishedProfileUsersMapper;
import com.zyapaar.analytics.properties.B2bProperties;
import com.zyapaar.analytics.repository.CompanyRepository;
import com.zyapaar.analytics.repository.ProfileCompleteSummaryRepo;
import com.zyapaar.analytics.repository.ProfileCompletionFormulaRepo;
import com.zyapaar.analytics.repository.SignupStatusRepository;
import com.zyapaar.analytics.repository.UserRepository;
import com.zyapaar.analytics.repository.UserWiseConnectionRepository;
import com.zyapaar.analytics.request.ListingRequest;
import com.zyapaar.commons.dto.Response;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.util.ObjectUtils;
import org.unitils.reflectionassert.ReflectionAssert;

/**
 * Manage page member service test
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = { B2bProperties.class })
public class ManageVendorPaymentServiceTests {

	@InjectMocks
	ManageVendorPaymentService vendorPaymentService;
	@Mock
	ManageRegisteredUsersMisService registeredUsersMisService;
	@Mock
	B2bProperties b2bProperties;
	@Mock
	ProfileCompleteSummary profileCompleteSummary;
	@Mock
	List<UserEntity> userEntity;
	@Mock
	UnfinishedProfileUsersMapper unfinishedProfileUsersMapper;
	@Mock
	ProfileUsersExcelCompletionMapper profileUsersExcelCompletionMapper;
	@Mock
	ProfileCompletionFormulaMapper profileCompletionFormulaMapper;
	@Mock
	ProfileCsvCompletionMapper profileCsvCompletionMapper;
	@Mock
	ProfileCompletionFormula vendor;
	@Mock
	UserRepository userRepository;
	@Mock
	CompanyRepository companyRepository;
	@Mock
	SignupStatusRepository signupStatusRepository;
	@Mock
	UserWiseConnectionRepository userWiseConnectionRepository;
	@Mock
	ProfileCompletionFormulaDto profileCompletionFormulaDto;
	@Mock
	List<String> mobileNo;
	@Mock
	ResponseEntity<Response> response;
	@Mock
	ResponseEntity<InputStream> inputStream;
	@Mock
	Pageable page;
	@Mock
	ListingRequest listingRequest;
	@Mock
	com.zyapaar.commons.request.ListingRequest listingCommonRequest;
	@Mock
	InputStream file;
	@Mock
	ProfileCompleteSummaryRepo profileCompleteSummaryRepo;
	@Mock
	ProfileCompletionFormulaRepo profileCompletionFormulaRepo;

	@BeforeEach
	void setUp() {
		userRepository = Mockito.mock(UserRepository.class);
		companyRepository = Mockito.mock(CompanyRepository.class);
		signupStatusRepository = Mockito.mock(SignupStatusRepository.class);
		vendorPaymentService = new ManageVendorPaymentService(profileCompleteSummaryRepo, profileCompletionFormulaRepo, 
		userWiseConnectionRepository, userRepository, b2bProperties, 
		unfinishedProfileUsersMapper, profileUsersExcelCompletionMapper, 
		profileCompletionFormulaMapper, profileCsvCompletionMapper);
	}

	//done
	@Test
  @DisplayName("paymentCompleteSummaryInput")
  void paymentCompleteSummaryInput(){
    
		List<UserEntity> expectedList = userRepository.getUnfinishedProfileUsers();
		OffsetDateTime loacalTime = OffsetDateTime.now().toInstant().atOffset(ZoneOffset.UTC);
		 
		expectedList.add(new UserEntity("1",null, 
		null, null, "1",loacalTime, null,
		"vis@123gmail.com",true,"Rahul", "Rahul lokesh", null,
		"lokesh", "8299334455", "user","Accountant", "1",
		loacalTime, null, "loki", true));

		 List<ProfileCompleteSummary> summaryUserList = new ArrayList<>();

		 summaryUserList.add(new ProfileCompleteSummary("1",loacalTime ,true,loacalTime, 
		 loacalTime,loacalTime,loacalTime,"8299326400",loacalTime,80,
		 loacalTime,loacalTime,loacalTime,loacalTime));

		 equals(new ResponseEntity(summaryUserList, HttpStatus.OK));
		 Mockito.verify(userRepository, Mockito.times(1)).getUnfinishedProfileUsers();
	
		}

	//done
	@Test
  @DisplayName("payment")
  void payment(){

		List<ProfileCompleteSummary> expected = profileCompleteSummaryRepo.checkforValue();
		OffsetDateTime loacalTime = OffsetDateTime.now().toInstant().atOffset(ZoneOffset.UTC);

		expected.add(new ProfileCompleteSummary("1",loacalTime ,true,loacalTime, 
		loacalTime,loacalTime,loacalTime,"8299326400",loacalTime,80,
		loacalTime,loacalTime,loacalTime,loacalTime));

		UserWiseConnection userWiseConnection = new UserWiseConnection();
		Timestamp time = new Timestamp(0, 0, 0, 0, 0, 0, 0);
		List<String> value = new ArrayList<>();

		Mockito.when(profileCompleteSummaryRepo.findByDowlaodNativeQuery(Mockito.any()))
		.thenReturn(time);

		Mockito.when(profileCompleteSummaryRepo.findByRegistrationNativeQuery(Mockito.any()))
		.thenReturn(time);

		Mockito.when(profileCompleteSummaryRepo.findByUserLogoNativeQuery(Mockito.any()))
		.thenReturn(time);

		Mockito.when(profileCompleteSummaryRepo.findByEntityLogoNativeQuery(Mockito.any()))
		.thenReturn(value);

		Mockito.when(profileCompleteSummaryRepo.findByProductNativeQuery(Mockito.any()))
		.thenReturn(true);

		Mockito.when(profileCompleteSummaryRepo.findByBuyNativeQuery(Mockito.any()))
		.thenReturn(true);

		Mockito.when(profileCompleteSummaryRepo.findBySellNativeQuery(Mockito.any()))
		.thenReturn(true);

		Mockito.when(userWiseConnectionRepository.findByConnectionNativeQuery(Mockito.any()))
		.thenReturn(userWiseConnection);

		Mockito.when(profileCompleteSummary.getComplete())
		.thenReturn(true);

		Mockito.when(vendorPaymentService.payment())
		.thenReturn(new ResponseEntity(expected, HttpStatus.OK));		
		ResponseEntity<Response> actual = vendorPaymentService.payment();
		assertEquals(actual, new ResponseEntity(expected, HttpStatus.OK));
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findByDowlaodNativeQuery(Mockito.any());
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findByRegistrationNativeQuery(Mockito.any());
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findByUserLogoNativeQuery(Mockito.any());
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findByEntityLogoNativeQuery(Mockito.any());
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findByProductNativeQuery(Mockito.any());
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findByBuyNativeQuery(Mockito.any());
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findBySellNativeQuery(Mockito.any());
		Mockito.verify(userWiseConnectionRepository, Mockito.times(1)).findByConnectionNativeQuery(Mockito.any());
  }

	//done
	@Test
  @DisplayName("paymentCompletionFormula")
  void paymentCompletionFormula(){

		when(listingCommonRequest.getPage()).thenReturn(1);

		List<ProfileCompleteSummary> excelCompletionList = profileCompleteSummaryRepo.findByExcelWeekNativeQuery();
		OffsetDateTime loacalTime = OffsetDateTime.now().toInstant().atOffset(ZoneOffset.UTC);

		excelCompletionList.add(new ProfileCompleteSummary("1",loacalTime ,true,loacalTime, 
		loacalTime,loacalTime,loacalTime,"8299326400",loacalTime,80,
		loacalTime,loacalTime,loacalTime,loacalTime));

		List<ProfileCompletionFormulaDto> expectedList = new ArrayList<ProfileCompletionFormulaDto>();
		
		expectedList.add(new ProfileCompletionFormulaDto("1","829932400",loacalTime, 
		loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, 
		loacalTime, null, null));

		ResponseEntity<Response> actual = vendorPaymentService.paymentCompletionFormula(Mockito.any(), listingRequest);
    assertEquals(actual, new ResponseEntity(excelCompletionList, HttpStatus.OK));
		assertEquals(actual, new ResponseEntity(expectedList, HttpStatus.OK));
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findByWeekNativeQuery(page);
  }

	//done
	@Test
  @DisplayName("loadPaymentExcel")
  void loadPaymentExcel(){

		when(listingCommonRequest.getPage()).thenReturn(1);

		List<ProfileCompletionFormulaDto> expectedList = new ArrayList<ProfileCompletionFormulaDto>();
		OffsetDateTime loacalTime = OffsetDateTime.now().toInstant().atOffset(ZoneOffset.UTC);
		expectedList.add(new ProfileCompletionFormulaDto("1","829932400",loacalTime, 
		 loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, 
		 loacalTime, null, null));

		InputStream inputStream = vendorPaymentService.loadPaymentExcel();
    assertEquals(inputStream, new ResponseEntity(expectedList, HttpStatus.OK));
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findByExcelWeekNativeQuery();
  }

//done
	@Test
  @DisplayName("getCsvFileData")
  void getCsvFileData(){

		when(listingCommonRequest.getPage()).thenReturn(1);

		List<ProfileCompleteSummary> expected = new ArrayList<>();
		OffsetDateTime loacalTime = OffsetDateTime.now().toInstant().atOffset(ZoneOffset.UTC);

		expected.add(new ProfileCompleteSummary("1",loacalTime ,true,loacalTime, 
		loacalTime,loacalTime,loacalTime,"8299326400",loacalTime,80,
		loacalTime,loacalTime,loacalTime,loacalTime));
		
		when(profileCompleteSummaryRepo.findByMobileNo(Mockito.any(), page))
		.thenReturn(expected);
		ResponseEntity<Response> actual = vendorPaymentService.getCsvFileData(Mockito.any(), listingCommonRequest);
		assertEquals(actual, new ResponseEntity(expected, HttpStatus.OK));
		Mockito.verify(profileCompleteSummaryRepo, Mockito.times(1)).findByMobileNo(Mockito.any(),page);

  }

	@AfterEach
	void afterEach(){
			System.out.println("@AfterEach executed");
	}


}
