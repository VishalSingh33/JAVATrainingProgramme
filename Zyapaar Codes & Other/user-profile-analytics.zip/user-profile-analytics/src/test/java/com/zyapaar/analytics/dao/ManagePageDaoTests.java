package com.zyapaar.analytics.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.when;

import java.util.List;

// import com.zyapaar.pageservice.dto.PageDetails;
// import com.zyapaar.pageservice.model.PageMembers;
// import com.zyapaar.pageservice.model.Pages;
import com.zyapaar.analytics.properties.B2bProperties;
import com.zyapaar.analytics.properties.B2bProperties.Paging;
// import com.zyapaar.pageservice.repository.PageRepository;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.data.mongodb.core.MongoTemplate;
// import org.springframework.data.mongodb.core.aggregation.Aggregation;
// import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.test.context.ContextConfiguration;

/**
 * page dao tests
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = { B2bProperties.class })
public class ManagePageDaoTests {

  // @InjectMocks
  // ManagePageDao managePageDao;
  // @Mock
  // PageRepository pageRepository;
  // @Mock
  // Pages pages;
  // @Mock
  // B2bProperties b2bProperties;
  // @Mock
  // Paging paging;
  // @Mock
  // List<PageDetails> pagesList;
  // @Mock
  // MongoTemplate mongoTemplate;
  // @Mock
  // AggregationResults<PageDetails> aggregationResults;

  // @Test
  // @DisplayName("createPage")
  // void createPage(){

  //   when(pageRepository.save(isA(Pages.class))).thenReturn(pages);

  //   Pages actual = managePageDao.createPage(pages);

  //   assertNotNull(actual);
  // }

  // @Test
  // @DisplayName("getPageDetails")
  // void getPageDetails(){

  //   when(pageRepository.findByIdAndAdmin(anyString(), anyString())).thenReturn(pages);

  //   Pages actual = managePageDao.getPageDetails("userId", "pageId");
  //   assertEquals(pages, actual);
  // }

  // @Test
  // @DisplayName("getPageList")
  // void getPageList(){

  //   when(b2bProperties.getPaging()).thenReturn(paging);
  //   when(paging.getPageListSize()).thenReturn(1);

  //   when(mongoTemplate.aggregate(isA(Aggregation.class), eq(PageMembers.class), 
  //       eq(PageDetails.class))).thenReturn(aggregationResults);
  //   when(aggregationResults.getMappedResults()).thenReturn(pagesList);

  //   List<PageDetails> actual = managePageDao.getPageList("userId", 1);

  //   assertEquals(pagesList, actual);
  // }

}
