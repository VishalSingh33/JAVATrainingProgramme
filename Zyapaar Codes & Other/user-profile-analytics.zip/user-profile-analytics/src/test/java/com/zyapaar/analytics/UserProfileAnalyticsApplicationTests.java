// package com.zyapaar.analytics;

// import org.junit.jupiter.api.Test;
// import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
// class UserProfileAnalyticsApplicationTests {

// 	@Test
// 	void contextLoads() {
// 	}

// }
