package com.zyapaar.analytics.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.doNothing;

import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.List;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.analytics.properties.B2bProperties;
import com.zyapaar.analytics.request.ListingRequest;
import static org.mockito.Mockito.when;
import com.zyapaar.analytics.service.ManageRegisteredUsersMisService;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;

/**
 * Page member controller
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = { B2bProperties.class })
public class RegisteredUsersMisControllerTest {

	@InjectMocks
	ManageRegisteredUsersMisController registeredUsersMisController;
	@Mock
	ManageRegisteredUsersMisService registeredUsersMisService;
	@Mock
	ListingRequest listingRequest;
	@Mock
	com.zyapaar.commons.request.ListingRequest listingCommonRequest;
	@Mock
	CommonSearch commonSearch;
	@Mock
	ResponseEntity<Response> response;

	//done
	@Test
  @DisplayName("getRegisteredUsers")
  void getRegisteredUsers() {
    when(registeredUsersMisService.getRegisteredUsers( isA(CommonSearch.class)))
		.thenReturn(response);
    ResponseEntity<Response> actual = registeredUsersMisController.getRegisteredUsers(commonSearch);
    assertEquals(HttpStatus.OK, actual.getStatusCode());
    assertEquals(response, actual.getBody().getData());
	}

	//done
	@Test
  @DisplayName("getAllReg")
  void getAllReg() {
		when(registeredUsersMisService.getAllReg(isA(CommonSearch.class)))
		.thenReturn(response);
    ResponseEntity<Response> actual = registeredUsersMisController.getAllReg(commonSearch);
    assertEquals(HttpStatus.OK, actual.getStatusCode());
    assertEquals(response, actual.getBody().getData());
  }



}
