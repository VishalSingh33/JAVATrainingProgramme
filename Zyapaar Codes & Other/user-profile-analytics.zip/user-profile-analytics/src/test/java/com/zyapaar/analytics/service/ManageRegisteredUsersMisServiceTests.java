package com.zyapaar.analytics.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Answers.values;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.AccessDeniedException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.analytics.dto.HalfFullRegDto;
import com.zyapaar.analytics.dto.ProfileCompletionFormulaDto;
import com.zyapaar.analytics.entities.Entities;
import com.zyapaar.analytics.entities.ProfileCompleteSummary;
import com.zyapaar.analytics.entities.ProfileCompletionFormula;
import com.zyapaar.analytics.entities.UserEntity;
import com.zyapaar.analytics.mapper.ProfileCompletionFormulaMapper;
import com.zyapaar.analytics.mapper.ProfileUsersExcelCompletionMapper;
import com.zyapaar.analytics.mapper.UnfinishedProfileUsersMapper;
import com.zyapaar.analytics.properties.B2bProperties;
import com.zyapaar.analytics.repository.CompanyRepository;
import com.zyapaar.analytics.repository.ProfileCompleteSummaryRepo;
import com.zyapaar.analytics.repository.ProfileCompletionFormulaRepo;
import com.zyapaar.analytics.repository.SignupStatusRepository;
import com.zyapaar.analytics.repository.UserRepository;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.FileUploadResponse;
import com.zyapaar.commons.response.ListingResponse;
import org.unitils.reflectionassert.ReflectionAssert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import java.util.Optional;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

import reactor.core.publisher.Mono;

/**
 * page service test
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = { B2bProperties.class })
public class ManageRegisteredUsersMisServiceTests {

	@InjectMocks
	ManageVendorPaymentService vendorPaymentService;
	@Mock
	ManageRegisteredUsersMisService registeredUsersMisService;
	@Mock
	B2bProperties b2bProperties;
	@Mock
	ProfileCompleteSummary profileCompleteSummary;
	@Mock
	UserEntity userEntity;
	@Mock
	UnfinishedProfileUsersMapper unfinishedProfileUsersMapper;
	@Mock
	ProfileUsersExcelCompletionMapper profileUsersExcelCompletionMapper;
	@Mock
	ProfileCompletionFormulaMapper profileCompletionFormulaMapper;
	@Mock
	ProfileCompletionFormula vendor;
	@Mock
	ProfileCompletionFormulaDto profileCompletionFormulaDto;
	@Mock
	Optional<String> mobileNo;
	@Mock
	List<HalfFullRegDto> registeredUserEntity;
	@Mock
	ResponseEntity<Response> response;
	@Mock
	ListingRequest listingRequest;
	@Mock
	com.zyapaar.commons.request.ListingRequest listingCommonRequest;
	@Mock
	InputStream file;
	@Mock
	UserRepository userRepository;
	@Mock
	CompanyRepository companyRepository;
	@Mock
	SignupStatusRepository signupStatusRepository;
	@Mock
	ProfileCompleteSummaryRepo profileCompleteSummaryRepo;
	@Mock
	ProfileCompletionFormulaRepo profileCompletionFormulaRepo;
	@Mock
	CommonSearch commonSearch;
	@Mock
	Pageable page;

	@BeforeEach
	void setUp() {
		userRepository = Mockito.mock(UserRepository.class);
		companyRepository = Mockito.mock(CompanyRepository.class);
		signupStatusRepository = Mockito.mock(SignupStatusRepository.class);
		registeredUsersMisService = new ManageRegisteredUsersMisService(userRepository,
				companyRepository, b2bProperties, signupStatusRepository,
				profileCompleteSummaryRepo, profileUsersExcelCompletionMapper);
	}

	@Test
	@DisplayName("getRegisteredUsers")
void getRegisteredUsers() {

		// when(registeredUsersMisService.getRegisteredUsers(isA(CommonSearch.class)))
		// .thenReturn(response);

		// String expextedSearch = commonSearch.getSearch();
		// Mockito.when(commonSearch.getSearch())
		// 		.thenReturn(expextedSearch);

		// Entities expextedIdentity = companyRepository.getByIdentityNo(expextedSearch);
		// Mockito.when(commonSearch.getSearch())
		// 		.thenReturn(expextedSearch);

		// String expextedtype = commonSearch.getType();
		// Mockito.when(signupStatusRepository.findByMobileNo(expextedtype))
		// 		.thenReturn(mobileNo);

		// ResponseEntity<Response> actual = registeredUsersMisService.getRegisteredUsers(commonSearch);
		// ReflectionAssert.assertReflectionEquals(actual, null);

		 List<ProfileCompleteSummary> expected = new ArrayList<>();
		 List<ProfileCompletionFormulaDto> registeredList = new ArrayList<>();
		 OffsetDateTime loacalTime = OffsetDateTime.now().toInstant().atOffset(ZoneOffset.UTC);
		 
		 registeredList.add(new ProfileCompletionFormulaDto("1","829932400",loacalTime, 
		 loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, loacalTime, 
		 loacalTime, null, null));

		 expected.add(new ProfileCompleteSummary("1",loacalTime ,true,loacalTime 
		 ,loacalTime,loacalTime,loacalTime,"8299326400",loacalTime,80,
		 loacalTime,loacalTime,loacalTime,loacalTime));
		 when(profileCompleteSummaryRepo.findAll())
		 .thenReturn(expected);
		 CommonSearch commonSearch = new CommonSearch(Mockito.any(),Mockito.any(),0);
		 Mockito.when(signupStatusRepository.findByMobileNo(Mockito.any()))
		 .thenReturn(Optional.of("FULL"));
		 
		 OffsetDateTime loacalZone = OffsetDateTime.now().toInstant().atOffset(ZoneOffset.UTC);
		 Entities entities = new Entities("1",null,"SEO",null,"Rahul",1,
		 3,
		 "Ahmedabad","Ashram Rd","382481", "Ahmedabad", null, null, "vishal@123gmail.com"
		 , "goods", "24ADZPP9308E1Z2", loacalZone, loacalZone, "1", "3", null,
		  null, null, null, null, "2");
		 Mockito.when( companyRepository.getByIdentityNo(Mockito.any()))
		 .thenReturn(entities);
		 Mockito.when( registeredUsersMisService.getRegisteredUsers(commonSearch))
		 .thenReturn( new ResponseEntity(registeredList, HttpStatus.OK));
		 ResponseEntity<Response> actual = registeredUsersMisService.getRegisteredUsers(commonSearch);
		 assertEquals(actual, new ResponseEntity(registeredList, HttpStatus.OK));
		 Mockito.verify(signupStatusRepository, Mockito.times(1)).findByMobileNo(Mockito.any());
	}

	@Test
  @DisplayName("getAllReg")
  void getAllReg(){

		// when(registeredUsersMisService.getAllReg(isA(CommonSearch.class)))
		// .thenReturn(response);

		// when(listingCommonRequest.getPage()).thenReturn(1);

		// List<HalfFullRegDto> expected = new ArrayList<>();
		// Mockito.when(userRepository.getReg(Mockito.any(), Mockito.any(), null))
		// .thenReturn(expected);

		// Mockito.when(userRepository.getRegBySearch(Mockito.any(), null))
		// .thenReturn(expected);

		// Mockito.when(userRepository.getRegByType(Mockito.any(), null))
		// .thenReturn(expected);

		// Mockito.when(userRepository.getReg( null))
		// .thenReturn(expected);

		// ResponseEntity<Response> actual = registeredUsersMisService.getAllReg(commonSearch);
    // ReflectionAssert.assertReflectionEquals(actual, actual);

		when(listingCommonRequest.getPage()).thenReturn(1);

		List<HalfFullRegDto> expected = new ArrayList<>();
		OffsetDateTime loacalZone = OffsetDateTime.now().toInstant().atOffset(ZoneOffset.UTC);
		// expected.add(new HalfFullRegDto("FULL","1","Vishal","8233326400",loacalZone,loacalZone,"1","221003","Ahmedabad","2","2154688748"));
		CommonSearch commonSearch = new CommonSearch(Mockito.any(),Mockito.any(),0);

		 Mockito.when(userRepository.getRegBySearch(Mockito.any(),page))
		 .thenReturn(expected);

		 Mockito.when(userRepository.getRegByType(Mockito.any(),page))
		 .thenReturn(expected);

		 Mockito.when(userRepository.getReg(Mockito.any(),Mockito.any(),page))
		 .thenReturn(expected);


		 Mockito.when( registeredUsersMisService.getAllReg(commonSearch))
		 .thenReturn( new ResponseEntity(expected, HttpStatus.OK));
		 ResponseEntity<Response> actual = registeredUsersMisService.getAllReg(commonSearch);
		 assertEquals(actual, new ResponseEntity(expected, HttpStatus.OK));
		 Mockito.verify(userRepository, Mockito.times(1)).getRegBySearch(Mockito.any(),page);
		 Mockito.verify(userRepository, Mockito.times(1)).getRegByType(Mockito.any(),page);
		 Mockito.verify(userRepository, Mockito.times(1)).getReg(Mockito.any(),Mockito.any(),page);
	}

	@AfterEach
	void afterEach(){
			System.out.println("@AfterEach executed");
	}

}
