package com.zyapaar.analytics.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

// import com.zyapaar.analytics.model.Industry;
import com.zyapaar.analytics.properties.B2bProperties;
// import com.zyapaar.analytics.repository.IndustryRepository;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

/**
 * Industry dao test
 * 
 * @author Uday Halpara
 */
@SpringBootTest
@ContextConfiguration(classes = { B2bProperties.class })
public class ManageIndustryDaoTests {

  // @InjectMocks
  // ManageIndustryDao manageIndustryDao;
  // @Mock
  // IndustryRepository industryRepository;
  // @Mock
  // Industry industry;

  // @Test
  // @DisplayName("getIndstry test")
  // void getIndstry(){

  //   when(industryRepository.findBySubIndustryID(anyString())).thenReturn(industry);

  //   Industry actual = manageIndustryDao.getIndstry("catagory");

  //   assertEquals(industry, actual);

  // }

}
