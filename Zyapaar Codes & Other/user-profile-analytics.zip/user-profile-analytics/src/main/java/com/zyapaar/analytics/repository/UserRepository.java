package com.zyapaar.analytics.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import com.zyapaar.analytics.dto.HalfFullRegDto;
import com.zyapaar.analytics.entities.UserEntity;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, String> {

	@Query(
    nativeQuery = true,
    value = "SELECT EXISTS(SELECT id FROM users WHERE id<>:userId AND mobile_no=:mobileNumber)"
  )
  Boolean existsByMobileNumberAndUserId(String mobileNumber, String userId);

  @Query(
    nativeQuery = true,
    value = "SELECT EXISTS(SELECT id FROM users WHERE mobile_no=:mobileNumber)"
  )
  Boolean existsByMobileNumber(String mobileNumber);
 
  @Query(
    nativeQuery = true,
    value = "SELECT * FROM users WHERE id in (:userId)"
  )
  List<UserEntity> existsByUserIdAndUserConnection(List<String> userId,
      Pageable requestedPage);

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM users WHERE id in (:userIdList)"
  )
  List<UserEntity> findMatchedUserData(List<String> userIdList,
      Pageable requestedPage);

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM users WHERE mobile_no=:mobileNo"
  )
  UserEntity findByMobileNumber(String mobileNo);

  @Query(
    nativeQuery = true,
    value = "SELECT u.* FROM user_connection uc" +
      " INNER JOIN users u ON (u.id = uc.from_user_id OR u.id = uc.to_user_id) AND u.id != :userId" +
      " WHERE(uc.from_user_id=:userId OR uc.to_user_id=:userId) AND uc.status=:status"
  )
  Optional<List<UserEntity>> findUserConnectionsById(String userId, Pageable paging,String status); //accept

  @Query(
    nativeQuery = true,
    value = "SELECT u.* FROM user_connection uc" 
      + " INNER JOIN user_industry ui ON (ui.user_id = uc.from_user_id OR ui.user_id = uc.to_user_id)"
        + " AND ui.user_id != :userId AND :industryId = ANY(ui.keyword_buys_sells_id)"
      + " INNER JOIN users u ON u.id = ui.user_id"
      + " WHERE (uc.from_user_id = :userId OR uc.to_user_id = :userId) AND uc.status = :status"
  )
  Optional<List<UserEntity>> findUserConnectionsByIndustry(String userId, String industryId, String status, Pageable paging);

  @Query(
    nativeQuery = true,
    value = "SELECT DISTINCT u.* FROM follower f"
      + " INNER JOIN users u ON f.follower_user = u.id"
      + " WHERE f.status = 'ACTIVE' AND f.user_follower_id=:userId"
  )
  List<UserEntity> getFollowerById(String userId, Pageable paging);
  
  @Query(
    nativeQuery = true,
    value = "SELECT DISTINCT u.* FROM follower f"
      + " INNER JOIN users u ON f.user_follower_id = u.id"
      + " WHERE f.status = 'ACTIVE' AND f.follower_user=:userId"
  )
  List<UserEntity> getFollowingById(String userId, Pageable paging);

	@Query(nativeQuery = true, value = "	SELECT * FROM users u  "
	+ " WHERE updated_on >=(NOW() - interval '1 day') ")
  List<UserEntity> getUnfinishedProfileUsers();

// findAll
@Query(nativeQuery = true, value = " SELECT COUNT(*) OVER () as TotalCount, ss.status,u.id,u.full_name as fullName ,"
+ " u.mobile_no as mobileNo ,u.created_on as createdOn, u.updated_on as updatedOn, "
+ "	CASE e.nature_of_business WHEN 1 THEN'MANUFACTURING'WHEN 2 THEN'TRADER'WHEN 3 THEN'PUBLIC_LIMITED_COMPANY' "
+ " WHEN 4 THEN'PVT_LIMITED_COMPANY'WHEN 5 THEN'FREELANCER'WHEN 6 THEN'NON_PROFIT_ORGANIZATION'  "
+ " WHEN 7 THEN'OTHERS' END AS natureOfBusiness, e.pincode, e.city, "
+ " CASE e.type WHEN 1 THEN'PROPRIETORSHIP'WHEN 2 THEN'PARTNERSHIP_LLP'WHEN 3 THEN'SERVICE_PROVIDER'WHEN 4 "
+ " THEN'WORKS_CONTRACT'WHEN 5 THEN'TRUST'WHEN 6 THEN'SOCIETIES'WHEN 7 THEN'ASSOCIATIONS_CLUB' "
+ " WHEN 8 THEN'BANK_FINANCIAL_INSTITUTATION' WHEN 9 THEN'EDUCATION_INSTUATION' "
+ " WHEN 10 THEN'GOVERNMENT_PUBLIC_SECTOR_Undertaking' WHEN 11 THEN'OTHERS' END AS type, "
+ " e.identity_number as identityNo from users u left join entities e on u.id = e.user_id left "
+ " join signup_status ss on u.mobile_no = ss.mobile_no WHERE "
+ "	(e.identity_number = :search or u.mobile_no = :search ) and ss.status = :typeSearch  ")
List<HalfFullRegDto> getReg(String search, String typeSearch, Pageable paging);

@Query(nativeQuery = true, value = " SELECT COUNT(*) OVER () as TotalCount, ss.status,u.id,u.full_name as fullName ,"
+ " u.mobile_no as mobileNo ,u.created_on as createdOn, u.updated_on as updatedOn, "
+ "	CASE e.nature_of_business WHEN 1 THEN'MANUFACTURING'WHEN 2 THEN'TRADER'WHEN 3 THEN'PUBLIC_LIMITED_COMPANY' "
+ " WHEN 4 THEN'PVT_LIMITED_COMPANY'WHEN 5 THEN'FREELANCER'WHEN 6 THEN'NON_PROFIT_ORGANIZATION'  "
+ " WHEN 7 THEN'OTHERS' END AS natureOfBusiness, e.pincode, e.city, "
+ " CASE e.type WHEN 1 THEN'PROPRIETORSHIP'WHEN 2 THEN'PARTNERSHIP_LLP'WHEN 3 THEN'SERVICE_PROVIDER'WHEN 4 "
+ " THEN'WORKS_CONTRACT'WHEN 5 THEN'TRUST'WHEN 6 THEN'SOCIETIES'WHEN 7 THEN'ASSOCIATIONS_CLUB' "
+ " WHEN 8 THEN'BANK_FINANCIAL_INSTITUTATION' WHEN 9 THEN'EDUCATION_INSTUATION' "
+ " WHEN 10 THEN'GOVERNMENT_PUBLIC_SECTOR_Undertaking' WHEN 11 THEN'OTHERS' END AS type, "
+ " e.identity_number as identityNo from users u left join entities e on u.id = e.user_id left "
+ " join signup_status ss on u.mobile_no = ss.mobile_no WHERE "
+ "	(e.identity_number = :search or u.mobile_no = :search ) and ss.status = :typeSearch and u.updated_on between :from and :to ")
List<HalfFullRegDto> getRegDate(String search, String typeSearch, LocalDate from, LocalDate to, Pageable paging);

//type && search == null
@Query(nativeQuery = true, value =" SELECT COUNT(*) OVER () as TotalCount, ss.status,u.id,u.full_name as fullName ,"
+ " u.mobile_no as mobileNo ,u.created_on as createdOn, u.updated_on as updatedOn, "
+ "	CASE e.nature_of_business WHEN 1 THEN'MANUFACTURING'WHEN 2 THEN'TRADER'WHEN 3 THEN'PUBLIC_LIMITED_COMPANY' "
+ " WHEN 4 THEN'PVT_LIMITED_COMPANY'WHEN 5 THEN'FREELANCER'WHEN 6 THEN'NON_PROFIT_ORGANIZATION'  "
+ " WHEN 7 THEN'OTHERS' END AS natureOfBusiness, e.pincode, e.city, "
+ " CASE e.type WHEN 1 THEN'PROPRIETORSHIP'WHEN 2 THEN'PARTNERSHIP_LLP'WHEN 3 THEN'SERVICE_PROVIDER'WHEN 4 "
+ " THEN'WORKS_CONTRACT'WHEN 5 THEN'TRUST'WHEN 6 THEN'SOCIETIES'WHEN 7 THEN'ASSOCIATIONS_CLUB' "
+ " WHEN 8 THEN'BANK_FINANCIAL_INSTITUTATION' WHEN 9 THEN'EDUCATION_INSTUATION' "
+ " WHEN 10 THEN'GOVERNMENT_PUBLIC_SECTOR_Undertaking' WHEN 11 THEN'OTHERS' END AS type, "
+ " e.identity_number as identityNo from users u left join entities e on u.id = e.user_id left "
+ " join signup_status ss on u.mobile_no = ss.mobile_no WHERE "
+ " u.updated_on between :from and :to " )
List<HalfFullRegDto> getByDate(LocalDate from, LocalDate to, Pageable paging);



// search
@Query(nativeQuery = true, value = " SELECT COUNT(*) OVER () as TotalCount, ss.status,u.id,u.full_name as fullName ,"
+ " u.mobile_no as mobileNo ,u.created_on as createdOn, u.updated_on as updatedOn, "
+ "	CASE e.nature_of_business WHEN 1 THEN'MANUFACTURING'WHEN 2 THEN'TRADER'WHEN 3 THEN'PUBLIC_LIMITED_COMPANY' "
+ " WHEN 4 THEN'PVT_LIMITED_COMPANY'WHEN 5 THEN'FREELANCER'WHEN 6 THEN'NON_PROFIT_ORGANIZATION'  "
+ " WHEN 7 THEN'OTHERS' END AS natureOfBusiness, e.pincode, e.city, "
+ " CASE e.type WHEN 1 THEN'PROPRIETORSHIP'WHEN 2 THEN'PARTNERSHIP_LLP'WHEN 3 THEN'SERVICE_PROVIDER'WHEN 4 "
+ " THEN'WORKS_CONTRACT'WHEN 5 THEN'TRUST'WHEN 6 THEN'SOCIETIES'WHEN 7 THEN'ASSOCIATIONS_CLUB' "
+ " WHEN 8 THEN'BANK_FINANCIAL_INSTITUTATION' WHEN 9 THEN'EDUCATION_INSTUATION' "
+ " WHEN 10 THEN'GOVERNMENT_PUBLIC_SECTOR_Undertaking' WHEN 11 THEN'OTHERS' END AS type, "
+ " e.identity_number as identityNo from users u left join entities e on u.id = e.user_id left "
+ " join signup_status ss on u.mobile_no = ss.mobile_no WHERE "
+ "	(e.identity_number = :search or u.mobile_no = :search ) ")
List<HalfFullRegDto> getRegBySearch(String search, Pageable paging);

@Query(nativeQuery = true, value = " SELECT COUNT(*) OVER () as TotalCount, ss.status,u.id,u.full_name as fullName ,"
+ " u.mobile_no as mobileNo ,u.created_on as createdOn, u.updated_on as updatedOn, "
+ "	CASE e.nature_of_business WHEN 1 THEN'MANUFACTURING'WHEN 2 THEN'TRADER'WHEN 3 THEN'PUBLIC_LIMITED_COMPANY' "
+ " WHEN 4 THEN'PVT_LIMITED_COMPANY'WHEN 5 THEN'FREELANCER'WHEN 6 THEN'NON_PROFIT_ORGANIZATION'  "
+ " WHEN 7 THEN'OTHERS' END AS natureOfBusiness, e.pincode, e.city, "
+ " CASE e.type WHEN 1 THEN'PROPRIETORSHIP'WHEN 2 THEN'PARTNERSHIP_LLP'WHEN 3 THEN'SERVICE_PROVIDER'WHEN 4 "
+ " THEN'WORKS_CONTRACT'WHEN 5 THEN'TRUST'WHEN 6 THEN'SOCIETIES'WHEN 7 THEN'ASSOCIATIONS_CLUB' "
+ " WHEN 8 THEN'BANK_FINANCIAL_INSTITUTATION' WHEN 9 THEN'EDUCATION_INSTUATION' "
+ " WHEN 10 THEN'GOVERNMENT_PUBLIC_SECTOR_Undertaking' WHEN 11 THEN'OTHERS' END AS type, "
+ " e.identity_number as identityNo from users u left join entities e on u.id = e.user_id left "
+ " join signup_status ss on u.mobile_no = ss.mobile_no WHERE "
+ "	(e.identity_number = :search or u.mobile_no = :search ) and u.updated_on between :from and :to  ")
List<HalfFullRegDto> getRegBySearchDate(String search, LocalDate from, LocalDate to, Pageable paging);

// type
@Query(nativeQuery = true, value = " SELECT COUNT(*) OVER () as TotalCount, ss.status,u.id,u.full_name as fullName ,"
+ " u.mobile_no as mobileNo ,u.created_on as createdOn, u.updated_on as updatedOn, "
+ "	CASE e.nature_of_business WHEN 1 THEN'MANUFACTURING'WHEN 2 THEN'TRADER'WHEN 3 THEN'PUBLIC_LIMITED_COMPANY' "
+ " WHEN 4 THEN'PVT_LIMITED_COMPANY'WHEN 5 THEN'FREELANCER'WHEN 6 THEN'NON_PROFIT_ORGANIZATION'  "
+ " WHEN 7 THEN'OTHERS' END AS natureOfBusiness, e.pincode, e.city, "
+ " CASE e.type WHEN 1 THEN'PROPRIETORSHIP'WHEN 2 THEN'PARTNERSHIP_LLP'WHEN 3 THEN'SERVICE_PROVIDER'WHEN 4 "
+ " THEN'WORKS_CONTRACT'WHEN 5 THEN'TRUST'WHEN 6 THEN'SOCIETIES'WHEN 7 THEN'ASSOCIATIONS_CLUB' "
+ " WHEN 8 THEN'BANK_FINANCIAL_INSTITUTATION' WHEN 9 THEN'EDUCATION_INSTUATION' "
+ " WHEN 10 THEN'GOVERNMENT_PUBLIC_SECTOR_Undertaking' WHEN 11 THEN'OTHERS' END AS type, "
+ " e.identity_number as identityNo from users u left join entities e on u.id = e.user_id left "
+ " join signup_status ss on u.mobile_no = ss.mobile_no WHERE ss.status = 'FULL' ")
List<HalfFullRegDto> getRegByType(Pageable paging);

@Query(nativeQuery = true, value = " SELECT COUNT(*) OVER () as TotalCount, ss.status,u.id,u.full_name as fullName ,"
+ " u.mobile_no as mobileNo ,u.created_on as createdOn, u.updated_on as updatedOn, "
+ "	CASE e.nature_of_business WHEN 1 THEN'MANUFACTURING'WHEN 2 THEN'TRADER'WHEN 3 THEN'PUBLIC_LIMITED_COMPANY' "
+ " WHEN 4 THEN'PVT_LIMITED_COMPANY'WHEN 5 THEN'FREELANCER'WHEN 6 THEN'NON_PROFIT_ORGANIZATION'  "
+ " WHEN 7 THEN'OTHERS' END AS natureOfBusiness, e.pincode, e.city, "
+ " CASE e.type WHEN 1 THEN'PROPRIETORSHIP'WHEN 2 THEN'PARTNERSHIP_LLP'WHEN 3 THEN'SERVICE_PROVIDER'WHEN 4 "
+ " THEN'WORKS_CONTRACT'WHEN 5 THEN'TRUST'WHEN 6 THEN'SOCIETIES'WHEN 7 THEN'ASSOCIATIONS_CLUB' "
+ " WHEN 8 THEN'BANK_FINANCIAL_INSTITUTATION' WHEN 9 THEN'EDUCATION_INSTUATION' "
+ " WHEN 10 THEN'GOVERNMENT_PUBLIC_SECTOR_Undertaking' WHEN 11 THEN'OTHERS' END AS type, "
+ " e.identity_number as identityNo from users u left join entities e on u.id = e.user_id left "
+ " join signup_status ss on u.mobile_no = ss.mobile_no WHERE "
+ " ss.status = 'FULL' and u.updated_on between :from and :to " )
List<HalfFullRegDto> getRegByTypeDate(LocalDate from, LocalDate to, Pageable paging);

@Query(nativeQuery = true, value = " SELECT COUNT(*) OVER () as TotalCount, ss.status, "
+ " ss.mobile_no as signUpMobileNo, u.id,u.full_name as fullName, "
+ " u.mobile_no as mobileNo ,u.created_on as createdOn, u.updated_on as updatedOn, "
+ "	CASE e.nature_of_business WHEN 1 THEN'MANUFACTURING'WHEN 2 THEN'TRADER'WHEN 3 THEN'PUBLIC_LIMITED_COMPANY' "
+ " WHEN 4 THEN'PVT_LIMITED_COMPANY'WHEN 5 THEN'FREELANCER'WHEN 6 THEN'NON_PROFIT_ORGANIZATION'  "
+ " WHEN 7 THEN'OTHERS' END AS natureOfBusiness, e.pincode, e.city, "
+ " CASE e.type WHEN 1 THEN'PROPRIETORSHIP'WHEN 2 THEN'PARTNERSHIP_LLP'WHEN 3 THEN'SERVICE_PROVIDER'WHEN 4 "
+ " THEN'WORKS_CONTRACT'WHEN 5 THEN'TRUST'WHEN 6 THEN'SOCIETIES'WHEN 7 THEN'ASSOCIATIONS_CLUB' "
+ " WHEN 8 THEN'BANK_FINANCIAL_INSTITUTATION' WHEN 9 THEN'EDUCATION_INSTUATION' "
+ " WHEN 10 THEN'GOVERNMENT_PUBLIC_SECTOR_Undertaking' WHEN 11 THEN'OTHERS' END AS type, "
+ " e.identity_number as identityNo from users u left join entities e on u.id = e.user_id left "
+ " join signup_status ss on u.mobile_no = ss.mobile_no WHERE ss.status ilike '%REG%' "
+ " union "
+ " SELECT COUNT(*) OVER () as TotalCount, ss.status, ss.mobile_no as signUpMobileNo, "
+ " null as id, null as fullName ,null as mobileNo ,null as createdOn ,null as updatedOn, "
+ " null as natureOfBusiness,null as pincode,null as city,null as type , null as identityNo "
+ " from signup_status ss WHERE (ss.status = 'NEW' OR ss.status = 'SIGNUP') ")
List<HalfFullRegDto> getRegByTypeAll(Pageable paging);

@Query(nativeQuery = true, value = " SELECT COUNT(*) OVER () as TotalCount, ss.status, "
+ " ss.mobile_no as signUpMobileNo, u.id,u.full_name as fullName, "
+ " u.mobile_no as mobileNo ,u.created_on as createdOn, u.updated_on as updatedOn, "
+ "	CASE e.nature_of_business WHEN 1 THEN'MANUFACTURING'WHEN 2 THEN'TRADER'WHEN 3 THEN'PUBLIC_LIMITED_COMPANY' "
+ " WHEN 4 THEN'PVT_LIMITED_COMPANY'WHEN 5 THEN'FREELANCER'WHEN 6 THEN'NON_PROFIT_ORGANIZATION'  "
+ " WHEN 7 THEN'OTHERS' END AS natureOfBusiness, e.pincode, e.city, "
+ " CASE e.type WHEN 1 THEN'PROPRIETORSHIP'WHEN 2 THEN'PARTNERSHIP_LLP'WHEN 3 THEN'SERVICE_PROVIDER'WHEN 4 "
+ " THEN'WORKS_CONTRACT'WHEN 5 THEN'TRUST'WHEN 6 THEN'SOCIETIES'WHEN 7 THEN'ASSOCIATIONS_CLUB' "
+ " WHEN 8 THEN'BANK_FINANCIAL_INSTITUTATION' WHEN 9 THEN'EDUCATION_INSTUATION' "
+ " WHEN 10 THEN'GOVERNMENT_PUBLIC_SECTOR_Undertaking' WHEN 11 THEN'OTHERS' END AS type, "
+ " e.identity_number as identityNo from users u left join entities e on u.id = e.user_id left "
+ " join signup_status ss on u.mobile_no = ss.mobile_no WHERE "
+ " ss.status ilike '%REG%' and u.updated_on between :from and :to "
+ " union "
+ " SELECT COUNT(*) OVER () as TotalCount, ss.status, ss.mobile_no as signUpMobileNo, "
+ " null as id, null as fullName ,null as mobileNo ,null as createdOn ,null as updatedOn, "
+ " null as natureOfBusiness,null as pincode,null as city,null as type , null as identityNo "
+ " from signup_status ss WHERE (ss.status = 'NEW' OR ss.status = 'SIGNUP') and "
+ " ss.created_on between :from and :to  " )
List<HalfFullRegDto> getRegByTypeAllDate( LocalDate from, LocalDate to, Pageable paging);

}

// DYANMIC BANWANA H ??....agar value aaye tbhi search ya typeSreach chale warna wahana pe value na aaye