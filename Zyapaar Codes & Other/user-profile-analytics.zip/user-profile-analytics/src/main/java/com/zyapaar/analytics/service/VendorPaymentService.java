package com.zyapaar.analytics.service;

import java.io.InputStream;
import java.util.List;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;

import com.zyapaar.analytics.request.ListingRequest;
import com.zyapaar.commons.dto.Response;

public interface VendorPaymentService {

	ResponseEntity<Response> payment();

	void paymentCompleteSummaryInput();

	ResponseEntity<Response> paymentCompletionFormula(String authUserId,ListingRequest listingRequest);

	InputStream loadPaymentExcel();

	ResponseEntity<Response> getCsvFileData( List<String> mobileNo, com.zyapaar.commons.request.ListingRequest listingRequest);

}
