package com.zyapaar.analytics.dto;

import lombok.Data;

/**
 * User Suggestion Dto
 * 
 * @author Uday Halpara
 */
@Data
public class UserList {

  private String id;
  private String name;
  private String img;
  private String designation;
  private String cover;

}
