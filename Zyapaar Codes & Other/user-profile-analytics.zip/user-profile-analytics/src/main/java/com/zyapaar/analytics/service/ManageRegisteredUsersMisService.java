package com.zyapaar.analytics.service;

import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.analytics.dto.HalfFullRegDto;
import com.zyapaar.analytics.repository.UserRepository;
import com.zyapaar.analytics.request.ExcelMisRegistered;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ManageRegisteredUsersMisService implements RegisteredUsersMisService {

	private final UserRepository userRepository;

	@Override
	public ResponseEntity<Response> getAllReg(CommonSearch commonSearch) {

		String type = (commonSearch.getType() == null || commonSearch.getType().equals("")) ? null : commonSearch.getType();
		String search = (commonSearch.getSearch() == null || commonSearch.getSearch().equals("")) ? null : commonSearch.getSearch();
		LocalDate fromDate = (commonSearch.getFromDate() == null || commonSearch.getFromDate().equals("")) ? null : LocalDate.parse(commonSearch.getFromDate());
		LocalDate toDate = (commonSearch.getToDate() == null || commonSearch.getToDate().equals("")) ? null : LocalDate.parse(commonSearch.getToDate());


		Pageable paging = PageRequest.of(commonSearch.getPage(), 10);
//		Sort.by(Sort.Direction.DESC, "u.updated_on"));
		List<HalfFullRegDto> registeredUserEntity = null;

		if (type == null && search == null && fromDate == null && toDate == null) {
			try {
				// registeredUserEntity = userRepository.getReg(paging);
				throw new BadRequestException("Enter any Input to get Result");
			} catch (Exception e) {
				log.info("create : {}", e);
				throw new BadRequestException("Error during getAll company", e);
			}
		}		
		
		else if (type == null && search == null) {
			registeredUserEntity = userRepository.getByDate(fromDate, toDate, paging);

		}  
		
		else if (type == null && search != null)
			if (fromDate != null && toDate != null) {
				registeredUserEntity = userRepository.getRegBySearchDate(search, fromDate, toDate, paging);
				// regCount = userRepository.getRegBySearchCountDate(search, fromDate, toDate);
			}
			else {
				registeredUserEntity = userRepository.getRegBySearch(search, paging);
				// regCount = userRepository.getRegBySearchCount(search);
			}

		else if (type != null && search == null) {
			if (type.equals("FULL")) {
				if (fromDate != null && toDate != null) {
					registeredUserEntity = userRepository.getRegByTypeDate(fromDate, toDate, paging);
					// regCount = userRepository.getRegByTypeCount(type);
				}
				// type.equals("REG")
				else {
					registeredUserEntity = userRepository.getRegByType(paging);
					// regCount = userRepository.getRegByTypeCount(type);
				}
			} else {
				if (fromDate != null && toDate != null) {
					registeredUserEntity = userRepository.getRegByTypeAllDate(fromDate, toDate, paging);
					// regCount = userRepository.getRegByTypeAllCountDate(type, fromDate, toDate);
				}
				else {
					registeredUserEntity = userRepository.getRegByTypeAll(paging);
					// regCount = userRepository.getRegByTypeAllCount(type);
				}
			}
		}

		else if (fromDate != null && toDate != null) {
			registeredUserEntity = userRepository.getRegDate(search, type, fromDate, toDate, paging);
			// regCount = userRepository.getRegCountDate(search, type, fromDate, toDate);
		}
		else {
			registeredUserEntity = userRepository.getReg(search, type, paging);
			// regCount = userRepository.getRegCount(search, type);
		}

		return ResponseEntity.status(HttpStatus.OK)
				.body(Response.builder().message("Listing Response")
						.data(new ListingResponse(registeredUserEntity, commonSearch.getPage()))
						.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

	}

	@Override
	public InputStream getAllRegExcel(CommonSearch commonSearch) {

		String type = (commonSearch.getType() == null || commonSearch.getType().equals("")) ? null : commonSearch.getType();
		String search = (commonSearch.getSearch() == null || commonSearch.getSearch().equals("")) ? null : commonSearch.getSearch();
		LocalDate fromDate = (commonSearch.getFromDate() == null || commonSearch.getFromDate().equals("")) ? null : LocalDate.parse(commonSearch.getFromDate());
		LocalDate toDate = (commonSearch.getToDate() == null || commonSearch.getToDate().equals("")) ? null : LocalDate.parse(commonSearch.getToDate());


		List<HalfFullRegDto> registeredUserEntity = null;

		if (type == null && search == null && fromDate == null && toDate == null) {
			try {
				// registeredUserEntity = userRepository.getReg(null);
				throw new BadRequestException("Enter any Input to get Result");
			} catch (Exception e) {
				log.info("create : {}", e);
				throw new BadRequestException("Error during getAll company", e);
			}
		}		
		
		else if (type == null && search == null) {
			registeredUserEntity = userRepository.getByDate(fromDate, toDate, null);

		}  
		
		else if (type == null && search != null)
			if (fromDate != null && toDate != null) {
				registeredUserEntity = userRepository.getRegBySearchDate(search, fromDate, toDate, null);
			}
			else {
				registeredUserEntity = userRepository.getRegBySearch(search, null);
			}

		else if (type != null && search == null) {
			if (type.equals("FULL")) {
				if (fromDate != null && toDate != null) {
					registeredUserEntity = userRepository.getRegByTypeDate(fromDate, toDate, null);
				}
				// type.equals("REG")
				else {
					registeredUserEntity = userRepository.getRegByType(null);
				}
			} else {
				if (fromDate != null && toDate != null) {
					registeredUserEntity = userRepository.getRegByTypeAllDate(fromDate, toDate, null);
				}
				else {
					registeredUserEntity = userRepository.getRegByTypeAll(null);
				}
			}
		}

		else if (fromDate != null && toDate != null) {
			registeredUserEntity = userRepository.getRegDate(search, type, fromDate, toDate, null);
		}
		else {
			registeredUserEntity = userRepository.getReg(search, type, null);
		}

//		return ExcelMisRegistered.registeredMisUsers(registeredUserEntity);
		ByteArrayInputStream in = ExcelMisRegistered.registeredMisUsers(registeredUserEntity);
		return in;
	}
	

}
