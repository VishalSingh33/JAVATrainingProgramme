package com.zyapaar.analytics.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.analytics.entities.SignupStatus;

@Repository
public interface SignupStatusRepository extends JpaRepository<SignupStatus, String> {

	@Query(nativeQuery = true, value = "SELECT status FROM signup_status WHERE mobile_no=:mobileNo")
	Optional<String> findByMobileNo(String mobileNo);

}
