package com.zyapaar.analytics.entities;

import java.time.OffsetDateTime;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import com.vladmihalcea.hibernate.type.array.ListArrayType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "entities")
@TypeDef(name = "list-array",typeClass = ListArrayType.class)  //add onetomanny in userentity
public class Entities{

    @Id
    @NotNull
    @Column(name = "id", nullable = false, length = 19)
    private String id;

    @Column(name = "logo")
    private String logo;

    @NotNull
    @Column(name = "designation", nullable = false, length = 150)
    private String designation;

    @Column(name = "verified_by", length = 1)  //Int
    private Integer verifiedBy;

    @NotNull
    @Column(name = "name", nullable = false, length = 200)
    private String name;

    @NotNull
    @Column(name = "type", nullable = false, length = 2)   //Int
    private Integer type;

    @NotNull
    @Column(name = "nature_of_business", nullable = false, length = 1)   //Int
    private Integer natureOfBusiness;

    @NotNull
    @Column(name = "address_line1", nullable = false, length = 150)
    private String addressLine1;

    @Column(name = "address_line2", length = 150)
    private String addressLine2;

    @NotNull
    @Column(name = "pincode", nullable = false, length = 6)
    private String pincode;

    @NotNull
    @Column(name = "city", nullable = false, length = 100)
    private String city;

    @Column(name = "contact_no1", length = 10)
    private String contactNo1;

    @Column(name = "contact_no2", length = 10)
    private String contactNo2;

    @NotNull
    @Column(name = "email", nullable = false, length = 100)
    private String email;

    @NotNull
    @Column(name = "about", nullable = false, length = 500)
    private String about;

    @Column(name = "identity_number", length = 30)
    private String identityNumber;

    @NotNull
    @Column(name = "created_on", nullable = false)
    private OffsetDateTime createdOn;

    @Column(name = "updated_on")
    private OffsetDateTime updatedOn;

    @NotNull
    @Column(name = "created_by", nullable = false, length = 19)
    private String createdBy;

    @Column(name = "updated_by", length = 19)
    private String updatedBy;

    @Column(name = "hide")
    private Boolean hide;

    @Column(name = "keyword_buys_id",columnDefinition = "text[]")
    @Type(type = "list-array")
    private List<String> keywordBuys; 

    @NotNull
    @Column(name = "keyword_sells_id",columnDefinition = "text[]")
    @Type(type = "list-array")
    private List<String> keywordSells; 

    // @ManyToOne(fetch = FetchType.LAZY, optional = true,targetEntity = Country.class)   
    // @PrimaryKeyJoinColumn(name = "country_id",referencedColumnName = "id")
		@Column(name="country_id")
    private String country;

    // @ManyToOne(fetch = FetchType.LAZY,optional = true,targetEntity = StateEntity.class)
    // @PrimaryKeyJoinColumn(name = "state_id",referencedColumnName = "id")
		@Column(name = "state_id")
    private String state;

    // @ManyToOne(fetch = FetchType.LAZY,optional = true,targetEntity = UserEntity.class)   
    // @PrimaryKeyJoinColumn(name = "user_id",referencedColumnName = "id")
		@Column(name = "user_id")
    private String user;

	//bi-directional many-to-one association to EntityInvite
	// @OneToMany(targetEntity=EntityInvite.class, mappedBy="entities", fetch=FetchType.LAZY,
  //       cascade = {CascadeType.PERSIST,CascadeType.MERGE})
	// private List<EntityInvite> entityInvite;
}