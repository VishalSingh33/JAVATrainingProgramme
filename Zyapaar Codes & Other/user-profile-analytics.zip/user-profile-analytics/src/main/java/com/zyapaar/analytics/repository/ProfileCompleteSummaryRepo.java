package com.zyapaar.analytics.repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.zyapaar.analytics.dto.ProfileCompletionFormulaDto;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zyapaar.analytics.entities.ProfileCompleteSummary;

@Repository
public interface ProfileCompleteSummaryRepo extends JpaRepository<ProfileCompleteSummary, String> {

	// to check table is complete or ...
	@Query(nativeQuery = true, value = "SELECT * FROM profile_complete_summary WHERE complete = false or complete is null")
	List<ProfileCompleteSummary> checkforValue();

	@Modifying
	@Query(nativeQuery = true, value = " UPDATE profile_complete_summary SET proportion_percentage = 100 WHERE complete = true ")
	void upadteCompleteValue();

	// to check app is dowlaoded or ...
	@Query(value = "SELECT created_on FROM user_fcms WHERE id = :userId", nativeQuery = true)
	Timestamp findByDowlaodNativeQuery(String userId);

	// to check registrtion is full or not
	@Query(value = "SELECT created_on FROM entities e WHERE user_id = :user_id limit 1", nativeQuery = true)
	Timestamp findByRegistrationNativeQuery(String user_id);

	// to check userlogo
	@Query(value = " SELECT CASE WHEN (users.img ) IS NULL then null ELSE updated_on end as logo_update FROM users "
			+ " WHERE id = :user_id", nativeQuery = true)
	Timestamp findByUserLogoNativeQuery(String user_id);

	// to check entity logo----
	@Query(value = "SELECT logo FROM entities WHERE created_by = :user_id ", nativeQuery = true)
	List<String> findByEntityLogoNativeQuery(String user_id);

	// to check product(product => 3)
	@Query(value = "SELECT CASE WHEN count(id) > 4 then 'TRUE' else 'FALSE'  end FROM entity_products  "
			+ " WHERE entities_id in(SELECT id FROM entities WHERE created_by = :user_id)", nativeQuery = true)
	Boolean findByProductNativeQuery(String user_id);

	// to check buypost
	@Query(value = " SELECT CASE WHEN count(id) > 0 then 'TRUE' else 'FALSE' END FROM feed p "
			+ " WHERE user_id = :user_id and type='1' and is_active = true", nativeQuery = true)
	boolean findByBuyNativeQuery(String user_id);

	// to check sellpost
	@Query(value = "SELECT CASE WHEN count(id) > 0 then 'TRUE' else 'FALSE' END FROM feed p " +
			" WHERE user_id  = :user_id and type='2' and is_active = true ", nativeQuery = true)
	boolean findBySellNativeQuery(String user_id);

	// //otl
	// @Query(value = " SELECT * FROM profile_complete_summary WHERE (updated_on >=
	// date_trunc('week', "
	// + " CURRENT_TIMESTAMP - interval '1 week') and updated_on <
	// date_trunc('week', CURRENT_TIMESTAMP)) ", nativeQuery = true)
	// List<ProfileCompleteSummary> findByWeekNativeQuery();

	// ctl
	@Query(value = " SELECT * FROM profile_complete_summary WHERE updated_on >=(NOW() - interval '1 day')", nativeQuery = true)
	List<ProfileCompleteSummary> findByWeekNativeQuery(Pageable paging);

	@Query(value = " SELECT * FROM profile_complete_summary WHERE updated_on >=(NOW() - interval '1 day')", nativeQuery = true)
	List<ProfileCompleteSummary> findByExcelWeekNativeQuery();

	@Query(value = "	SELECT * FROM profile_complete_summary pcs WHERE mobile_no IN (:mobileNo) ", nativeQuery = true)	
	List<ProfileCompleteSummary> findByMobileNo(@Param("mobileNo") List<String> mobileNo, Pageable paging);

	@Query(nativeQuery= true,
		value= " select * from profile_complete_summary pcs where updated_on between :from and :to ")
	List<ProfileCompleteSummary> getDataBetween(LocalDateTime from, LocalDateTime to, Pageable pageable);

	@Query(nativeQuery= true,
			value= " select count(*) from (select * from profile_complete_summary pcs where " +
					" updated_on between :from and :to) as a " )
	Optional<String> findUsersCount(LocalDateTime from, LocalDateTime to);

}
