package com.zyapaar.analytics.dto;

import java.sql.Timestamp;
import org.springframework.stereotype.Component;


@Component
	public interface HalfFullRegDto {

	String getTotalCount();
	  String getStatus();
	 String getId();
	 String getFullName();
	 String getSignUpMobileNo(); 
	 String getMobileNo();
	 Timestamp getCreatedOn();
	 Timestamp getUpdatedOn();
	 String getNatureOfBusiness();
	 String getPincode();
	 String getCity();
	 String getType();
	 String getIdentityNo();
	
}