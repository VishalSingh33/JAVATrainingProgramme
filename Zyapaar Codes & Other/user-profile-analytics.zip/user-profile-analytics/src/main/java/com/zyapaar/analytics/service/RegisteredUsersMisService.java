package com.zyapaar.analytics.service;

import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.commons.dto.Response;
import org.springframework.http.ResponseEntity;

import java.io.InputStream;

public interface RegisteredUsersMisService {

	public ResponseEntity<Response>  getAllReg(CommonSearch commonSearch);

	InputStream getAllRegExcel(CommonSearch commonSearch);

}
