package com.zyapaar.analytics.entities;

import java.io.Serializable;
import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.OffsetDateTime;

/**
 * The persistent class for the "Vendor" database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "vendor")
public class Vendor {
	
	@Id
	private String id;

	private String name;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_on")
	private OffsetDateTime createdOn;
	
	@Column(name = "mobile_no")
	private String mobileNo;
	
	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name="updated_on")
	private Timestamp updatedOn;
}