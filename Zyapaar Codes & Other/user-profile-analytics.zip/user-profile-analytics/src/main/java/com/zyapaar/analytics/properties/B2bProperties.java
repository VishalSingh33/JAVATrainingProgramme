package com.zyapaar.analytics.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

/**
 * Property class
 * 
 * @author UDaY HaLPaRa
 */
@ConfigurationProperties(prefix = "app")
@Getter
@Component
public class B2bProperties {

  private Topic topic = new Topic();
  private Store store = new Store();
  private Api api = new Api();
  private Paging paging = new Paging();
  private Size size = new Size();
  private EmailNotification emailNotification = new EmailNotification();
  private DefaultImages defaultImages = new DefaultImages();
	private Vendor vendor = new Vendor();
	private ConValue conValue = new ConValue();

	@Getter
	@Setter
	public static class Vendor{

		private String vendorId;
	}

  @Getter
  @Setter
  public static class Size {

    private long image;

  }

  @Getter
  @Setter
  public static class Topic {

    private String signupPhaseOne;
    // private String userRegistration;
    // private String companyRegistration;
    // private String connectionRequest;
    // private String userOverview;
    // private String usersWiseIndustry;
    // private String userConnection;
    // private String companyWiseIndustry;
    // private String emailNotification;
    // private String userFollowyEvent;
    private String profileViewEvent;
    // private String userConnectionRequestEvent;
    // private String teamRequestEvent;

  }

  @Getter
  @Setter
  public static class Store {

    private String signupPhaseOneStore;
    // private String userConnection;
    // private String userOverview;

  }

  @Getter
  @Setter
  public static class Api {

    private String notificationsOtp;
    private String notificationsOtpVerify;
    // private String companyLogoUpload;
    private String userProfileUpload;
    private String identityValidation;
    // private String productMap;
    // private String productNames;
    // private String industry;
    // private String states;

  }

  @Getter
  @Setter
  public static class Paging {

    private Integer userStatus;
    private Integer payment;
  }

  @Getter
  @Setter
  public static class EmailNotification {

    private String welcomeEmail;
    private String connectionRequestAccept;
    private String connectionRequest;
    private String viewProfile;

  }

  @Getter
  @Setter
  public static class DefaultImages {

    private String user;

  }
	@Getter
  @Setter
	public static class ConValue
 {
	private String cron;
	private String cronPayment;
 }
}
