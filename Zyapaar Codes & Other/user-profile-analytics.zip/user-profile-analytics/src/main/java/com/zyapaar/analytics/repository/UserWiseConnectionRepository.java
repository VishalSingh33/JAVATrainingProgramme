package com.zyapaar.analytics.repository;

import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.zyapaar.analytics.entities.IIndustryCount;
import com.zyapaar.analytics.entities.UserEntity;
import com.zyapaar.analytics.entities.UserWiseConnection;

@Repository
public interface UserWiseConnectionRepository extends JpaRepository<UserWiseConnection, String> {

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_wise_connection WHERE id = :fromUserId OR id = :toUserId"
  )
  Optional<List<UserWiseConnection>> findByFromAndToUserId(UserEntity fromUserId, UserEntity toUserId);

  @Query(
    nativeQuery = true,
    value = "SELECT count(s.sid), s.sid as id, si.name FROM ("
      + " SELECT DISTINCT ui.id,  unnest(ui.keyword_buys_sells_id) as sid FROM user_wise_connection uwc"
      + " INNER JOIN user_industry ui ON ui.user_id = ANY(uwc.user_ids)"
      + " WHERE uwc.id = :userId) s"
      + " INNER JOIN sub_industry si ON s.sid = si.id"
      + " GROUP BY s.sid, si.name"
  )
  List<IIndustryCount> findIndustryByUser(String userId);

	// to check connection
	@Query(value = " SELECT * FROM user_wise_connection uwc2 WHERE id = :user_id ", nativeQuery = true)
 	UserWiseConnection findByConnectionNativeQuery(String user_id);

  
}
