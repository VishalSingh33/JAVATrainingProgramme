package com.zyapaar.analytics.controller;

import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.analytics.service.ManageRegisteredUsersMisService;
import com.zyapaar.commons.dto.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@RestController
@Slf4j
@RequiredArgsConstructor
public class ManageRegisteredUsersMisController implements RegisteredUsersMisController {

	private final ManageRegisteredUsersMisService manageRegisteredUsersMisService;

	@Override
	public ResponseEntity<Response> getAllReg(CommonSearch commonSearch) {

		return manageRegisteredUsersMisService.getAllReg(commonSearch);
	}


	@Override
	public ResponseEntity<InputStreamResource> getAllRegExcel(CommonSearch commonSearch) {

		LocalDateTime localDateTime =  LocalDateTime.now();
		String filename = "Registered_MIS_users_" + localDateTime + ".xlsx";

		InputStreamResource file = new InputStreamResource(manageRegisteredUsersMisService.getAllRegExcel(commonSearch));

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
				.body(file);
	}


}