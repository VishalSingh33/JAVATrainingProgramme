package com.zyapaar.analytics.controller;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.analytics.dto.CommonSearch;

@Validated
@CrossOrigin("*")
@RequestMapping("/api/admin/v1")
public interface RegisteredUsersMisController {


	@PostMapping(value = "/mis/users-status")
	public ResponseEntity<Response>  getAllReg(@RequestBody CommonSearch commonSearch );

	@PostMapping("/mis/users-status/excel")
	public ResponseEntity<InputStreamResource>  getAllRegExcel(@RequestBody CommonSearch commonSearch );

}