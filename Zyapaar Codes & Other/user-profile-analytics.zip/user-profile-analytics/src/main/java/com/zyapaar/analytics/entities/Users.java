package com.zyapaar.analytics.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.time.OffsetDateTime;

// @JsonInclude(value = Include.NON_NULL)
// @JsonIgnoreType(value = true)
// @JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "users")
public class Users {
  @Id
  @NotNull
  @Column(name = "id", nullable = false, length = 19)
  private String id;

  @Column(name = "about_us")
  private String aboutUs;

  @Column(name = "account_non_expired")
  private Boolean accountNonExpired;

  @Column(name = "account_non_locked")
  private Boolean accountNonLocked;

  @NotNull
  @Column(name = "created_by", nullable = false, length = 19)
  private String createdBy;

  @NotNull
  @Column(name = "created_on", nullable = false)
  private OffsetDateTime createdOn;

  @Column(name = "credentials_non_expired")
  private Boolean credentialsNonExpired;

  @Column(name = "email_id")
  private String emailId;

  @Column(name = "enable")
  private Boolean enable;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "full_name")
  private String fullName;

  @Column(name = "img")
  private String img;

  @Column(name = "last_name")
  private String lastName;

  @Column(name = "mobile_no")
  private String mobileNo;
  
  @Column(name = "role")
  private String role;

  @Column(name = "title")
  private String title; // As Designation

  @Column(name = "updated_by")
  private String updatedBy;

  @Column(name = "updated_on")
  private OffsetDateTime updatedOn;

  @Column(name = "is_hide")
  private Boolean isHide;

}
