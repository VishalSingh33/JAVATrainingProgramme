package com.zyapaar.analytics.repository;

import com.zyapaar.analytics.entities.Entities;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EntityRepository extends JpaRepository<Entities, String>{

  @Query(nativeQuery= true, 
  value= "select * from entities e where (e.id =:id or e.identity_number =:id)")
  Optional<Entities> findByIdOrIdentityId(String id);
  
}
