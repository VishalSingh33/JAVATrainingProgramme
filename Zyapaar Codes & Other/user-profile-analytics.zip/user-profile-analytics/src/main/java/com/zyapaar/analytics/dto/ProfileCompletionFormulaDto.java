package com.zyapaar.analytics.dto;

import java.time.OffsetDateTime;

import org.hibernate.type.StringNVarcharType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Component
@AllArgsConstructor
@NoArgsConstructor
public class ProfileCompletionFormulaDto {

	private String userId;
	private String mobileNo;
	private OffsetDateTime updatedOn;
	private OffsetDateTime createdOn;
	private OffsetDateTime download;
	private OffsetDateTime registration;
	private OffsetDateTime userLogo;
	private OffsetDateTime buyPost;
	private OffsetDateTime connection;
	private OffsetDateTime entityLogo;
	private OffsetDateTime product;
	private OffsetDateTime sellPost;
	private Long proportionPercentage;
	private Long totalAmount;

}
