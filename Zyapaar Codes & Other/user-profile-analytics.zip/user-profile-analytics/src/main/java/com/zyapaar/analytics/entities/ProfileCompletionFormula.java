package com.zyapaar.analytics.entities;

import java.io.Serializable;
import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.List;

/**
 * The persistent class for the profile_completion_formula database table.
 * 
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "profile_completion_formula")
public class ProfileCompletionFormula {
	
	// private static final long serialVersionUID = 1L;
	
	@Id
	private String id;

	@Column(name = "buy_post_amt")
	private Long buyPostAmt;
	
	@Column(name = "buy_post_pr")
	private Integer buyPostPr;
	
	@Column(name = "connection_amt")
	private Long connectionAmt;
	
	@Column(name = "connection_pr")
	private Integer connectionPr;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_on")
	private Timestamp createdOn;
	
	@Column(name = "download_amt")
	private Long downloadAmt;
	
	@Column(name = "download_pr")
	private Integer downloadPr;
	
	@Column(name = "entity_logo_amt")
	private Long entityLogoAmt;
	
	@Column(name = "entity_logo_pr")
	private Integer entityLogoPr;
	
	@Column(name = "is_active")
	private Boolean isActive;
	
	@Column(name = "product_amt")
	private Long productAmt;
	
	@Column(name = "product_pr")
	private Integer productPr;
	
	@Column(name = "registration_amt")
	private Long registrationAmt;
	
	@Column(name = "registration_pr")
	private Integer registrationPr;
	
	@Column(name = "sell_post_amt")
	private Long sellPostAmt;
	
	@Column(name = "sell_post_pr")
	private Integer sellPostPr;
	
	@Column(name = "user_logo_amt")
	private Long userLogoAmt;
	
	@Column(name = "user_logo_pr")
	private Integer userLogoPr;
	
	@Column(name = "vendor_id")
	private String vendorId;
}
