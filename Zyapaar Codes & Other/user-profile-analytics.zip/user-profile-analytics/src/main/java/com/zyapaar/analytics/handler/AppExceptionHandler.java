package com.zyapaar.analytics.handler;

import org.springframework.stereotype.Component;
import com.zyapaar.exceptionhandler.ApplicationExceptionHandler;

@Component
public class AppExceptionHandler extends ApplicationExceptionHandler {
  
}
