package com.zyapaar.analytics.properties;

import java.util.*;

public class FindCount {
	public static void main(String[] args) {
      
    // String str = "this is not righ ttime to start a conversation";
    // char[] arr = str.toCharArray();
		// int[] fr = new int[str.length()];

		// for(int  i = 0; i < str.length(); i++)
		// {
    //   fr[i] = 1;
		// 	for(int j = 1; j < str.length(); j++)
		// 	{
    //     if( arr[i] == arr[j] )
		// 		{
    //       fr[i]++;
		// 			arr[j] = '0';
		// 		}
		// 	}
		// }
		// for(int i=0; i < str.length(); i++) {
		  
		// 	if(arr[i] != ' ' && arr[i] !='0')
		// System.out.println(arr[i] + " " + fr[i]  );
		
		// }

		String str = "this it tips";
		char[] arr = str.toCharArray();
			int [] fr = new int [arr.length];  
			int visited = -1;  
			for(int i = 0; i < arr.length; i++){  
					int count = 1;  
					for(int j = i+1; j < arr.length; j++){  
							if(arr[i] == arr[j]){  
									count++;  
									//To avoid counting same element again  
									fr[j] = visited;  
							}  
					}  
					if(fr[i] != visited)  
							fr[i] = count;  
			}  

			//Displays the frequency of each element present in array  
			System.out.println("---------------------------------------");  
			System.out.println(" Element | Frequency");  
			System.out.println("---------------------------------------");  
			for(int i = 0; i < fr.length; i++){  
					if(fr[i] != visited && arr[i] != ' ' )  
							System.out.println("    " + arr[i] + "    |    " + fr[i]);  
			}  

	
		
		
  }
}