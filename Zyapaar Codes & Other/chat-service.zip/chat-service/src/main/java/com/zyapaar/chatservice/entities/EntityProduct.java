package com.zyapaar.chatservice.entities;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.Type;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "entity_products")
public class EntityProduct {

  @Id
  @NotNull
  @Column(name = "id", nullable = false, length = 19)
  private String id;
  
  @NotNull
  @Column(name = "product_name")
  private String productName;

  @NotNull
  @Column(name = "description")
  private String description;

  @NotNull
  @Column(name = "price")
  private BigDecimal price;

  @Column(name = "brand_name")
  private String brandName;

  @NotNull
  @Column(name = "minimum_qty")
  private String minimumQty;

  @NotNull
  @Column(name = "payment_terms")
  private String paymentTerms;
  
  @Column(name = "logo",columnDefinition = "text[]")
  @Type(type = "list-array")
  private List<String> logo; 

  @Column(name = "is_active")
  private Boolean isActive;

  @NotNull
  @Column(name = "created_on", nullable = false)
  private OffsetDateTime createdOn;

  @NotNull
  @Column(name = "created_by", nullable = false, length = 19)
  private String createdBy;

  @Column(name = "updated_on")
  private OffsetDateTime updatedOn;

  @Column(name = "updated_by", length = 19)
  private String updatedBy;

  @Column(name = "user_id")
  private String user; 
 
  @ManyToOne(fetch = FetchType.LAZY,optional = true,targetEntity = Entities.class)   
  @PrimaryKeyJoinColumn(name = "entities_id",referencedColumnName = "id")
  private Entities entities; 
  
}