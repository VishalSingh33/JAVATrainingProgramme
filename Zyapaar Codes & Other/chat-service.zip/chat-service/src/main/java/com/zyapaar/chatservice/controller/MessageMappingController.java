package com.zyapaar.chatservice.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Controller;
import com.zyapaar.chatservice.dto.InquireMessageDto;
import com.zyapaar.chatservice.service.ChatInquireService;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.utils.DateTimeUtils;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class MessageMappingController {
  private final ChatInquireService chatInquireService;

  // @MessageMapping("/chat")
  @MessageMapping("/app")
  public ResponseEntity<Response> processInquire(@Payload InquireMessageDto chatMessage) {

    chatInquireService.newInquire(chatMessage);

    return ResponseEntity.status(HttpStatus.CREATED)
    .body(Response.builder().message("Inquire Created")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }
  
}
