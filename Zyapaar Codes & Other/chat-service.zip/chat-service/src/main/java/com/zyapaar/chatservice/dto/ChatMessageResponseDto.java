package com.zyapaar.chatservice.dto;

import java.time.OffsetDateTime;
import com.zyapaar.chatservice.entities.MessageStatus;
import lombok.Data;

@Data
public class ChatMessageResponseDto {
  
  private String id;
  private String chatId;
  private String senderId;
  private String receiverId;
  private String content;
  private MessageStatus status;
  private OffsetDateTime createdOn;
}
