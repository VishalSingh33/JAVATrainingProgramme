package com.zyapaar.chatservice.controller;

import javax.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import com.zyapaar.chatservice.dto.OriginType;
import com.zyapaar.chatservice.service.ChatInquireService;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.utils.DateTimeUtils;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class ChatInquireController {
  
  private final ChatInquireService chatInquireService;

  // @PostMapping(value="/inquire/room")
  @PostMapping(value="/chat-room")
  public ResponseEntity<Response>  inquireChatRoom(
    @RequestHeader("Z-AUTH-USERID") String userId
    , @Valid @RequestBody ListingRequest request) {
      return chatInquireService.inquireChatRoom(userId, request);
  }

  // @PostMapping("/inquire/{senderId}/{receiverId}")
  @PostMapping("/messages/{senderId}/{receiverId}")
  public ResponseEntity<Response> findInquireMessages(@PathVariable String senderId,
      @PathVariable String receiverId, @Valid @RequestBody ListingRequest request) {
    return ResponseEntity.status(HttpStatus.OK)
      .body(Response.builder().message("data found")
      .data(chatInquireService.findInquireMessages(senderId, receiverId, request))
      .timestamp(DateTimeUtils.currentDateTimeUTCInString())
      .build());
  }

  // @GetMapping("/inquire/{senderId}/{receiverId}/count")
  @GetMapping("/messages/{senderId}/{receiverId}/count")
  public ResponseEntity<Long> countNewInquire(@PathVariable String senderId,
      @PathVariable String receiverId) {

    return ResponseEntity.ok(chatInquireService.countNewInquire(senderId, receiverId));
  }

  // @GetMapping("/inquire/unread/count")
  @GetMapping("/messages/unread/count")
  public ResponseEntity<Long> countUnreadMessage(
    @RequestHeader("Z-AUTH-USERID") String userId){
      return ResponseEntity.ok(chatInquireService.getUnReadCount(userId));
  }

  // @GetMapping("/inquire/{id}")
  @GetMapping("/messages/{id}")
  public ResponseEntity<?> findInquire(@PathVariable String id) { 
    return ResponseEntity.ok(chatInquireService.findById(id));
  }

  // @GetMapping("/inquire/status/{id}")
  @GetMapping("/messages/status/{id}")
  public ResponseEntity<Response> changeStatusForSingleMessage(
    @PathVariable String id, @RequestHeader("Z-AUTH-USERID") String userId
  ){
    chatInquireService.changeStatusForSingleMessage(id, userId);
    return ResponseEntity.status(HttpStatus.OK)
    .body(Response.builder().message("status changed")
    .timestamp(DateTimeUtils.currentDateTimeUTCInString())
  .build());
  }

  // @GetMapping("/inquire/origin/{type}/{id}")
  @GetMapping("/messages/origin/{type}/{id}")
  public ResponseEntity<Response> getDetailsByOrigin(
    @PathVariable("type") OriginType type,
    @PathVariable("id") String originId,
    @RequestHeader("Z-AUTH-USERID") String userId
  ){
    return chatInquireService.getDetailsByOrigin(originId, userId, type);
    
  }


}
