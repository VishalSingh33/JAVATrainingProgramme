package com.zyapaar.chatservice.service;

import javax.validation.Valid;
import org.springframework.http.ResponseEntity;
import com.zyapaar.chatservice.dto.ChatMessageResponseDto;
import com.zyapaar.chatservice.dto.ChatMessageResquestDto;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;

public interface ChatService {

  void newChatMessage(ChatMessageResquestDto chatMessage);

  Long countNewMessages(String senderId, String receiverId);

  ChatMessageResponseDto findById(String id);

  ListingResponse findChatMessages(String senderId, String receiverId,
      @Valid ListingRequest request);

  ResponseEntity<Response> getActiveChatRoom(String userId, @Valid ListingRequest request);

  Long getUnReadCount(String userId);

  void changeStatusForMessage(String messageId, String userId);

}
