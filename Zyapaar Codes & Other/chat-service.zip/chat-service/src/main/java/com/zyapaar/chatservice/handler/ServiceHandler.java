package com.zyapaar.chatservice.handler;

import com.zyapaar.exceptionhandler.ApplicationExceptionHandler;

import org.springframework.stereotype.Component;

/**
 * It is used to handle exception across the application.
 * 
 * @author CHiRAG RATHOD
 */

@Component
public class ServiceHandler extends ApplicationExceptionHandler {

}