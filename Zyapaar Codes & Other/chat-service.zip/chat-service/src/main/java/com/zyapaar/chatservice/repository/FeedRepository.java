package com.zyapaar.chatservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.zyapaar.chatservice.entities.Feed;

@Repository
public interface FeedRepository extends JpaRepository<Feed, String> {

}
