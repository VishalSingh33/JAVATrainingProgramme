package com.zyapaar.chatservice.entities;

public enum MessageStatus {
  RECEIVED, DELIVERED
}
