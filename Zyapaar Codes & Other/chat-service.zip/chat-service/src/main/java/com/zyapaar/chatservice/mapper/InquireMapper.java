package com.zyapaar.chatservice.mapper;

import java.time.OffsetDateTime;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import com.zyapaar.chatservice.dto.FeedDto;
import com.zyapaar.chatservice.dto.InquireMessageDto;
import com.zyapaar.chatservice.dto.InquireResponseDto;
import com.zyapaar.chatservice.dto.InquireRoomDto;
import com.zyapaar.chatservice.dto.InquireRoomResponse;
import com.zyapaar.chatservice.dto.OriginType;
import com.zyapaar.chatservice.dto.ProductDto;
import com.zyapaar.chatservice.entities.Content;
import com.zyapaar.chatservice.entities.EntityProduct;
import com.zyapaar.chatservice.entities.Feed;
import com.zyapaar.chatservice.entities.InquireMessage;
import com.zyapaar.chatservice.repository.InquireMessageRepository;
import com.zyapaar.commons.utils.TimeCount;

@Mapper(componentModel = "spring")
public abstract class InquireMapper {

  @Autowired InquireMessageRepository inquireMessageRepository;

  // @Mapping(target = "sender_id", source = "dto.senderId")
  // @Mapping(target = "receiver_id", source = "dto.receiverId")
  // // @Mapping(target = "origin_id", source = "dto.originId")
  // // @Mapping(target = "origin_type", source = "dto.originType")
  // @Mapping(target = "content", source = "dto.content")
  // MessageDto create(InquireMessageDto dto, OffsetDateTime created_on,
  //     MessageStatus status);

  String map(OriginType originType){
    if(ObjectUtils.isEmpty(originType)){
      return null;
    }
    return originType.type();
  }

  @Mapping(target = "origin", source = "inquire.originType")
  @Mapping(target = "origin_id", source = "inquire.originId")
  @Mapping(target = "message", source = "message")
  public abstract Content createContent(InquireMessageDto inquire);

  @Mapping(target = "message", source = "message.content.message")
  @Mapping(target = "originId", source = "message.content.origin_id")
  @Mapping(target = "origin", source = "message.content.origin")
  @Mapping(target = "createdOn", source = "createdOn")
  @Mapping(target = "updatedOn", source = "createdOn")
  public abstract InquireResponseDto toInquireMessage(InquireMessage message);
  
  public abstract List<InquireResponseDto> toInquireMessage(List<InquireMessage> message); 

  public abstract FeedDto toFeedDto(Feed feed);
  
  @Mapping(target = "entityName", source = "product.entities.name")
  @Mapping(target = "entityId", source = "product.entities.id")
  public abstract ProductDto toProductDto(EntityProduct product);

  @Mapping(target = "count", expression = "java(toCount(inquireRoom))")
  @Mapping(target = "message", expression = "java(toMessage(inquireRoom))")
  @Mapping(target = "updateOn", source = "updatedOn")
  public abstract InquireRoomResponse toInquireRoomResponse(InquireRoomDto inquireRoom);

	public abstract List<InquireRoomResponse> toInquireRoomResponse(List<InquireRoomDto> inquireRoom);

  InquireResponseDto toMessage(InquireRoomDto inquireRoom){

    InquireMessage message = inquireMessageRepository.findLastMessage(inquireRoom.getChatRoomId());
    if(ObjectUtils.isEmpty(message)){
      return null;
    } else{
      return this.toInquireMessage(message);
    }
  }

  Long toCount(InquireRoomDto inquireRoom){
    return inquireMessageRepository.
      countReceivedMessageForSenderAndReceiver(inquireRoom.getId(), inquireRoom.getMyId());
  }

  String utilTime(OffsetDateTime updatedOn){
    return TimeCount.timeFromUpload(updatedOn.toInstant().toEpochMilli());
  }
  
}
