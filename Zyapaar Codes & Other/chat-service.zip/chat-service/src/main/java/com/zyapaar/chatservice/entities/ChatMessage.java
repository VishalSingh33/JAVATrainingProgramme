package com.zyapaar.chatservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "chat_message")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class ChatMessage {

  @Id
  private String id;

  @Column(name = "chat_id")
  private String chatId;

  @Type(type = "jsonb")
  @Column(name = "message", columnDefinition = "jsonb")
  private Message message;
}
