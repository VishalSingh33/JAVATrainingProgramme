package com.zyapaar.chatservice.service;

import javax.validation.Valid;
import org.springframework.http.ResponseEntity;
import com.zyapaar.chatservice.dto.InquireMessageDto;
import com.zyapaar.chatservice.dto.InquireResponseDto;
import com.zyapaar.chatservice.dto.OriginType;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;

public interface ChatInquireService {

  void newInquire(InquireMessageDto inquire);

  ResponseEntity<Response> inquireChatRoom(String userId, ListingRequest request);

  ListingResponse findInquireMessages(String senderId, String receiverId,
      @Valid ListingRequest request);

  Long countNewInquire(String senderId, String receiverId);

  Long getUnReadCount(String userId);

  InquireResponseDto findById(String id);

  void changeStatusForSingleMessage(String inquireId, String userId);

  ResponseEntity<Response> getDetailsByOrigin(String originId, String userId, OriginType type);

}
