# knowledge-centre-service
> Prepared by: Dharmendrasinh Chudasama

> Requirement
	- lombok
		- Installation steps:
		> explorer			> Maven Dependencies
		> lombok jar		> Right click
		> Run As			> Java Application
		> Select path of your IDE like eclipse.exe / eclipse.ini
		> Click on update button > Restart
		> Update maven project with check "Force Update for Snapshot/Release"
	- JDK 11 or more
	- Maven
	- Postgresql

> Liquibase (Database management)
	- Apply changes in database: mvn liquibase:update
	- Clear database: mvn liquibase:dropAll
	- For get additional liquibase command help: mvn liquibase:help
	- For make any change in database create new xml file or tag and include file address in src/main/resources/db/changelog/db.changelog-master.xml
	- WARNING: Never change on any existing <changelog> tab which is committed, otherwise changed part will never considered on other machines

> Entity class
	- Extend BaseEntity in all entities for manage ID generation through code
	- Automatically generating ID from java code: com.zyapaar.knowledge.util.CommonUtils.generateId() method

> Swagger URL: http://localhost:8080/swagger-ui/index.html

> For complete detailed example follow CRUD operation of DesignationMaster
