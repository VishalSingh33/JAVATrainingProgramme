package com.zyapaar.knowledge.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import com.zyapaar.knowledge.enums.Status;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
// import jakarta.validation.constraints.NotNull;
// import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PartnerPlanRequestDto {

	@NotNull(message = "Enter partner plan name")
	// @Size(min = 2, message = "Minimum ${min} character require")
	@Size(max = 50, message = "Maximum ${max} character allowed")
	private String planName;

	@NotNull(message = "Enter duration unit")
	private int durationUnit;
	
	/** Type for duration_unit (Days,Months,Years,etc.) */
	@NotNull(message = "Enter duration type [Days,Months,Years,etc.]")
	@Size(max = 10, message = "Maximum ${max} character allowed")
	private String durationType;
	
	/** name of industry like banking, insurance, etc. */
	@Size(max = 20, message = "Maximum ${max} character allowed")
	// private String industry;
	private BigDecimal amount;
	private OffsetDateTime startDate;
	private OffsetDateTime endDate;
	private Integer webinarCredit;
	@Size(max = 255, message = "Maximum ${max} character allowed")
	private String remarks;


//  @NotNull(message = "Enter status")
//  @Size(min = 2, message = "Minimum 2 character require")
//  @Size(max = 15, message = "Maximum 15 character allowed")
	private Status status = Status.ACTIVE;
}
