package com.zyapaar.knowledge.dto;

import com.zyapaar.knowledge.enums.Status;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DesignationRequestDto {

	@NotNull(message = "Enter designation name")
	@Size(min = 2, message = "Minimum 2 character require")
	@Size(max = 50, message = "Maximum 50 character allowed")
	private String designationName;

	//  @NotNull(message = "Enter status")
	//  @Size(min = 2, message = "Minimum 2 character require")
	//  @Size(max = 15, message = "Maximum 15 character allowed")
	private Status status = Status.ACTIVE;
}
