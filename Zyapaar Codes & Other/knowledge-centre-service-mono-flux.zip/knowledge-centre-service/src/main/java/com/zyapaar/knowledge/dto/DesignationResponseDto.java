package com.zyapaar.knowledge.dto;

import java.time.OffsetDateTime;

import com.zyapaar.knowledge.enums.Status;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DesignationResponseDto {

	private String id;
	private String designationName;
	private Status status;
	private String createdBy;
	private OffsetDateTime createdDate;
	private String updatedBy;
	private OffsetDateTime updatedDate;

}
