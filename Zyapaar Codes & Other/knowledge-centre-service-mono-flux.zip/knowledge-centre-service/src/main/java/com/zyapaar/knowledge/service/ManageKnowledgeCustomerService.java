package com.zyapaar.knowledge.service;

import java.time.Duration;
import java.util.Comparator;
import org.springframework.stereotype.Service;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.knowledge.dto.KnowledgeCustomerPartnerResponseDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerResponseDto;
import com.zyapaar.knowledge.entity.GSTFormula;
import com.zyapaar.knowledge.entity.KnowledgeCustomer;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.mapper.KnowledgeCustomerMapper;
import com.zyapaar.knowledge.mapper.KnowledgeCustomerPartnerMapper;
import com.zyapaar.knowledge.repository.GSTFormulaRepository;
import com.zyapaar.knowledge.repository.KnowledgeCustomerRepository;
import com.zyapaar.knowledge.repository.PlanMasterRepository;
import com.zyapaar.knowledge.repository.SubIndustryRepository;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageKnowledgeCustomerService implements KnowledgeCustomerService {

	private static final Duration DELAY_DURATION = Duration.ofMillis(20);

	private final KnowledgeCustomerRepository knowledgeCustomerRepository;
	private final PlanMasterRepository planMasterRepository;
	private final GSTFormulaRepository gstFormulaRepository;
	private final SubIndustryRepository subIndustryRepository;
	private final KnowledgeCustomerMapper knowledgeCustomerMapper;
	private final KnowledgeCustomerPartnerMapper knowledgeCustomerPartnerMapper;

	@Override
	public ResponseEntity<Response> getAllKnowledgeCustomers(String companyName, String industryName, Status status,
	long page, long size) {
		try {

			if (companyName != null)
				companyName = companyName.isEmpty() ? null : "%" + companyName + "%";
			if (industryName != null)
				industryName = industryName.isEmpty() ? null : "%" + industryName + "%";

				Flux<KnowledgeCustomerResponseDto> result = knowledgeCustomerRepository.findAll(companyName, industryName, status)
				.sort(Comparator.comparing(KnowledgeCustomer::getCreatedDate).reversed())
				.map(this::toKnowledgeCustomerResponseDto)
				.flatMap(p -> findCustomerByCustomerId(p.getId())).skip(page * size).take(size)
				.delayElements(DELAY_DURATION);

				String sizeLength = String.valueOf(
					knowledgeCustomerRepository.findAll(companyName, industryName, status)
					.flatMap(p -> findCustomerByCustomerId(p.getId())).collectList().block().size());

					return ResponseEntity.status(HttpStatus.OK)
					.body(Response.builder().message("Listing Response")
					.data(new ListingResponse(result.collectList().block(), Integer.parseInt(sizeLength)))
					.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
							
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	@Override
	public Mono<KnowledgeCustomerResponseDto> findCustomerByCustomerId(String knowledgeCustomerId) {
		try {
			return knowledgeCustomerRepository.findCustomerByCustomerId(knowledgeCustomerId)
					// .map(this::toKnowledgeCustomerResponseDto)
					.delayElement(DELAY_DURATION);
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	@Override
	public Mono<KnowledgeCustomerResponseDto> create(Mono<KnowledgeCustomerRequestDto> knowledgeCustomerRequestDtoMono,
			String curUserId) {
		try {
			return knowledgeCustomerRequestDtoMono
					.map(knowledgeCustomerMapper::toKnowledgeCustomer)
					.map(KnowledgeCustomer -> {
						KnowledgeCustomer.setCreatedBy(curUserId);
						return KnowledgeCustomer;
					})
					.flatMap(knowledgeCustomerRepository::save)
					.flatMap(p -> findCustomerByCustomerId(p.getId()))
					.delayElement(DELAY_DURATION);
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	@Override
	public Mono<KnowledgeCustomerResponseDto> updateById(String knowledgeCustomerId,
			Mono<KnowledgeCustomerRequestDto> knowledgeCustomerRequestDtoMono, String curUserId) {
		try {
			return this.knowledgeCustomerRepository.findById(knowledgeCustomerId)
					.flatMap(knowledgeCustomer -> knowledgeCustomerRequestDtoMono.map(knowledgeCustomerRequestDto -> {
						knowledgeCustomerMapper.update(knowledgeCustomer, knowledgeCustomerRequestDto);
						knowledgeCustomer.setUpdatedBy(curUserId);
						return knowledgeCustomer;
					}))
					.flatMap(knowledgeCustomerRepository::save)
					.flatMap(p -> findCustomerByCustomerId(p.getId()))
					.delayElement(DELAY_DURATION);
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	@Override
	public Mono<Void> deleteById(String knowledgeCustomerId, String curUserId) {
		try {
			// return knowledgeCustomerRepository.deleteById(knowledgeCustomerId);
			return knowledgeCustomerRepository.inactiveById(knowledgeCustomerId, curUserId);
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	private KnowledgeCustomerResponseDto toKnowledgeCustomerResponseDto(KnowledgeCustomer entity) {
		try {
			KnowledgeCustomerResponseDto responseDto = knowledgeCustomerMapper.toKnowledgeCustomerResponseDto(entity);

			if (entity.getPlanMasterId() != null) {
				planMasterRepository.findPlanNameById(entity.getPlanMasterId())
						.subscribe(responseDto::setPlanName);
			}

			if (entity.getGstFormulaId() != null) {
				gstFormulaRepository.findById(entity.getGstFormulaId())
						.map(GSTFormula::getFormula)
						.subscribe(responseDto::setGstFormula);
			}

			return responseDto;
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during mapping Customer", e);
		}
	}

// getAll for knowlwdgePartner-Customer
	@Override
	public ResponseEntity<Response> getAllKnowledgePartner() {

		try {
			Flux<KnowledgeCustomerPartnerResponseDto> result = knowledgeCustomerRepository.findAll()
			    .sort(Comparator.comparing(KnowledgeCustomer::getCreatedDate).reversed())
					.map(this::tooKnowledgeCustomerResponseDto)
			// Flux<KnowledgeCustomerResponseDto> result = knowledgeCustomerRepository.findAll()
			// .map(this::toKnowledgeCustomerResponseDto)
			// 		.flatMap(p -> findCustomerByCustomerId(p.getId()))
			.delayElements(DELAY_DURATION);
			
			// String sizeList = String.valueOf(
			// 		knowledgeCustomerRepository.findAll()
			// 		// .flatMap(p -> findCustomerByCustomerId(p.getId()))
			// 		.collectList().block().size());

			return ResponseEntity.status(HttpStatus.OK).body(
					Response.builder().data(result.collectList().block()).message("Listing Response")
							.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgePartner company", e);
		}
	}


	private KnowledgeCustomerPartnerResponseDto tooKnowledgeCustomerResponseDto(KnowledgeCustomer entity) {
		try {
			KnowledgeCustomerPartnerResponseDto responseDto = knowledgeCustomerPartnerMapper.tooKnowledgeCustomerResponseDto(entity);
			
			if (entity.getPlanMasterId() != null) {
				planMasterRepository.findPlanNameById(entity.getPlanMasterId())
						.subscribe(responseDto::setPlanName);
			}
			if (entity.getIndustry() != null) {
				subIndustryRepository.findIndustryNameById(entity.getIndustry())
						.subscribe(responseDto::setIndustryName);
			}

			return responseDto;
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgePartner partner", e);
		}
	}


}
