package com.zyapaar.knowledge.controller;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.knowledge.dto.DesignationRequestDto;
import com.zyapaar.knowledge.dto.DesignationResponseDto;
import com.zyapaar.knowledge.enums.Status;
import jakarta.validation.Valid;
// import jakarta.validation.Valid;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** Manage Designation
 * @author Dharmendrasinh Chudasama
 */
@RequestMapping(path = "/api/admin/v1/designations")
@CrossOrigin("*")
public interface DesignationController {

	@GetMapping
	ResponseEntity<Response> getAll(
			@RequestParam(required = false) String designationName,
			@RequestParam(required = false) Status status,
			@RequestParam(value = "page", defaultValue = "0") long page,
			@RequestParam(value = "size", defaultValue = "10") long size
		);

		@GetMapping("/findAll")
		ResponseEntity<Response> getAllWithoutPagination(
				@RequestParam(required = false) String designationName,
				@RequestParam(required = false) Status status
			);

	@GetMapping("/{designationId}")
	public Mono<ResponseEntity<DesignationResponseDto>> getById(@PathVariable String designationId);

	@PostMapping
	Mono<DesignationResponseDto> create(@RequestBody @Valid Mono<DesignationRequestDto> designationRequestDtoMono, @RequestHeader String curUserId);
	
	@PutMapping("/{designationId}")
	Mono<ResponseEntity<DesignationResponseDto>> updateById(@PathVariable String designationId, @RequestBody @Valid Mono<DesignationRequestDto> designationRequestDtoMono, @RequestHeader String curUserId);

	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	@DeleteMapping("/{designationId}")
	Mono<Void> deleteById(@PathVariable String designationId, @RequestHeader String curUserId);

}
