package com.zyapaar.knowledge.service;

import org.springframework.http.ResponseEntity;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.knowledge.dto.UserRequestDto;
import com.zyapaar.knowledge.dto.UserResponseDto;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface UserService {

	ResponseEntity<Response> getAllUsers(String name, Status status, long page, long size);

	Mono<UserResponseDto> getById(String userId);

	Mono<UserResponseDto> create(Mono<UserRequestDto> userRequestDtoMono, String curUserId);

	Mono<UserResponseDto> updateById(String userId, Mono<UserRequestDto> userRequestDtoMono, String curUserId);

	Mono<Void> deleteById(String userId, String curUserId);

}
