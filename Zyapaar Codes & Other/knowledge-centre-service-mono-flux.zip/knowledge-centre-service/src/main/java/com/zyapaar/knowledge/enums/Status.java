package com.zyapaar.knowledge.enums;

public enum Status {
	ACTIVE, INACTIVE
}
