package com.zyapaar.knowledge.entity;

import java.time.OffsetDateTime;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import com.zyapaar.knowledge.enums.Status;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Table(value = "designation_master")
public class DesignationMaster extends BaseEntity {

	@Column("designation_name")
	private String designationName;

	@Column
	private Status status;

}