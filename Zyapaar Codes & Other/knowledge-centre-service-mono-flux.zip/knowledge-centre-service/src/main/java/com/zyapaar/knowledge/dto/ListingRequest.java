package com.zyapaar.knowledge.dto;

import org.hibernate.validator.constraints.Range;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ListingRequest {

	@NotNull(message = "Please provide page number")
	@Range(min = 0, message = "Please provide valid page number")
	private Integer page;
}