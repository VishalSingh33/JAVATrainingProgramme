package com.zyapaar.knowledge.repository;

import java.time.LocalDate;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zyapaar.knowledge.entity.KnowledgeCenterInq;
import com.zyapaar.knowledge.enums.Status;
import org.springframework.data.domain.Pageable;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Repository
public interface KnowledgeCenterInqRepository extends R2dbcRepository<KnowledgeCenterInq, String> {
	
	@Query("SELECT * FROM knowledge_center_inq"
			+ " WHERE (:companyName IS NULL OR company_name ILIKE CONCAT('%',:companyName,'%'))"
			+ " AND (:personName IS NULL OR person_name ILIKE CONCAT('%',:personName,'%'))"
			+ " AND (:fromDate IS NULL OR DATE(created_date) >= :fromDate)"
			+ " AND (:toDate IS NULL OR DATE(created_date) <= :toDate)"
			+ " AND (:status IS NULL OR status=:status)"
		)
	Flux<KnowledgeCenterInq> findAll(String companyName, String personName, LocalDate fromDate, LocalDate toDate, Status status);

	// @Query("SELECT * FROM knowledge_center_inq"
	// 		+ " WHERE (:companyName IS NULL OR company_name ILIKE CONCAT('%',:companyName,'%'))"
	// 		+ " AND (:personName IS NULL OR person_name ILIKE CONCAT('%',:personName,'%'))"
	// 		+ " AND (:fromDate IS NULL OR DATE(created_date) >= :fromDate)"
	// 		+ " AND (:toDate IS NULL OR DATE(created_date) <= :toDate)"
	// 		+ " AND (:status IS NULL OR status=:status)"
	// 	)
	// Flux<KnowledgeCenterInq> findPageNo(String companyName, String personName, LocalDate fromDate, LocalDate toDate, Status status);
	
	@Modifying
	@Query("UPDATE knowledge_center_inq SET status='INACTIVE', updated_date=NOW(), updated_by = :curUserId WHERE id = :id")
	Mono<Void> inactiveById(@Param("id") String id, @Param("curUserId") String curUserId);

}
