package com.zyapaar.knowledge.service;

import java.time.Duration;
import java.util.Comparator;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.knowledge.dto.PartnerPlanRequestDto;
import com.zyapaar.knowledge.dto.PartnerPlanResponseDto;
import com.zyapaar.knowledge.dto.PartnerPlanResposeAmountDto;
import com.zyapaar.knowledge.entity.PlanMaster;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.mapper.PartnerPlanAmountMapper;
import com.zyapaar.knowledge.mapper.PartnerPlanMapper;
import com.zyapaar.knowledge.repository.PlanMasterRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManagePartnerPlanService implements PartnerPlanService {

	private static final Duration DELAY_DURATION = Duration.ofMillis(20);

	private final PlanMasterRepository planMasterRepository;
	private final PartnerPlanMapper partnerPlanMapper;
	private final PartnerPlanAmountMapper partnerPlanAmountMapper;

	// @Override
	// public Flux<PartnerPlanResponseDto> getAllPartnerPlans(String planName,
	// String industryName, Status status) {
	// if(planName != null)
	// planName = planName.isEmpty() ? null : "%"+planName+"%";
	// if(industryName != null)
	// industryName = industryName.isEmpty() ? null : "%"+industryName+"%";

	// return planMasterRepository.findAll(planName, industryName, status)
	// .map(partnerPlanMapper::toPartnerPlanResponseDto);
	// }

	@Override
	public ResponseEntity<Response> getAllPartnerPlans(String planName, String industryName, Status status, long page,
			long size) {

		try {

			log.info("create : {}", planName, industryName, status);
			if (planName != null)
				planName = planName.isEmpty() ? null : "%" + planName + "%";
			if (industryName != null)
				industryName = industryName.isEmpty() ? null : "%" + industryName + "%";

			Flux<PartnerPlanResponseDto> result = planMasterRepository.findAll(planName, industryName, status)
				.map(partnerPlanMapper::toPartnerPlanResponseDto);
		 // .flatMap(p -> findPlanByPlanId(p.getId()));

		String sizeLength = String.valueOf(planMasterRepository.findAll(planName, industryName,
		status).collectList().block().size());

		return ResponseEntity.status(HttpStatus.OK)
				.body(Response.builder().message("Listing Response")
				.data(new ListingResponse(result.collectList().block(), Integer.parseInt(sizeLength)))
				.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAll company", e);
		}
	}

	@Override
	public ResponseEntity<Response> getAllPartnerPlanWithoutPagi(String planName, String industryName, Status status) {

		try {
			log.info("create : {}", planName, industryName, status);
			if (planName != null)
				planName = planName.isEmpty() ? null : "%" + planName + "%";
			if (industryName != null)
				industryName = industryName.isEmpty() ? null : "%" + industryName + "%";

			Flux<PartnerPlanResponseDto> result = planMasterRepository.findAll(planName, industryName, status)
					.map(partnerPlanMapper::toPartnerPlanResponseDto);
			// .flatMap(p -> findPlanByPlanId(p.getId()));

			// String sizeList = String
			// .valueOf(planMasterRepository.findAll(planName, industryName,
			// status).collectList().block().size());

			return ResponseEntity.status(HttpStatus.OK).body(
					Response.builder().data(result.collectList().block()).message("Listing Response")
							.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAll company", e);
		}
	}

	@Override
	public Mono<PartnerPlanResponseDto> findPlanByPlanId(String planId) {
		return planMasterRepository.findPlanByPlanId(planId);
		// .map(partnerPlanMapper::toPartnerPlanResponseDto);
	}

	@Override
	public Mono<PartnerPlanResponseDto> create(Mono<PartnerPlanRequestDto> partnerPlanRequestDtoMono, String curUserId) {
		return partnerPlanRequestDtoMono
				.map(partnerPlanMapper::toPlanMaster)
				.map(partnerPlanMaster -> {
					partnerPlanMaster.setCreatedBy(curUserId);
					return partnerPlanMaster;
				})
				.flatMap(planMasterRepository::save)
				// .flatMap(p -> findPlanByPlanId(p.getId()));
				.map(partnerPlanMapper::toPartnerPlanResponseDto);
	}

	@Override
	public Mono<PartnerPlanResponseDto> updateById(String planId, Mono<PartnerPlanRequestDto> partnerPlanRequestDtoMono,
			String curUserId) {
		return this.planMasterRepository.findById(planId)
				.flatMap(partnerPlan -> partnerPlanRequestDtoMono.map(partnerPlanRequestDto -> {
					partnerPlanMapper.update(partnerPlan, partnerPlanRequestDto);
					partnerPlan.setUpdatedBy(curUserId);
					return partnerPlan;
				}))
				.flatMap(planMasterRepository::save)
				// .flatMap(p -> findPlanByPlanId(p.getId()));
				.map(partnerPlanMapper::toPartnerPlanResponseDto);
	}

	// @Override
	// public Mono<PartnerPlanResponseDto> updateById(String planId,
	// Mono<PartnerPlanRequestDto> partnerPlanRequestDtoMono, String curUserId) {
	// try {
	// log.info("getAll : {}", partnerPlanRequestDtoMono);

	// return planMasterRepository.findPlanByPlanId(planId);
	// // planMasterRepository.saveAll(planId);
	// }
	// catch (Exception e) {
	// log.info("create : {}", e);
	// throw new BadRequestException("Error during updateById company", e);
	// }
	// }

	@Override
	public Mono<Void> deleteById(String planId, String curUserId) {
		// return partnerPlanRepository.deleteById(planId);
		return planMasterRepository.inactiveById(planId, curUserId);
	}

	@Override
	public ResponseEntity<Response> getAllPartnerAmount() {

		try {
			Flux<PartnerPlanResposeAmountDto> result = planMasterRepository.findAll()
					// .sort(Comparator.comparing(PlanMaster::getCreatedDate).reversed())
					// .map(this::toPartnerPlanAmountResponseDto)
					// .delayElements(DELAY_DURATION);
					.map(partnerPlanAmountMapper::toPartnerPlanAmountResponseDto);
			// .flatMap(p -> findPlanByPlanId(p.getId()));

			return ResponseEntity.status(HttpStatus.OK).body(
					Response.builder().data(result.collectList().block()).message("Plan Amount List")
							.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAll company", e);
		}
	}

	private PartnerPlanResposeAmountDto toPartnerPlanAmountResponseDto(PlanMaster entity) {
		try {
			PartnerPlanResposeAmountDto responseDto = partnerPlanAmountMapper.toPartnerPlanAmountResponseDto(entity);

			if (entity.getPlanName() != null) {
				planMasterRepository.findPlanNameById(entity.getPlanName())
						.subscribe(responseDto::setPlanName);
			}
			// if (entity.getPlanName() != null) {
			// planMasterRepository.findPlanAmount(entity.getPlanName())
			// .subscribe(responseDto::setAmount);
			// }
			return responseDto;
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgePartner partner", e);
		}
	}

}
