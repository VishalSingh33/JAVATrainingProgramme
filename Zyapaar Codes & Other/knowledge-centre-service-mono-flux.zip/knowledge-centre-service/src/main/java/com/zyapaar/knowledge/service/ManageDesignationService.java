package com.zyapaar.knowledge.service;

import org.springframework.stereotype.Service;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.knowledge.dto.DesignationRequestDto;
import com.zyapaar.knowledge.dto.DesignationResponseDto;
import com.zyapaar.knowledge.entity.DesignationMaster;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.mapper.DesignationMapper;
import com.zyapaar.knowledge.repository.DesignationMasterRepository;

import java.util.Comparator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageDesignationService implements DesignationService {

	private final DesignationMasterRepository designationRepository;
	private final DesignationMapper designationMapper;

	@Override
	public ResponseEntity<Response> getAllDesignations(String designationName, Status status, long page, long size) {

		try {
			log.info("getAll : {}", designationName, status);

			if (designationName != null)
				designationName = designationName.isEmpty() ? null : "%" + designationName + "%";

				Flux<DesignationResponseDto> result = designationRepository.findAll(designationName, status)
				.skip(page * size).take(size)
				.sort(Comparator.comparing(DesignationMaster::getCreatedDate).reversed())
				.map(designationMapper::toDesignationResponseDto);

				String sizeLength = String
				.valueOf(designationRepository.findAll(designationName, status).collectList().block().size());

				return ResponseEntity.status(HttpStatus.OK)
				.body(Response.builder().message("Listing Response")
				.data(new ListingResponse(result.collectList().block(), Integer.parseInt(sizeLength)))
				.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

		} catch (Exception e) {
			log.info("getAll : {}", e);
			throw new BadRequestException("Error during getAllDesignations company", e);
		}
	}

	@Override
	public ResponseEntity<Response> getAllDesignationWithoutPagination(String designationName, Status status) {

		try {
			log.info("getAll : {}", designationName, status);

			if (designationName != null)
				designationName = designationName.isEmpty() ? null : "%" + designationName + "%";

			Flux<DesignationResponseDto> result = designationRepository.findAll(designationName, status)
					.sort(Comparator.comparing(DesignationMaster::getCreatedDate).reversed())
					.map(designationMapper::toDesignationResponseDto);

			// String sizeLength = String
			// .valueOf(designationRepository.findAll(designationName,
			// status).collectList().block().size());

			return ResponseEntity.status(HttpStatus.OK).body(
					Response.builder().data(result.collectList().block()).message("Listing Responce")
							.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

		} catch (Exception e) {
			log.info("getAll : {}", e);
			throw new BadRequestException("Error during getAllDesignations company", e);
		}
	}

	@Override
	public Mono<DesignationResponseDto> getById(String designationId) {

		try {
			log.info("getById : {}", designationId);
			return designationRepository.findById(designationId)
					.map(designationMapper::toDesignationResponseDto);
		} catch (Exception e) {
			log.info("getById : {}", e);
			throw new BadRequestException("Error during getById company", e);
		}
	}

	@Override
	public Mono<DesignationResponseDto> create(Mono<DesignationRequestDto> designationRequestDtoMono, String curUserId) {
		try {
			log.info("create : {}", designationRequestDtoMono);
			return designationRequestDtoMono
					.map(designationMapper::toDesignationMaster)
					.map(designationMaster -> {
						designationMaster.setCreatedBy(curUserId);
						return designationMaster;
					})
					.flatMap(designationRepository::save)
					.map(designationMapper::toDesignationResponseDto);

			// DesignationMaster designationMaster =
			// designationMapper.toDesignationMaster(designationRequestDto);
			//
			// designationMaster.setCreatedBy(CommonUtils.generateId());
			// designationMaster.setCreatedDate(OffsetDateTime.now());
			// Mono<DesignationMaster> createdDesignation =
			// designationRepository.save(designationMaster);
			//
			// return designationMapper.toDesignationResponseDtoMono(createdDesignation);
		} catch (Exception e) {
			log.info("getById : {}", e);
			throw new BadRequestException("Error during create company", e);
		}
	}

	@Override
	public Mono<DesignationResponseDto> updateById(String designationId,
			Mono<DesignationRequestDto> designationRequestDtoMono, String curUserId) {

		try {
			log.info("updateById : {}", designationRequestDtoMono);
			return this.designationRepository.findById(designationId)
					.flatMap(designation -> designationRequestDtoMono.map(designationRequestDto -> {
						designationMapper.update(designation, designationRequestDto);
						designation.setUpdatedBy(curUserId);
						return designation;
					}))
					.flatMap(designationRepository::save)
					.map(designationMapper::toDesignationResponseDto);
		} catch (Exception e) {
			log.info("getById : {}", e);
			throw new BadRequestException("Error during updateById company", e);
		}
	}

	@Override
	public Mono<Void> deleteById(String designationId, String curUserId) {
		try {
			log.info("deleteById : {}", designationId);
			// return designationRepository.deleteById(designationId);
			return designationRepository.inactiveById(designationId, curUserId);
		} catch (Exception e) {
			log.info("getById : {}", e);
			throw new BadRequestException("Error during deleteById company", e);
		}
	}

}
