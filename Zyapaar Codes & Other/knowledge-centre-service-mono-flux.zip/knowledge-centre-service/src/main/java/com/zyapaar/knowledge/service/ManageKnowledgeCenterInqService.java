package com.zyapaar.knowledge.service;

import java.time.LocalDate;
import java.util.Comparator;

import org.springframework.stereotype.Service;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqResponseDto;
import com.zyapaar.knowledge.entity.KnowledgeCenterInq;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.mapper.KnowledgeCenterInqMapper;
import com.zyapaar.knowledge.repository.KnowledgeCenterInqRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ManageKnowledgeCenterInqService implements KnowledgeCenterInqService {

	private final KnowledgeCenterInqRepository knowledgeCenterInqRepository;
	private final KnowledgeCenterInqMapper knowledgeCenterInqMapper;

	@Override
	public ResponseEntity<Response> getAllKnowledgeCenterInqs(String companyName, String personName,
			LocalDate fromDate, LocalDate toDate, Status status, long page, long size) {
		try {
			
			log.info("getAll : {}", companyName, personName, fromDate, toDate, status);
			if (companyName != null)
				companyName = companyName.isEmpty() ? null : "%" + companyName + "%";
			if (personName != null)
				personName = personName.isEmpty() ? null : "%" + personName + "%";

		  Flux<KnowledgeCenterInqResponseDto> result = knowledgeCenterInqRepository
				.findAll(companyName, personName, fromDate, toDate, status).skip(page * size).take(size)
				.sort(Comparator.comparing(KnowledgeCenterInq::getCreatedDate).reversed())
				.map(knowledgeCenterInqMapper::toKnowledgeCenterInqResponseDto);

		  String sizeLength = String.valueOf(knowledgeCenterInqRepository
				.findAll(companyName, personName, fromDate, toDate, status).collectList().block().size());

				return ResponseEntity.status(HttpStatus.OK)
				.body(Response.builder().message("Listing Response")
				.data(new ListingResponse(result.collectList().block(), Integer.parseInt(sizeLength)))
				.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	@Override
	public Mono<KnowledgeCenterInqResponseDto> getById(String knowledgeCenterInqId) {

		try {
			log.info("getById : {}", knowledgeCenterInqId);
			return knowledgeCenterInqRepository.findById(knowledgeCenterInqId)
					.map(knowledgeCenterInqMapper::toKnowledgeCenterInqResponseDto);

		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during create company", e);
		}

	}

	@Override
	public Mono<KnowledgeCenterInqResponseDto> create(Mono<KnowledgeCenterInqRequestDto> knowledgeCenterInqRequestDtoMono,
			String curUserId) {
		// return knowledgeCenterInqRequestDtoMono
		// .map(knowledgeCenterInqMapper::toKnowledgeCenterInq)
		// // .map(knowledgeCenterInq->{
		// // designationMaster.setCreatedBy(curUserId);
		// // return designationMaster;
		// // })
		// .flatMap(knowledgeCenterInqRepository::save)
		// .map(knowledgeCenterInqMapper::toKnowledgeCenterInqResponseDto);

		try {
			log.info("create : {}", knowledgeCenterInqRequestDtoMono);
			return knowledgeCenterInqRequestDtoMono
					.map(knowledgeCenterInqMapper::toKnowledgeCenterInq)
					// .map(e ->{ e.setCreatedBy(curUserId); })
					.map(knowledgeCenterInq -> {
						knowledgeCenterInq.setCreatedBy(curUserId);
						return knowledgeCenterInq;
					})

					.flatMap(knowledgeCenterInqRepository::save)
					.map(knowledgeCenterInqMapper::toKnowledgeCenterInqResponseDto);

		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during create company", e);
		}
	}

	@Override
	public Mono<KnowledgeCenterInqResponseDto> updateById(String knowledgeCenterInqId,
			Mono<KnowledgeCenterInqRequestDto> knowledgeCenterInqRequestDtoMono, String curUserId) {

		try {
			log.info("upadte : {}", knowledgeCenterInqRequestDtoMono);
			return this.knowledgeCenterInqRepository.findById(knowledgeCenterInqId)
					.flatMap(knowledgeCenterInq -> knowledgeCenterInqRequestDtoMono.map(knowledgeCenterInqRequestDto -> {
						knowledgeCenterInqMapper.update(knowledgeCenterInq, knowledgeCenterInqRequestDto);
						knowledgeCenterInq.setUpdatedBy(curUserId);
						return knowledgeCenterInq;
					}))
					.flatMap(knowledgeCenterInqRepository::save)
					.map(knowledgeCenterInqMapper::toKnowledgeCenterInqResponseDto);

		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during updating company", e);
		}
	}

	@Override
	public Mono<Void> deleteById(String knowledgeCenterInqId, String curUserId) {

		try {
			log.info("delete : {}", knowledgeCenterInqId);
			return knowledgeCenterInqRepository.inactiveById(knowledgeCenterInqId, curUserId);
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during deleting company", e);
		}
	}

}
