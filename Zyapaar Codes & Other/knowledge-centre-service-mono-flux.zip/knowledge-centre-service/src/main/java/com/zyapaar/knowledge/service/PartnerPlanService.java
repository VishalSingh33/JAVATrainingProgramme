package com.zyapaar.knowledge.service;

import org.springframework.http.ResponseEntity;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.knowledge.dto.PartnerPlanRequestDto;
import com.zyapaar.knowledge.dto.PartnerPlanResponseDto;
import com.zyapaar.knowledge.dto.PartnerPlanSaveDto;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface PartnerPlanService {

	ResponseEntity<Response> getAllPartnerPlans(String planName, String industryName, Status status, long page, long size);

	ResponseEntity<Response> getAllPartnerPlanWithoutPagi(String planName, String industryName, Status status);

	Mono<PartnerPlanResponseDto> findPlanByPlanId(String planId);

	Mono<PartnerPlanResponseDto> create(Mono<PartnerPlanRequestDto> partnerPlanRequestDtoMono, String curUserId);

	Mono<PartnerPlanResponseDto> updateById(String planId, Mono<PartnerPlanRequestDto> partnerPlanRequestDtoMono, String curUserId);

	Mono<Void> deleteById(String planId, String curUserId);


	ResponseEntity<Response> getAllPartnerAmount();


}
