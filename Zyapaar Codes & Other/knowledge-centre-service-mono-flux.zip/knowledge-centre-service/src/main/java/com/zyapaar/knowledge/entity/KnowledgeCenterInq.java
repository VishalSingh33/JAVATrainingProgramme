package com.zyapaar.knowledge.entity;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import com.zyapaar.knowledge.enums.Status;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder

//@Entity
@Table("knowledge_center_inq")
public class KnowledgeCenterInq extends BaseEntity {

	@Column("company_name")
	private String companyName;

	@Column("person_name")
	private String personName;

	@Column("contact_no")
	private String contactNo;

	@Column
	private String email;

	@Column
	private Status status;

}