package com.zyapaar.knowledge.dto;

import com.zyapaar.knowledge.enums.Status;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserRequestDto {

//	@Pattern(regexp = "(^[\\w!#$%&’*+/=?`{|}~^-]+(?:.[\\w!#$%&’*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+.)+([a-zA-Z]{2,6})$)*", message = "Please enter valid emailId")
//	private String emailId;

	@NotNull(message = "Enter a name")
	@Size(min = 2, message = "Minimum 2 character require")
	@Size(max = 100, message = "Maximum ${max} character allowed")
	private String name;

	@Size(min = 19, max = 19, message = "${max} character allowed")
	private String designationId;
	
	// @Size(max = 20, message = "Maximum ${max} character allowed")
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid ContactNo")
	private String mobile;
	
	@Size(max = 20, message = "Maximum ${max} character allowed")
	private String code;
	
	@Size(max = 20, message = "Maximum ${max} character allowed")
	private String role;
	
	@NotNull(message = "Enter username")
	@Size(min = 2, message = "Minimum 2 character require")
	@Size(max = 50, message = "Maximum ${max} character allowed")
	private String username;

	// @NotNull(message = "Enter password")
	// @Size(min = 2, message = "Minimum 2 character require")
	// @Size(max = 100, message = "Maximum ${max} character allowed")
	private String password;

	private Status status = Status.ACTIVE;
}
