package com.zyapaar.knowledge.controller;

import java.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqResponseDto;
import com.zyapaar.knowledge.enums.Status;
import jakarta.validation.Valid;
import reactor.core.publisher.Mono;

/** Manage KnowledgeCenterInquiry
 * @author Dharmendrasinh Chudasama
 */
@CrossOrigin("*")
@RequestMapping(path = "/api/admin/v1/knowledge-center-inquiries")
public interface KnowledgeCenterInqController {

	@GetMapping
	ResponseEntity<Response> getAll(
			@RequestParam(required = false) String companyName,
			@RequestParam(required = false) String personName,
			@RequestParam(required = false) @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate fromDate,
			@RequestParam(required = false) @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate toDate,
			@RequestParam(required = false) Status status , 
			@RequestParam(value = "page", defaultValue = "0") long page,
			@RequestParam(value = "size", defaultValue = "10") long size
		);

	@GetMapping("/{knowledgeCenterInqId}")
	public Mono<ResponseEntity<KnowledgeCenterInqResponseDto>> getById(@PathVariable String knowledgeCenterInqId);

	@PostMapping
	Mono<KnowledgeCenterInqResponseDto> create(@RequestBody @Valid Mono<KnowledgeCenterInqRequestDto> knowledgeCenterInqRequestDtoMono, 
	@RequestHeader String curUserId);
	
	@PutMapping("/{knowledgeCenterInqId}")
	Mono<ResponseEntity<KnowledgeCenterInqResponseDto>> updateById(@PathVariable String knowledgeCenterInqId, @RequestBody @Valid Mono<KnowledgeCenterInqRequestDto> knowledgeCenterInqRequestDtoMono, @RequestHeader String curUserId);

	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	@DeleteMapping("/{knowledgeCenterInqId}")
	Mono<Void> deleteById(@PathVariable String knowledgeCenterInqId, @RequestHeader String curUserId);

}
