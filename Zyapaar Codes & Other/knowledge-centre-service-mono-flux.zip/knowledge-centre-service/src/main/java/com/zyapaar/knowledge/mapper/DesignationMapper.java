package com.zyapaar.knowledge.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.zyapaar.knowledge.dto.DesignationRequestDto;
import com.zyapaar.knowledge.dto.DesignationResponseDto;
import com.zyapaar.knowledge.entity.DesignationMaster;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Mapper
public interface DesignationMapper {

	DesignationMaster toDesignationMaster(DesignationRequestDto designationRequestDto);

	@Mapping(target = "id", ignore = true)
	@Mapping(target = "createdBy", ignore = true)
	@Mapping(target = "createdDate", ignore = true)
	@Mapping(target = "updatedBy", ignore = true)
	@Mapping(target = "updatedDate", ignore = true)
	void update(@MappingTarget DesignationMaster designationMaster, DesignationRequestDto designationRequestDto);

	DesignationResponseDto toDesignationResponseDto(DesignationMaster designationMaster);

	default Mono<DesignationResponseDto> toDesignationResponseDtoMono(Mono<DesignationMaster> designationMasterMono) {
		return designationMasterMono.map(this::toDesignationResponseDto);
	}

	default Flux<DesignationResponseDto> toDesignationResponseDtoFlux(Flux<DesignationMaster> designations) {
		return designations.map(this::toDesignationResponseDto);
	}

}
