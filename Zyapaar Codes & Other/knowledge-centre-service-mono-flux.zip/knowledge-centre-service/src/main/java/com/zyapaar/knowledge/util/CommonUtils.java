package com.zyapaar.knowledge.util;

import java.time.Duration;
import java.util.UUID;
import lombok.experimental.UtilityClass;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@UtilityClass
public class CommonUtils {
	
	public static String generateId() {
		return UUID.randomUUID().toString().substring(0, 19);
	}
	
	public static <T> T block(Mono<T> mono) {
		return mono.share().block( Duration.ofSeconds(15) );
	}

}
