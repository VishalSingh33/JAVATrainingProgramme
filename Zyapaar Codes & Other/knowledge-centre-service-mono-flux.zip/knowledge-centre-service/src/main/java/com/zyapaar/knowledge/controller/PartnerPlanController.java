package com.zyapaar.knowledge.controller;


// import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.knowledge.dto.PartnerPlanRequestDto;
import com.zyapaar.knowledge.dto.PartnerPlanResponseDto;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Mono;

/** Manage PartnerPlan
 * @author Dharmendrasinh Chudasama
 */
@RequestMapping(path = "/api/admin/v1/plans")
@CrossOrigin("*")
public interface PartnerPlanController {

	@GetMapping
	ResponseEntity<Response> getAll(
			@RequestParam(required = false) String planName,
			@RequestParam(required = false) String industryName,
			@RequestParam(required = false) Status status,
			@RequestParam(value = "page", defaultValue = "0") long page,
			@RequestParam(value = "size", defaultValue = "10") long size
		);

		@GetMapping("/getAll")
		ResponseEntity<Response> getAllWithoutPagi(
				@RequestParam(required = false) String planName,
				@RequestParam(required = false) String industryName,
				@RequestParam(required = false) Status status
			);

	@GetMapping("/{planId}")
	public Mono<ResponseEntity<PartnerPlanResponseDto>> findPlanByPlanId(@PathVariable String planId);

	@PostMapping
	Mono<PartnerPlanResponseDto> create(@RequestBody Mono<PartnerPlanRequestDto> partnerPlanRequestDtoMono, @RequestHeader String curUserId);
	
	@PutMapping("/{planId}")
	Mono<ResponseEntity<PartnerPlanResponseDto>> updateById(@PathVariable String planId, @RequestBody Mono<PartnerPlanRequestDto> partnerPlanRequestDtoMono, @RequestHeader String curUserId);

	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	@DeleteMapping("/{planId}")
	Mono<Void> deleteById(@PathVariable String planId, @RequestHeader String curUserId);


	@GetMapping("/PlaneAmount")
	ResponseEntity<Response> getPlaneAmount();

}
