package com.zyapaar.knowledge.dto;

import java.time.OffsetDateTime;

import com.zyapaar.knowledge.enums.Status;

import lombok.Data;

@Data
public class KnowledgeCenterInqResponseDto {

	private String id;

	private String companyName;
	private String personName;
	private String contactNo;
	private String email;

	private Status status;
	
	private String createdBy;
	private OffsetDateTime createdDate;
	private String updatedBy;
	private OffsetDateTime updatedDate;

}
