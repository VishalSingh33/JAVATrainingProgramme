package com.zyapaar.knowledge.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.zyapaar.knowledge.dto.UserRequestDto;
import com.zyapaar.knowledge.dto.UserResponseDto;
import com.zyapaar.knowledge.entity.Login;
import com.zyapaar.knowledge.entity.User;

/**
 * Manage User and Login both
 * @author Dharmendrasinh Chudasama
 */
@Mapper
public interface UserMapper {

	User toUser(UserRequestDto userRequestDto);
	Login toLogin(UserRequestDto userRequestDto);

	@Mapping(target = "id", ignore = true)
	@Mapping(target = "createdBy", ignore = true)
	@Mapping(target = "createdDate", ignore = true)
	@Mapping(target = "updatedBy", ignore = true)
	@Mapping(target = "updatedDate", ignore = true)
	void update(@MappingTarget User user, UserRequestDto userRequestDto);

	@Mapping(target = "id", ignore = true)
	@Mapping(target = "createdBy", ignore = true)
	@Mapping(target = "createdDate", ignore = true)
	@Mapping(target = "updatedBy", ignore = true)
	@Mapping(target = "updatedDate", ignore = true)
	void update(@MappingTarget Login login, UserRequestDto userRequestDto);

	UserResponseDto toUserResponseDto(User user);

	@Mapping(target = "id", ignore = true)
	@Mapping(target = "createdBy", ignore = true)
	@Mapping(target = "createdDate", ignore = true)
	@Mapping(target = "updatedBy", ignore = true)
	@Mapping(target = "updatedDate", ignore = true)
	UserResponseDto updateuserResponseDto(@MappingTarget UserResponseDto userResponseDto, Login login);

}
