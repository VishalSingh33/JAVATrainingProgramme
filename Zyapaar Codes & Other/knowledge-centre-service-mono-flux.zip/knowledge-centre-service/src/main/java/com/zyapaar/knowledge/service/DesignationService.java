package com.zyapaar.knowledge.service;

import com.zyapaar.commons.request.ListingRequest;

import org.springframework.http.ResponseEntity;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.knowledge.dto.DesignationRequestDto;
import com.zyapaar.knowledge.dto.DesignationResponseDto;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface DesignationService {

	ResponseEntity<Response> getAllDesignations(String designationName, Status status, long page, long size);

	ResponseEntity<Response> getAllDesignationWithoutPagination(String designationName, Status status);

	Mono<DesignationResponseDto> getById(String designationId);

	Mono<DesignationResponseDto> create(Mono<DesignationRequestDto> designationRequestDtoMono, String curUserId);

	Mono<DesignationResponseDto> updateById(String designationId, Mono<DesignationRequestDto> designationRequestDtoMono, String curUserId);

	Mono<Void> deleteById(String designationId, String curUserId);

}
