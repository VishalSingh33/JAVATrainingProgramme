package com.zyapaar.knowledge.service;

import org.springframework.stereotype.Service;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.knowledge.dto.UserRequestDto;
import com.zyapaar.knowledge.dto.UserResponseDto;
import com.zyapaar.knowledge.entity.Login;
import com.zyapaar.knowledge.entity.User;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.mapper.UserMapper;
import com.zyapaar.knowledge.repository.DesignationMasterRepository;
import com.zyapaar.knowledge.repository.LoginRepository;
import com.zyapaar.knowledge.repository.UserRepository;
import com.zyapaar.knowledge.util.CommonUtils;

import java.util.Comparator;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageUserService implements UserService {

	private final UserRepository userRepository;
	private final LoginRepository loginRepository;
	private final DesignationMasterRepository designationRepository;
	private final UserMapper userMapper;

	@Override
	public ResponseEntity<Response> getAllUsers(String name, Status status, long page, long size) {
		try {

			if (name != null)
				name = name.isEmpty() ? null : "%" + name + "%";

				Flux<UserResponseDto> result = userRepository.findAll(name, status).skip(page * size).take(size)
				.sort(Comparator.comparing(User::getCreatedDate).reversed())
				.flatMap(this::toUserResponseDto);

		String sizeLength = String.valueOf(userRepository.findAll(name,
				status).collectList().block().size());

				return ResponseEntity.status(HttpStatus.OK)
				.body(Response.builder().message("Listing Response")
				.data(new ListingResponse(result.collectList().block(), Integer.parseInt(sizeLength)))
				.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	@Override
	public Mono<UserResponseDto> getById(String userId) {
		try {
			return userRepository.findById(userId)
					.flatMap(this::toUserResponseDto);
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	@Override
	public Mono<UserResponseDto> create(Mono<UserRequestDto> userRequestDtoMono, String curUserId) {
		try {
			return userRequestDtoMono.map(userRequestDto -> {
				Login login = userMapper.toLogin(userRequestDto);
				login.setCreatedBy(curUserId);
				Login retLogin = CommonUtils.block(loginRepository.save(login));

				User user = userMapper.toUser(userRequestDto);
				user.setCreatedBy(curUserId);
				user.setUsersLoginId(retLogin.getId()); // dLoginMono.map(Login::getId).subscribe(user::setUsersLoginId);
				User retUser = CommonUtils.block(userRepository.save(user));

				UserResponseDto responseDto = userMapper.toUserResponseDto(retUser);
				userMapper.updateuserResponseDto(responseDto, retLogin);
				return responseDto;
			});
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	@Override
	public Mono<UserResponseDto> updateById(String userId, Mono<UserRequestDto> userRequestDtoMono, String curUserId) {
		try {
			return userRequestDtoMono.map(userReqDto -> {
				User retUser = userRepository.findById(userId)
						.flatMap(user -> {
							userMapper.update(user, userReqDto);
							user.setUpdatedBy(curUserId);
							return userRepository.save(user);
						})
						.share().block();

				Login retLogin = loginRepository.findById(retUser.getUsersLoginId())
						.flatMap(login -> {
							userMapper.update(login, userReqDto);
							login.setUpdatedBy(curUserId);
							return loginRepository.save(login);
						})
						.share().block();

				UserResponseDto userResponseDto = userMapper.toUserResponseDto(retUser);
				userMapper.updateuserResponseDto(userResponseDto, retLogin);
				return userResponseDto;
			});
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	@Override
	public Mono<Void> deleteById(String userId, String curUserId) {
		try {
			String loginId = userRepository.findByUsersLoginId(userId).share().block().getUsersLoginId();
			return userRepository.inactiveById(userId, curUserId)
					.and(loginRepository.inactiveById(loginId, curUserId));
		} catch (Exception e) {
			log.info("create : {}", e);
			throw new BadRequestException("Error during getAllKnowledgeCenterInqs company", e);
		}
	}

	private Mono<UserResponseDto> toUserResponseDto(User user) {
		UserResponseDto dto = userMapper.toUserResponseDto(user);

		return Mono.just(dto)
				.flatMap(respDto -> {
					if (user.getUsersLoginId() != null) {
						return loginRepository.findById(user.getUsersLoginId())
								.map(login -> {
									dto.setUsername(login.getUsername());
									return dto;
								});
					} else {
						return Mono.just(respDto);
					}
				})
				.flatMap(respDto -> {
					if (user.getDesignationId() != null) {
						return designationRepository.findById(user.getDesignationId())
								.map(desig -> {
									dto.setDesignationName(desig.getDesignationName());
									return dto;
								});
					} else {
						return Mono.just(respDto);
					}
				});

		// Login login = CommonUtils.block(loginRepository.findById(loginId));
		// dto.setUsername(login.getUsername());
		// return respMono;
	}

}
