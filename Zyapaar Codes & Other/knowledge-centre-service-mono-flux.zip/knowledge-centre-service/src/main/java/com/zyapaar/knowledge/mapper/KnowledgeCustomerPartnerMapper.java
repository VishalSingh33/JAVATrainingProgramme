package com.zyapaar.knowledge.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.zyapaar.knowledge.dto.KnowledgeCustomerPartnerResponseDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerResponseDto;
import com.zyapaar.knowledge.entity.KnowledgeCustomer;

@Mapper
public interface KnowledgeCustomerPartnerMapper {

	KnowledgeCustomerPartnerResponseDto tooKnowledgeCustomerResponseDto(KnowledgeCustomer entity);

	

	



}
