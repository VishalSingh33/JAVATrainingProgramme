package com.zyapaar.knowledge.handler;


import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.zyapaar.knowledge.dto.KnowledgeCenterInqRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqResponseDto;
import com.zyapaar.knowledge.exception.UnAuthorizedException;

import reactor.core.publisher.Mono;

@Component
public class AuthorHandler {

    // public Mono<ServerResponse> getAuthor(ServerRequest serverRequest) {
    //     return Mono.error(new UnAuthorizedException("Access denied"));
    // }

		Mono<ResponseEntity<KnowledgeCenterInqResponseDto>> create( Mono<KnowledgeCenterInqRequestDto> knowledgeCenterInqRequestDtoMono)
		{
			return Mono.error(new UnAuthorizedException("Access denied"));
		}
	
}