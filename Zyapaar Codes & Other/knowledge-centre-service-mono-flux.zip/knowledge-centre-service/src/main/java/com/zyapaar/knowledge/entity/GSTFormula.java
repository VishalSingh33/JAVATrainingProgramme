package com.zyapaar.knowledge.entity;

import java.math.BigDecimal;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import com.zyapaar.knowledge.enums.Status;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Table(value = "gst_formula")
public class GSTFormula extends BaseEntity {

	/** [REVERSE,FORWARD] */
	@Column("formula_type")
	private String formulaType;

	/** Percentage */
	@Column
	private BigDecimal cgst;

	/** Percentage */
	@Column
	private BigDecimal sgst;

	/** Percentage */
	@Column
	private BigDecimal cess;

	@Column
	private String formula;

	@Column
	private Status status;

}