package com.zyapaar.knowledge.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import com.zyapaar.knowledge.enums.ClientWillProvide;
import com.zyapaar.knowledge.enums.Status;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class KnowledgeCustomerRequestDto {

//	@NotNull(message = "Enter knowledgeCustomer name")
//	@Size(min = 2, message = "Minimum 2 character require")
//	@Size(max = 50, message = "Maximum 50 character allowed")
//	private String knowledgeCustomerName;

	private String knowledgeCenterInqId;
	
	@Size(max = 50, message = "Maximum ${max} character allowed")
	private String companyName;
	
	@Size(max = 50, message = "Maximum ${max} character allowed")
	private String personName;
	
	// @Size(max = 20, message = "Maximum ${max} character allowed")
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid ContactNo")
	private String contactNo;
	
	@Size(max = 20, message = "Maximum ${max} character allowed")
	@Pattern(regexp = "(^[\\w!#$%&’*+/=?`{|}~^-]+(?:.[\\w!#$%&’*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+.)+([a-zA-Z]{2,6})$)*", message = "Please enter valid email")
	private String email;
	
	@Size(max = 15, message = "Maximum ${max} character allowed")
	private String gstNo;

	private String planMasterId;
	
	private BigDecimal amount;
	
	private BigDecimal discount;

	private BigDecimal totalAmount;
	
	private BigDecimal invoiceAmount;
	
	private Boolean gstIncluded;
	
	private BigDecimal cgst;
	
	private BigDecimal sgst;
	
	private OffsetDateTime startDate;
	
	private OffsetDateTime endDate;
	
	private String paymentDetails;
	
	private OffsetDateTime paymentDate;
	
	private String industry;
	
	private String salesRepPlan;
	
	private String salesRepVal;
	
	/** [HTML,LINK] */
	@NotNull(message = "Enter clientWillProvide")
	private ClientWillProvide clientWillProvide;
	private String productDetailsContent;
	private String contactDetailsContent;
	private String chatSnippetContent;
	private String htmlMetaTagContent;
	private String webpageUrl; //if clientWillProvide=LINK
	
	private String logoUrl;
	private String partnerLabel;
	
	private Integer webinarCredit;
	private String webinarCodes;
	
	private String usersId; //
	private String gstFormulaId; //

//  @NotNull(message = "Enter status")
//  @Size(min = 2, message = "Minimum 2 character require")
//  @Size(max = 15, message = "Maximum 15 character allowed")
	private Status status = Status.ACTIVE;
}
