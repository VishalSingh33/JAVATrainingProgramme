package com.zyapaar.knowledge.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import com.zyapaar.knowledge.enums.ClientWillProvide;
import com.zyapaar.knowledge.enums.Status;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Table(value = "knowledge_customer")
public class KnowledgeCustomer extends BaseEntity {

	@Column("knowledge_center_inq_id")
	private String knowledgeCenterInqId;

	@Column("company_name")
	private String companyName;

	@Column("person_name")
	private String personName;

	@Column("contact_no")
	private String contactNo;

	@Column
	private String email;

	@Column("gst_no")
	private String gstNo;

	@Column("plan_master_id")
	private String planMasterId;

	@Column
	private BigDecimal amount;

	@Column("total_amount")
	private BigDecimal totalAmount;

	@Column
	private BigDecimal discount;

	@Column("invoice_amount")
	private BigDecimal invoiceAmount;

	@Column("gst_included")
	private Boolean gstIncluded;

	@Column
	private BigDecimal cgst;

	@Column
	private BigDecimal sgst;

	@Column("start_date")
	private OffsetDateTime startDate;

	@Column("end_date")
	private OffsetDateTime endDate;

	@Column("payment_details")
	private String paymentDetails;

	@Column("payment_date")
	private OffsetDateTime paymentDate;

	@Column
	private String industry;

	@Column("sales_rep_plan")
	private String salesRepPlan;

	@Column("sales_rep_val")
	private String salesRepVal;

	/** [HTML,LINK] */
	@Column("client_will_provide")
	private ClientWillProvide clientWillProvide;
	@Column("product_details_content")
	private String productDetailsContent;
	@Column("contact_details_content")
	private String contactDetailsContent;
	@Column("chat_snippet_content")
	private String chatSnippetContent;
	@Column("html_meta_tag_content")
	private String htmlMetaTagContent;
	@Column("webpage_url")
	private String webpageUrl; //if clientWillProvide=LINK

	@Column("logo_url")
	private String logoUrl;
	@Column("partner_label")
	private String partnerLabel;

	@Column("webinar_credit")
	private Integer webinarCredit;
	@Column("webinar_codes")
	private String webinarCodes;

	@Column("users_id")
	private String usersId;
	@Column("gst_formula_id")
	private String gstFormulaId;

	@Column
	private Status status;

}