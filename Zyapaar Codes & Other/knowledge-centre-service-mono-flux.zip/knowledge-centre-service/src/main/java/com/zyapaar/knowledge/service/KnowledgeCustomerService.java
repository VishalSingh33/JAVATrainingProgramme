package com.zyapaar.knowledge.service;

import com.zyapaar.commons.request.ListingRequest;

import org.springframework.http.ResponseEntity;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.knowledge.dto.KnowledgeCustomerPartnerResponseDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerResponseDto;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface KnowledgeCustomerService {

	ResponseEntity<Response> getAllKnowledgeCustomers(String companyName, String industryName, Status status, long page, long size);

	Mono<KnowledgeCustomerResponseDto> findCustomerByCustomerId(String knowledgeCustomerId);

	Mono<KnowledgeCustomerResponseDto> create(Mono<KnowledgeCustomerRequestDto> knowledgeCustomerRequestDtoMono, String curUserId);

	Mono<KnowledgeCustomerResponseDto> updateById(String knowledgeCustomerId, Mono<KnowledgeCustomerRequestDto> knowledgeCustomerRequestDtoMono, String curUserId);

	Mono<Void> deleteById(String knowledgeCustomerId, String curUserId);


	ResponseEntity<Response> getAllKnowledgePartner();
}
