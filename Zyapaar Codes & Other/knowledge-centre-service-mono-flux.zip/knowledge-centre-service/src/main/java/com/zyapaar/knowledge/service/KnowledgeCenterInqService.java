package com.zyapaar.knowledge.service;

import java.time.LocalDate;

import org.springframework.http.ResponseEntity;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqResponseDto;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface KnowledgeCenterInqService {

	ResponseEntity<Response> getAllKnowledgeCenterInqs(String companyName, String personName, LocalDate fromDate, LocalDate toDate, Status status, long page, long size);

	Mono<KnowledgeCenterInqResponseDto> getById(String knowledgeCenterInqId);

	Mono<KnowledgeCenterInqResponseDto> create(Mono<KnowledgeCenterInqRequestDto> knowledgeCenterInqRequestDtoMono, String curUserId);

	Mono<KnowledgeCenterInqResponseDto> updateById(String knowledgeCenterInqId, Mono<KnowledgeCenterInqRequestDto> knowledgeCenterInqRequestDtoMono, String curUserId);

	Mono<Void> deleteById(String knowledgeCenterInqId, String curUserId);

}
