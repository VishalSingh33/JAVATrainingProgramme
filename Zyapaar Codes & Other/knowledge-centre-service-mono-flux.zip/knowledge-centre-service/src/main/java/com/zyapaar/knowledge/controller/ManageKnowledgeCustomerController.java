package com.zyapaar.knowledge.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.knowledge.dto.KnowledgeCustomerPartnerResponseDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerResponseDto;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.service.KnowledgeCustomerService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
@Slf4j
@RequiredArgsConstructor
@RestController
public class ManageKnowledgeCustomerController implements KnowledgeCustomerController {

	private final KnowledgeCustomerService knowledgeCustomerService;

	@Override
	public ResponseEntity<Response> getAll(String companyName, String industryName, Status status, long page, long size) {
		try {
			return knowledgeCustomerService.getAllKnowledgeCustomers(companyName, industryName, status, page, size);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public Mono<ResponseEntity<KnowledgeCustomerResponseDto>> getById(String knowledgeCustomerId) {
		try {
			return knowledgeCustomerService.findCustomerByCustomerId(knowledgeCustomerId)
				.map(ResponseEntity::ok)
				.defaultIfEmpty(ResponseEntity.notFound().build());
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public Mono<KnowledgeCustomerResponseDto> create(Mono<KnowledgeCustomerRequestDto> knowledgeCustomerRequestDtoMono, String curUserId) {
		try {
			return knowledgeCustomerService.create(knowledgeCustomerRequestDtoMono, curUserId);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public Mono<ResponseEntity<KnowledgeCustomerResponseDto>> updateById(String knowledgeCustomerId, Mono<KnowledgeCustomerRequestDto> knowledgeCustomerRequestDtoMono, String curUserId) {
		try {
			return knowledgeCustomerService.updateById(knowledgeCustomerId, knowledgeCustomerRequestDtoMono, curUserId)
				.map(ResponseEntity::ok)
				.defaultIfEmpty(ResponseEntity.notFound().build());
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public Mono<Void> deleteById(String knowledgeCustomerId, String curUserId) {
		try {
			return knowledgeCustomerService.deleteById(knowledgeCustomerId, curUserId);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}


	@Override
	public ResponseEntity<Response> getKnowledgePartner() {

		return knowledgeCustomerService.getAllKnowledgePartner();
	}
	
}
