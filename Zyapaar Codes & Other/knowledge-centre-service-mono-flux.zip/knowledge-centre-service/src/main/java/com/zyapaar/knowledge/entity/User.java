package com.zyapaar.knowledge.entity;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import com.zyapaar.knowledge.enums.Status;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder

//@Entity
@Table("employees")
public class  User extends BaseEntity {

	@Column
	private String name;

	@Column("designation_id")
	private String designationId;
	
	@Column("users_login_id")
	private String usersLoginId;
	
	@Column
	private String mobile;
	
	@Column
	private String code;
	
	@Column
	private String role;
	
	@Column
	private Status status;

}