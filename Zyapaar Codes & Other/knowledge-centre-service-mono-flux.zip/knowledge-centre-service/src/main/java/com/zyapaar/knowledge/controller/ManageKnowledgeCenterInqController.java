package com.zyapaar.knowledge.controller;

import java.time.LocalDate;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqResponseDto;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.service.KnowledgeCenterInqService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
@RestController
@Slf4j
public class ManageKnowledgeCenterInqController implements KnowledgeCenterInqController {

	private final KnowledgeCenterInqService knowledgeCenterInqService;


	@Override
	public ResponseEntity<Response> getAll(String companyName, String personName, LocalDate fromDate, LocalDate toDate, Status status, long page, long size) {
		try {
			return knowledgeCenterInqService.getAllKnowledgeCenterInqs(companyName, personName, fromDate, toDate, status, page, size);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}



	@Override
	public Mono<ResponseEntity<KnowledgeCenterInqResponseDto>> getById(String knowledgeCenterInqId) {

try {
	return knowledgeCenterInqService.getById(knowledgeCenterInqId)
	.map(ResponseEntity::ok)
	.defaultIfEmpty(ResponseEntity.notFound().build());
	
} catch (Exception e) {
	log.info(":::: exception: {}",e);
	return null;
}
	}

	@Override
	public Mono<KnowledgeCenterInqResponseDto> create(Mono<KnowledgeCenterInqRequestDto> knowledgeCenterInqRequestDtoMono, String curUserId) {
		// return knowledgeCenterInqService.create(knowledgeCenterInqRequestDtoMono);

		try {
			return knowledgeCenterInqService.create(knowledgeCenterInqRequestDtoMono, curUserId);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	

	@Override
	public Mono<ResponseEntity<KnowledgeCenterInqResponseDto>> updateById(String knowledgeCenterInqId, Mono<KnowledgeCenterInqRequestDto> knowledgeCenterInqRequestDtoMono, String curUserId) {

try {
	return knowledgeCenterInqService.updateById(knowledgeCenterInqId, knowledgeCenterInqRequestDtoMono, curUserId)
	.map(ResponseEntity::ok)
	.defaultIfEmpty(ResponseEntity.notFound().build());
} catch (Exception e) {
	log.info(":::: exception: {}",e);
	return null;
}
	}

	@Override
	public Mono<Void> deleteById(String knowledgeCenterInqId, String curUserId) {

try {
	return knowledgeCenterInqService.deleteById(knowledgeCenterInqId, curUserId);
} catch (Exception e) {
	log.info(":::: exception: {}",e);
	return null;
}
	}


}
