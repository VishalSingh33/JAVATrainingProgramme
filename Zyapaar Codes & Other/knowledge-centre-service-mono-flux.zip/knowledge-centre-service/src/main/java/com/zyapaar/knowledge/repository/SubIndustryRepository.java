package com.zyapaar.knowledge.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.zyapaar.knowledge.dto.PartnerPlanResponseDto;
import com.zyapaar.knowledge.entity.SubIndustry;

import reactor.core.publisher.Mono;

@Repository
public interface SubIndustryRepository extends ReactiveCrudRepository<SubIndustry,String> {

	// @Query(" Select pm.* , si.name  from plan_master pm  inner join sub_industry si on pm.industry  = si.id  ")
	// Mono<PartnerPlanResponseDto> findUsingId(String id);

	@Query("SELECT name FROM sub_industry where id = :id")
	Mono<String> findIndustryNameById(String id);
	
}
