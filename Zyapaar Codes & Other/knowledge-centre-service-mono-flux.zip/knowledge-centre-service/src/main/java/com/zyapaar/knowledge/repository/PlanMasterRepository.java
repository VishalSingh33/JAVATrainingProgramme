package com.zyapaar.knowledge.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.zyapaar.knowledge.dto.PartnerPlanResponseDto;
import com.zyapaar.knowledge.dto.PartnerPlanResposeAmountDto;
import com.zyapaar.knowledge.entity.PlanMaster;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Repository
public interface PlanMasterRepository extends ReactiveCrudRepository<PlanMaster, String> {
	
	@Query("SELECT * FROM plan_master"
			+ " WHERE (:planName IS NULL OR plan_name ILIKE CONCAT('%',:planName,'%'))"
			+ " AND (:industryName IS NULL OR industry ILIKE CONCAT('%',:industryName,'%'))"
			+ " AND (:status IS NULL OR status=:status)"
		)
	Flux<PlanMaster> findAll(String planName, String industryName, Status status);

	// @Query("SELECT * FROM plan_master"
	// 		+ " WHERE (:planName IS NULL OR plan_name ILIKE CONCAT('%',:planName,'%'))"
	// 		+ " AND (:industryName IS NULL OR industry ILIKE CONCAT('%',:industryName,'%'))"
	// 		+ " AND (:status IS NULL OR status=:status)"
	// 	)
	// Flux<PlanMaster> findPageNo(String planName, String industryName, Status status);
	
	@Query("SELECT plan_name FROM plan_master WHERE id = :id")
	Mono<String> findPlanNameById(String id);
	
	@Modifying
	@Query("UPDATE plan_master SET status='INACTIVE', updated_date=NOW(), updated_by = :curUserId WHERE id = :id")
	Mono<Void> inactiveById(String id, String curUserId);

	@Query(
				value = "SELECT pm.id, pm.plan_name, pm.duration_unit, pm.duration_type, pm.amount, pm.start_date, pm.end_date,"
					+ " pm.webinar_credit, pm.remarks, pm.status, pm.industry as industry_id, si.name as industry_name FROM plan_master pm"
					+ " INNER JOIN sub_industry si ON pm.industry = si.id WHERE pm.id = :planId"
  )
	Mono<PartnerPlanResponseDto> findPlanByPlanId(String planId);


	@Query(" SELECT amount FROM plan_master pm  where id = :id ")
	Mono<String> findPlanAmount(String id);

}
