package com.zyapaar.knowledge.dto;

import com.zyapaar.knowledge.enums.Status;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class KnowledgeCenterInqRequestDto {

	@NotNull(message = "Enter a companyName")
	@Size(min = 2, message = "Minimum 2 character require")
	@Size(max = 50, message = "Maximum ${max} character allowed")
	private String companyName;

	@NotNull(message = "Enter a personName")
	@Size(min = 2, message = "Minimum 2 character require")
	@Size(max = 50, message = "Maximum ${max} character allowed")
	private String personName;

	// @Size(max = 20, message = "Maximum ${max} character allowed")
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Please enter valid ContactNo")
	private String contactNo;

	@Size(max = 20, message = "Maximum ${max} character allowed")
	@Pattern(regexp = "(^[\\w!#$%&’*+/=?`{|}~^-]+(?:.[\\w!#$%&’*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+.)+([a-zA-Z]{2,6})$)*", message = "Please enter valid email")
	private String email;

	private Status status = Status.ACTIVE;
}
