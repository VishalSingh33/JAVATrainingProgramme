package com.zyapaar.knowledge.controller;

// import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.knowledge.dto.UserRequestDto;
import com.zyapaar.knowledge.dto.UserResponseDto;
import com.zyapaar.knowledge.enums.Status;
import jakarta.validation.Valid;
import reactor.core.publisher.Mono;

/** Manage User
 * @author Dharmendrasinh Chudasama
 */
@RequestMapping(path = "/api/admin/v1/users")
@CrossOrigin("*")
public interface UserController {

	@GetMapping
	ResponseEntity<Response> getAll(
			@RequestParam(required = false) String name,
			@RequestParam(required = false) Status status,
			@RequestParam(value = "page", defaultValue = "0") long page,
			@RequestParam(value = "size", defaultValue = "10") long size
		);

	@GetMapping("/{userId}")
	public Mono<ResponseEntity<UserResponseDto>> getById(@PathVariable String userId);

	@PostMapping
	Mono<UserResponseDto> create(@RequestBody @Valid Mono<UserRequestDto> userRequestDtoMono, @RequestHeader String curUserId);
	
	@PutMapping("/{userId}")
	Mono<ResponseEntity<UserResponseDto>> updateById(@PathVariable String userId, @RequestBody @Valid Mono<UserRequestDto> userRequestDtoMono, @RequestHeader String curUserId);

	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	@DeleteMapping("/{userId}")
	Mono<Void> deleteById(@PathVariable String userId, @RequestHeader String curUserId);

}
