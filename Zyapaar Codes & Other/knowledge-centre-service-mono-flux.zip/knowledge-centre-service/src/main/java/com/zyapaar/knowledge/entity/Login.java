package com.zyapaar.knowledge.entity;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import com.zyapaar.knowledge.enums.Status;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder

//@Entity
@Table("employee_login")
public class Login extends BaseEntity {

	@Column("user_name")
	private String username;

	@Column
	private String password;
	
	@Column
	private String role;
	
	@Column
	private Status status;

}