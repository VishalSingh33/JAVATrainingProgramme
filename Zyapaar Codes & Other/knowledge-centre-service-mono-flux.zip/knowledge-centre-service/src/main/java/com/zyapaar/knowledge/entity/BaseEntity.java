package com.zyapaar.knowledge.entity;

import java.time.OffsetDateTime;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;

import com.zyapaar.knowledge.util.CommonUtils;
import jakarta.validation.constraints.NotNull;
// import jakarta.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Super class for all entity classes, id auto-generation handled
 * 
 */
@Data
@NoArgsConstructor
public abstract class BaseEntity implements Persistable<String> {

	@Id
	@Column //(nullable = false, length = 19)
	private String id;

	@CreatedBy
	// @NotNull
	@Column("created_by") //, nullable = false, length = 19)
	private String createdBy;

//	@CreatedDate
	@NotNull
	@Column("created_date") //, nullable = false)
	private OffsetDateTime createdDate;

	@LastModifiedBy
	@Column("updated_by")
	private String updatedBy;

//	@LastModifiedDate
	@Column("updated_date")
	private OffsetDateTime updatedDate;
	
	// -------- Custom Logic -------------

	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	@Transient
	private Boolean isNew = null;
	
	@Override
	public synchronized boolean isNew() {
		if(isNew==null) {//check for double call safety
			if (getId()==null) { //insert
				isNew=Boolean.TRUE;
				setId(CommonUtils.generateId());
//				setCreatedBy(createdBy);// Handle in method
				setCreatedDate(OffsetDateTime.now());
			}
			else { //update
				isNew=Boolean.FALSE;
//				setUpdatedBy(updatedBy);// Handle in method
				setUpdatedDate(OffsetDateTime.now());
			}
		}
		return this.isNew;
	}

}
