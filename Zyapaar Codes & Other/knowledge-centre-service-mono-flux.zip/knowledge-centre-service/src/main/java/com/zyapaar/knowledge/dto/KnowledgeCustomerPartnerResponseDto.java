package com.zyapaar.knowledge.dto;

import com.zyapaar.knowledge.enums.Status;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KnowledgeCustomerPartnerResponseDto {

	private String id;

	private String knowledgeCenterInqId;
	private String companyName;
	// private String personName;
	// private String contactNo;
	// private String email;
	// private String gstNo;
	private String planMasterId;
	// private BigDecimal amount;
	// private BigDecimal discount;
	// private BigDecimal invoiceAmount;
	// private Boolean gstIncluded;
	// private BigDecimal cgst;
	// private BigDecimal sgst;
	// private OffsetDateTime startDate;
	// private OffsetDateTime endDate;
	// private String paymentDetails;
	// private OffsetDateTime paymentDate;
	private String industry;
	// private String salesRepPlan;
	// private String salesRepVal;
	private String industryName;
	/** [HTML,LINK] */
	// private ClientWillProvide clientWillProvide;
	// private String productDetailsContent;
	// private String contactDetailsContent;
	// private String chatSnippetContent;
	// private String htmlMetaTagContent;
	private String webpageUrl; //if clientWillProvide=LINK
	
	private String logoUrl;
	private String partnerLabel;
	
	// private Integer webinarCredit;
	// private String webinarCodes;
	
	// private String usersId; //
	// private String gstFormulaId; //
	
	private String planName;
	// private String gstFormula;

	private Status status;
	// private String createdBy;
	// private OffsetDateTime createdDate;
	// private String updatedBy;
	// private OffsetDateTime updatedDate;

}
