package com.zyapaar.knowledge.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import com.zyapaar.knowledge.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PartnerPlanResponseDto {

	private String id;
	private String planName;
	private int durationUnit;
	/** Type for duration_unit (Days,Months,Years,etc.) */
	private String durationType;
	/** name of industry like banking, insurance, etc. */
	// private String industryId;
	// private String industryName;
	private BigDecimal amount;
	private OffsetDateTime startDate;
	private OffsetDateTime endDate;
	private Integer webinarCredit;
	private String remarks;
	private Status status;
	private String createdBy;
	private OffsetDateTime createdDate;
	private String updatedBy;
	private OffsetDateTime updatedDate;
}