package com.zyapaar.knowledge.repository;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Pageable;
import com.zyapaar.knowledge.entity.User;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Repository
public interface UserRepository extends R2dbcRepository<User, String> {
	
	@Query("SELECT * FROM employees"
			+ " WHERE (:name IS NULL OR name ILIKE CONCAT('%',:name,'%'))"
			+ " AND (:status IS NULL OR status=:status)"
		)
	Flux<User> findAll(@Param("name") String name, @Param("status") Status status);

	// @Query("SELECT * FROM employees"
	// 		+ " WHERE (:name IS NULL OR name ILIKE CONCAT('%',:name,'%'))"
	// 		+ " AND (:status IS NULL OR status=:status)"
	// 	)
	// Flux<User> findPageNo(@Param("name") String name, @Param("status") Status status);

	@Query("SELECT * FROM employees"
			+ " WHERE (:name IS NULL OR name ILIKE CONCAT('%',:name,'%'))"
			+ " AND (:status IS NULL OR status=:status)"
		)
	Flux<User> findPageNO(@Param("name") String name, @Param("status") Status status);
	
	@Modifying
	@Query("UPDATE employees SET status='INACTIVE', updated_date=NOW(), updated_by = :curUserId WHERE users_login_id = :id")
	Mono<Void> inactiveById(@Param("id") String id, @Param("curUserId") String curUserId);

	@Query("select * from employees where users_login_id = :id")
	Mono<User> findByUsersLoginId(String id);

}
