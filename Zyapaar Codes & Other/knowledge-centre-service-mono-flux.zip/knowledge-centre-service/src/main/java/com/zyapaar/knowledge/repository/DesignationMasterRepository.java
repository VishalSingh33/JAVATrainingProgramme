package com.zyapaar.knowledge.repository;

import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zyapaar.knowledge.entity.DesignationMaster;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Repository
public interface DesignationMasterRepository extends R2dbcRepository<DesignationMaster, String> {

	@Query("SELECT * FROM designation_master"
			+ " WHERE (:designationName IS NULL OR designation_name ILIKE CONCAT('%',:designationName,'%'))"
			+ " AND (:status IS NULL OR status=:status)")
	Flux<DesignationMaster> findAll(@Param("designationName") String designationName, @Param("status") Status status);

	@Modifying
	@Query("UPDATE designation_master SET status='INACTIVE', updated_date=NOW(), updated_by = :curUserId WHERE id = :id")
	Mono<Void> inactiveById(@Param("id") String id, @Param("curUserId") String curUserId);

	@Query("SELECT status from designation_master where id = :id")
	Optional<Mono<String>> findStatusById(@Param("id") String id);

}
