package com.zyapaar.knowledge.entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.OffsetDateTime;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Builder
@Table(value = "sub_industry")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubIndustry {


    @Column("id")
    private String id;

    @Column("name")
    private String name;

    @Column("created_on")
    private OffsetDateTime createdOn;
		
    @Column("created_by")
    private String createdBy;

    @Column("updated_on")
    private OffsetDateTime updatedOn;

    @Column("updated_by")
    private String updatedBy;

		@Column("product_id")
		private String productId;	
}
