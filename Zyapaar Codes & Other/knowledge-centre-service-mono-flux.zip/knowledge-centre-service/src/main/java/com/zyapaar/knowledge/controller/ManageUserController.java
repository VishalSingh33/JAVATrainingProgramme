package com.zyapaar.knowledge.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.knowledge.dto.UserRequestDto;
import com.zyapaar.knowledge.dto.UserResponseDto;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.service.UserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@RequiredArgsConstructor
@RestController
public class ManageUserController implements UserController {

	private final UserService userService;

	@Override
	public ResponseEntity<Response> getAll(String name, Status status, long page, long size) {
		try {
			return userService.getAllUsers(name, status, page, size);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public Mono<ResponseEntity<UserResponseDto>> getById(String userId) {
		try {
			return userService.getById(userId)
				.map(ResponseEntity::ok)
				.defaultIfEmpty(ResponseEntity.notFound().build());
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public Mono<UserResponseDto> create(Mono<UserRequestDto> userRequestDtoMono, String curUserId) {
		try {
			return userService.create(userRequestDtoMono, curUserId);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public Mono<ResponseEntity<UserResponseDto>> updateById(String userId, Mono<UserRequestDto> userRequestDtoMono, String curUserId) {
		try {
			return userService.updateById(userId, userRequestDtoMono, curUserId)
				.map(ResponseEntity::ok)
				.defaultIfEmpty(ResponseEntity.notFound().build());
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public Mono<Void> deleteById(String userId, String curUserId) {
		try {
			return userService.deleteById(userId, curUserId);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}
	
}
