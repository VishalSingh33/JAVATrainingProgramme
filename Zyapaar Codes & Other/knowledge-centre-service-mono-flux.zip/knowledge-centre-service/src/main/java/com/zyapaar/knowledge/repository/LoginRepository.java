package com.zyapaar.knowledge.repository;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.zyapaar.knowledge.entity.Login;

import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Repository
public interface LoginRepository extends R2dbcRepository<Login, String> {
	
	@Modifying
	@Query("UPDATE employee_login SET status='INACTIVE', updated_date=NOW(), updated_by = :curLoginId WHERE id = :id")
	Mono<Void> inactiveById(@Param("id") String id, @Param("curLoginId") String curLoginId);

}
