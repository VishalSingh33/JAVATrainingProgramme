package com.zyapaar.knowledge.dto;

import java.time.OffsetDateTime;

import com.zyapaar.knowledge.enums.Status;

import lombok.Data;

@Data
public class UserResponseDto {

	private String id;
	private String name;
	private String mobile;
	private String code;
	private String role;

	private String designationId;
	private String designationName;

	private String usersLoginId;
	private String username;
//	private String password;

	private Status status;
	private String createdBy;
	private OffsetDateTime createdDate;
	private String updatedBy;
	private OffsetDateTime updatedDate;

}
