package com.zyapaar.knowledge.exception;

import org.springframework.http.HttpStatus;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ExceptionRule {
	// public ExceptionRule(Class<UnAuthorizedException> class1, org.springframework.http.HttpStatus unauthorized) {
	// }
	Class<UnAuthorizedException> exceptionClass;
	HttpStatus status;
}
