package com.zyapaar.knowledge.mapper;

import org.mapstruct.Mapper;
import com.zyapaar.knowledge.dto.PartnerPlanResposeAmountDto;
import com.zyapaar.knowledge.entity.PlanMaster;


@Mapper
public interface PartnerPlanAmountMapper {

	PartnerPlanResposeAmountDto toPartnerPlanAmountResponseDto(PlanMaster entity);

}
