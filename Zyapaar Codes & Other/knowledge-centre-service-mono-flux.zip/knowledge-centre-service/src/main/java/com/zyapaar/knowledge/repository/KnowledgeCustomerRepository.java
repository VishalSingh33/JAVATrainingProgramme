package com.zyapaar.knowledge.repository;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.http.ResponseEntity;

import com.zyapaar.knowledge.dto.KnowledgeCustomerPartnerResponseDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerResponseDto;
import com.zyapaar.knowledge.entity.KnowledgeCustomer;
import com.zyapaar.knowledge.enums.Status;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author Dharmendrasinh Chudasama
 */
@Repository
public interface KnowledgeCustomerRepository extends ReactiveCrudRepository<KnowledgeCustomer, String> {
	
	@Query("SELECT * FROM knowledge_customer"
			+ " WHERE (:companyName IS NULL OR company_name ILIKE CONCAT('%',:companyName,'%'))"
			+ " AND (:industryName IS NULL OR industry LIKE :industryName)"
			+ " AND (:status IS NULL OR status=:status)"
		)
	Flux<KnowledgeCustomer> findAll(String companyName, String industryName, Status status);

	@Query(
				value = " SELECT kc.*,  si.name as industry_name , pm.plan_name "
			+ "	FROM knowledge_customer kc INNER JOIN sub_industry si ON kc.industry = si.id " 
			+ "	INNER  join plan_master pm on kc.plan_master_id  = pm.id WHERE kc.id = :kCustomerId " )
	Mono<KnowledgeCustomerResponseDto> findCustomerByCustomerId(String kCustomerId);	

	@Query(
				value = " SELECT kc.*,  si.name as industry_name , pm.plan_name "
			+	" FROM knowledge_customer kc INNER JOIN sub_industry si ON kc.industry = si.id "
			+ "	INNER  join plan_master pm on kc.plan_master_id  = pm.id " )
	Mono<KnowledgeCustomerResponseDto> findCustomerByCustomer(String kCustomerId);

	
	
	@Modifying
	@Query("UPDATE knowledge_customer SET status='INACTIVE', updated_date=NOW(), updated_by = :curUserId WHERE id = :id")
	Mono<Void> inactiveById(String id, String curUserId);

	@Query(
				value ="\n" + 
				" select kc.id , kc.company_name, kc.plan_master_id , kc.start_date , kc.end_date ,payment_details , kc.payment_details ,\n" + 
				" kc.payment_date , kc.industry , kc.webpage_url , logo_url ,kc.partner_label , kc.users_id ,kc.gst_formula_id , kc.status ,\n" + 
				" created_by, created_date, updated_by, updated_date\n" + 
				" from knowledge_customer kc\n " )
	Mono<ResponseEntity<KnowledgeCustomerPartnerResponseDto>> findKnowledgePartner();

}
