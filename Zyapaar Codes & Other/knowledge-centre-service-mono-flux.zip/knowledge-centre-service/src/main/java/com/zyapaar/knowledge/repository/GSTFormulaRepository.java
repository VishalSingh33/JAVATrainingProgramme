package com.zyapaar.knowledge.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.zyapaar.knowledge.entity.GSTFormula;

/**
 * @author Dharmendrasinh Chudasama
 */
@Repository
public interface GSTFormulaRepository extends R2dbcRepository<GSTFormula, String> {
	
//	@Query("SELECT * FROM gst_formula"
//			+ " WHERE (:companyName IS NULL OR company_name LIKE :companyName)"
//			+ " AND (:personName IS NULL OR person_name LIKE :personName)"
//			+ " AND (:fromDate IS NULL OR DATE(created_date) >= :fromDate)"
//			+ " AND (:toDate IS NULL OR DATE(created_date) <= :toDate)"
//			+ " AND (:status IS NULL OR status=:status)"
//		)
//	Flux<GSTFormula> findAll(String companyName, String personName, LocalDate fromDate, LocalDate toDate, Status status);
//	
//	@Modifying
//	@Query("UPDATE gst_formula SET status='INACTIVE', updated_date=NOW(), updated_by = :curUserId WHERE id = :id")
//	Mono<Void> inactiveById(@Param("id") String id, @Param("curUserId") String curUserId);

}
