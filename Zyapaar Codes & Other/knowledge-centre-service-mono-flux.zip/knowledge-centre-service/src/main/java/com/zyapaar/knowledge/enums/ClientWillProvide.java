package com.zyapaar.knowledge.enums;

public enum ClientWillProvide {
	HTML, LINK
}
