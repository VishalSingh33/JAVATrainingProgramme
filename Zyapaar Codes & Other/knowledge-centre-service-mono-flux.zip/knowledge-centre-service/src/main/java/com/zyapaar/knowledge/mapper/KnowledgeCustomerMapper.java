package com.zyapaar.knowledge.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.zyapaar.knowledge.dto.KnowledgeCustomerPartnerResponseDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCustomerResponseDto;
import com.zyapaar.knowledge.entity.KnowledgeCustomer;

@Mapper
public interface KnowledgeCustomerMapper {

	KnowledgeCustomer toKnowledgeCustomer(KnowledgeCustomerRequestDto knowledgeCustomerRequestDto);

	@Mapping(target = "id", ignore = true)
	@Mapping(target = "createdBy", ignore = true)
	@Mapping(target = "createdDate", ignore = true)
	@Mapping(target = "updatedBy", ignore = true)
	@Mapping(target = "updatedDate", ignore = true)
	void update(@MappingTarget KnowledgeCustomer KnowledgeCustomer, KnowledgeCustomerRequestDto knowledgeCustomerRequestDto);
	
	KnowledgeCustomerResponseDto toKnowledgeCustomerResponseDto(KnowledgeCustomer KnowledgeCustomer);

	// KnowledgeCustomerPartnerResponseDto tooKnowledgeCustomerResponseDto(KnowledgeCustomer KnowledgeCustomer);

}
