package com.zyapaar.knowledge.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.zyapaar.knowledge.dto.PartnerPlanRequestDto;
import com.zyapaar.knowledge.dto.PartnerPlanResponseDto;
import com.zyapaar.knowledge.entity.PlanMaster;


@Mapper
public interface PartnerPlanMapper {

	PlanMaster toPlanMaster(PartnerPlanRequestDto partnerPlanRequestDto);

	@Mapping(target = "id", ignore = true)
	@Mapping(target = "createdBy", ignore = true)
	@Mapping(target = "createdDate", ignore = true)
	@Mapping(target = "updatedBy", ignore = true)
	@Mapping(target = "updatedDate", ignore = true)
	void update(@MappingTarget PlanMaster planMaster, PartnerPlanRequestDto partnerPlanRequestDto);
	
	PartnerPlanResponseDto toPartnerPlanResponseDto(PlanMaster planMaster);


	// PartnerPlanResponseDto toPartnerPlanAmountResponseDto(PlanMaster entity);

	
}
