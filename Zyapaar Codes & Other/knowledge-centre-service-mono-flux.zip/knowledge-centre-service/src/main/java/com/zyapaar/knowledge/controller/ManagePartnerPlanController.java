package com.zyapaar.knowledge.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.knowledge.dto.PartnerPlanRequestDto;
import com.zyapaar.knowledge.dto.PartnerPlanResponseDto;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.service.PartnerPlanService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@RequiredArgsConstructor
@RestController
public class ManagePartnerPlanController implements PartnerPlanController {

	private final PartnerPlanService partnerPlanService;

	@Override
	public ResponseEntity<Response> getAll(String planName, String industryName, Status status, long page, long size) {
		try {
			return partnerPlanService.getAllPartnerPlans(planName, industryName, status, page, size);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public ResponseEntity<Response> getAllWithoutPagi(String planName, String industryName, Status status) {
		try {
			return partnerPlanService.getAllPartnerPlanWithoutPagi(planName, industryName, status);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

	@Override
	public Mono<ResponseEntity<PartnerPlanResponseDto>> findPlanByPlanId(String planId) {
		return partnerPlanService.findPlanByPlanId(planId)
				.map(ResponseEntity::ok)
				.defaultIfEmpty(ResponseEntity.notFound().build());
	}

	@Override
	public Mono<PartnerPlanResponseDto> create(Mono<PartnerPlanRequestDto> partnerPlanRequestDtoMono, String curUserId) {
		try {
			return partnerPlanService.create(partnerPlanRequestDtoMono, curUserId);
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}

// working put
	@Override
	public Mono<ResponseEntity<PartnerPlanResponseDto>> updateById(String planId, Mono<PartnerPlanRequestDto> partnerPlanRequestDtoMono, String curUserId) {
		try {
			return partnerPlanService.updateById(planId, partnerPlanRequestDtoMono, curUserId)
				.map(ResponseEntity::ok)
				.defaultIfEmpty(ResponseEntity.notFound().build());
		} catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
		}

	@Override
	public Mono<Void> deleteById(String planId, String curUserId) {
		try {
			return partnerPlanService.deleteById(planId, curUserId);
		}  catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
		}



	@Override
	public ResponseEntity<Response> getPlaneAmount() {
		
		return partnerPlanService.getAllPartnerAmount();
	}

		
}
