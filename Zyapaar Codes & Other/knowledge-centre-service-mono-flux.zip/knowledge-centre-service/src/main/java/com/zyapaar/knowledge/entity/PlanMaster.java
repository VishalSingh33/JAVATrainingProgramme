package com.zyapaar.knowledge.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import com.zyapaar.knowledge.enums.Status;


//import org.springframework.data.annotation.CreatedBy;
//import org.springframework.data.annotation.CreatedDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(value = "plan_master")
public class PlanMaster extends BaseEntity {

	@Column("plan_name")
	private String planName;

	@Column("duration_unit")
	private int durationUnit;
	
	/**
	 * Type for duration_unit (Days,Months,Years,etc.)
	 */
	@Column("duration_type")
	private String durationType;
	
	/**
	 * name of industry like banking, insurance, etc.
	 */
	private String industry;

	@Column
	private BigDecimal amount;

	@Column("start_date")
	private OffsetDateTime startDate;
	
	@Column("end_date")
	private OffsetDateTime endDate;
	
	@Column("webinar_credit")
	private Integer webinarCredit;
	
	@Column
	private String remarks;

	@Column
	private Status status;

}