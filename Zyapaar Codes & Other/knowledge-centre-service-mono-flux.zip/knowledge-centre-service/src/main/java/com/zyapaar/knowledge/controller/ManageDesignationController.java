package com.zyapaar.knowledge.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.knowledge.dto.DesignationRequestDto;
import com.zyapaar.knowledge.dto.DesignationResponseDto;
import com.zyapaar.knowledge.enums.Status;
import com.zyapaar.knowledge.service.DesignationService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@RequiredArgsConstructor
@RestController
public class ManageDesignationController implements DesignationController {

	private final DesignationService designationService;

	@Override
	public ResponseEntity<Response> getAll(String designationName, Status status,long page, long size)
	// , ListingRequest listingRequest) 
	{
try {
	return designationService.getAllDesignations(designationName, status, page, size);
} catch (Exception e) {
	log.info(":::: exception: {}",e);
	return null;
}
	}

	@Override
	public ResponseEntity<Response> getAllWithoutPagination(String designationName, Status status)
	{
try {
	return designationService.getAllDesignationWithoutPagination(designationName, status);
} catch (Exception e) {
	log.info(":::: exception: {}",e);
	return null;
}
	}

	@Override
	public Mono<ResponseEntity<DesignationResponseDto>> getById(String designationId) {
try {
	return designationService.getById(designationId)
				.map(ResponseEntity::ok)
				.defaultIfEmpty(ResponseEntity.notFound().build());
} catch (Exception e) {
	log.info(":::: exception: {}",e);
	return null;
}
	}

	@Override
	public Mono<DesignationResponseDto> create(Mono<DesignationRequestDto> designationRequestDtoMono, String curUserId) {
try {
	return designationService.create(designationRequestDtoMono, curUserId);
} catch (Exception e) {
	log.info(":::: exception: {}",e);
	return null;
}
	}

	@Override
	public Mono<ResponseEntity<DesignationResponseDto>> updateById(String designationId, Mono<DesignationRequestDto> designationRequestDtoMono, String curUserId) {
		return designationService.updateById(designationId, designationRequestDtoMono, curUserId)
				.map(ResponseEntity::ok)
				.defaultIfEmpty(ResponseEntity.notFound().build());
	}

	@Override
	public Mono<Void> deleteById(String designationId, String curUserId) {
		try {
			return designationService.deleteById(designationId, curUserId);
		}  catch (Exception e) {
			log.info(":::: exception: {}",e);
			return null;
		}
	}
	
}
