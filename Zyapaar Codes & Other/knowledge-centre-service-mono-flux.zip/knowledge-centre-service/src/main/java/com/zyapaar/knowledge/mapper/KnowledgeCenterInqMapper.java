package com.zyapaar.knowledge.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.zyapaar.knowledge.dto.KnowledgeCenterInqRequestDto;
import com.zyapaar.knowledge.dto.KnowledgeCenterInqResponseDto;
import com.zyapaar.knowledge.entity.KnowledgeCenterInq;

/**
 * Manage KnowledgeCenterInq and Login both
 * @author Dharmendrasinh Chudasama
 */
@Mapper
public interface KnowledgeCenterInqMapper {

	KnowledgeCenterInq toKnowledgeCenterInq(KnowledgeCenterInqRequestDto knowledgeCenterInqRequestDto);

	@Mapping(target = "id", ignore = true)
	@Mapping(target = "createdBy", ignore = true)
	@Mapping(target = "createdDate", ignore = true)
	@Mapping(target = "updatedBy", ignore = true)
	@Mapping(target = "updatedDate", ignore = true)
	void update(@MappingTarget KnowledgeCenterInq knowledgeCenterInq, KnowledgeCenterInqRequestDto knowledgeCenterInqRequestDto);

	KnowledgeCenterInqResponseDto toKnowledgeCenterInqResponseDto(KnowledgeCenterInq knowledgeCenterInq);

}
