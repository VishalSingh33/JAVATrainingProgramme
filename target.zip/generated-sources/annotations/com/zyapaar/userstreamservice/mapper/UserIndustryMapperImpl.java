package com.zyapaar.userstreamservice.mapper;

import UserInd.pgdb.user_industry.Value;
import com.zyapaar.serde.IndustryCount;
import com.zyapaar.serde.UserIndustryAvro;
import com.zyapaar.serde.UserIndustryAvro.Builder;
import com.zyapaar.serde.UserIndustryCountAvro;
import com.zyapaar.serde.UserIndustryCountCompactAvro;
import com.zyapaar.userstreamservice.dto.IndustryCountDto;
import com.zyapaar.userstreamservice.dto.UserIndustryCountDto;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.processing.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    comments = "version: 1.4.2.Final, compiler: Eclipse JDT (IDE) 1.4.200.v20220719-0747, environment: Java 17.0.4 (Eclipse Adoptium)"
)
@Component
public class UserIndustryMapperImpl implements UserIndustryMapper {

    @Override
    public UserIndustryAvro toUserIndustryAvro(Value value) {
        if ( value == null ) {
            return null;
        }

        Builder userIndustryAvro = UserIndustryAvro.newBuilder();

        List<CharSequence> list = value.getKeywordBuysId();
        if ( list != null ) {
            userIndustryAvro.setBuyIndustry( new ArrayList<CharSequence>( list ) );
        }
        List<CharSequence> list1 = value.getKeywordSellsId();
        if ( list1 != null ) {
            userIndustryAvro.setSaleIndustry( new ArrayList<CharSequence>( list1 ) );
        }
        userIndustryAvro.setId( toString( value.getId() ) );

        return userIndustryAvro.build();
    }

    @Override
    public UserIndustryCountDto toUserIndustryCountDto(UserIndustryCountAvro avro) {
        if ( avro == null ) {
            return null;
        }

        UserIndustryCountDto userIndustryCountDto = new UserIndustryCountDto();

        userIndustryCountDto.setId( toString( avro.getId() ) );
        userIndustryCountDto.setIndustryCount( charSequenceIndustryCountMapToStringIndustryCountDtoMap( avro.getIndustryCount() ) );

        return userIndustryCountDto;
    }

    @Override
    public UserIndustryCountCompactAvro toUserIndustryCountFlatAvro(UserIndustryCountDto countDto) {
        if ( countDto == null ) {
            return null;
        }

        com.zyapaar.serde.UserIndustryCountCompactAvro.Builder userIndustryCountCompactAvro = UserIndustryCountCompactAvro.newBuilder();

        userIndustryCountCompactAvro.setId( toString( countDto.getId() ) );
        userIndustryCountCompactAvro.setIndustryCount( mapToString( countDto.getIndustryCount() ) );

        return userIndustryCountCompactAvro.build();
    }

    protected IndustryCountDto industryCountToIndustryCountDto(IndustryCount industryCount) {
        if ( industryCount == null ) {
            return null;
        }

        IndustryCountDto industryCountDto = new IndustryCountDto();

        industryCountDto.setCount( industryCount.getCount() );
        industryCountDto.setName( toString( industryCount.getName() ) );

        return industryCountDto;
    }

    protected Map<String, IndustryCountDto> charSequenceIndustryCountMapToStringIndustryCountDtoMap(Map<CharSequence, IndustryCount> map) {
        if ( map == null ) {
            return null;
        }

        Map<String, IndustryCountDto> map1 = new HashMap<String, IndustryCountDto>( Math.max( (int) ( map.size() / .75f ) + 1, 16 ) );

        for ( java.util.Map.Entry<CharSequence, IndustryCount> entry : map.entrySet() ) {
            String key = toString( entry.getKey() );
            IndustryCountDto value = industryCountToIndustryCountDto( entry.getValue() );
            map1.put( key, value );
        }

        return map1;
    }
}
