package com.zyapaar.userstreamservice.mapper;

import com.zyapaar.serde.EmailNotificationAvro;
import com.zyapaar.serde.EmailNotificationAvro.Builder;
import javax.annotation.processing.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    comments = "version: 1.4.2.Final, compiler: Eclipse JDT (IDE) 1.4.200.v20220719-0747, environment: Java 17.0.4 (Eclipse Adoptium)"
)
@Component
public class EmailMapperImpl implements EmailMapper {

    @Override
    public EmailNotificationAvro toEmailNotification(String id, CharSequence email, String subject, String content, String meta, Long createdOn) {
        if ( id == null && email == null && subject == null && content == null && meta == null && createdOn == null ) {
            return null;
        }

        Builder emailNotificationAvro = EmailNotificationAvro.newBuilder();

        if ( id != null ) {
            emailNotificationAvro.setId( id );
        }
        if ( email != null ) {
            emailNotificationAvro.setEmail( email );
        }
        if ( subject != null ) {
            emailNotificationAvro.setSubject( subject );
        }
        if ( content != null ) {
            emailNotificationAvro.setContent( content );
        }
        if ( meta != null ) {
            emailNotificationAvro.setMeta( meta );
        }
        if ( createdOn != null ) {
            emailNotificationAvro.setCreatedOn( createdOn );
        }

        return emailNotificationAvro.build();
    }
}
