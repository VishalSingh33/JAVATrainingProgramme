package com.zyapaar.userstreamservice.mapper;

import com.zyapaar.commons.dto.NotificationFor;
import com.zyapaar.commons.dto.NotificationStatus;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.serde.EmailNotificationAvro;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.NotificationEventAvro.Builder;
import com.zyapaar.serde.SmsNotificationAvro;
import com.zyapaar.userstreamservice.entities.SmsTemplate;
import javax.annotation.processing.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    comments = "version: 1.4.2.Final, compiler: Eclipse JDT (IDE) 1.4.200.v20220719-0747, environment: Java 17.0.4 (Eclipse Adoptium)"
)
@Component
public class NotificationMapperImpl implements NotificationMapper {

    @Override
    public NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor, NotificationTypes type, String requestId, NotificationFor requestType) {
        if ( id == null && actionBy == null && generatedFor == null && type == null && requestId == null && requestType == null ) {
            return null;
        }

        Builder notificationEventAvro = NotificationEventAvro.newBuilder();

        if ( id != null ) {
            notificationEventAvro.setId( id );
        }
        if ( actionBy != null ) {
            notificationEventAvro.setActionBy( actionBy );
        }
        if ( generatedFor != null ) {
            notificationEventAvro.setGeneratedFor( generatedFor );
        }
        if ( type != null ) {
            notificationEventAvro.setType( map( type ) );
        }
        if ( requestId != null ) {
            notificationEventAvro.setRequestId( requestId );
        }
        if ( requestType != null ) {
            notificationEventAvro.setRequestType( map( requestType ) );
        }

        return notificationEventAvro.build();
    }

    @Override
    public NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor, NotificationTypes type, CharSequence requestId, NotificationStatus requestType) {
        if ( id == null && actionBy == null && generatedFor == null && type == null && requestId == null && requestType == null ) {
            return null;
        }

        Builder notificationEventAvro = NotificationEventAvro.newBuilder();

        if ( id != null ) {
            notificationEventAvro.setId( id );
        }
        if ( actionBy != null ) {
            notificationEventAvro.setActionBy( actionBy );
        }
        if ( generatedFor != null ) {
            notificationEventAvro.setGeneratedFor( generatedFor );
        }
        if ( type != null ) {
            notificationEventAvro.setType( map( type ) );
        }
        if ( requestId != null ) {
            notificationEventAvro.setRequestId( requestId );
        }
        if ( requestType != null ) {
            notificationEventAvro.setRequestType( map( requestType ) );
        }

        return notificationEventAvro.build();
    }

    @Override
    public NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor, NotificationTypes type, String originId) {
        if ( id == null && actionBy == null && generatedFor == null && type == null && originId == null ) {
            return null;
        }

        Builder notificationEventAvro = NotificationEventAvro.newBuilder();

        if ( id != null ) {
            notificationEventAvro.setId( id );
        }
        if ( actionBy != null ) {
            notificationEventAvro.setActionBy( actionBy );
        }
        if ( generatedFor != null ) {
            notificationEventAvro.setGeneratedFor( generatedFor );
        }
        if ( type != null ) {
            notificationEventAvro.setType( map( type ) );
        }
        if ( originId != null ) {
            notificationEventAvro.setOriginId( originId );
        }

        return notificationEventAvro.build();
    }

    @Override
    public NotificationEventAvro buildNotificationEvent(String id, String actionBy, NotificationTypes type, String originId, String requestId) {
        if ( id == null && actionBy == null && type == null && originId == null && requestId == null ) {
            return null;
        }

        Builder notificationEventAvro = NotificationEventAvro.newBuilder();

        if ( id != null ) {
            notificationEventAvro.setId( id );
        }
        if ( actionBy != null ) {
            notificationEventAvro.setActionBy( actionBy );
        }
        if ( type != null ) {
            notificationEventAvro.setType( map( type ) );
        }
        if ( originId != null ) {
            notificationEventAvro.setOriginId( originId );
        }
        if ( requestId != null ) {
            notificationEventAvro.setRequestId( requestId );
        }

        return notificationEventAvro.build();
    }

    @Override
    public NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor, NotificationTypes type, String requestId, Boolean isActive) {
        if ( id == null && actionBy == null && generatedFor == null && type == null && requestId == null && isActive == null ) {
            return null;
        }

        Builder notificationEventAvro = NotificationEventAvro.newBuilder();

        if ( id != null ) {
            notificationEventAvro.setId( id );
        }
        if ( actionBy != null ) {
            notificationEventAvro.setActionBy( actionBy );
        }
        if ( generatedFor != null ) {
            notificationEventAvro.setGeneratedFor( generatedFor );
        }
        if ( type != null ) {
            notificationEventAvro.setType( map( type ) );
        }
        if ( requestId != null ) {
            notificationEventAvro.setRequestId( requestId );
        }
        if ( isActive != null ) {
            notificationEventAvro.setIsActive( isActive );
        }

        return notificationEventAvro.build();
    }

    @Override
    public NotificationEventAvro buildNotificationEvent(String id, String actionBy, NotificationTypes type, String originId, String requestId, NotificationFor requestType) {
        if ( id == null && actionBy == null && type == null && originId == null && requestId == null && requestType == null ) {
            return null;
        }

        Builder notificationEventAvro = NotificationEventAvro.newBuilder();

        if ( id != null ) {
            notificationEventAvro.setId( id );
        }
        if ( actionBy != null ) {
            notificationEventAvro.setActionBy( actionBy );
        }
        if ( type != null ) {
            notificationEventAvro.setType( map( type ) );
        }
        if ( originId != null ) {
            notificationEventAvro.setOriginId( originId );
        }
        if ( requestId != null ) {
            notificationEventAvro.setRequestId( requestId );
        }
        if ( requestType != null ) {
            notificationEventAvro.setRequestType( map( requestType ) );
        }

        return notificationEventAvro.build();
    }

    @Override
    public NotificationEventAvro buildNotificationEvent(CharSequence id, CharSequence actionBy, CharSequence generatedFor, NotificationTypes type, CharSequence requestId, NotificationFor requestType) {
        if ( id == null && actionBy == null && generatedFor == null && type == null && requestId == null && requestType == null ) {
            return null;
        }

        Builder notificationEventAvro = NotificationEventAvro.newBuilder();

        if ( id != null ) {
            notificationEventAvro.setId( id );
        }
        if ( actionBy != null ) {
            notificationEventAvro.setActionBy( actionBy );
        }
        if ( generatedFor != null ) {
            notificationEventAvro.setGeneratedFor( generatedFor );
        }
        if ( type != null ) {
            notificationEventAvro.setType( map( type ) );
        }
        if ( requestId != null ) {
            notificationEventAvro.setRequestId( requestId );
        }
        if ( requestType != null ) {
            notificationEventAvro.setRequestType( map( requestType ) );
        }

        return notificationEventAvro.build();
    }

    @Override
    public NotificationEventAvro buildNotificationEvent(CharSequence id, CharSequence actionBy, CharSequence generatedFor, NotificationTypes type, CharSequence requestId, Boolean isActive) {
        if ( id == null && actionBy == null && generatedFor == null && type == null && requestId == null && isActive == null ) {
            return null;
        }

        Builder notificationEventAvro = NotificationEventAvro.newBuilder();

        if ( id != null ) {
            notificationEventAvro.setId( id );
        }
        if ( actionBy != null ) {
            notificationEventAvro.setActionBy( actionBy );
        }
        if ( generatedFor != null ) {
            notificationEventAvro.setGeneratedFor( generatedFor );
        }
        if ( type != null ) {
            notificationEventAvro.setType( map( type ) );
        }
        if ( requestId != null ) {
            notificationEventAvro.setRequestId( requestId );
        }
        if ( isActive != null ) {
            notificationEventAvro.setIsActive( isActive );
        }

        return notificationEventAvro.build();
    }

    @Override
    public SmsNotificationAvro toSmsNotificationAvro(SmsTemplate template, String id, String text, String phoneNumber) {
        if ( template == null && id == null && text == null && phoneNumber == null ) {
            return null;
        }

        com.zyapaar.serde.SmsNotificationAvro.Builder smsNotificationAvro = SmsNotificationAvro.newBuilder();

        if ( template != null ) {
            smsNotificationAvro.setEntityId( template.getEntityId() );
            smsNotificationAvro.setTemplateId( template.getTemplateId() );
        }
        if ( id != null ) {
            smsNotificationAvro.setId( id );
        }
        if ( text != null ) {
            smsNotificationAvro.setText( text );
        }
        if ( phoneNumber != null ) {
            smsNotificationAvro.setPhoneNumber( phoneNumber );
        }

        return smsNotificationAvro.build();
    }

    @Override
    public EmailNotificationAvro toEmailNotification(String id, CharSequence email, String subject, String content, String meta, Long createdOn) {
        if ( id == null && email == null && subject == null && content == null && meta == null && createdOn == null ) {
            return null;
        }

        com.zyapaar.serde.EmailNotificationAvro.Builder emailNotificationAvro = EmailNotificationAvro.newBuilder();

        if ( id != null ) {
            emailNotificationAvro.setId( id );
        }
        if ( email != null ) {
            emailNotificationAvro.setEmail( email );
        }
        if ( subject != null ) {
            emailNotificationAvro.setSubject( subject );
        }
        if ( content != null ) {
            emailNotificationAvro.setContent( content );
        }
        if ( meta != null ) {
            emailNotificationAvro.setMeta( meta );
        }
        if ( createdOn != null ) {
            emailNotificationAvro.setCreatedOn( createdOn );
        }

        return emailNotificationAvro.build();
    }
}
