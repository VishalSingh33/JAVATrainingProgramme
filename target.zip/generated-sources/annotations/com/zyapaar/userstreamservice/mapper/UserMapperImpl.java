package com.zyapaar.userstreamservice.mapper;

import User.pgdb.users.Value;
import com.zyapaar.serde.UserRegistrationAvro;
import com.zyapaar.serde.UserRegistrationAvro.Builder;
import javax.annotation.processing.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    comments = "version: 1.4.2.Final, compiler: Eclipse JDT (IDE) 1.4.200.v20220719-0747, environment: Java 17.0.4 (Eclipse Adoptium)"
)
@Component
public class UserMapperImpl implements UserMapper {

    @Override
    public UserRegistrationAvro toRegistrationAvro(Value user) {
        if ( user == null ) {
            return null;
        }

        Builder userRegistrationAvro = UserRegistrationAvro.newBuilder();

        if ( user.getTitle() != null ) {
            userRegistrationAvro.setProfileTitle( user.getTitle() );
        }
        if ( user.getImg() != null ) {
            userRegistrationAvro.setProfileImg( user.getImg() );
        }
        if ( user.getAboutUs() != null ) {
            userRegistrationAvro.setAboutUs( user.getAboutUs() );
        }
        if ( user.getEmailId() != null ) {
            userRegistrationAvro.setEmailId( user.getEmailId() );
        }
        if ( user.getAccountNonExpired() != null ) {
            userRegistrationAvro.setAccountNonExpired( user.getAccountNonExpired() );
        }
        if ( user.getAccountNonLocked() != null ) {
            userRegistrationAvro.setAccountNonLocked( user.getAccountNonLocked() );
        }
        if ( user.getCredentialsNonExpired() != null ) {
            userRegistrationAvro.setCredentialsNonExpired( user.getCredentialsNonExpired() );
        }
        if ( user.getEnable() != null ) {
            userRegistrationAvro.setEnable( user.getEnable() );
        }
        userRegistrationAvro.setFirstName( user.getFirstName() );
        userRegistrationAvro.setFullName( user.getFullName() );
        userRegistrationAvro.setId( user.getId() );
        if ( user.getIsHide() != null ) {
            userRegistrationAvro.setIsHide( user.getIsHide() );
        }
        userRegistrationAvro.setLastName( user.getLastName() );
        userRegistrationAvro.setMobileNo( user.getMobileNo() );
        userRegistrationAvro.setRole( user.getRole() );

        return userRegistrationAvro.build();
    }
}
