# Feed Service

# This URL use for swagger documentation => http://localhost:8080/swagger-ui.html
## This URL use for API documentation => http://localhost:8080/v3/api-docs

# connectors
## user activity to user activity 
## hashtag count to hashtags
