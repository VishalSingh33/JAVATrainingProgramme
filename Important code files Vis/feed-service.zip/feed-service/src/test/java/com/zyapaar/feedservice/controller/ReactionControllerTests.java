// package com.zyapaar.feedservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.feedservice.dto.ReactionDto;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.request.RequestReaction;
// import com.zyapaar.feedservice.response.ReactionCountResponse;
// import com.zyapaar.feedservice.service.ReactionService;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Reaction controller test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ReactionControllerTests {

//   @InjectMocks
//   ReactionController reactionController;
//   @Mock
//   ReactionService reactionService;
//   @Mock
//   ReactionDto reactionDto;
//   @Mock
//   ReactionCountResponse reactionCountResponse;
//   @Mock
//   RequestReaction requestReaction;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   ListingRequest listingRequest;

//   @Test
//   @DisplayName("submit post reaction return OK status")
//   void submitPostReaction_return_createdStatus() 
//       throws InterruptedException, ExecutionException, TimeoutException {

//     when(reactionService.submitPostReaction(anyString(), anyString(), isA(ReactionDto.class)))
//         .thenReturn("value");

//     ResponseEntity<Response> actual = reactionController.submitPostReaction("userId", "postId", 
//         reactionDto);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals("reaction added successfully", actual.getBody().getMessage());
//   }

//   @Test
//   @DisplayName("submit comment reaction return OK status")
//   void submitCommentReaction_return_createdStatus() 
//       throws InterruptedException, ExecutionException, TimeoutException {

//     when(reactionService.submitcommentReaction(anyString(), anyString(), anyString(), 
//         isA(ReactionDto.class))).thenReturn("value");

//     ResponseEntity<Response> actual = reactionController
//         .submitCommentReaction("userId", "commentId", "postId",reactionDto);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals("reaction added successfully", actual.getBody().getMessage());
//   }

//   @Test
//   @DisplayName("getReactionCount")
//   void getReactionCount(){
    
//     when(reactionService.getReactionCount(anyString())).thenReturn(reactionCountResponse);

//     ResponseEntity<Response> actual = reactionController.getReactionCount("postId");

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(reactionCountResponse, actual.getBody().getData());
//   }

//   @Test
//   @DisplayName("get Reacted user Listing")
//   void getReacteduserListing(){

//     when(reactionService.getReacteduserListing(isA(RequestReaction.class), isA(ListingRequest.class),
//         anyString())).thenReturn(listingResponse);
    
//     ResponseEntity<Response> actual = reactionController.getReacteduserListing("postId", 
//         requestReaction, listingRequest);
      
//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());
//   }

// }
