// package com.zyapaar.feedservice.util;

// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.eq;
// import static org.mockito.Mockito.when;

// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.JsonMappingException;
// import com.fasterxml.jackson.databind.ObjectMapper;
// import com.zyapaar.feedservice.dto.PostDto;
// import com.zyapaar.feedservice.properties.B2bProperties;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * String to post dto
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class StringToPostDtoTests {
  
//   @InjectMocks
//   StringToPostDto stringToPostDto;
//   @Mock
//   ObjectMapper objectMapper;
//   @Mock
//   PostDto postDto;

//   @Test
//   @DisplayName("convert test")
//   void convert() throws JsonMappingException, JsonProcessingException{
//     when(objectMapper.readValue(anyString(), eq(PostDto.class))).thenReturn(postDto);
    
//     PostDto actual = stringToPostDto.convert("source");

//     assertNotNull(actual);
//   }

// }
