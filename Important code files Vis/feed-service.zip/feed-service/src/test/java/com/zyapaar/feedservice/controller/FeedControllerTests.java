// package com.zyapaar.feedservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.feedservice.dto.Feeds;
// import com.zyapaar.feedservice.dto.PostOrigin;
// import com.zyapaar.feedservice.dto.Type;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.service.FeedService;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * feed controller tests
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class FeedControllerTests {

//   @InjectMocks
//   FeedController feedController;
//   @Mock
//   FeedService feedService;
//   @Mock
//   ResponseEntity<Response> entity;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   PostOrigin postOrigin;
//   @Mock
//   Feeds feeds;

//   @Test
//   @DisplayName("get feeds method test")
//   void getFeed() {

//     when(feedService.getFeed(anyString(), isA(ListingRequest.class),isA(Type.class), isA(PostOrigin.class)))
//         .thenReturn(listingResponse);

//     ResponseEntity<Response> actual = feedController.getFeed("userId", postOrigin,Type.ALL, listingRequest);

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());

//   }

//   @Test
//   @DisplayName("viewFeed")
//   void viewFeed() throws InterruptedException, ExecutionException, TimeoutException{

//     when(feedService.viewFeed(anyString(), anyString())).thenReturn(feeds);

//     ResponseEntity<Response> actual = feedController.viewFeed("userId", "feedId");

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(feeds, actual.getBody().getData());
//   }

//   @Test
//   @DisplayName("getOriginWiseFeeds")
//   void getOriginWiseFeeds(){

//     when(feedService.getOriginWiseFeeds(anyString(), isA(ListingRequest.class), anyString(), 
//         isA(PostOrigin.class))).thenReturn(listingResponse);

//     ResponseEntity<Response> actual = feedController.getOriginWiseFeeds("userId", postOrigin, 
//         "originId", listingRequest);

//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());

//   }

// }
