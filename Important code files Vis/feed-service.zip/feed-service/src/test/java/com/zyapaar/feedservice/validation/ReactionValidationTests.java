// package com.zyapaar.feedservice.validation;

// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.Mockito.when;

// import javax.validation.ConstraintValidatorContext;
// import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext;

// import com.zyapaar.feedservice.dto.Reaction;
// import com.zyapaar.feedservice.dto.ReactionDto;
// import com.zyapaar.feedservice.properties.B2bProperties;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.test.util.ReflectionTestUtils;

// /**
//  * Reaction dto
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class ReactionValidationTests {

//   @InjectMocks
//   ReactionValidation.Validators validators;
//   @Mock
//   ConstraintValidatorContext context;
//   @Mock
//   ConstraintValidatorContext.ConstraintViolationBuilder contextBuilder;
//   @Mock
//   NodeBuilderCustomizableContext nodeBuilderCustomizableContext;
//   @Mock
//   ReactionDto reactionDto;

//   @Test
//   @DisplayName("isValid true case")
//   void isValid_true() {

//     when(reactionDto.getOldReaction()).thenReturn(null);
//     when(reactionDto.getNewReaction()).thenReturn(null);

//     assertTrue(validators.isValid(reactionDto, context));

//   }

//   @Test
//   @DisplayName("isValid both none")
//   void isValid_both_NONE() {

//     when(reactionDto.getOldReaction()).thenReturn(Reaction.NONE);
//     when(reactionDto.getNewReaction()).thenReturn(Reaction.NONE);
//     ReflectionTestUtils.setField(validators, "oldReaction", "oldReaction");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     assertFalse(validators.isValid(reactionDto, context));

//   }

//   @Test
//   @DisplayName("isValid id is ok And old is none")
//   void isValid_IdOk_old_is_none(){

//     when(reactionDto.getId()).thenReturn(null);
//     when(reactionDto.getOldReaction()).thenReturn(Reaction.LIKE);
//     when(reactionDto.getNewReaction()).thenReturn(Reaction.NONE);
//     ReflectionTestUtils.setField(validators, "id", "id");
//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addPropertyNode(anyString())).thenReturn(nodeBuilderCustomizableContext);
//     when(nodeBuilderCustomizableContext.addConstraintViolation()).thenReturn(context);

//     assertFalse(validators.isValid(reactionDto, context));


//   }

// }
