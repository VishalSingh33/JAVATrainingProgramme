// package com.zyapaar.feedservice.dao;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.eq;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.List;

// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.feedservice.dto.ReactedUser;
// import com.zyapaar.feedservice.model.CommentReaction;
// import com.zyapaar.feedservice.model.PostReaction;
// import com.zyapaar.feedservice.model.PostReactionCount;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.properties.B2bProperties.Paging;
// import com.zyapaar.feedservice.repository.CommentReactionRepository;
// import com.zyapaar.feedservice.repository.PostReactionCountRepository;
// import com.zyapaar.feedservice.repository.PostReactionRepository;
// import com.zyapaar.feedservice.request.RequestReaction;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.data.mongodb.core.MongoTemplate;
// import org.springframework.data.mongodb.core.aggregation.Aggregation;
// import org.springframework.data.mongodb.core.aggregation.AggregationResults;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Manage reaction dao tests
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageReactionDaoTests {
  
//   @InjectMocks
//   ManageReactionDao manageReactionDao;
//   @Mock
//   PostReactionCountRepository postReactionCountRepository;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   MongoTemplate mongoTemplate;
//   @Mock
//   List<ReactedUser> reactedUsers;
//   @Mock
//   RequestReaction requestReaction;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   Paging paging;
//   @Mock
//   PostReactionCount postReactionCount;
//   @Mock
//   AggregationResults results; 
//   @Mock
//   Aggregation aggregation;
//   @Mock
//   PostReactionRepository postReactionRepository;
//   @Mock
//   PostReaction postReaction;
//   @Mock
//   CommentReactionRepository commentReactionRepository;
//   @Mock
//   CommentReaction commentReaction;

//   @Test
//   @DisplayName("getReactionCount")
//   void getReactionCount(){
    
//     when(postReactionCountRepository.findByPostId(anyString())).thenReturn(postReactionCount);

//     PostReactionCount actual = manageReactionDao.getReactionCount("postId");

//     assertNotNull(actual);
//     assertEquals(postReactionCount, actual);
//   }

//   @Test
//   @DisplayName("getReacteduserListing")
//   void getReacteduserListing(){
    
//     when(requestReaction.reaction()).thenReturn("value");
//     when(b2bProperties.getPaging()).thenReturn(paging);
//     when(paging.getFeedSize()).thenReturn(3);
//     when(listingRequest.getPage()).thenReturn(1);
//     when(mongoTemplate.aggregate(isA(Aggregation.class), eq(PostReaction.class), eq(ReactedUser.class)))
//         .thenReturn(results);
//     when(results.getMappedResults()).thenReturn(reactedUsers);

//     List<ReactedUser> actual = manageReactionDao.getReacteduserListing(requestReaction, 
//         listingRequest, "postId");
    
//     assertNotNull(actual);
//     assertEquals(reactedUsers, actual);
//   }

//   @Test
//   @DisplayName("getPostReaction test")
//   void getPostReaction(){
//     when(postReactionRepository.findByUserIdAndPostId(anyString(), anyString()))
//         .thenReturn(postReaction);
    
//     PostReaction actual = manageReactionDao.getPostReaction("userId", "postId");
//     assertEquals(postReaction, actual);
//   }

//   @Test
//   @DisplayName("getCommentReaction test")
//   void getCommentReaction(){
//     when(commentReactionRepository.findByUserIdAndCommentIdAndPostId(anyString(), anyString(), 
//         anyString())).thenReturn(commentReaction);
//     CommentReaction actual = manageReactionDao.getCommentReaction("userId", "commentId", "postId");

//     assertEquals(commentReaction, actual);
//   }

//   @Test
//   @DisplayName("isPostReactionExist") 
//   void isPostReactionExist(){
//     when(postReactionRepository.existsByUserIdAndPostId(anyString(), anyString())).thenReturn(true);
//     assertTrue(manageReactionDao.isPostReactionExist("userId", "postId"));
//   }

//   @Test
//   @DisplayName("isCommentReactionExist") 
//   void isCommentReactionExist(){
//     when(commentReactionRepository.existsByUserIdAndCommentIdAndPostId(anyString(), anyString(), 
//         anyString())).thenReturn(false);
//     assertFalse(manageReactionDao.isPostReactionExist("userId", "postId"));
//   }
// }
