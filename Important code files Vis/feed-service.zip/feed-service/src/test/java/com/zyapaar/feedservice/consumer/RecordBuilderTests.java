// package com.zyapaar.feedservice.consumer;

// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.Mockito.when;

// import java.util.List;

// import com.zyapaar.feedservice.dao.UserDao;
// import com.zyapaar.feedservice.dto.UserIndustryAvroDto;
// import com.zyapaar.feedservice.dto.UserRegistrationAvroDto;
// import com.zyapaar.feedservice.mapper.FeedCommentAvroMapper;
// import com.zyapaar.feedservice.mapper.FeedMapper;
// import com.zyapaar.feedservice.model.User;
// import com.zyapaar.feedservice.model.UserIndustry;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.serde.CommentAvro;
// import com.zyapaar.serde.CommentCountAvro;
// import com.zyapaar.serde.CommentReactionAvro;
// import com.zyapaar.serde.CommentReactionCountAvro;
// import com.zyapaar.serde.CommentReplyCountAvro;
// import com.zyapaar.serde.FeedAvro;
// import com.zyapaar.serde.FeedCommentAvro;
// import com.zyapaar.serde.PostAvro;
// import com.zyapaar.serde.PostReactionAvro;
// import com.zyapaar.serde.PostReactionCountAvro;
// import com.zyapaar.serde.UserIndustryAvro;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * record builder tests
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class RecordBuilderTests {

//   @InjectMocks
//   RecordBuilder recordBuilder;
//   @Mock
//   FeedMapper feedAvroMapper;
//   @Mock
//   FeedAvro feedAvro;
//   @Mock
//   FeedCommentAvroMapper feedCommentAvroMapper;
//   @Mock
//   PostAvro postAvro;
//   @Mock
//   CommentCountAvro commentCountAvro;
//   @Mock
//   List<CharSequence> charaList;
//   @Mock
//   PostReactionCountAvro postReactionCountAvro;
//   @Mock
//   FeedCommentAvro feedCommentAvro;
//   @Mock
//   CommentAvro commentAvro;
//   @Mock
//   CommentReactionCountAvro commentReactionCountAvro;
//   @Mock
//   PostReactionAvro postReactionAvro;
//   @Mock
//   CommentReactionAvro commentReactionAvro;
//   @Mock
//   UserIndustryAvro userIndustryAvro;
//   @Mock
//   UserRegistrationAvroDto userRegistrationAvroDto;
//   @Mock
//   UserIndustryAvroDto userIndustryAvroDto;
//   @Mock
//   List<String> strings;
//   @Mock
//   CommentReplyCountAvro CommentReplyCountAvro;
//   @Mock
//   UserDao userDao;
//   @Mock
//   User user;
//   @Mock
//   UserIndustry userIndustry;

//   @Test
//   @DisplayName("reaction 1 test")
//   void updatePostResctionCount_1() {

//     when(postReactionAvro.getNewReaction()).thenReturn("1");
//     when(postReactionAvro.getOldReaction()).thenReturn("2");
//     when(postReactionCountAvro.getLikeCount()).thenReturn(1L);
//     when(postReactionCountAvro.getCelebrateCount()).thenReturn(1L);

//     PostReactionCountAvro actual = recordBuilder.updatePostReactionCount(postReactionAvro,
//         postReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 2 test")
//   void updatePostResctionCount_2() {

//     when(postReactionAvro.getNewReaction()).thenReturn("2");
//     when(postReactionAvro.getOldReaction()).thenReturn("3");
//     when(postReactionCountAvro.getInterestCount()).thenReturn(1L);
//     when(postReactionCountAvro.getCelebrateCount()).thenReturn(1L);

//     PostReactionCountAvro actual = recordBuilder.updatePostReactionCount(postReactionAvro,
//         postReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 3 test")
//   void updatePostResctionCount_3() {

//     when(postReactionAvro.getNewReaction()).thenReturn("3");
//     when(postReactionAvro.getOldReaction()).thenReturn("4");
//     when(postReactionCountAvro.getInterestCount()).thenReturn(1L);
//     when(postReactionCountAvro.getShakeHandCount()).thenReturn(1L);

//     PostReactionCountAvro actual = recordBuilder.updatePostReactionCount(postReactionAvro,
//         postReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 4 test")
//   void updatePostResctionCount_4() {

//     when(postReactionAvro.getNewReaction()).thenReturn("4");
//     when(postReactionAvro.getOldReaction()).thenReturn("5");
//     when(postReactionCountAvro.getShakeHandCount()).thenReturn(1L);
//     when(postReactionCountAvro.getSupportCount()).thenReturn(1L);

//     PostReactionCountAvro actual = recordBuilder.updatePostReactionCount(postReactionAvro,
//         postReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 5 old is null test")
//   void updatePostResctionCount_5_old_is_null() {

//     when(postReactionCountAvro.getCount()).thenReturn(2L);
//     when(postReactionAvro.getNewReaction()).thenReturn("5");
//     when(postReactionAvro.getOldReaction()).thenReturn(null);
//     when(postReactionCountAvro.getSupportCount()).thenReturn(1L);

//     PostReactionCountAvro actual = recordBuilder.updatePostReactionCount(postReactionAvro,
//         postReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 1 new is null test")
//   void updatePostResctionCount_1_new_is_null() {

//     when(postReactionCountAvro.getCount()).thenReturn(2L);
//     when(postReactionAvro.getNewReaction()).thenReturn(null);
//     when(postReactionAvro.getOldReaction()).thenReturn("1");
//     when(postReactionCountAvro.getLikeCount()).thenReturn(1L);

//     PostReactionCountAvro actual = recordBuilder.updatePostReactionCount(postReactionAvro,
//         postReactionCountAvro);

//     assertNotNull(actual);
//   }

//   /************************ */
//   @Test
//   @DisplayName("reaction 1 test")
//   void updateCommentResctionCount_1() {

//     when(commentReactionAvro.getNewReaction()).thenReturn("1");
//     when(commentReactionAvro.getOldReaction()).thenReturn("2");
//     when(commentReactionCountAvro.getLikeCount()).thenReturn(1L);
//     when(commentReactionCountAvro.getCelebrateCount()).thenReturn(1L);

//     CommentReactionCountAvro actual = recordBuilder.updateCommentReactionCount(commentReactionAvro,
//         commentReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 2 test")
//   void updateCommentResctionCount_2() {

//     when(commentReactionAvro.getNewReaction()).thenReturn("2");
//     when(commentReactionAvro.getOldReaction()).thenReturn("3");
//     when(commentReactionCountAvro.getInterestCount()).thenReturn(1L);
//     when(commentReactionCountAvro.getCelebrateCount()).thenReturn(1L);

//     CommentReactionCountAvro actual = recordBuilder.updateCommentReactionCount(commentReactionAvro,
//         commentReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 3 test")
//   void updateCommentResctionCount_3() {

//     when(commentReactionAvro.getNewReaction()).thenReturn("3");
//     when(commentReactionAvro.getOldReaction()).thenReturn("4");
//     when(commentReactionCountAvro.getInterestCount()).thenReturn(1L);
//     when(commentReactionCountAvro.getShakeHandCount()).thenReturn(1L);

//     CommentReactionCountAvro actual = recordBuilder.updateCommentReactionCount(commentReactionAvro,
//         commentReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 4 test")
//   void updateCommentResctionCount_4() {

//     when(commentReactionAvro.getNewReaction()).thenReturn("4");
//     when(commentReactionAvro.getOldReaction()).thenReturn("5");
//     when(commentReactionCountAvro.getShakeHandCount()).thenReturn(1L);
//     when(commentReactionCountAvro.getSupportCount()).thenReturn(1L);

//     CommentReactionCountAvro actual = recordBuilder.updateCommentReactionCount(commentReactionAvro,
//         commentReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 5 old is null test")
//   void updateCommentResctionCount_5_old_is_null() {

//     when(commentReactionCountAvro.getCount()).thenReturn(2L);
//     when(commentReactionAvro.getNewReaction()).thenReturn("5");
//     when(commentReactionAvro.getOldReaction()).thenReturn(null);
//     when(commentReactionCountAvro.getSupportCount()).thenReturn(1L);

//     CommentReactionCountAvro actual = recordBuilder.updateCommentReactionCount(commentReactionAvro,
//         commentReactionCountAvro);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("reaction 1 new is null test")
//   void updateCommentResctionCount_1_new_is_null() {

//     when(commentReactionCountAvro.getCount()).thenReturn(2L);
//     when(commentReactionAvro.getNewReaction()).thenReturn(null);
//     when(commentReactionAvro.getOldReaction()).thenReturn("1");
//     when(commentReactionCountAvro.getLikeCount()).thenReturn(1L);

//     CommentReactionCountAvro actual = recordBuilder.updateCommentReactionCount(commentReactionAvro,
//         commentReactionCountAvro);

//     assertNotNull(actual);
//   }

// }
