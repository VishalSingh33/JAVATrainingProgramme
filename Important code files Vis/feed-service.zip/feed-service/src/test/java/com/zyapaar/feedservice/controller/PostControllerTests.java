// package com.zyapaar.feedservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.io.IOException;
// import java.util.List;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.feedservice.dto.PostDto;
// import com.zyapaar.feedservice.dto.PostResponse;
// import com.zyapaar.feedservice.dto.Privacy;
// import com.zyapaar.feedservice.dto.Type;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.service.PostService;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.MediaType;
// import org.springframework.http.ResponseEntity;
// import org.springframework.mock.web.MockMultipartFile;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.web.multipart.MultipartFile;

// /**
//  * post controller test class
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class PostControllerTests {

//   @InjectMocks
//   PostController postController;
//   @Mock
//   PostService postService;

//   @Mock
//   List<MultipartFile> fileList;

//   @Mock
//   PostResponse postResponse;

//   PostDto postDto;
//   MockMultipartFile multipartImage = new MockMultipartFile("file", "1k.png", MediaType.IMAGE_PNG_VALUE,
//       "imagePngByte".getBytes());

//   @BeforeEach
//   void setUp(){
//     postDto = new PostDto();
//     postDto.setPrivacy(Privacy.ANYONE);
//     postDto.setType(Type.BUY);
//     postDto.setId("id");
//     postDto.setHashTag("#hashTag");
//   }

//   @Test
//   @DisplayName("post function return creates response")
//   void post_Created() throws IOException, InterruptedException, ExecutionException, TimeoutException {

//     when(postService.createPost(isA(PostDto.class), anyString(), isA(List.class))).thenReturn(postResponse);
//     fileList.add(multipartImage);

//     ResponseEntity<Response> result = postController.post("userId", postDto, fileList);

//     assertNotNull(result);
//     assertEquals(HttpStatus.CREATED, result.getStatusCode());
//     assertEquals("post created successfully", result.getBody().getMessage());
//   }

// }
