// package com.zyapaar.feedservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.Mockito.when;

// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.service.FeedEmitterService;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

// /**
//  * Feed Emitter Controller test
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class FeedEmitterControllerTests {

//   @InjectMocks
//   FeedEmitterController feedEmitterController;
//   @Mock
//   FeedEmitterService feedEmitterService;
//   @Mock
//   SseEmitter sseEmitter;

//   @Test
//   @DisplayName("emit feed test")
//   void subscribeToFeeds() {

//     when(feedEmitterService.createEmitter(anyString())).thenReturn(sseEmitter);

//     SseEmitter actual = feedEmitterController.subscribeToFeeds("userId");

//     assertEquals(sseEmitter, actual);

//   }
// }
