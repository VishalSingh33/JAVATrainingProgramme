// package com.zyapaar.feedservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.service.HashTagService;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Hashtag controller test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class HashTagControllerTests {

//   @InjectMocks
//   HashTagController controller;
//   @Mock
//   HashTagService hashTagService;
//   @Mock
//   ListingRequest request;
//   @Mock
//   ListingResponse response;
  
//   @Test
//   @DisplayName("getHashTags test")
//   void getHashTags(){

//     when(hashTagService.getHashTags(isA(ListingRequest.class))).thenReturn(response);

//     ResponseEntity<Response> actual = controller.getHashTags("userId", request);

//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(response, actual.getBody().getData());
//   }


// }
