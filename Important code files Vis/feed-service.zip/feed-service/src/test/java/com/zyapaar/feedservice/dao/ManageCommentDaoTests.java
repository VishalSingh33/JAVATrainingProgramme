// package com.zyapaar.feedservice.dao;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.feedservice.model.FeedComment;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.properties.B2bProperties.Paging;
// import com.zyapaar.feedservice.repository.FeedCommentRepository;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.data.domain.Pageable;
// import org.springframework.data.domain.Slice;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * manage comment dao test 
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageCommentDaoTests {
  
//   @InjectMocks
//   ManageCommentDao manageCommentDao;
//   @Mock
//   Slice<FeedComment> slice;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   FeedCommentRepository commentMongoRepository;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   Paging paging;

//   @Test
//   @DisplayName("get comment test")
//   void getCommentd() {

//     when(listingRequest.getPage()).thenReturn(0);
//     when(b2bProperties.getPaging()).thenReturn(paging);
//     when(paging.getCommentSize()).thenReturn(1);
//     when(commentMongoRepository.findByPostId(anyString(), isA(Pageable.class))).thenReturn(slice);

//     Slice<FeedComment> actual = manageCommentDao.getComments("commentId", listingRequest);

//     assertNotNull(actual);
//     assertEquals(slice, actual);
//   }

//   @Test
//   @DisplayName("get sub comment test")
//   void getSubCommentd() {

//     when(listingRequest.getPage()).thenReturn(0);
//     when(b2bProperties.getPaging()).thenReturn(paging);
//     when(paging.getCommentSize()).thenReturn(1);
//     when(commentMongoRepository.findByPostIdAndCommentId(anyString(), anyString(), 
//         isA(Pageable.class))).thenReturn(slice);

//     Slice<FeedComment> actual = manageCommentDao.getSubComment("postId","commentId", listingRequest);

//     assertNotNull(actual);
//     assertEquals(slice, actual);

//   }


// }
