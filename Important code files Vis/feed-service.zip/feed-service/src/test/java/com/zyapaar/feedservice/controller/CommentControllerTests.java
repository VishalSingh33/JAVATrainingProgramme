// package com.zyapaar.feedservice.controller;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import com.zyapaar.commons.dto.Response;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.feedservice.dto.CommentDto;
// import com.zyapaar.feedservice.dto.CommentUpdateDto;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.service.CommentService;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.data.domain.Page;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * comment controller test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class CommentControllerTests {

//   @InjectMocks
//   CommentController commentController;
//   @Mock
//   CommentService commentService;
//   @Mock
//   CommentDto commentDto;
//   @Mock
//   Page<CommentDto> page;
//   @Mock
//   ResponseEntity<Response> entity;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   CommentUpdateDto commentUpdateDto;

//   @Test
//   @DisplayName("create Comment created")
//   void createComment_created() throws InterruptedException, ExecutionException, TimeoutException {

//     when(commentService.createComment(anyString(), anyString(), isA(CommentDto.class)))
//         .thenReturn("true");
//     when(commentDto.getId()).thenReturn("value");
//     ResponseEntity<Response> result = commentController.createComment("userId", "postId", commentDto);

//     assertNotNull(result);
//     assertEquals(HttpStatus.CREATED, result.getStatusCode());
//     assertEquals("comment added successfully", result.getBody().getMessage());
//   }

//   @Test
//   @DisplayName("updateComment")
//   void updateComment() throws InterruptedException, ExecutionException, TimeoutException{

//     when(commentService.updateComment(anyString(), isA(CommentUpdateDto.class))).thenReturn("value");

//     ResponseEntity<Response> actual = commentController.updateComment("userId", commentUpdateDto);
//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals("comment updated successfully", actual.getBody().getMessage());
//   }

//   @Test
//   @DisplayName("get comment")
//   void getComments(){
//     when(commentService.getComment(anyString(),isA(ListingRequest.class), anyString()))
//         .thenReturn(listingResponse);
//     ResponseEntity<Response> actual = commentController.getComments("userId", listingRequest, "postId");

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());
//   }

//   @Test
//   @DisplayName("get sub comment")
//   void getSubComments(){
//     when(commentService.getSubComment(anyString(), anyString() ,isA(ListingRequest.class), anyString()))
//         .thenReturn(listingResponse);
//     ResponseEntity<Response> actual = commentController
//         .getSubComments("userId", listingRequest, "postId","commentId");

//     assertNotNull(actual);
//     assertEquals(HttpStatus.OK, actual.getStatusCode());
//     assertEquals(listingResponse, actual.getBody().getData());
//   }
// }
