// package com.zyapaar.feedservice.service;

// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyList;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.eq;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.io.IOException;
// import java.util.ArrayList;
// import java.util.List;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import com.zyapaar.commons.dto.Attribute;
// import com.zyapaar.commons.response.FileUploadResponse;
// import com.zyapaar.feedservice.dao.UserDao;
// import com.zyapaar.feedservice.dto.Content;
// import com.zyapaar.feedservice.dto.PostDto;
// import com.zyapaar.feedservice.dto.PostResponse;
// import com.zyapaar.feedservice.dto.Status;
// import com.zyapaar.feedservice.mapper.PostAvroMapper;
// import com.zyapaar.feedservice.model.User;
// import com.zyapaar.feedservice.producer.Producer;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.properties.B2bProperties.Api;
// import com.zyapaar.serde.PostAvro;

// import org.apache.kafka.clients.producer.RecordMetadata;
// import org.junit.jupiter.api.AfterEach;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockedStatic;
// import org.mockito.Mockito;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.mock.web.MockMultipartFile;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.web.multipart.MultipartFile;
// import org.springframework.web.reactive.function.BodyInserters;
// import org.springframework.web.reactive.function.client.WebClient;
// import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
// import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
// import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
// import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

// import reactor.core.publisher.Mono;

// /**
//  * Manage post service class test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManagePostServiceTests {

//   @InjectMocks
//   ManagePostService managePostService;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   PostAvroMapper postAvroMapper;
//   @Mock
//   Producer producer;
//   @Mock
//   Api api;
//   @Mock
//   PostAvro postAvro;
//   @Mock
//   PostDto postDto;
//   @Mock
//   WebClient webClientMock;
//   @Mock
//   WebClient.Builder builder;
//   @Mock
//   RequestBodyUriSpec requestBodyUriSpec;
//   @Mock
//   RequestBodySpec requestBodySpec;
//   @Mock
//   RequestHeadersSpec requestHeadersSpec;
//   @Mock
//   ResponseSpec responseSpec;
//   @Mock
//   Mono<FileUploadResponse> monoFileUploadResponse;
//   @Mock
//   FileUploadResponse fileUploadResponse; 
//   @Mock
//   SendResult<String, PostAvro> sendPostResult;
//   @Mock
//   UserDao userDao;
//   @Mock
//   RecordMetadata recordMetadata;
//   @Mock
//   PostResponse postResponse;
//   @Mock
//   List<Attribute> attributes;
//   @Mock
//   Content content;
//   @Mock
//   User user;

//   List<MultipartFile> fileList = new ArrayList<>();


//   MockedStatic<BodyInserters> bodyInsertersMockedStatic = Mockito.mockStatic(BodyInserters.class);

//   MultipartFile multipartImage = new MockMultipartFile("file", "1k.png", 
//       MediaType.IMAGE_PNG_VALUE,	"imagePngByte".getBytes());

//   @AfterEach
//   void setDown() {
//     bodyInsertersMockedStatic.close();
//   }

//   @Test
//   @DisplayName("create post test")
//   void createPost() throws InterruptedException, ExecutionException, TimeoutException, IOException {
    
//     when(b2bProperties.getApi()).thenReturn(api);
//     when(api.getUserPostUpload()).thenReturn("value");

//     when(builder.build()).thenReturn(webClientMock);
//     when(webClientMock.post()).thenReturn(requestBodyUriSpec);
//     when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//     when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
//     when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//     when(responseSpec.bodyToMono(FileUploadResponse.class)).thenReturn(monoFileUploadResponse);
//     when(monoFileUploadResponse.block()).thenReturn(fileUploadResponse);
//     when(fileUploadResponse.getFileUrl()).thenReturn("value");
//     when(postDto.getContent()).thenReturn(content);
//     when(content.getAttributes()).thenReturn(attributes);
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(attributes.isEmpty()).thenReturn(true);

//     when(postAvroMapper.toPostAvro(isA(PostDto.class), anyString(), anyList(), anyLong(), 
//         anyLong(), eq(Status.ACTIVE.status()))).thenReturn(postAvro);
//     when(producer.producePost(isA(PostAvro.class))).thenReturn(sendPostResult);
//     when(sendPostResult.getRecordMetadata()).thenReturn(recordMetadata);

//     fileList.add(multipartImage);

//     when(postAvroMapper.toPostResponse(isA(PostAvro.class))).thenReturn(postResponse);
//     PostResponse actual = managePostService.createPost(postDto, "userId", fileList);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("create post test file null case")
//   void createPost_file_null_case() throws InterruptedException, ExecutionException,
//     TimeoutException, IOException {
//     when(postAvroMapper.toPostAvro(isA(PostDto.class), anyString(), any(), anyLong(), 
//         anyLong(), eq(Status.ACTIVE.status()))).thenReturn(postAvro);
    
//     when(postDto.getContent()).thenReturn(content);
//     when(content.getAttributes()).thenReturn(attributes);
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(attributes.isEmpty()).thenReturn(true);
//     when(producer.producePost(isA(PostAvro.class))).thenReturn(sendPostResult);
//     when(sendPostResult.getRecordMetadata()).thenReturn(null);
//     when(postAvroMapper.toPostResponse(isA(PostAvro.class))).thenReturn(postResponse);
//     PostResponse actual = managePostService.createPost(postDto, "userId", null);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("create post test file list size zero case")
//   void createPost_file_list_size_zero_case() throws InterruptedException, ExecutionException,
//     TimeoutException, IOException {
//     when(postDto.getContent()).thenReturn(content);
//     when(content.getAttributes()).thenReturn(attributes);
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(attributes.isEmpty()).thenReturn(true);
//     when(postAvroMapper.toPostAvro(isA(PostDto.class), anyString(), any(), anyLong(), 
//         anyLong(), eq(Status.ACTIVE.status()))).thenReturn(postAvro);
//     when(producer.producePost(isA(PostAvro.class))).thenReturn(sendPostResult);
//     when(sendPostResult.getRecordMetadata()).thenReturn(null);
//     when(postAvroMapper.toPostResponse(isA(PostAvro.class))).thenReturn(postResponse);
//     PostResponse actual = managePostService.createPost(postDto, "userId", fileList);

//     assertNotNull(actual);
//   }

// }
