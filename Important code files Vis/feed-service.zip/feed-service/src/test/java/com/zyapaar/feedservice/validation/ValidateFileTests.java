// package com.zyapaar.feedservice.validation;

// import static org.junit.jupiter.api.Assertions.assertFalse;
// import static org.junit.jupiter.api.Assertions.assertTrue;
// import static org.mockito.ArgumentMatchers.anyInt;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.Mockito.when;

// import java.util.Iterator;
// import java.util.List;

// import javax.validation.ConstraintValidatorContext;

// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.properties.B2bProperties.MediaSize;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.web.multipart.MultipartFile;

// /**
//  * file validation test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ValidateFileTests {
  
//   @InjectMocks
//   ValidateFile.Validators objectMock;
//   @Mock
//   ConstraintValidatorContext context;
//   @Mock
//   ConstraintValidatorContext.ConstraintViolationBuilder contextBuilder;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   MediaSize mediaSize;
//   @Mock
//   List<MultipartFile> fileList;
//   @Mock
//   MultipartFile multipartFile;
//   @Mock
//   Iterator<MultipartFile> iterator;

//   @BeforeEach
//   void init(){
//     when(b2bProperties.getMediaSize()).thenReturn(mediaSize);
//     when(mediaSize.getImage()).thenReturn(15000L);
//     when(mediaSize.getVideo()).thenReturn(25000L);
//     when(mediaSize.getPdf()).thenReturn(25000L);
//   }

//   /**
//    * PNG Image Validator
//    */
//   @Test
//   @DisplayName("PNG Image Validator")
//   void imagePngValidator() {

//     when(fileList.size()).thenReturn(1);
//     when(fileList.isEmpty()).thenReturn(false);
//     when(fileList.get(anyInt())).thenReturn(multipartFile);
//     when(fileList.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(multipartFile);
//     when(multipartFile.getSize()).thenReturn(14000L);
//     when(multipartFile.getOriginalFilename()).thenReturn("1kb.png");

//     boolean status = objectMock.isValid(fileList, context);
//     assertTrue(status);


//   }

//   /**
//    * JPG Image Validator
//    */
//   @Test
//   @DisplayName("JPG Image Validator")
//   void imageJpgValidator() {

//     when(fileList.size()).thenReturn(1);
//     when(fileList.isEmpty()).thenReturn(false);
//     when(fileList.get(anyInt())).thenReturn(multipartFile);
//     when(fileList.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(multipartFile);
//     when(multipartFile.getSize()).thenReturn(14000L);
//     when(multipartFile.getOriginalFilename()).thenReturn("1kb.jpg");

//     boolean status = objectMock.isValid(fileList, context);
//     assertTrue(status);
//   }

//   /**
//    * JPEG Image Validator
//    */
//   @Test
//   @DisplayName("JPEG Image Validator")
//   void imageJpegValidator() {

//     when(fileList.size()).thenReturn(1);
//     when(fileList.isEmpty()).thenReturn(false);
//     when(fileList.get(anyInt())).thenReturn(multipartFile);
//     when(fileList.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(multipartFile);
//     when(multipartFile.getSize()).thenReturn(14000L);
//     when(multipartFile.getOriginalFilename()).thenReturn("1kb.jpeg");

//     boolean status = objectMock.isValid(fileList, context);
//     assertTrue(status);
//   }

//   /**
//    * GIF Image Validator
//    */
//   @Test
//   @DisplayName("GIF Image Validator")
//   void imageGifValidator() {

//     when(fileList.size()).thenReturn(1);
//     when(fileList.isEmpty()).thenReturn(false);
//     when(fileList.get(anyInt())).thenReturn(multipartFile);
//     when(fileList.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(multipartFile);
//     when(multipartFile.getSize()).thenReturn(14000L);
//     when(multipartFile.getOriginalFilename()).thenReturn("1kb.gif");

//     boolean status = objectMock.isValid(fileList, context);
//     assertTrue(status);
//   }

//   /**
//    * NULL Image Validator
//    */
//   @Test
//   @DisplayName("NULL Image Validator")
//   void imageNullValidator() {

//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addConstraintViolation()).thenReturn(context);
//     when(fileList.size()).thenReturn(1);
//     when(fileList.isEmpty()).thenReturn(false);
//     when(fileList.get(anyInt())).thenReturn(multipartFile);
//     when(fileList.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(multipartFile);
//     when(multipartFile.getSize()).thenReturn(0L);
//     when(multipartFile.getOriginalFilename()).thenReturn("1kb.gif");

//     boolean status = objectMock.isValid(fileList, context);
//     assertFalse(status);
//   }

//   /**
//    * Wrong Image Validator
//    */
//   @Test
//   @DisplayName("Wrong Extention Image Validator")
//   void imageWrongValidator() {

//     when(context.buildConstraintViolationWithTemplate(anyString())).thenReturn(contextBuilder);
//     when(contextBuilder.addConstraintViolation()).thenReturn(context);
//     when(fileList.size()).thenReturn(1);
//     when(fileList.isEmpty()).thenReturn(false);
//     when(fileList.get(anyInt())).thenReturn(multipartFile);
//     when(fileList.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(multipartFile);
//     when(multipartFile.getSize()).thenReturn(0L);
//     when(multipartFile.getOriginalFilename()).thenReturn("1kb.xml");

//     boolean status = objectMock.isValid(fileList, context);
//     assertFalse(status);
//   }

//   /**
//    * MP4 Video Validator
//    */
//   @Test
//   @DisplayName("mp4 video Validator")
//   void videoMp4Validator() {

//     when(fileList.size()).thenReturn(1);
//     when(fileList.isEmpty()).thenReturn(false);
//     when(fileList.get(anyInt())).thenReturn(multipartFile);
//     when(fileList.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(multipartFile);
//     when(multipartFile.getSize()).thenReturn(0L);
//     when(multipartFile.getOriginalFilename()).thenReturn("1kb.mp4");

//     boolean status = objectMock.isValid(fileList, context);
//     assertTrue(status);
//   }

//   /**
//    * MP4 Video Validator
//    */
//   @Test
//   @DisplayName("mp4 video Validator")
//   void videoMovValidator() {

//     when(fileList.size()).thenReturn(1);
//     when(fileList.isEmpty()).thenReturn(false);
//     when(fileList.get(anyInt())).thenReturn(multipartFile);
//     when(fileList.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(multipartFile);
//     when(multipartFile.getSize()).thenReturn(0L);
//     when(multipartFile.getOriginalFilename()).thenReturn("1kb.mov");

//     boolean status = objectMock.isValid(fileList, context);
//     assertTrue(status);
//   }

//   /**
//    * PDF Video Validator
//    */
//   @Test
//   @DisplayName("Quicktime video Validator")
//   void PDFValidator() {

//     when(fileList.size()).thenReturn(1);
//     when(fileList.isEmpty()).thenReturn(false);
//     when(fileList.get(anyInt())).thenReturn(multipartFile);
//     when(fileList.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(multipartFile);
//     when(multipartFile.getSize()).thenReturn(0L);
//     when(multipartFile.getOriginalFilename()).thenReturn("1kb.pdf");

//     boolean status = objectMock.isValid(fileList, context);
//     assertTrue(status);
//   }
// }
