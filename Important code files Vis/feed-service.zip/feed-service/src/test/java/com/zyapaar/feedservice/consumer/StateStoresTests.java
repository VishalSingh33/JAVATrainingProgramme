// package com.zyapaar.feedservice.consumer;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertNull;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.eq;
// import static org.mockito.Mockito.when;

// import java.util.Iterator;
// import java.util.List;

// import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.properties.B2bProperties.Store;
// import com.zyapaar.serde.CommentReactionAvro;
// import com.zyapaar.serde.PostReactionAvro;
// import com.zyapaar.serde.PostReactionCountAvro;

// import org.apache.kafka.streams.errors.StateStoreMigratedException;
// import org.apache.kafka.streams.state.QueryableStoreType;
// import org.apache.kafka.streams.state.QueryableStoreTypes;
// import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
// import org.junit.jupiter.api.AfterEach;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockedStatic;
// import org.mockito.Mockito;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.cloud.stream.binder.kafka.streams.InteractiveQueryService;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * states store test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class StateStoresTests {

//   @InjectMocks
//   StateStores stateStores;

//   @Mock
//   InteractiveQueryService interactiveQueryService;

//   @Mock
//   B2bProperties b2bProperties;

//   @Mock
//   Store store;

//   @Mock
//   ReadOnlyKeyValueStore<String, PostReactionAvro> keyValueStorePostReactionAvro;

//   @Mock
//   QueryableStoreType<ReadOnlyKeyValueStore<String, PostReactionAvro>> storeTypePostReactionAvro;

//   @Mock
//   PostReactionAvro postReactionAvro;

//   @Mock
//   ReadOnlyKeyValueStore<String, CommentReactionAvro> keyValueStoreCommentReactionAvro;

//   @Mock
//   QueryableStoreType<ReadOnlyKeyValueStore<String, CommentReactionAvro>> storeTypeCommentReactionAvro;

//   @Mock
//   CommentReactionAvro commentReactionAvro;

//   @Mock
//   List<CharSequence> charSequences;

//   @Mock
//   Iterator<CharSequence> iteratorCharSequence;

//   @Mock
//   ReadOnlyKeyValueStore<String, PostReactionCountAvro> keyValueStorePostReactionCountAvro;

//   @Mock
//   QueryableStoreType<ReadOnlyKeyValueStore<String, PostReactionCountAvro>> storeTypePostReactionCountAvro;

//   @Mock
//   PostReactionCountAvro postReactionCountAvro;

//   MockedStatic<QueryableStoreTypes> queryableStoreTypes = Mockito.mockStatic(QueryableStoreTypes.class);

//   @AfterEach
//   public void name() {
//     queryableStoreTypes.close();
//   }

//   @Test
//   @DisplayName("get post reaction return data test")
//   void getPostReaction_return_data() {

//     when(b2bProperties.getStore()).thenReturn(store);
//     when(store.getPostReactionStore()).thenReturn("value");
//     queryableStoreTypes.when(() -> QueryableStoreTypes.keyValueStore())
//         .thenReturn(storeTypePostReactionAvro);
//     when(interactiveQueryService.getQueryableStore(anyString(), eq(storeTypePostReactionAvro)))
//         .thenReturn(keyValueStorePostReactionAvro);
//     when(keyValueStorePostReactionAvro.get(anyString())).thenReturn(postReactionAvro);

//     PostReactionAvro actual = stateStores.getPostReaction("userId");

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("get post reaction return null test")
//   void getPostReaction_return_null() {

//     when(b2bProperties.getStore()).thenReturn(store);
//     when(store.getPostReactionStore()).thenReturn("value");
//     queryableStoreTypes.when(() -> QueryableStoreTypes.keyValueStore())
//         .thenReturn(storeTypePostReactionAvro);
//     when(interactiveQueryService.getQueryableStore(anyString(), eq(storeTypePostReactionAvro)))
//         .thenThrow(new StateStoreMigratedException("message"));

//     PostReactionAvro actual = stateStores.getPostReaction("userId");

//     assertNull(actual);
//   }

//   @Test
//   @DisplayName("get comment reaction return data test")
//   void getCommentReaction_return_data() {

//     when(b2bProperties.getStore()).thenReturn(store);
//     when(store.getCommentReactionStore()).thenReturn("value");
//     queryableStoreTypes.when(() -> QueryableStoreTypes.keyValueStore())
//         .thenReturn(storeTypeCommentReactionAvro);
//     when(interactiveQueryService.getQueryableStore(anyString(), eq(storeTypeCommentReactionAvro)))
//         .thenReturn(keyValueStoreCommentReactionAvro);
//     when(keyValueStoreCommentReactionAvro.get(anyString())).thenReturn(commentReactionAvro);

//     CommentReactionAvro actual = stateStores.getCommentReaction("userId");

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("get comment reaction return null test")
//   void getCommentReaction_return_null() {

//     when(b2bProperties.getStore()).thenReturn(store);
//     when(store.getCommentReactionStore()).thenReturn("value");
//     queryableStoreTypes.when(() -> QueryableStoreTypes.keyValueStore())
//         .thenReturn(storeTypeCommentReactionAvro);
//     when(interactiveQueryService.getQueryableStore(anyString(), eq(storeTypeCommentReactionAvro)))
//         .thenThrow(new StateStoreMigratedException("message"));

//     CommentReactionAvro actual = stateStores.getCommentReaction("userId");

//     assertNull(actual);
//   }


//   @Test
//   @DisplayName("getPostReactionCount data found test")
//   void getPostReactionCount_data_found() {

//     when(b2bProperties.getStore()).thenReturn(store);
//     when(store.getPostReactionCountStore()).thenReturn("value");
//     queryableStoreTypes.when(() -> QueryableStoreTypes.keyValueStore())
//         .thenReturn(storeTypePostReactionCountAvro);
//     when(interactiveQueryService.getQueryableStore(anyString(), eq(storeTypePostReactionCountAvro)))
//         .thenReturn(keyValueStorePostReactionCountAvro);
//     when(keyValueStorePostReactionCountAvro.get(anyString())).thenReturn(postReactionCountAvro);

//     PostReactionCountAvro actual = stateStores.getPostReactionCount("userId");

//     assertNotNull(actual);
//     assertEquals(postReactionCountAvro, actual);

//   }

//   @Test
//   @DisplayName("getPostReactionCount data not found test")
//   void getPostReactionCount_data_not_found() {

//     when(b2bProperties.getStore()).thenReturn(store);
//     when(store.getPostReactionCountStore()).thenReturn("value");
//     queryableStoreTypes.when(() -> QueryableStoreTypes.keyValueStore())
//         .thenReturn(storeTypePostReactionCountAvro);
//     when(interactiveQueryService.getQueryableStore(anyString(), eq(storeTypePostReactionCountAvro)))
//         .thenThrow(new StateStoreMigratedException("message"));

//     assertThrows(ResourceNotFoundException.class, () -> stateStores.getPostReactionCount("userId"));
//   }

// }
