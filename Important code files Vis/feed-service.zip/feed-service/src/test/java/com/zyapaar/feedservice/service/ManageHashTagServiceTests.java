// package com.zyapaar.feedservice.service;

// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyInt;
// import static org.mockito.ArgumentMatchers.anyList;
// import static org.mockito.Mockito.when;

// import java.util.List;

// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.feedservice.dao.HashTagDao;
// import com.zyapaar.feedservice.dto.HashTagsDto;
// import com.zyapaar.feedservice.mapper.HashTagMapper;
// import com.zyapaar.feedservice.model.HashTags;
// import com.zyapaar.feedservice.properties.B2bProperties;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.data.domain.Page;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Manage hash tag service
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class ManageHashTagServiceTests {

//   @InjectMocks
//   ManageHashTagService service;
//   @Mock
//   HashTagDao hashTagDao;
//   @Mock
//   Page<HashTags> page;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   HashTagMapper hashTagMapper;
//   @Mock
//   List<HashTagsDto> dtos;
//   @Mock
//   List<HashTags> hashTags;

//   @Test
//   @DisplayName("getHashTags TEST")
//   void getHashTags(){

//     when(listingRequest.getPage()).thenReturn(11);
//     when(hashTagDao.getHashTags(anyInt())).thenReturn(page);
//     when(page.getContent()).thenReturn(hashTags);
//     when(hashTagMapper.toHashTagsDtos(anyList())).thenReturn(dtos);

//     assertNotNull(service.getHashTags(listingRequest));

//   }


// }
