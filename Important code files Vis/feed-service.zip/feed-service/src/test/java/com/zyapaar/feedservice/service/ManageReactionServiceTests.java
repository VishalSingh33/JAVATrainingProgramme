// package com.zyapaar.feedservice.service;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.Iterator;
// import java.util.List;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import org.apache.kafka.clients.producer.RecordMetadata;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;

// import com.zyapaar.commons.dto.NotificationContent;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.exceptionhandler.custom.OperationNotAllowedException;
// import com.zyapaar.feedservice.consumer.StateStores;
// import com.zyapaar.feedservice.dao.CommentDao;
// import com.zyapaar.feedservice.dao.FeedDao;
// import com.zyapaar.feedservice.dao.ReactionDao;
// import com.zyapaar.feedservice.dao.UserDao;
// import com.zyapaar.feedservice.dto.Notification;
// import com.zyapaar.feedservice.dto.ReactedUser;
// import com.zyapaar.feedservice.dto.Reaction;
// import com.zyapaar.feedservice.dto.ReactionDto;
// import com.zyapaar.feedservice.mapper.CommentReactionAvroMapper;
// import com.zyapaar.feedservice.mapper.NotificationMapper;
// import com.zyapaar.feedservice.mapper.PostReactionAvroMapper;
// import com.zyapaar.feedservice.mapper.ReactionMapper;
// import com.zyapaar.feedservice.model.Feed;
// import com.zyapaar.feedservice.model.FeedComment;
// import com.zyapaar.feedservice.model.PostReactionCount;
// import com.zyapaar.feedservice.model.User;
// import com.zyapaar.feedservice.model.UserConnections;
// import com.zyapaar.feedservice.producer.Producer;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.properties.B2bProperties.NotificationMsg;
// import com.zyapaar.feedservice.properties.B2bProperties.Topic;
// import com.zyapaar.feedservice.request.RequestReaction;
// import com.zyapaar.feedservice.response.ReactionCountResponse;
// import com.zyapaar.feedservice.util.NotificationUtils;
// import com.zyapaar.serde.CommentReactionAvro;
// import com.zyapaar.serde.PostReactionAvro;

// /**
//  * manage reaction service tests
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageReactionServiceTests {

//   @InjectMocks
//   ManageReactionService manageReactionService;
//   @Mock
//   Producer producer;
//   @Mock
//   PostReactionAvroMapper postReactionAvroMapper;
//   @Mock
//   CommentReactionAvroMapper commentReactionAvroMapper;
//   @Mock
//   CommentReactionAvro commentReactionAvro;
//   @Mock
//   PostReactionAvro postReactionAvro;
//   @Mock
//   ReactionDto reactionDto;
//   @Mock
//   Reaction reaction;
//   @Mock
//   FeedDao feedDao;
//   @Mock
//   SendResult<String,PostReactionAvro> sendPostResult;
//   @Mock
//   SendResult<String,CommentReactionAvro> sendCommentResult;
//   @Mock
//   RecordMetadata recordMetadata;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   NotificationMsg notificationMsg;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   NotificationMapper notificationMapper;
//   @Mock
//   Notification notification;
//   @Mock
//   ReactionMapper reactionMapper;
//   @Mock
//   UserDao userDao;
//   @Mock
//   List<String> list;
//   @Mock
//   Iterator<String> stringIterator;
//   @Mock
//   ReactionCountResponse reactionCountResponse;
//   @Mock
//   PostReactionCount postReactionCount;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   ReactionDao reactionDao;
//   @Mock
//   List<ReactedUser> reactedUsers;
//   @Mock
//   RequestReaction requestReaction;
//   @Mock
//   NotificationUtils notificationUtils;
//   @Mock
//   NotificationContent notificationContent;
//   @Mock
//   UserConnections userConnections;
//   @Mock
//   User user;
//   @Mock
//   CommentDao commentDao;
//   @Mock
//   FeedComment feedComment;
//   @Mock
//   Topic topic;
//   @Mock
//   Feed feed;

//   @Test
//   @DisplayName("submit post Reaction return true")
//   void submitPostReactionReturnTrueCase() throws InterruptedException, ExecutionException, 
//       TimeoutException{

//     when(user.getId()).thenReturn("value");

//     when(reactionDao.isPostReactionExist(anyString(), anyString())).thenReturn(false);
//     when(reactionDto.getId()).thenReturn("value");
//     when(reactionDto.getNewReaction()).thenReturn(Reaction.LIKE);
//     when(reactionDto.getPostUserId()).thenReturn("value");

//     when(postReactionAvroMapper.toPostReactionAvro(isA(ReactionDto.class), anyString(),anyString(), 
//         anyLong(), anyLong())).thenReturn(postReactionAvro);

//     when(feedDao.getFeed(anyString())).thenReturn(feed);
//     when(feed.getPostOf()).thenReturn(null);

//     when(producer.producePostReaction(isA(PostReactionAvro.class))).thenReturn(sendPostResult);
//     when(sendPostResult.getRecordMetadata()).thenReturn(recordMetadata);

//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getPostReactionEvent()).thenReturn("value");
//     when(userDao.getUserConnections(anyString())).thenReturn(userConnections);
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(user.getEmailId()).thenReturn(null);
//     when(userConnections.getUserIds()).thenReturn(list);
//     when(list.iterator()).thenReturn(stringIterator);
//     when(stringIterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(stringIterator.next()).thenReturn("value");

//     String actual = manageReactionService.submitPostReaction("userId", "postId", reactionDto);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("submit post Reaction return false")
//   void submitPostReactionReturnFalseCase() throws InterruptedException, ExecutionException, 
//       TimeoutException{

//     when(reactionDao.isPostReactionExist(anyString(), anyString())).thenReturn(false);
//     when(reactionDto.getId()).thenReturn("value");
//     when(postReactionAvroMapper.toPostReactionAvro(isA(ReactionDto.class), anyString(),anyString(), 
//         anyLong(), anyLong())).thenReturn(postReactionAvro);

//     when(producer.producePostReaction(isA(PostReactionAvro.class))).thenReturn(sendPostResult);
//     when(sendPostResult.getRecordMetadata()).thenReturn(null);

//     String actual = manageReactionService.submitPostReaction("userId", "postId", reactionDto);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("submit post Reaction return Opration not allowed")
//   void submitPostReactionReturnOperationNotAllowed() throws InterruptedException, ExecutionException, 
//       TimeoutException{
//     when(reactionDao.isPostReactionExist(anyString(), anyString())).thenReturn(true);

//     assertThrows(OperationNotAllowedException.class, 
//         () -> manageReactionService.submitPostReaction("userId", "postId", reactionDto));
//   }

//   @Test
//   @DisplayName("submit comment Reaction return true")
//   void submitCommentReactionReturnTrueCase() throws InterruptedException, ExecutionException, 
//       TimeoutException{

//     when(reactionDao.isCommentReactionExist(anyString(), anyString(), anyString())).thenReturn(false);
//     when(reactionDto.getId()).thenReturn("value");
//     when(commentReactionAvroMapper.toCommentReactionAvro(isA(ReactionDto.class), anyString(),
//         anyString(),anyString(), anyLong(), anyLong())).thenReturn(commentReactionAvro);
//     when(reactionDto.getNewReaction()).thenReturn(Reaction.LIKE);

//     when(producer.produceCommentReaction(isA(CommentReactionAvro.class)))
//         .thenReturn(sendCommentResult);
//     when(sendCommentResult.getRecordMetadata()).thenReturn(recordMetadata);
//     when(b2bProperties.getNotificationMsg()).thenReturn(notificationMsg);
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getCommentReactionEvent()).thenReturn("value");

//     when(commentDao.getComment(anyString())).thenReturn(feedComment);
//     when(feedComment.getUserId()).thenReturn("value");
//     when(feedComment.getUserName()).thenReturn("value");

//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(user.getFullName()).thenReturn("value");

//     when(userDao.getUserConnections(anyString())).thenReturn(userConnections);
//     when(userConnections.getUserIds()).thenReturn(list);
//     when(list.iterator()).thenReturn(stringIterator);
//     when(stringIterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(stringIterator.next()).thenReturn("value");

//     String actual = manageReactionService.submitcommentReaction("userId", "commentId", "postId", 
//         reactionDto);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("submit comment Reaction return false")
//   void submitCommentReactionReturnFalseCase() throws InterruptedException, ExecutionException, 
//       TimeoutException{

//     when(reactionDto.getId()).thenReturn("value");
//     when(commentReactionAvroMapper.toCommentReactionAvro(isA(ReactionDto.class), anyString(),
//         anyString(),anyString(), anyLong(), anyLong())).thenReturn(commentReactionAvro);

//     when(producer.produceCommentReaction(isA(CommentReactionAvro.class)))
//         .thenReturn(sendCommentResult);
//     when(sendCommentResult.getRecordMetadata()).thenReturn(null);

//     String actual = manageReactionService.submitcommentReaction("userId", "commentId", "postId", 
//         reactionDto);

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("submit post Reaction return Opration not allowed")
//   void submitCommentReactionReturnOperationNotAllowed() throws InterruptedException, ExecutionException, 
//       TimeoutException{
//     when(reactionDao.isCommentReactionExist(anyString(), anyString(), anyString())).thenReturn(true);

//     assertThrows(OperationNotAllowedException.class, 
//         () -> manageReactionService.submitcommentReaction("userId", "commentId", "postId", reactionDto));
//   }

//   @Test
//   @DisplayName("get Reaction Count Test")
//   void getReactionCount(){

//     when(reactionDao.getReactionCount(anyString())).thenReturn(postReactionCount);
//     when(reactionMapper.toReactionCountResponse(isA(PostReactionCount.class)))
//         .thenReturn(reactionCountResponse);
    
//     ReactionCountResponse actual = manageReactionService.getReactionCount("postId");

//     assertNotNull(actual);
//     assertEquals(reactionCountResponse, actual);
//   }

//   @Test
//   @DisplayName("get Reacteduser Listing")
//   void getReacteduserListing(){
    
//     when(reactionDao.getReacteduserListing(isA(RequestReaction.class), isA(ListingRequest.class), 
//         anyString())).thenReturn(reactedUsers);
//     when(listingRequest.getPage()).thenReturn(1);

//     ListingResponse actual = manageReactionService.getReacteduserListing(requestReaction, 
//         listingRequest, "postId");

//     assertNotNull(actual);
//     assertEquals(reactedUsers, actual.getContent());
//   }
// }
