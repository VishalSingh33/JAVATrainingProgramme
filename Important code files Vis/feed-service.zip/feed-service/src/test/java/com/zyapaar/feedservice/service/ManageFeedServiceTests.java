// package com.zyapaar.feedservice.service;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.anyInt;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;

// import java.util.Iterator;
// import java.util.List;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
// import com.zyapaar.feedservice.consumer.StateStores;
// import com.zyapaar.feedservice.dao.FeedDao;
// import com.zyapaar.feedservice.dao.ReactionDao;
// import com.zyapaar.feedservice.dto.Feeds;
// import com.zyapaar.feedservice.dto.PostOrigin;
// import com.zyapaar.feedservice.dto.Type;
// import com.zyapaar.feedservice.mapper.FeedMapper;
// import com.zyapaar.feedservice.model.Feed;
// import com.zyapaar.feedservice.model.PostReaction;
// import com.zyapaar.feedservice.producer.Producer;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.serde.PostReactionCountAvro;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * manage feed service tests
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageFeedServiceTests {

//   @InjectMocks
//   ManageFeedService manageFeedService;
//   @Mock
//   FeedDao feedDao;
//   @Mock
//   ListingRequest request;
//   @Mock
//   Iterator<Feeds> iterator;
//   @Mock
//   Feeds feeds;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   List<Feeds> feedss; 
//   @Mock
//   ReactionDao reactionDao;
//   @Mock
//   PostReaction postReaction;
//   @Mock
//   PostOrigin postOrigin;
//   @Mock
//   FeedMapper feedMapper;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   Producer producer;
//   @Mock
//   Feed feed;
//   @Mock
//   PostReactionCountAvro postAvro;
//   @Mock
//   SendResult<String, PostReactionCountAvro> result;

//   @Test
//   @DisplayName("get feed test")
//   void getFeed() {
//     when(feedDao.getFeed(anyString(), isA(ListingRequest.class),isA(Type.class), isA(PostOrigin.class)))
//         .thenReturn(feedss);
//     when(feedss.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(feeds);
//     when(feeds.getCreatedOn()).thenReturn(123456L);
//     when(feeds.getId()).thenReturn("value");
//     when(reactionDao.getPostReaction(anyString(), anyString())).thenReturn(postReaction);
//     when(postReaction.getId()).thenReturn("value");
//     when(postReaction.getNewReaction()).thenReturn("value");

//     ListingResponse actual = manageFeedService.getFeed("userId", request, Type.ALL, postOrigin);

//     assertNotNull(actual);
//     assertEquals(feedss, actual.getContent());
//   }

//   @Test
//   @DisplayName("get feed not found")
//   void feeds_not_found(){

//     when(feedDao.getFeed(anyString())).thenReturn(null);

//     assertThrows(ResourceNotFoundException.class,() ->  manageFeedService.viewFeed("userId", "feedId"));

//   }

//   @Test
//   @DisplayName("get feed found")
//   void feeds_found() throws InterruptedException, ExecutionException, TimeoutException{

//     when(feedDao.getFeed(anyString())).thenReturn(feed);
//     when(feed.getIsActive()).thenReturn(true);
//     when(feed.getIsHide()).thenReturn(false);
//     when(feedMapper.feedToFeeds(isA(Feed.class))).thenReturn(feeds);
//     when(feeds.getCreatedOn()).thenReturn(11L);
//     when(reactionDao.getPostReaction(anyString(), anyString())).thenReturn(postReaction);
//     when(postReaction.getId()).thenReturn("value");
//     when(postReaction.getNewReaction()).thenReturn("value");
//     when(stateStores.getPostReactionCount(anyString())).thenReturn(postAvro);
//     when(postAvro.getViewCount()).thenReturn(23L);
//     doNothing().when(producer).producePostReactionCount(isA(PostReactionCountAvro.class));

//     Feeds actual = manageFeedService.viewFeed("userId", "feedId");
//     assertNotNull(actual);

//   }

//   @Test
//   @DisplayName("get feed test")
//   void getOriginWiseFeeds() {

//     when(request.getPage()).thenReturn(1);
//     when(feedDao.getOriginWiseFeeds(anyInt(), anyString(), isA(PostOrigin.class))).thenReturn(feedss);

//     when(feedss.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(feeds);
//     when(feeds.getCreatedOn()).thenReturn(123456L);
//     when(feeds.getId()).thenReturn("value");
//     when(reactionDao.getPostReaction(anyString(), anyString())).thenReturn(postReaction);
//     when(postReaction.getId()).thenReturn("value");
//     when(postReaction.getNewReaction()).thenReturn("value");

//     ListingResponse actual = manageFeedService.getOriginWiseFeeds("UserId", request, "originId", postOrigin);

//     assertNotNull(actual);
//     assertEquals(feedss, actual.getContent());
//   }

// }
