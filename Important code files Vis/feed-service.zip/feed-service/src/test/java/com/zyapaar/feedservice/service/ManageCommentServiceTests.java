// package com.zyapaar.feedservice.service;

// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.anyBoolean;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.Iterator;
// import java.util.List;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;

// import org.apache.kafka.clients.producer.RecordMetadata;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.data.domain.Pageable;
// import org.springframework.data.domain.Slice;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;

// import com.zyapaar.commons.dto.Attribute;
// import com.zyapaar.commons.dto.NotificationContent;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.exceptionhandler.custom.BadRequestException;
// import com.zyapaar.feedservice.consumer.StateStores;
// import com.zyapaar.feedservice.dao.CommentDao;
// import com.zyapaar.feedservice.dao.ReactionDao;
// import com.zyapaar.feedservice.dao.UserDao;
// import com.zyapaar.feedservice.dto.CommentDto;
// import com.zyapaar.feedservice.dto.CommentUpdateDto;
// import com.zyapaar.feedservice.dto.Content;
// import com.zyapaar.feedservice.dto.Notification;
// import com.zyapaar.feedservice.mapper.CommentAvroMapper;
// import com.zyapaar.feedservice.mapper.NotificationMapper;
// import com.zyapaar.feedservice.model.CommentReaction;
// import com.zyapaar.feedservice.model.FeedComment;
// import com.zyapaar.feedservice.model.User;
// import com.zyapaar.feedservice.model.UserConnections;
// import com.zyapaar.feedservice.producer.Producer;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.properties.B2bProperties.NotificationMsg;
// import com.zyapaar.feedservice.util.NotificationUtils;
// import com.zyapaar.serde.CommentAvro;

// /**
//  * manage comment service test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageCommentServiceTests {

//   @InjectMocks
//   ManageCommentService manageCommentService;
//   @Mock
//   Producer producer;
//   @Mock
//   CommentAvroMapper commentAvroMapper;
//   @Mock
//   CommentDto commentDto;
//   @Mock
//   CommentAvro commentAvro;
//   @Mock
//   SendResult<String, CommentAvro> sendCommentResult;
//   @Mock
//   RecordMetadata recordMetadata;
//   @Mock
//   Slice<FeedComment> slice;
//   @Mock
//   CommentDao commentDao;
//   @Mock
//   ListingRequest request;
//   @Mock
//   ListingResponse listingResponse;
//   @Mock
//   List<FeedComment> feedComments;
//   @Mock
//   Iterator<FeedComment> iterator;
//   @Mock
//   FeedComment feedComment;
//   @Mock
//   Pageable pageable;
//   @Mock
//   StateStores stateStores;
//   @Mock
//   List<String> list;
//   @Mock
//   NotificationMsg notificationMsg;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   NotificationMapper notificationMapper;
//   @Mock
//   Notification notification;
//   @Mock
//   UserDao userDao;
//   @Mock
//   Iterator<String> stringIterator;
//   @Mock
//   NotificationUtils notificationUtils;
//   @Mock
//   NotificationContent notificationContent;
//   @Mock
//   ReactionDao reactionDao;
//   @Mock
//   CommentReaction commentReaction;
//   @Mock
//   UserConnections userConnections;
//   @Mock
//   User user;
//   @Mock
//   List<Attribute> attributes;
//   @Mock
//   Content content;
//   @Mock
//   CommentUpdateDto commentUpdateDto;

//   @Test
//   @DisplayName("create comment test return true")
//   void createComment() throws InterruptedException, ExecutionException, TimeoutException{

//     when(commentAvroMapper.toCommentAvro(isA(CommentDto.class), anyString(), anyString(), 
//         anyLong(), anyLong())).thenReturn(commentAvro);
//     when(producer.produceComment(isA(CommentAvro.class))).thenReturn(sendCommentResult);
//     when(sendCommentResult.getRecordMetadata()).thenReturn(recordMetadata);

//     when(b2bProperties.getNotificationMsg()).thenReturn(notificationMsg);

//     when(commentDto.getPostUserId()).thenReturn("value");
//     when(commentDto.getReplyOf()).thenReturn("value");
    
//     when(commentDto.getContent()).thenReturn(content);
//     when(content.getAttributes()).thenReturn(attributes);
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(attributes.isEmpty()).thenReturn(true);

//     when(userDao.getUserConnections(anyString())).thenReturn(userConnections);
//     when(userConnections.getUserIds()).thenReturn(list);
//     when(userDao.getUser(anyString())).thenReturn(user);
//     when(user.getEmailId()).thenReturn(null);

//     when(list.iterator()).thenReturn(stringIterator);
//     when(stringIterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(stringIterator.next()).thenReturn("value");
//     when(commentDto.getId()).thenReturn("value");

//     when(commentDao.getComment(anyString())).thenReturn(feedComment);
//     when(feedComment.getUserId()).thenReturn("value");

//     String actual = manageCommentService.createComment("userId", "postId", commentDto);
//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("create comment test return false")
//   void createComment_return_false() throws InterruptedException, ExecutionException, TimeoutException{

//     when(commentAvroMapper.toCommentAvro(isA(CommentDto.class), anyString(), anyString(), 
//         anyLong(), anyLong())).thenReturn(commentAvro);
//     when(producer.produceComment(isA(CommentAvro.class))).thenReturn(sendCommentResult);
//     when(sendCommentResult.getRecordMetadata()).thenReturn(null);
//     when(commentDto.getId()).thenReturn("value");

//     String actual = manageCommentService.createComment("userId", "postId", commentDto);
//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("update comment test return true")
//   void updateComment_return_true() throws InterruptedException, ExecutionException, TimeoutException{

//     when(commentUpdateDto.getId()).thenReturn("value");
//     when(commentDao.getComment(anyString())).thenReturn(feedComment);
//     when(feedComment.getUserId()).thenReturn("userId");
//     when(feedComment.getCreatedOn()).thenReturn(123L);

//     when(commentAvroMapper.toCommentAvro(isA(CommentUpdateDto.class), anyString(), anyString(), 
//         anyString()  ,anyLong(), anyLong(), anyBoolean())).thenReturn(commentAvro);
//     when(producer.produceComment(isA(CommentAvro.class))).thenReturn(sendCommentResult);
//     when(commentDto.getId()).thenReturn("value");

//     String actual = manageCommentService.updateComment("userId", commentUpdateDto);
//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("update comment test return false")
//   void updateComment_return_fasle() throws InterruptedException, ExecutionException, TimeoutException{

//     when(commentUpdateDto.getId()).thenReturn("value");
//     when(commentDao.getComment(anyString())).thenReturn(feedComment);
//     when(feedComment.getUserId()).thenReturn("userI");

//     when(commentDto.getId()).thenReturn("value");

//     assertThrows(BadRequestException.class,() ->  manageCommentService.updateComment("userId", commentUpdateDto));
//   }


//   @Test
//   @DisplayName("get comment")
//   void getComment(){
//     when(commentDao.getComments(anyString(), isA(ListingRequest.class))).thenReturn(slice);
//     when(slice.getContent()).thenReturn(feedComments);
//     when(slice.getPageable()).thenReturn(pageable);
//     when(pageable.getPageNumber()).thenReturn(1);
//     when(feedComments.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(feedComment);
//     when(feedComment.getCreatedOn()).thenReturn(1321345645464L);

//     ListingResponse actual = manageCommentService.getComment("postId", request, "userId");

//     assertNotNull(actual);
//   }

//   @Test
//   @DisplayName("get sub comment")
//   void getSubComment(){
//     when(commentDao.getSubComment(anyString(), anyString(), isA(ListingRequest.class))).thenReturn(slice);
//     when(slice.getContent()).thenReturn(feedComments);
//     when(slice.getPageable()).thenReturn(pageable);
//     when(pageable.getPageNumber()).thenReturn(1);
//     when(feedComments.iterator()).thenReturn(iterator);
//     when(iterator.hasNext()).thenReturn(true).thenReturn(false);
//     when(iterator.next()).thenReturn(feedComment);
//     when(feedComment.getCreatedOn()).thenReturn(1321345645464L);
//     when(reactionDao.getCommentReaction(anyString(), anyString(), anyString())).thenReturn(commentReaction);
//     when(commentReaction.getId()).thenReturn("value");
//     when(commentReaction.getNewReaction()).thenReturn("value");

//     ListingResponse actual = manageCommentService.getSubComment("postId","commentId", request, "userId");

//     assertNotNull(actual);
//   }
// }
