// package com.zyapaar.feedservice.dao;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import com.zyapaar.feedservice.model.HashTags;
// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.properties.B2bProperties.Paging;
// import com.zyapaar.feedservice.repository.HashTagsRepo;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.Pageable;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * Manage hash tag dao test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class ManageHashTagDaoTests {


//   @InjectMocks
//   ManageHashTagDao hashTagDao;
//   @Mock
//   HashTagsRepo tagsRepo;
//   @Mock
//   Page<HashTags>  page;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   Paging paging;

//   @Test
//   @DisplayName("getHashTags test")
//   void getHashTags(){

//     when(tagsRepo.findAll(isA(Pageable.class))).thenReturn(page);
//     when(b2bProperties.getPaging()).thenReturn(paging);
//     when(paging.getHashTagSize()).thenReturn(3);

//     Page<HashTags> actual = hashTagDao.getHashTags(3);

//     assertEquals(page, actual);
//   }

// }

