// package com.zyapaar.feedservice.dao;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.ArgumentMatchers.eq;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.when;

// import java.util.List;

// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.feedservice.dto.Feeds;
// import com.zyapaar.feedservice.dto.PostOrigin;
// import com.zyapaar.feedservice.dto.Type;
// import com.zyapaar.feedservice.model.Feed;
// import com.zyapaar.feedservice.model.UserIndustry;
// import com.zyapaar.feedservice.properties.B2bProperties;

// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.data.domain.Slice;
// import org.springframework.data.mongodb.core.MongoTemplate;
// import org.springframework.data.mongodb.core.aggregation.Aggregation;
// import org.springframework.data.mongodb.core.aggregation.AggregationResults;
// import org.springframework.test.context.ContextConfiguration;

// /**
//  * manage feed dao test
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = {B2bProperties.class})
// public class ManageFeedDaoTests {

//   @InjectMocks
//   ManageFeedDao manageFeedDao;
//   @Mock
//   Slice<Feed> slice;
//   @Mock
//   ListingRequest listingRequest;
//   @Mock
//   MongoTemplate mongoTemplate;
//   @Mock
//   AggregationResults results; 
//   @Mock
//   Aggregation aggregation;
//   @Mock
//   Feed feed;
//   @Mock
//   Feeds feeds;
//   @Mock
//   Type type;
//   @Mock
//   List<Feeds> list;
//   @Mock
//   PostOrigin origin;

//   @Test
//   @DisplayName("get all feed test")
//   void getAllFeed() {

//     when(type.type()).thenReturn("0");
//     when(mongoTemplate.aggregate(isA(Aggregation.class), eq(UserIndustry.class), eq(Feeds.class)))
//         .thenReturn(results);

//     when(results.getMappedResults()).thenReturn(list);
//     List<Feeds> actual = manageFeedDao.getFeed("userId", listingRequest, type, origin);

//     assertEquals(list, actual);
//   }

//   @Test
//   @DisplayName("get selected feed test")
//   void getSelectedFeed() {

//     when(type.type()).thenReturn("1");
//     when(mongoTemplate.aggregate(isA(Aggregation.class), eq(UserIndustry.class), eq(Feeds.class)))
//         .thenReturn(results);

//     when(results.getMappedResults()).thenReturn(list);
//     List<Feeds> actual = manageFeedDao.getFeed("userId", listingRequest, type, origin);

//     assertEquals(list, actual);
//   }

//   @Test
//   @DisplayName("getFeed")
//   void getFeed(){

//     when(mongoTemplate.findById(anyString(), eq(Feed.class))).thenReturn(feed);

//     assertEquals(feed, manageFeedDao.getFeed("feedId"));

//   }

//   @Test
//   @DisplayName("get selected feed test")
//   void getOriginWiseFeeds() {

//     when(origin.origin()).thenReturn("1");
//     when(mongoTemplate.aggregate(isA(Aggregation.class), eq(Feed.class), eq(Feeds.class)))
//         .thenReturn(results);

//     when(results.getMappedResults()).thenReturn(list);
//     List<Feeds> actual = manageFeedDao.getOriginWiseFeeds(1, "originId", origin);

//     assertEquals(list, actual);
//   }

// }
