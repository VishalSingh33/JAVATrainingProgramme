// package com.zyapaar.feedservice.producer;

// import static org.junit.jupiter.api.Assertions.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.ArgumentMatchers.isA;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeUnit;
// import java.util.concurrent.TimeoutException;

// import org.apache.kafka.clients.producer.ProducerRecord;
// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.DisplayName;
// import org.junit.jupiter.api.Test;
// import org.mockito.Mock;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.kafka.core.KafkaTemplate;
// import org.springframework.kafka.support.SendResult;
// import org.springframework.test.context.ContextConfiguration;
// import org.springframework.util.concurrent.SettableListenableFuture;

// import com.zyapaar.feedservice.properties.B2bProperties;
// import com.zyapaar.feedservice.properties.B2bProperties.Topic;
// import com.zyapaar.serde.CommentAvro;
// import com.zyapaar.serde.CommentReactionAvro;
// import com.zyapaar.serde.HashTagsAvro;
// import com.zyapaar.serde.NotificationEventAvro;
// import com.zyapaar.serde.NotificationV2Avro;
// import com.zyapaar.serde.PostAvro;
// import com.zyapaar.serde.PostReactionAvro;
// import com.zyapaar.serde.PostReactionCountAvro;

// /**
//  * Post producer test class
//  * 
//  * @author Uday Halpara
//  */
// @SpringBootTest
// @ContextConfiguration(classes = { B2bProperties.class })
// public class ManageProducerTests {

//   ManageProducer producer;
//   @Mock
//   KafkaTemplate<String, PostAvro> postKafkaTemplate;
//   @Mock
//   KafkaTemplate<String, CommentAvro> commentKafkaTemplate;
//   @Mock
//   KafkaTemplate<String, PostReactionAvro> postReactionKafkaTemplate;
//   @Mock
//   KafkaTemplate<String, CommentReactionAvro> commentReactionKafkaTemplate;
//   @Mock
//   B2bProperties b2bProperties;
//   @Mock
//   KafkaTemplate<String, NotificationAvro> notificationKafkaTemplate;
//   @Mock
//   KafkaTemplate<String, PostReactionCountAvro> postReactionCountKafkaTemplate;
//   @Mock
//   KafkaTemplate<String, HashTagsAvro> hashTagKafkaTemplate;
//   @Mock
//   KafkaTemplate<String, NotificationEventAvro> notificationEventKafkaTemplate;
//   @Mock
//   KafkaTemplate<String, NotificationV2Avro> notificationV2KafkaTemplate;

//   @Mock
//   PostAvro postAvro;

//   @Mock
//   CommentAvro commentAvro;

//   @Mock
//   PostReactionAvro postReactionAvro;

//   @Mock
//   CommentReactionAvro commentReactionAvro;

//   @Mock
//   PostReactionCountAvro postReactionCountAvro;

//   @Mock
//   Topic topic;

//   @Mock
//   SettableListenableFuture<SendResult<String, PostReactionCountAvro>> futurepostReactionCount;

//   @Mock
//   SettableListenableFuture<SendResult<String, PostAvro>> futurePost;

//   @Mock
//   SendResult<String, PostAvro> sendPostResult;

//   @Mock
//   SettableListenableFuture<SendResult<String, CommentAvro>> futureComment;

//   @Mock
//   SendResult<String, CommentAvro> sendCommentResult;

//   @Mock
//   SettableListenableFuture<SendResult<String, PostReactionAvro>> futurePostReaction;

//   @Mock
//   SendResult<String, PostReactionAvro> sendPostReactgionResult;

//   @Mock
//   SettableListenableFuture<SendResult<String, CommentReactionAvro>> futureCommentReaction;

//   @Mock
//   SendResult<String, CommentReactionAvro> sendCommentReactgionResult;

//   @Mock
//   NotificationAvro notification;

//   @Mock
//   SendResult<String, NotificationAvro> sendNotificationResult;

//   @Mock
//   SettableListenableFuture<SendResult<String, NotificationAvro>> futureNotification;

//   @Mock
//   HashTagsAvro hashTagsAvro;

//   @Mock
//   SendResult<String, HashTagsAvro> sendHashTagsAvro;

//   @Mock
//   SettableListenableFuture<SendResult<String, HashTagsAvro>> futureHashTagsAvro;

//   @BeforeEach
//   void setUp() {
//     producer = new ManageProducer(b2bProperties, notificationKafkaTemplate, postKafkaTemplate,
//         commentKafkaTemplate, postReactionKafkaTemplate, commentReactionKafkaTemplate,
//         postReactionCountKafkaTemplate, hashTagKafkaTemplate,
//         notificationEventKafkaTemplate, notificationV2KafkaTemplate);
//   }

//   @Test
//   @DisplayName("produce post sucess case")
//   void producePost_sucess_case() throws InterruptedException, ExecutionException, TimeoutException {

//     when(postAvro.getId()).thenReturn("value");
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getPost()).thenReturn("value");
//     when(postKafkaTemplate.send(isA(ProducerRecord.class))).thenReturn(futurePost);
//     when(futurePost.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendPostResult);

//     SendResult<String, PostAvro> result = producer.producePost(postAvro);

//     assertNotNull(result);
//   }

//   @Test
//   @DisplayName("produce comment sucess case")
//   void produceComment_sucess_case() throws InterruptedException,
//       ExecutionException, TimeoutException {

//     when(commentAvro.getId()).thenReturn("value");
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getComment()).thenReturn("value");
//     when(commentKafkaTemplate.send(isA(ProducerRecord.class))).thenReturn(futureComment);
//     when(futureComment.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendCommentResult);

//     SendResult<String, CommentAvro> result = producer.produceComment(commentAvro);

//     assertNotNull(result);
//   }

//   @Test
//   @DisplayName("produce post reaction sucess case")
//   void producePostReaction_sucess_case() throws InterruptedException,
//       ExecutionException, TimeoutException {

//     when(postReactionAvro.getId()).thenReturn("value");
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getPostReaction()).thenReturn("value");
//     when(postReactionKafkaTemplate.send(isA(ProducerRecord.class))).thenReturn(futurePostReaction);
//     when(futurePostReaction.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendPostReactgionResult);

//     SendResult<String, PostReactionAvro> result = producer.producePostReaction(postReactionAvro);

//     assertNotNull(result);
//   }

//   @Test
//   @DisplayName("produce comment reaction sucess case")
//   void produceCommentReaction_sucess_case() throws InterruptedException,
//       ExecutionException, TimeoutException {

//     when(postReactionAvro.getId()).thenReturn("value");
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getCommentReaction()).thenReturn("value");
//     when(commentReactionKafkaTemplate.send(isA(ProducerRecord.class))).thenReturn(futureCommentReaction);
//     when(futureCommentReaction.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendCommentReactgionResult);

//     SendResult<String, CommentReactionAvro> result = producer.produceCommentReaction(commentReactionAvro);

//     assertNotNull(result);
//   }

//   @Test
//   @DisplayName("produce notification test")
//   void produceNotification() throws InterruptedException, ExecutionException, TimeoutException {

//     when(notification.getId()).thenReturn("value");
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getNotifications()).thenReturn("value");
//     when(notificationKafkaTemplate.send(isA(ProducerRecord.class))).thenReturn(futureNotification);
//     when(futureNotification.get(anyLong(), isA(TimeUnit.class))).thenReturn(sendNotificationResult);

//     SendResult<String, NotificationAvro> actual = producer.produceNotification(notification);

//     assertEquals(sendNotificationResult, actual);
//   }

//   @Test
//   @DisplayName("producePostReactionCount test")
//   void producePostReactionCount() {

//     when(postReactionCountAvro.getPostId()).thenReturn("value");
//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getPostReactionCount()).thenReturn("value");
//     when(postReactionCountKafkaTemplate.send(isA(ProducerRecord.class)))
//         .thenReturn(futurepostReactionCount);

//     producer.producePostReactionCount(postReactionCountAvro);

//     verify(postReactionCountKafkaTemplate, times(1)).send(isA(ProducerRecord.class));

//   }

//   @Test
//   @DisplayName("produceHashTag")
//   void produceHashTag() {

//     when(b2bProperties.getTopic()).thenReturn(topic);
//     when(topic.getHashTag()).thenReturn("dasd");
//     when(hashTagKafkaTemplate.send(isA(ProducerRecord.class))).thenReturn(futureHashTagsAvro);

//     String[] hashTags = { "asd", "dsad" };

//     producer.produceHashTag(hashTags);

//     verify(hashTagKafkaTemplate, times(2)).send(isA(ProducerRecord.class));
//   }
// }
