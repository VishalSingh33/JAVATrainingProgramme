package com.zyapaar.feedservice.dto;

import java.util.List;

import lombok.Data;

/**
 * Feed listing class
 * 
 * @author Uday Halpara
 */
@Data
public class Feeds {

  private String id;
  private String userId;
  private String postOf;
  private String content;
  private String hashTag;
  private List<String> mediaUrl;
  private List<String> products;
  private String type;
  private String privacy;
  private String status;
  private Long createdOn;
  private Long updatedOn;
  private String ageOfPost;
  private Long commentCount;
  private Long reactionCount;
  private String userProfile;
  private String userName;
  private String userDesignation;
  private List<String> sendTo;
  private String aboutUser;
  private String reactionId;
  private String reaction;
  private Long viewCount;
  private Boolean isHide;
  private String origin;
  private String originId;
  private Boolean isActive;
  private String userCompany;

}
