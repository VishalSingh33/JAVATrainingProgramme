package com.zyapaar.feedservice.mapper;

import com.zyapaar.feedservice.dto.Reaction;
import com.zyapaar.feedservice.dto.ReactionDto;
import com.zyapaar.serde.CommentReactionAvro;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;

/**
 * comment reaction mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface CommentReactionAvroMapper {

  @Mapping(target = "oldReaction", source = "reactionDto.oldReaction", 
      nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "newReaction", source = "reactionDto.newReaction", 
      nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  CommentReactionAvro toCommentReactionAvro(ReactionDto reactionDto, String userId, String commentId,
      String postId, long createdOn, long updatedOn);

  default CharSequence map(Reaction value) {
    return value.reaction();
  }
}
