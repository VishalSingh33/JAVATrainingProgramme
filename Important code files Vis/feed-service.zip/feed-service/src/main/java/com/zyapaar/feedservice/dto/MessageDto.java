package com.zyapaar.feedservice.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

/**
 * Message dto
 * 
 * @author Uday Halpara
 */
@Data
public class MessageDto {

  @NotNull(message = "Please povide message")
  @Size(min = 10, message = "Minimum 10 character required")
  @Size(max = 500, message = "Maximum 500 character allowed")
  private String message;

  @NotNull(message = "Please select user")
  private String userId;

}
