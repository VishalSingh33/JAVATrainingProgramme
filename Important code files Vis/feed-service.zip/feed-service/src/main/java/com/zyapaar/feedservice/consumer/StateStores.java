package com.zyapaar.feedservice.consumer;

import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.feedservice.properties.B2bProperties;
import com.zyapaar.serde.CommentReactionAvro;
import com.zyapaar.serde.PostReactionAvro;
import com.zyapaar.serde.PostReactionCountAvro;

import org.apache.kafka.streams.errors.StateStoreMigratedException;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.springframework.cloud.stream.binder.kafka.streams.InteractiveQueryService;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * state stores class
 * 
 * @author UDaY HaLPaRa
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StateStores {

  private final InteractiveQueryService interactiveQueryService;
  private final B2bProperties b2bProperties;

  public PostReactionAvro getPostReaction(String postReactionId) {
    log.info("[getPostReaction] get post reaction data : {}", postReactionId);
    try {
      ReadOnlyKeyValueStore<String, PostReactionAvro> keyValueStore = interactiveQueryService
          .getQueryableStore(
              b2bProperties.getStore().getPostReactionStore(),
              QueryableStoreTypes.keyValueStore());

      return keyValueStore.get(postReactionId);
    } catch (StateStoreMigratedException e) {
      log.error(e.getMessage());
      return null;
    }
  }

  public CommentReactionAvro getCommentReaction(String commentReactionId) {
    log.info("[getPostReaction] get comment reaction data : {}", commentReactionId);
    try {
      ReadOnlyKeyValueStore<String, CommentReactionAvro> keyValueStore = interactiveQueryService
          .getQueryableStore(
              b2bProperties.getStore().getCommentReactionStore(),
              QueryableStoreTypes.keyValueStore());

      return keyValueStore.get(commentReactionId);
    } catch (StateStoreMigratedException e) {
      log.error(e.getMessage());
      return null;
    }
  }

  public PostReactionCountAvro getPostReactionCount(String postId) {
    log.info("[getPostReactionCount] get post reaction count data : {}", postId);
    try {
      ReadOnlyKeyValueStore<String, PostReactionCountAvro> keyValueStore = interactiveQueryService
          .getQueryableStore(
              b2bProperties.getStore().getPostReactionCountStore(),
              QueryableStoreTypes.keyValueStore());

      return keyValueStore.get(postId);
    } catch (StateStoreMigratedException e) {
      log.error(e.getMessage());
      throw new ResourceNotFoundException("Post reaction count", "", postId);
    }
  }

}
