package com.zyapaar.feedservice.service;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import com.zyapaar.commons.dto.Attribute;
import com.zyapaar.commons.dto.NotificationFor;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.feedservice.dto.BlockOrigin;
import com.zyapaar.feedservice.dto.BlockedStatus;
import com.zyapaar.feedservice.dto.CommentDto;
import com.zyapaar.feedservice.dto.CommentUpdateDto;
import com.zyapaar.feedservice.dto.FeedCommentDto;
import com.zyapaar.feedservice.dto.IFeedCommentDto;
import com.zyapaar.feedservice.dto.PostOrigin;
import com.zyapaar.feedservice.entities.Feed;
import com.zyapaar.feedservice.entities.FeedComment;
import com.zyapaar.feedservice.entities.SmsTemplate;
import com.zyapaar.feedservice.entities.User;
import com.zyapaar.feedservice.mapper.ActivityMapper;
import com.zyapaar.feedservice.mapper.CommentAvroMapper;
import com.zyapaar.feedservice.mapper.NotificationMapper;
import com.zyapaar.feedservice.mapper.SmsMapper;
import com.zyapaar.feedservice.producer.Producer;
import com.zyapaar.feedservice.properties.B2bProperties;
import com.zyapaar.feedservice.repo.FeedCommentRepository;
import com.zyapaar.feedservice.repo.FeedRepository;
import com.zyapaar.feedservice.repo.SmsTemplateRepository;
import com.zyapaar.feedservice.repo.UserRepository;
import com.zyapaar.serde.CommentAvro;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.SmsNotificationAvro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * manage comment service
 * 
 * @author Uday Halpara
 * @author Neel Shah
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageCommentService implements CommentService {

  private final CommentAvroMapper commentAvroMapper;
  private final Producer producer;
  private final B2bProperties b2bProperties;
  private final NotificationMapper notificationMapper;

  private final FeedRepository feedRepository;
  private final FeedCommentRepository feedCommentRepository;
  private final ActivityMapper activityMapper;

  private final SmsTemplateRepository smsTemplateRepository;
  private final SmsMapper smsMapper;

  private final UserRepository userRepository;

  /**
   * create comment method
   * 
   * @throws TimeoutException
   * @throws ExecutionException
   * @throws InterruptedException
   */
  @Override
  public String createComment(String userId, String postId, CommentDto commentDto)
      throws InterruptedException, ExecutionException, TimeoutException {


    // Post post = postRepository.findById(postId)
    // .orElseThrow(() -> new ResourceNotFoundException("post", "id", postId));
    log.info("[createComment] userId: {}, for postId: {}", userId, postId);

    Feed feed = findFeedById(postId);

    Boolean postOfPage = feed.getOrigin().equals(PostOrigin.PAGE.origin());
    Boolean postOfGroup = feed.getOrigin().equals(PostOrigin.GROUP.origin());


    log.info("[createComment] create comment");
    commentDto.setId(SequenceGenerator.getInstance().nextId());

    long currentTime = DateTimeUtils.currentDateTimeUTC();

    CommentAvro commentAvro =
        commentAvroMapper.toCommentAvro(commentDto, postId, userId, currentTime, currentTime);

    SendResult<String, CommentAvro> result = producer.produceComment(commentAvro);

    Boolean status = result.getRecordMetadata() != null;
    log.info("[createComment] produce notification");
    if (status) {

      String postUserId = commentDto.getPostUserId();
      Boolean isSelfComment = userId.equals(postUserId);

      //sms for comment
      if(!isSelfComment && !StringUtils.hasText(commentDto.getReplyOf()) 
          && !postOfGroup && !postOfPage){

            log.info("CASE1 STEP1");
        //postOwner ! = commentOwner
        //comment is not replyOf a post
        //post is not of group or page

        //sms to owner of post sending content
        //mobileNo of postOwner
        SmsTemplate template = smsTemplateRepository
                  .findById(b2bProperties.getSmsTemplate().getPostComment()).orElse(null);

        if(Objects.isNull(template)){
          log.info("MAJOR SmsTemplate not found with id: {}",
              b2bProperties.getSmsTemplate().getPostComment());
        }else{

          log.info("CASE1 STEP2");
          User user = findById(postUserId);
          SmsNotificationAvro notificationAvro = smsMapper.toSmsNotificationAvro(template,
                    SequenceGenerator.getInstance().nextId(),
                    template.getTemplateContent(), user.getMobileNo());
          log.info("CASE1 STEP3");
          producer.produceSmsNotification(notificationAvro);
        }
      }
      // Feed data = feedDao.getFeed(postId);

      // Request for normal post
      NotificationFor for1 = NotificationFor.REQUEST;

      if (StringUtils.hasText(feed.getPostOf())) {

        // shared post
        for1 = NotificationFor.ACCEPT;
      }

      // comment notification
      if (!isSelfComment) {

        log.info("[createComment] produce notification after success fully comment create");

        NotificationEventAvro eventAvro = null;
        if (postOfPage) {

          eventAvro = notificationMapper.buildNotificationEvent(
              postId + "_" + postUserId + "_" + NotificationTypes.PAGE_COMMENT.types(), userId,
              postUserId, NotificationTypes.PAGE_COMMENT, postId, for1);

          if (StringUtils.hasText(commentDto.getReplyOf())) {
            // commentDto.getReplyOf() != null){
            // replyOf some comment
            // so that owner of comment whoes reply this comment is won't get two notifications.
            // requestId = parentComment user's id
            FeedComment comment = findFeedCommentById(commentDto.getReplyOf());
            // FeedComment feedComment = commentDao.getComment(commentDto.getReplyOf());
            eventAvro.setRequestId(comment.getUserId());
          }

          producer.produceNotificationEvent(eventAvro,
              b2bProperties.getTopic().getPageCommentEvent());

        } else {

          eventAvro = notificationMapper.buildNotificationEvent(
              postId + "_" + postUserId + "_" + NotificationTypes.POST_COMMENT.types(), userId,
              postUserId, NotificationTypes.POST_COMMENT, postId, for1);

          producer.produceNotificationEvent(eventAvro,
              b2bProperties.getTopic().getPostCommentEvent());
        }

      }

      List<Attribute> attributes = commentDto.getContent().getAttributes();


      // Request for normal post


      log.info("[Comment List of attributes] : {}", attributes);

      // comment Tag notification
      if (!CollectionUtils.isEmpty(attributes)) {

        for (Attribute attribute : attributes) {

          log.info("[Comment attribute] : {}", attribute);
          log.info("[Comment USER-ID] : {}", userId);

          if (!(attribute.getId().equals(userId))) {

            NotificationEventAvro eventAvro = null;
            if (postOfPage) {

              eventAvro = notificationMapper.buildNotificationEvent(
                  commentDto.getId() + "_" + attribute.getId() + "_"
                      + NotificationTypes.PAGE_COMMENT_MENTION.types(),
                  userId, attribute.getId(), NotificationTypes.PAGE_COMMENT_MENTION, postId, for1);
              // always for1 = REQUEST as re-share of this post will not be part of page

              producer.produceNotificationEvent(eventAvro,
                  b2bProperties.getTopic().getPageCommentTagEvent());

            } else {

              eventAvro = notificationMapper.buildNotificationEvent(
                  commentDto.getId() + "_" + attribute.getId() + "_"
                      + NotificationTypes.COMMENT_MENTION.types(),
                  userId, attribute.getId(), NotificationTypes.COMMENT_MENTION, postId, for1);

              producer.produceNotificationEvent(eventAvro,
                  b2bProperties.getTopic().getCommentTagEvent());

            }


          }
        }
      }

      // comment reply
      if (commentDto.getReplyOf() != null) {

        String commentUserId = findFeedCommentById(commentDto.getReplyOf()).getUserId();
        // commentDao.getComment(commentDto.getReplyOf()).getUserId();

        if (!userId.equals(commentUserId)) { // I have not replied to my own comment

          if(isSelfComment && !postOfGroup && !postOfPage){
            //postOwner = userId(replyOwner)
            //postOwner !=commentOwner
            //for commwntOwner(commentUserId) user
            
            SmsTemplate template = smsTemplateRepository
            .findById(b2bProperties.getSmsTemplate().getReplyComment()).orElse(null);

            if(Objects.isNull(template)){
              log.info("MAJOR SmsTemplate not found with id: {}",
                  b2bProperties.getSmsTemplate().getReplyComment());
            }else{

              User user = findById(commentUserId);
              SmsNotificationAvro notificationAvro = smsMapper.toSmsNotificationAvro(template,
                        SequenceGenerator.getInstance().nextId(),
                        template.getTemplateContent(), user.getMobileNo());

              producer.produceSmsNotification(notificationAvro);
            }
          }

          if (commentUserId.equals(feed.getUserId()) && Objects.nonNull(feed.getPostOf())) {
            // comment owner is equal to post owner and feed is re-shared post of something
            // {0} replied to your comment on post that you shared
            NotificationEventAvro eventAvro = null;

            if (postOfPage) { // never gonna happen

              eventAvro = notificationMapper.buildNotificationEvent(
                  commentDto.getReplyOf() + "_" + userId + "_"
                      + NotificationTypes.PAGE_COMMENT_REPLY.types(),
                  userId, commentUserId, NotificationTypes.PAGE_COMMENT_REPLY, postId,
                  NotificationFor.ACCEPT);

              producer.produceNotificationEvent(eventAvro,
                  b2bProperties.getTopic().getPageCommentReplyEvent());

            } else {

              eventAvro = notificationMapper.buildNotificationEvent(
                  commentDto.getReplyOf() + "_" + userId + "_"
                      + NotificationTypes.COMMENT_REPLY.types(),
                  userId, commentUserId, NotificationTypes.COMMENT_REPLY, postId,
                  NotificationFor.ACCEPT);

              producer.produceNotificationEvent(eventAvro,
                  b2bProperties.getTopic().getCommentReplyEvent());

            }


          } else {
            NotificationEventAvro eventAvro = null;

            if (postOfPage) {

              eventAvro = notificationMapper.buildNotificationEvent(
                  commentDto.getReplyOf() + "_" + userId + "_"
                      + NotificationTypes.PAGE_COMMENT_REPLY.types(),
                  userId, commentUserId, NotificationTypes.PAGE_COMMENT_REPLY, postId,
                  NotificationFor.REQUEST);

              producer.produceNotificationEvent(eventAvro,
                  b2bProperties.getTopic().getPageCommentReplyEvent());

            } else {
              eventAvro = notificationMapper.buildNotificationEvent(
                  commentDto.getReplyOf() + "_" + userId + "_"
                      + NotificationTypes.COMMENT_REPLY.types(),
                  userId, commentUserId, NotificationTypes.COMMENT_REPLY, postId,
                  NotificationFor.REQUEST);

              producer.produceNotificationEvent(eventAvro,
                  b2bProperties.getTopic().getCommentReplyEvent());

            }
          }

        }

      }

    }

    return commentDto.getId();
  }

  @Override
  public String updateComment(String userId, CommentUpdateDto commentDto)
      throws InterruptedException, ExecutionException, TimeoutException {

    log.info("[updateComment] userId: {}, commentId: {}", userId, commentDto.getId());
    FeedComment comment = findFeedCommentById(commentDto.getId());


    // FeedComment feedComment = commentDao.getComment(commentDto.getId());

    if (comment.getUserId().equals(userId)) {

      long currentTime = DateTimeUtils.currentDateTimeUTC();

      CommentAvro commentAvro = commentAvroMapper.toCommentAvro(commentDto, comment.getPostId(),
          userId, comment.getReplyOf(), comment.getCreatedOn(), currentTime, true);

      producer.produceComment(commentAvro);

      return commentDto.getId();

    } else {
      throw new BadRequestException("This is not your comment, you can not edit this comment");
    }
  }

  @Override
  public ListingResponse getComment(String postId, ListingRequest request, String userId) {


    log.info("[getComment] get comment");
    Pageable requestedPage =
        PageRequest.of(request.getPage(), b2bProperties.getPaging().getCommentSize());

    List<IFeedCommentDto> commentList = feedCommentRepository.getCommentsByPostId(postId, userId, 
        BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);

    List<FeedCommentDto> comment = activityMapper.toFeedCommentDto(commentList);
    // findReactionIdAndType(postId, userId, commentList);

    
    // Slice<FeedComment> comments = commentDao.getComments(postId, request);
    // for (FeedComment comment : comments.getContent()) {
    //   comment.setAgeOfComment(TimeCount.timeFromUpload(comment.getCreatedOn()));
    //   CommentReaction commentReaction =
    //       reactionDao.getCommentReaction(userId, comment.getId(), postId);
    //   if (commentReaction != null) {
    //     comment.setReaction(commentReaction.getNewReaction());
    //     comment.setReactionId(commentReaction.getId());
    //   }
    // }

    return new ListingResponse(comment, request.getPage());
    // return new ListingResponse(comments.getContent(), comments.getPageable().getPageNumber());
  }

  @Override
  public ListingResponse getSubComment(String postId, String commentId, ListingRequest request,
      String userId) {

    log.info("[getSubComment] get sub comment");

    Pageable requestedPage =
        PageRequest.of(request.getPage(), b2bProperties.getPaging().getCommentSize(),
        Sort.by(Direction.DESC, "created_on"));

    List<IFeedCommentDto> subCommentList = 
      feedCommentRepository.getSubCommentByPostIdAndCommentId(postId, commentId, userId, 
          BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);

      List<FeedCommentDto> feeds = activityMapper.toFeedCommentDto(subCommentList);

      // findReactionIdAndType(postId, userId, subCommentList);

      return new ListingResponse(feeds, request.getPage());

    // Slice<FeedComment> comments = commentDao.getSubComment(postId, commentId, request);
    // for (FeedComment comment : comments.getContent()) {
    //   comment.setAgeOfComment(TimeCount.timeFromUpload(comment.getCreatedOn()));
    //   CommentReaction commentReaction =
    //       reactionDao.getCommentReaction(userId, comment.getId(), postId);
    //   if (commentReaction != null) {
    //     comment.setReaction(commentReaction.getNewReaction());
    //     comment.setReactionId(commentReaction.getId());
    //   }

    // }

    // return new ListingResponse(comments.getContent(), comments.getPageable().getPageNumber());
  }


  @Override
  public void deleteComment(String userId, String commentId)
      throws InterruptedException, ExecutionException, TimeoutException {

    log.info("[deleteComment] delete comment with id: {} by user: {}", commentId, userId);

    FeedComment feedComment = findFeedCommentById(commentId);
    // commentDao.getComment(commentId);

    if (ObjectUtils.isEmpty(feedComment) || Boolean.FALSE.equals(feedComment.getIsActive())) {

      throw new ResourceNotFoundException("Comment", "commentId", commentId);

    } else if (userId.equals(feedComment.getUserId())) {

      CommentAvro commentAvro = commentAvroMapper.feedToCommentAvro(feedComment, false);
      producer.produceComment(commentAvro);

    } else {

      throw new BadRequestException("This is not your comment so you can not delete this comment");
    }

  }

  private FeedComment findFeedCommentById(String commentId) {
    return feedCommentRepository.findById(commentId)
        .orElseThrow(() -> new ResourceNotFoundException("comment", "id", commentId));
  }

  private Feed findFeedById(String postId) {
    return feedRepository.findById(postId)
        .orElseThrow(() -> new ResourceNotFoundException("post", "id", postId));
  }

  private User findById(String userId){

  return userRepository.findById(userId)
  .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId));
  }

  // private void findReactionIdAndType(String postId, String userId, List<IFeedCommentDto> commentList) {
  //   commentList.forEach((comment)-> {
  //     CommentReaction commentReaction = 
  //       commentReactionRepository.findByUserIdAndCommentIdAndPostId(userId, comment.getId(), postId);
  //     if(!ObjectUtils.isEmpty(commentReaction)){
  //       comment.setReaction(commentReaction.getNewReaction());
  //       comment.setReactionId(commentReaction.getId());
  //       comment.setAgeOfComment(TimeCount.timeFromUpload(comment.getCreatedOn()));
  //     }
 
  //   });
  // }


}
