package com.zyapaar.feedservice.repo;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.dto.IReactedUser;
import com.zyapaar.feedservice.entities.PostReaction;

@Repository
public interface PostReactionRepository extends JpaRepository<PostReaction, String>{

  @Query(nativeQuery = true, 
    value = "SELECT EXISTS(SELECT id FROM post_reaction WHERE user_id = :userId AND post_id = :postId)")
  boolean isPostReactionExist(String userId, String postId);

  @Query(nativeQuery = true,
    value = "select post_id as postId, null as commentId, u.full_name as userName, u.id as userId, " + 
    "u.img as profileImage, u.title as designation, pr.new_reaction as reaction " + 
    "from post_reaction pr " + 
    "inner join users u on pr.user_id = u.id " + 
    "left join block_user bu on " + 
    "((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
    "or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
    "and bu.status = :status and bu.origin = :originBlock " + 
    "where bu.id is null " + 
    "and pr.new_reaction = :reaction and pr.post_id = :postId and pr.new_reaction <>'0' ")
  List<IReactedUser> getReacteduserListing(String reaction, String postId, String userId, 
      String status, String originBlock, Pageable requestedPage); //done

  @Query(nativeQuery = true,
    value = "select post_id as postId, null as commentId, u.full_name as userName, u.id as userId, " + 
    "u.img as profileImage, u.title as designation, pr.new_reaction as reaction " + 
    "from post_reaction pr " + 
    "inner join users u on pr.user_id = u.id " + 
    "left join block_user bu on " + 
    "((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
    "or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
    "and bu.status = :status and bu.origin = :originBlock " + 
    "where bu.id is null " + 
    "and pr.post_id = :postId and pr.new_reaction <>'0' ")
  List<IReactedUser> getReacteduserListingForAll(String postId, String userId, 
      String status, String originBlock, Pageable requestedPage); //done

  // @Query(nativeQuery = true,
  //   value = "select * from post_reaction pr where post_id = :postId and user_id = :userId")
  // PostReaction findByUserIdAndPostId(String userId, String postId);
  
}
