package com.zyapaar.feedservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.entities.Entities;

@Repository
public interface EntitiesRepostiory extends JpaRepository<Entities, String> {

  @Query(
    nativeQuery = true,
    value = "SELECT e.name FROM entities e "
      + " INNER JOIN entity_invite ei ON e.id = ei.entities_id WHERE ei.user_id =:userId AND status='accept' LIMIT 1")
  String getNameOfCompany(String userId);
  
}
