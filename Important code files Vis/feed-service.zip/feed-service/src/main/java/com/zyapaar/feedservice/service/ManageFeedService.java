package com.zyapaar.feedservice.service;

import java.util.ArrayList;
import java.util.List;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.commons.utils.TimeCount;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.feedservice.consumer.StateStores;
import com.zyapaar.feedservice.dto.BlockOrigin;
import com.zyapaar.feedservice.dto.BlockedStatus;
import com.zyapaar.feedservice.dto.Feeds;
import com.zyapaar.feedservice.dto.IFeeds;
import com.zyapaar.feedservice.dto.PostOrigin;
import com.zyapaar.feedservice.dto.Type;
import com.zyapaar.feedservice.entities.Feed;
import com.zyapaar.feedservice.entities.LeadsCount;
import com.zyapaar.feedservice.entities.User;
import com.zyapaar.feedservice.mapper.ActivityMapper;
import com.zyapaar.feedservice.mapper.FeedMapper;
import com.zyapaar.feedservice.producer.Producer;
import com.zyapaar.feedservice.properties.B2bProperties;
import com.zyapaar.feedservice.repo.BlockUserRepository;
import com.zyapaar.feedservice.repo.FeedRepository;
import com.zyapaar.feedservice.repo.LeadsCountRepostiory;
import com.zyapaar.feedservice.repo.UserRepository;
import com.zyapaar.serde.PostReactionCountAvro;

import org.apache.commons.lang3.BooleanUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * manage feed service
 * 
 * @author Uday Halpara
 * @author Neel Shah
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageFeedService implements FeedService {

  private final FeedMapper feedMapper;
  private final StateStores stateStores;
  private final Producer producer;
  private final FeedRepository feedRepository;
  private final B2bProperties b2bProperties;
  private final ActivityMapper activityMapper;
  private final LeadsCountRepostiory leadsCountRepostiory;
  private final BlockUserRepository blockUserRepository;
  private final UserRepository userRepository;


  @Override
  public ListingResponse getFeed(String userId, ListingRequest request, Type type,
      PostOrigin origin) {
    log.info("[getFeed] get feeds");
    List<IFeeds> feeds = new ArrayList<>();

    Pageable requestedPage = PageRequest.of(request.getPage(),
      b2bProperties.getPaging().getFeedSize());

    if(!origin.equals(PostOrigin.USER)){
      throw new BadRequestException("Wrong Enpoint is called");
    }
    if(type.equals(Type.ALL)){
      feeds = feedRepository.getFeeds(userId,BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);
    } else {
      feeds = feedRepository.getFeeds(userId, type.type(),BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);
    }
    // feedDao.getFeeds(userId, request, type, origin);

    // for (Feeds feed : feeds) {
    //   feed.setAgeOfPost(TimeCount.timeFromUpload(feed.getCreatedOn()));
    //   PostReaction postReaction =
    //       postReactionRepository.findByUserIdAndPostId(userId, feed.getId());
    //   // reactionDao.getPostReaction(userId, feed.getId());
    //   if (postReaction != null) {
    //     feed.setReaction(postReaction.getNewReaction());
    //     feed.setReactionId(postReaction.getId());
    //   }
    // }

    return new ListingResponse(activityMapper.toFeeds(feeds), request.getPage());
  }

  @Override
  public Feeds viewFeed(String userId, String feedId) {
    log.info("[viewFeed] view feed with id: {}",feedId);

    // Feed feed = feedRepository.findById(feedId)
    //     .orElseThrow(() -> new ResourceNotFoundException("feed", "id", feedId));
    // // feedDao.getFeed(feedId);
    // // if (feed != null) {
    // if (!feed.getIsActive()) {
    //   log.info("[viewFeed] Post with id {} is deleted", feedId);
    //   throw new BadRequestException("Post was deleted by user");
    // }
    // if (BooleanUtils.isTrue(feed.getIsHide())) {

    //   log.info(feedId);
    //   throw new BadRequestException("Post is under review");
    // }
    // Feeds feeds = feedMapper.feedToFeeds(feed);
    // feeds.setAgeOfPost(TimeCount.timeFromUpload(feeds.getCreatedOn()));
    // PostReaction postReaction = postReactionRepository.findByUserIdAndPostId(userId, feeds.getId());
    // // reactionDao.getPostReaction(userId, feeds.getId());
    // if (postReaction != null) {
    //   feeds.setReaction(postReaction.getNewReaction());
    //   feeds.setReactionId(postReaction.getId());
    // }

    // if(blockUserRepository.isBlockedUser(userId, userId, userId, feedId))
    IFeeds iFeed = feedRepository.viewFeed(feedId, userId);

    if(ObjectUtils.isEmpty(iFeed)){
      throw new ResourceNotFoundException("feed", "id", feedId);
    }

    if(blockUserRepository.isBlockedUser(userId, iFeed.getUserId(), 
        BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin())){

      log.info("[viewFeed] userId1: {}, userId2: {} is blocked", userId, iFeed.getUserId());
      throw new BadRequestException("User profile is blocked for you");
    }

    Feeds feed = activityMapper.toFeeds(iFeed);

    if (!feed.getIsActive()) {
      log.info("[viewFeed] Post with id {} is deleted", feedId);
      throw new BadRequestException("Post was deleted by user");
    }
    if (BooleanUtils.isTrue(feed.getIsHide())) {

      log.info(feedId);
      throw new BadRequestException("Post is under review");
    }

    PostReactionCountAvro post = stateStores.getPostReactionCount(feedId);

    post.setViewCount(post.getViewCount() + 1);

    producer.producePostReactionCount(post);

    return feed;

    // } else {
    // throw new ResourceNotFoundException("Feed", "", feedId);
    // }
  }

  @Override
  public ListingResponse getOriginWiseFeeds(String userId, ListingRequest request, String originId, 
      PostOrigin origin) {

    log.info("[getOriginWiseFeeds] userId: {}, originId: {}", userId, originId);

    Pageable requestedPage = PageRequest.of(request.getPage(),
      b2bProperties.getPaging().getFeedSize());

    List<IFeeds> feeds = feedRepository 
        .getOriginWiseFeeds(origin.origin(), originId, userId,
            BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);
    // feedDao.getOriginWiseFeeds(request.getPage(), originId, origin);

    // for (Feeds feed : feeds) {
    //   feed.setAgeOfPost(TimeCount.timeFromUpload(feed.getCreatedOn()));
    //   PostReaction postReaction = postReactionRepository.findByUserIdAndPostId(userId, feed.getId());
    //   // reactionDao.getPostReaction(userId, feed.getId());
    //   if (postReaction != null) {
    //     feed.setReaction(postReaction.getNewReaction());
    //     feed.setReactionId(postReaction.getId());
    //   }
    // }

    return new ListingResponse(activityMapper.toFeeds(feeds), request.getPage());
  }

  @Override
  public Long getMonthlyPostCount(String userId) {

    log.info("[getMonthlyPostCount] of user: {}", userId);

    return feedRepository.getMonthlyPostCount(userId);
    // return feedDao.getMonthlyPostCount(userId);
  }

  @Override
  public Feeds getFeed(String userId, String feedId) {
    log.info("[getFeed] get view feed user: {}, feedId: {}", userId, feedId);

    Feed feed = findFeedById(feedId);
    // feedDao.getFeed(feedId);
    // if (feed != null) {
    if (!feed.getIsActive()) {
      log.info("[getFeed] postId: {} is deleted", feedId);
      throw new BadRequestException("Post was deleted by user");

    }
    if (BooleanUtils.isTrue(feed.getIsHide())) {
      log.info("[getFeed] postId: {} is reported", feedId);
      throw new BadRequestException("Post is under review");
    }
    
    User user = findUserById(feed.getUserId());
    Feeds feeds = feedMapper.feedToFeeds(feed, user);
    feeds.setAgeOfPost(TimeCount.timeFromUpload(feeds.getCreatedOn()));
    return feeds;

    // } else {
    // throw new ResourceNotFoundException("Feed", "", feedId);
    // }
  }

  @Override
  public Long getLeadsCount(String userId) {

    log.info("[getLeadsCount] of user: {}", userId);

    LeadsCount leadsCount = leadsCountRepostiory.findById(userId).orElse(null);
    long currentTime = DateTimeUtils.currentDateTimeUTC();
    long count = 0;    

    if(ObjectUtils.isEmpty(leadsCount)){
      
      // first time call should return with 0.
      leadsCount = new LeadsCount(userId, currentTime, currentTime);
      // count = feedRepository.getLeadsCount(userId, Type.BUY.type(), Long.valueOf(0)); 
      
            
    }else{
      count = feedRepository
        .getLeadsCount(userId, Type.BUY.type(),
            BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), leadsCount.getUpdatedOn());
      leadsCount.setUpdatedOn(currentTime);
    }

    try {
      leadsCountRepostiory.save(leadsCount);
      return count;
    } catch (Exception e) {

      log.info("[getLeadsCount] Exception while saving: {}",e);
      throw new BadRequestException("Something went wrong");
    }

  }

  private Feed findFeedById(String postId) {
    return feedRepository.findById(postId)
        .orElseThrow(() -> new ResourceNotFoundException("post", "id", postId));
  }

  private User findUserById(String userId) {
    return userRepository.findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
  }

  @Override
  public Long getLeadsCountUnchange(String userId) {

    log.info("[getLeadsCountUnchange] of user: {}", userId);
    LeadsCount leadsCount = leadsCountRepostiory.findById(userId).orElse(null);
    long count = 0;    

    if(!ObjectUtils.isEmpty(leadsCount)){ //if null then return 0 directly without creating any entry
      count = feedRepository.getLeadsCount(userId, Type.BUY.type(),
            BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), leadsCount.getUpdatedOn());
    }
    return count;
  }

}
