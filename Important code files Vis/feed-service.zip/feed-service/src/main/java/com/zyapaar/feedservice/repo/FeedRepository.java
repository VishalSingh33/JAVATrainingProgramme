package com.zyapaar.feedservice.repo;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.dto.IFeeds;
import com.zyapaar.feedservice.entities.Feed;

@Repository
public interface FeedRepository extends JpaRepository<Feed, String> {

  @Query(nativeQuery = true,  
    value = "select * FROM feed f WHERE f.post_of = :postId") //nothing like isActive, isHide wale flags
  List<Feed> getSharedFeeds(String postId);//findByPostOf

  @Query(nativeQuery = true,
    value = "select count(id) from feed f where user_id = :userId " + 
    "and is_active = true and to_timestamp(created_on/1000) >current_date - 30 ")
  Long getMonthlyPostCount(String userId);

  @Query(nativeQuery = true, 
    value = "select f.id as id, u.id as  userId, f.post_of as  postOf, f.content as content, " + 
    "f.hash_tag  as hashTag,array_to_string(f.media_url,'##') as  mediaUrl, " + 
    "null as products, f.type as type, f.privacy as  privacy, " + 
    "f.status as status, f.created_on as createdOn, " + 
    "f.updated_on as updatedOn, null as ageOfPost, " + 
    "f.comment_count as commentCount, f.reaction_count as reactionCount, " + 
    "u.img as userProfile, u.full_name as userName, u.title as userDesignation, " + 
    "array_to_string(f.send_to ,'##') as sendTo, u.about_us as aboutUser, pr.id as reactionId, " + 
    "pr.new_reaction as reaction, f.view_count as viewCount, f.is_hide as isHide, " + 
    "f.origin as origin, f.origin_id as originId, f.is_active as isActive, " + 
    "f.user_company as userCompany from feed f " + 
    "inner join users u on f.user_id = u.id " + 
    "left join post_reaction pr on pr.post_id = f.id and pr.user_id = :userId " + 
    "left join block_user bu on " + 
    "((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
    "or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
    "and bu.status = :status and bu.origin = :originBlock " + 
    "where bu.id is null " + 
    "and " + 
    "f.is_active = true and f.is_hide = false " + 
    "and f.origin = :origin and f.origin_id = :originId " + 
    "order by f.updated_on desc ")
  List<IFeeds> getOriginWiseFeeds(String origin, String originId, String userId, String status, 
    String originBlock, Pageable requestPage); //done

  @Query(nativeQuery = true,
    value = "select f.id id, u.id  userId, f.post_of  postOf, f.content as content, " + 
    "f.hash_tag  hashTag, array_to_string(f.media_url,'##')  mediaUrl, " + 
    "null as products, f.type as type, f.privacy  privacy, " + 
    "f.status as status, f.created_on as createdOn, " + 
    "f.updated_on as updatedOn, null as ageOfPost, " + 
    "f.comment_count  commentCount, f.reaction_count  reactionCount, " + 
    "u.img userProfile, u.full_name  userName, u.title  userDesignation, " + 
    "array_to_string(f.send_to ,'##')  sendTo, u.about_us  aboutUser, pr.id as reactionId, " + 
    "pr.new_reaction as reaction, f.view_count  viewCount, f.is_hide  isHide, " + 
    "f.origin  origin, f.origin_id  originId, f.is_active as isActive, " + 
    "f.user_company as userCompany from feed f " + 
    "inner join users u on u.id = f.user_id " + 
    "left join post_reaction pr on pr.post_id = f.id and pr.user_id = :userId " + 
    "left join block_user bu on " + 
    "((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
    "or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
    "and bu.status = :status and bu.origin = :origin " + 
    "where bu.id is null " + 
    "and ((f.user_id = any(array_cat( " + 
    "(select uwc.user_ids from user_wise_connection uwc where uwc.id = :userId), " + 
    "(select array_agg(ui.user_id) from user_industry ui where ui.keyword_buys_sells_id && " + 
    "any (select ui.keyword_buys_sells_id from user_industry ui where ui.user_id = :userId)) " + 
    ")) and f.origin = '1') or " + 
    "(f.origin_id = any( select pm.page_id from page_member pm where pm.user_id = :userId " + 
    "and pm.status = 'accept' and page_status <> 'inactive') and f.origin = '2') " + 
    "or (f.user_id = :userId and f.origin = '1' )) " + 
    "and f.is_active = true and f.is_hide = false " + 
    "order by f.updated_on desc ")
  List<IFeeds> getFeeds(String userId, String status, String origin, Pageable requestedPage); //done

  @Query(nativeQuery = true,
    value = "select f.id id, u.id  userId, f.post_of  postOf, f.content as content, " + 
    "f.hash_tag  hashTag, array_to_string(f.media_url,'##') mediaUrl, " + 
    "null as products, f.type as type, f.privacy  privacy, " + 
    "f.status as status, f.created_on as createdOn, " + 
    "f.updated_on as updatedOn, null as ageOfPost, " + 
    "f.comment_count  commentCount, f.reaction_count  reactionCount, " + 
    "u.img userProfile, u.full_name  userName, u.title  userDesignation, " + 
    "array_to_string(f.send_to ,'##') sendTo, u.about_us  aboutUser, pr.id as reactionId, " + 
    "pr.new_reaction  as reaction, f.view_count  viewCount, f.is_hide  isHide, " + 
    "f.origin  origin, f.origin_id  originId, f.is_active as isActive, " + 
    "f.user_company as userCompany " + 
    "from feed f " + 
    "inner join users u on u.id = f.user_id " + 
    "left join post_reaction pr on pr.post_id = f.id and pr.user_id = :userId " + 
    "left join block_user bu on " + 
    "((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
    "or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
    "and bu.status = :status and bu.origin = :origin " + 
    "where bu.id is null " + 
    "and ((f.user_id = any(array_cat( " + 
    "(select uwc.user_ids from user_wise_connection uwc where uwc.id = :userId), " + 
    "(select array_agg(ui.user_id) from user_industry ui where " + 
    "ui.keyword_buys_sells_id && " + 
    "any (select ui.keyword_buys_sells_id  from user_industry ui where ui.user_id = :userId)))) " + 
    "and f.origin = '1') or (f.user_id = :userId and f.origin = '1' )) " + 
    "and f.is_active = true and f.is_hide = false " + 
    "and f.type = :type order by f.updated_on desc ")
  List<IFeeds> getFeeds(String userId, String type,String status, String origin, Pageable requestedPage); //done

  @Query(nativeQuery = true, 
    value = "select f.id as id, u.id as  userId, f.post_of as  postOf, f.content as content, " + 
    "f.hash_tag  as hashTag,array_to_string(f.media_url,'##') as  mediaUrl, " + 
    "null as products, f.type as type, f.privacy as  privacy, " + 
    "f.status as status, f.created_on as createdOn, " + 
    "f.updated_on as updatedOn, null as ageOfPost, " + 
    "f.comment_count as commentCount, f.reaction_count as reactionCount, " + 
    "u.img as userProfile, u.full_name as userName, u.title as userDesignation, " + 
    "array_to_string(f.send_to ,'##') as sendTo, u.about_us as aboutUser, pr.id as reactionId, " + 
    "pr.new_reaction as reaction, f.view_count as viewCount, f.is_hide as isHide, " + 
    "f.origin as origin, f.origin_id as originId, f.is_active as isActive, " + 
    "f.user_company as userCompany " + 
    "from feed f " + 
    "inner join users u on f.user_id = u.id " + 
    "left join post_reaction pr on f.id = pr.post_id and pr.user_id = :userId " + 
    "where f.id = :feedId ")
  IFeeds viewFeed(String feedId, String userId);  //handled in service. 

  @Query(nativeQuery = true, 
    value = "select " + 
"count(f.id) " + 
"from " + 
"feed f " + 
"left join block_user bu on " + 
"((bu.from_user_id = f.user_id and bu.to_user_id = :userId) " + 
"or (bu.to_user_id = f.user_id and bu.from_user_id = :userId)) " + 
"and bu.status = :status and bu.origin = :origin " + 
"where bu.id is null " + 
"and " + 
"((f.user_id = any(array_cat( " + 
"(select uwc.user_ids from user_wise_connection uwc where uwc.id = :userId), " + 
"(select array_agg(ui.user_id) from user_industry ui where " + 
"ui.keyword_buys_sells_id && " + 
"any (select ui.keyword_buys_sells_id from user_industry ui where ui.user_id = :userId)))) " + 
"and f.origin = '1') " + 
"or (f.user_id = :userId " + 
"and f.origin = '1' )) " + 
"and f.is_active = true " + 
"and f.is_hide = false " + 
"and f.type = :type " + 
"and to_timestamp(f.created_on/1000) > to_timestamp(:createdOn/1000) ")
  Long getLeadsCount(String userId, String type, String status, String origin, Long createdOn); //done
}
