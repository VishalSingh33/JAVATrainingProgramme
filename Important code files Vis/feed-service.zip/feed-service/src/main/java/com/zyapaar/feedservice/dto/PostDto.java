package com.zyapaar.feedservice.dto;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Post dto model
 * 
 * @author Uday Halpara
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostDto {

  private String id;

  private String postOf;

  private Content content;

  private String hashTag;

  @NotNull(message = "Please Select Post Type")
  private Type type;

  @NotNull(message = "Please Select Post Privacy")
  private Privacy privacy;

  private PostOrigin origin;

  private String originId;

}
