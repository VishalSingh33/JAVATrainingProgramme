package com.zyapaar.feedservice.producer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import com.zyapaar.feedservice.properties.B2bProperties;
import com.zyapaar.serde.CommentAvro;
import com.zyapaar.serde.CommentReactionAvro;
import com.zyapaar.serde.HashTagsAvro;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.NotificationV2Avro;
import com.zyapaar.serde.PostAvro;
import com.zyapaar.serde.PostReactionAvro;
import com.zyapaar.serde.PostReactionCountAvro;
import com.zyapaar.serde.SmsNotificationAvro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * post producer class
 * 
 * @author Uday Halpara
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageProducer implements Producer {
  
  private final B2bProperties b2bProperties;
  private final KafkaTemplate<String, NotificationV2Avro> notificationKafkaTemplate;
  private final KafkaTemplate<String, PostAvro> postKafkaTemplate;
  private final KafkaTemplate<String, CommentAvro> commentKafkaTemplate;
  private final KafkaTemplate<String, PostReactionAvro> postReactionKafkaTemplate;
  private final KafkaTemplate<String, CommentReactionAvro> commentReactionKafkaTemplate;
  private final KafkaTemplate<String, PostReactionCountAvro> postReactionCountKafkaTemplate;
  private final KafkaTemplate<String, HashTagsAvro> hashTagKafkaTemplate;
  private final KafkaTemplate<String, NotificationEventAvro> notificationEventKafkaTemplate;
  private final KafkaTemplate<String, NotificationV2Avro> notificationV2KafkaTemplate;
  private final KafkaTemplate<String, SmsNotificationAvro> smsNotificationTemplate;
  
  /**
   * produce post method
   */
  @Override
  public SendResult<String, PostAvro> producePost(PostAvro postAvro) 
      throws InterruptedException, ExecutionException, TimeoutException {
    log.info("[producePost] produce post");
    String key = String.valueOf(postAvro.getId());
    
    ProducerRecord<String,PostAvro> producerRecord = 
        new ProducerRecord<>(
          b2bProperties.getTopic().getPost(), null, key, postAvro, null
        );

    return postKafkaTemplate.send(producerRecord).get(1, TimeUnit.SECONDS);
  }

  /**
   * produce comment method
   */
  @Override
  public SendResult<String, CommentAvro> produceComment(CommentAvro commentAvro) 
      throws InterruptedException, ExecutionException, TimeoutException {
    log.info("[produceComment] produce comment");
    String key = String.valueOf(commentAvro.getId());
    
    ProducerRecord<String,CommentAvro> producerRecord = 
        new ProducerRecord<>(
          b2bProperties.getTopic().getComment(), null, key, commentAvro, null
        );

    return commentKafkaTemplate.send(producerRecord).get(1, TimeUnit.SECONDS);
  }

  /**
   * produce post-reaction method
   */
  @Override
  public SendResult<String, PostReactionAvro> producePostReaction(PostReactionAvro postReactionAvro)
      throws InterruptedException, ExecutionException, TimeoutException {
    log.info("[producePostReaction] produce post reaction");
    String key = String.valueOf(postReactionAvro.getId());

    ProducerRecord<String,PostReactionAvro> producerRecord = 
        new ProducerRecord<>(
          b2bProperties.getTopic().getPostReaction(), null, key, postReactionAvro, null
        );

    return postReactionKafkaTemplate.send(producerRecord).get(1, TimeUnit.SECONDS);
  }

  /**
   * produce comment-reaction method
   */
  @Override
  public SendResult<String, CommentReactionAvro> produceCommentReaction(
      CommentReactionAvro commentReactionAvro)
      throws InterruptedException, ExecutionException, TimeoutException {
    log.info("[produceCommentReaction] produce comment reaction");
    String key = String.valueOf(commentReactionAvro.getId());

    ProducerRecord<String,CommentReactionAvro> producerRecord = 
        new ProducerRecord<>(
          b2bProperties.getTopic().getCommentReaction(), null, key, commentReactionAvro, null
        );

    return commentReactionKafkaTemplate.send(producerRecord).get(1, TimeUnit.SECONDS);
  }

  @Override
  public SendResult<String, NotificationV2Avro> produceNotification(NotificationV2Avro notificationAvro)
      throws InterruptedException, ExecutionException, TimeoutException {
    log.info("[produceNotification] produce notification");
    String key = String.valueOf(notificationAvro.getId());
    ProducerRecord<String, NotificationV2Avro> producerRecord = new ProducerRecord<>(
        b2bProperties.getTopic().getNotifications(), null, key, notificationAvro);

    return notificationKafkaTemplate.send(producerRecord).get(1, TimeUnit.SECONDS);
  }

  @Override
  public void producePostReactionCount(PostReactionCountAvro post) {

    log.info("[PostReactionCountAvro] produce PostReactionCountAvro");
    String key = String.valueOf(post.getPostId());
    ProducerRecord<String, PostReactionCountAvro> producerRecord = new ProducerRecord<>(
        b2bProperties.getTopic().getPostReactionCount(), null, key, post);

    postReactionCountKafkaTemplate.send(producerRecord);

  }

  @Override
  public void produceHashTag(String[] hashTags) {

    List<String> has = new ArrayList<>(Arrays.asList(hashTags));
    has.removeIf(s -> s.equals(""));
    log.info("[produceHashTag] produce hash tag");
    for (String hashTag : has) {
      ProducerRecord<String, HashTagsAvro> producerRecord = new ProducerRecord<String, HashTagsAvro>(
          b2bProperties.getTopic().getHashTag(), hashTag, new HashTagsAvro(hashTag));

      hashTagKafkaTemplate.send(producerRecord);
    }
  }

  @Override
  public void produceNotificationEvent(NotificationEventAvro eventAvro, String topic) {

    log.info("[produceNotificationEvent] produce Notification event");

    String key = String.valueOf(eventAvro.getId());

    ProducerRecord<String, NotificationEventAvro> producerRecord = new ProducerRecord<>(
        topic, key, eventAvro);

    notificationEventKafkaTemplate.send(producerRecord);

  }

  @Override
  public void produceNotificationV2(NotificationV2Avro notificationAvro) {
    log.info("[produceNotificationV2] produce Notification version .2");

    String key = String.valueOf(notificationAvro.getId());

    ProducerRecord<String, NotificationV2Avro> producerRecord = new ProducerRecord<>(
        b2bProperties.getTopic().getNotificationsV2(),
        key,
        notificationAvro);

    notificationV2KafkaTemplate.send(producerRecord);

  }

  @Override
  public void produceSmsNotification(SmsNotificationAvro smsNotificationAvro) {

    if(Boolean.valueOf(b2bProperties.getProduce().getSmsProduce())){

      log.info("CASE1 STEP4");

      String key = String.valueOf(smsNotificationAvro.getId());

      ProducerRecord<String, SmsNotificationAvro> producerRecord = new ProducerRecord<String, SmsNotificationAvro>(
          b2bProperties.getTopic().getSmsNotification(), key, smsNotificationAvro);

      smsNotificationTemplate.send(producerRecord);
    } else{

      log.info("CASE1 STEP4/");
      log.info("[smsNotificationAvro] history sms created using SmsNotificationAvro: {}", smsNotificationAvro);
    }

  }
}
