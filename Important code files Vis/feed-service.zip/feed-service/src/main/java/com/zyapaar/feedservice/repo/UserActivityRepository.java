package com.zyapaar.feedservice.repo;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
// import com.zyapaar.feedservice.dto.ActivityList;
import com.zyapaar.feedservice.dto.IActivityList;
import com.zyapaar.feedservice.entities.UserActivity;

@Repository
public interface UserActivityRepository extends JpaRepository<UserActivity, String>{

  @Query(nativeQuery = true, 
    value = "select ua.id as id, f.id as feedId, u.id as userId, f.post_of as postOf, " + 
"f.content as content, f.hash_tag as hashTag, " + 
"array_to_string(f.media_url,'##') as mediaUrl, " + 
"f.type as type, f.privacy as privacy, f.status as status, ua.created_on as updatedOn, " + 
"null as ageOfPost, f.comment_count as commentCount, f.reaction_count as reactionCount, " + 
"u.img as userProfile ,u.full_name as userName, u.title as userDesignation, " + 
"u.about_us as aboutUser, " + 
"pr.id as reactionId, " + 
"pr.new_reaction as reaction, " + 
"f.view_count as viewCount, ua.reaction as userReaction, " + 
"ua.type as activityType from user_activity ua " + 
"inner join feed f on ua.feed_id = f.id " + 
"inner join users u  on f.user_id = u.id " + 
"left join post_reaction pr on pr.post_id = f.id and pr.user_id = :userId " + 
"left join block_user bu on " + 
"((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
"or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
"and bu.status = :status and bu.origin = :originBlock " + 
"where bu.id is null " + 
"and ua.user_id = :userId " + 
"and ua.is_active = true " + 
"and f.is_active = true " + 
"and f.is_hide = false and f.origin <>'3' " + 
"order by ua.created_on desc ")
  List<IActivityList> getUserActivity(String userId, String status, String originBlock, Pageable requestPage);//done

  
  // List<ActivityList> getUserActivity(String userId);
}
/*
 * "select ua.id id, f.id feedId, u.id userId, f.post_of postOf, " + 
    "f.content as content, f.hash_tag hashTag, "+
    "f.media_url mediaUrl, " + 
    "f.type type, f.privacy privacy, f.status status, ua.created_on updatedOn, " + 
    "null as ageOfPost, f.comment_count commentCount, f.reaction_count reactionCount, " + 
    "u.img userProfile ,u.full_name userName, u.title userDesignation, " + 
    "u.about_us aboutUser, " + 
    "pr.id as reactionId, " + 
    "pr.new_reaction  as reaction, " + 
    "f.view_count viewCount, ua.reaction userReaction, " + 
    "ua.type activityType from user_activity ua " + 
    "inner join feed f on ua.feed_id = f.id " + 
    "inner join users u  on f.user_id = u.id " + 
    "left join post_reaction pr on pr.post_id = f.id and pr.user_id = :userId " + 
    "where ua.user_id = :userId " + 
    "and ua.is_active = true " + 
    "and f.is_active = true " + 
    "and f.is_hide = false and f.origin <>'3' " + 
    "order by ua.created_on desc "
 */