package com.zyapaar.feedservice.service;

import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

public interface FeedEmitterService {

  SseEmitter createEmitter(String userId);

}
