package com.zyapaar.feedservice.service;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.feedservice.dto.Feeds;
import com.zyapaar.feedservice.dto.PostOrigin;
import com.zyapaar.feedservice.dto.Type;

/**
 * feed service interface
 * 
 * @author Uday Halpara
 */
public interface FeedService {

  ListingResponse getFeed(String userId, ListingRequest request, Type type, PostOrigin origin);

  Feeds viewFeed(String userId, String feedId);

  ListingResponse getOriginWiseFeeds(String userId, ListingRequest request, String originId, PostOrigin origin);

  Long getMonthlyPostCount(String userId);

  Feeds getFeed(String userId, String feedId);

  Long getLeadsCount(String userId);

  Long getLeadsCountUnchange(String userId);
}
