package com.zyapaar.feedservice.dto;

import java.util.List;

import lombok.Data;

@Data
public class UserRegistrationAvroDto {

  private String id;

  private String firstName;

  private String lastName;

  private String fullName;

  private String mobileNo;

  private String emailId;

  private String aboutUs;

  private String profileTitle;

  private boolean enable;

  private String profileImg;

  private String role;

  private List<String> companies;

  private boolean accountNonExpired;

  private boolean accountNonLocked;

  private boolean credentialsNonExpired;

}
