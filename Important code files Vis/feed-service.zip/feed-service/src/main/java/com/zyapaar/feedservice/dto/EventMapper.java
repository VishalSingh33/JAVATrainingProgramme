package com.zyapaar.feedservice.dto;

import com.zyapaar.feedservice.model.Feed;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import lombok.AllArgsConstructor;

@Component
@AllArgsConstructor
public class EventMapper {
  public SseEmitter.SseEventBuilder toSseEventBuilder(EventDto event) {
    return SseEmitter.event()
      .id(RandomStringUtils.randomAlphabetic(12))
      .name(event.getType())
      .data(event.getBody());
  }

  public SseEmitter.SseEventBuilder toFeedSseEventBuilder(Feed feed) {
    return SseEmitter.event()
      .id(RandomStringUtils.randomAlphabetic(12))
      .name("Feed")
      .data(feed);
  }

  public SseEmitter.SseEventBuilder toNotificationSseEventBuilder(Notification notification) {
    return SseEmitter.event()
      .id(RandomStringUtils.randomAlphabetic(12))
      .name("Notification")
      .data(notification);
  }
}
