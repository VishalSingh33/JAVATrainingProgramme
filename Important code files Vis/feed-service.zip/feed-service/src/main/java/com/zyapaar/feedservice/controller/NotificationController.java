package com.zyapaar.feedservice.controller;

import com.zyapaar.feedservice.service.NotificationService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Notification emit controller
 * 
 * @author Uday Halpara
 */
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "Notification emit APIs")
@Slf4j
public class NotificationController {

  private final NotificationService notificationService;

  @Operation(description = "This Feed Emitter Service work to send feed to user")
  @GetMapping("/emits/notifications")
  public SseEmitter subscribeToNotifications(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
          @RequestHeader("Z-AUTH-USERID") String userId) {
    log.info("[subscribeToNotifications] emit notification");
    return notificationService.createEmitter(userId);
  }

}
