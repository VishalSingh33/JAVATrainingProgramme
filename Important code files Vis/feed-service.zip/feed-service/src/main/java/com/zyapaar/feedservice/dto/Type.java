package com.zyapaar.feedservice.dto;

/**
 * types enum
 * 
 * @author Uday Halpara
 */
public enum Type {
  BUY("1"),
  SELL("2"),
  GENERAL("3"),
  ALL("0");

  private final String type;

  Type(String type){
    this.type = type;
  }

  public String type(){
    return type;
  }
}
