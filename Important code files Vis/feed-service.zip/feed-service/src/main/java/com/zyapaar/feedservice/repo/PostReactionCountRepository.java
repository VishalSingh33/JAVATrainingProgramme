package com.zyapaar.feedservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.entities.PostReactionCount;
import com.zyapaar.feedservice.response.IReactionCountResponse;

@Repository
public interface PostReactionCountRepository extends JpaRepository<PostReactionCount, String>{

  @Query(nativeQuery = true,
    value = "select prc.post_id as postId, null as commentId, prc.count as count, " + 
    "prc.like_count as likeCount, prc.celebrate_count as celebrateCount, " + 
    "prc.interest_count as interestCount, prc.shake_hand_count as shakeHandCount, " + 
    "prc.support_count as supportCount from post_reaction_count prc where prc.id = :postId")
  IReactionCountResponse  getReactionCount(String postId); //post_id = id
  
}
