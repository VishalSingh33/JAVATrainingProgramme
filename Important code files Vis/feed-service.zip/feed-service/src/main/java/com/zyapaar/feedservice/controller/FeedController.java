package com.zyapaar.feedservice.controller;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import javax.validation.Valid;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.model.ApiError;
import com.zyapaar.feedservice.dto.Feeds;
import com.zyapaar.feedservice.dto.PostOrigin;
import com.zyapaar.feedservice.dto.Type;
import com.zyapaar.feedservice.service.FeedService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * feed controller 
 * 
 * @author Uday Halpara
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@Tag(name = "Feeds APIs")
@RequestMapping("/api/v1")
public class FeedController {

  private final FeedService feedService;

  /**
   * feed listing method
   */
  @Operation(
      description = "This Feed service works to create Feed. use Feed service which "
          + "contains model class (type), type has BUY, SELL, GENERAL, ALL",
      responses = {
          @ApiResponse(content = @Content(schema = @Schema(implementation = ListingResponse.class)),
              responseCode = "200", description = "data found"),
          @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
              responseCode = "400", description = "Bad request")})
  @PostMapping("/feeds/{origin}/{type}")
  public ResponseEntity<Response> getFeed(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID",
          required = true) @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(required = true) @PathVariable("origin") PostOrigin origin,
      @Parameter(required = true) @PathVariable("type") Type type,
      @Valid @RequestBody ListingRequest request) {
    log.info("[getFeed] get feeds");

    ListingResponse data = feedService.getFeed(userId, request, type, origin);
    return ResponseEntity.ok().body(Response.builder().data(data).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @GetMapping("/feed/{feedId}")
  public ResponseEntity<Response> viewFeed(@RequestHeader("Z-AUTH-USERID") String userId,
      @PathVariable("feedId") String feedId)
      throws InterruptedException, ExecutionException, TimeoutException {
    Feeds feed = feedService.viewFeed(userId, feedId);
    return ResponseEntity.ok(Response.builder().data(feed).message("Feed found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @PostMapping("/feed/{feedId}")
  public ResponseEntity<Response> getFeed(@RequestHeader("Z-AUTH-USERID") String userId,
      @PathVariable("feedId") String feedId)
      throws InterruptedException, ExecutionException, TimeoutException {
    Feeds feed = feedService.getFeed(userId, feedId);
    return ResponseEntity.ok(Response.builder().data(feed).message("Feed found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @PatchMapping("/feed/{origin}/{originId}")
  public ResponseEntity<Response> getOriginWiseFeeds(@RequestHeader("Z-AUTH-USERID") String userId,
      @PathVariable("origin") PostOrigin origin, @PathVariable("originId") String originId,
      @Valid @RequestBody ListingRequest request) {

    ListingResponse data = feedService.getOriginWiseFeeds(userId, request, originId, origin);
    return ResponseEntity.ok().body(Response.builder().data(data).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @GetMapping("/monthly/post")
  public ResponseEntity<Response> getMonthlyPostCount(
      @RequestHeader("Z-AUTH-USERID") String userId) {

    Long data = feedService.getMonthlyPostCount(userId);

    return ResponseEntity.ok(Response.builder().data(data).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @GetMapping("/leads/count")
  public ResponseEntity<Response> getLeadsCount(@RequestHeader("Z-AUTH-USERID") String userId) {

    Long leadsCount = feedService.getLeadsCount(userId);

    return ResponseEntity.ok(Response.builder().data(leadsCount).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  @GetMapping("/leads/count/unchange")
  public ResponseEntity<Response> getLeadsCountUnchange(@RequestHeader("Z-AUTH-USERID") String userId) {

    Long leadsCount = feedService.getLeadsCountUnchange(userId);

    return ResponseEntity.ok(Response.builder().data(leadsCount).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

}
