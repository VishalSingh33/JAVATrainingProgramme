package com.zyapaar.feedservice.dto;

import org.springframework.stereotype.Component;

@Component
public interface IFeeds {

   String getId();
   String getUserId();
   String getPostOf();
   String getContent();
   String getHashTag();
   String getMediaUrl();
   String getProducts();
   String getType();
   String getPrivacy();
   String getStatus();
   Long getCreatedOn();
   Long getUpdatedOn();
   String getAgeOfPost();
   Long getCommentCount();
   Long getReactionCount();
   String getUserProfile();
   String getUserName();
   String getUserDesignation();
   String getSendTo();
   String getAboutUser();
   String getReactionId();
   String getReaction();
   Long getViewCount();
   Boolean getIsHide();
   String getOrigin();
   String getOriginId();
   Boolean getIsActive();
   String getUserCompany();
  
}
