package com.zyapaar.feedservice.repo;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.dto.IFeedCommentDto;
import com.zyapaar.feedservice.entities.FeedComment;

@Repository
public interface FeedCommentRepository extends JpaRepository<FeedComment, String>{

  @Query(nativeQuery = true,
    value = "select fc.id id, fc.post_id postId, fc.user_id userId, fc.content content , " + 
    "fc.reply_of replyOf, fc.created_on createdOn ,fc.updated_on updatedOn, " + 
    "fc.reaction_count reactionCount, fc.reply_count replyCount,fc.is_active isActive , " + 
    "u.full_name userName, u.img userProfile, u.title userDesignation, " + 
    "null as ageOfComment, " + 
    "cr.id as reactionId, cr.new_reaction as reaction " + 
    "from feed_comment fc " + 
    "inner join users u on fc.user_id = u.id " + 
    "left join comment_reaction cr " + 
    "on cr.comment_id = fc.id and cr.user_id = :userId " + 
    "left join block_user bu on " + 
    "((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
    "or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
    "and bu.status = :status and bu.origin = :originBlock " + 
    "where bu.id is null " + 
    "and fc.post_id = :postId and fc.is_active = true " + 
    "and fc.is_hide = false and fc.reply_of is null " + 
    "order by fc.created_on desc ")
  List<IFeedCommentDto> getCommentsByPostId(String postId, String userId, String status, 
    String originBlock, Pageable requestedPage); //done

  @Query(nativeQuery = true,
    value = "select fc.id id, fc.post_id postId, fc.user_id userId, fc.content content, " + 
    "fc.reply_of replyOf, fc.created_on createdOn ,fc.updated_on updatedOn, " + 
    "fc.reaction_count reactionCount, fc.reply_count replyCount,fc.is_active isActive , " + 
    "u.full_name userName, u.img userProfile, u.title userDesignation, null as ageOfComment, " + 
    "cr.id as reactionId, cr.new_reaction as reaction " + 
    "from feed_comment fc " + 
    "inner join users u on fc.user_id = u.id " + 
    "left join comment_reaction cr " + 
    "on cr.comment_id = fc.id and cr.user_id = :userId " + 
    "left join block_user bu on " + 
    "((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
    "or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
    "and bu.status = :status and bu.origin = :originBlock " + 
    "where bu.id is null " + 
    "and fc.post_id = :postId and fc.reply_of = :commentId " + 
    "and fc.is_active = true and fc.is_hide = false " + 
    "order by fc.created_on desc ")
  List<IFeedCommentDto> getSubCommentByPostIdAndCommentId(String postId, String commentId, String userId,
      String status, String originBlock, Pageable requestedPage); //done

  @Query(nativeQuery = true,
    value = "select count(id) from feed_comment fc where fc.reply_of = :id and fc.is_active = true")
  Long countByReplyOfAndIsActiveTrue(String id);
  
}
