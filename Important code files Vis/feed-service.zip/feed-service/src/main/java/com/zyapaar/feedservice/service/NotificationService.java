package com.zyapaar.feedservice.service;

import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

/**
 * Notification Service
 * 
 * @author Uday Halpara
 */
public interface NotificationService {

  SseEmitter createEmitter(String userId);

}
