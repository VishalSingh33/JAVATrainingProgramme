package com.zyapaar.feedservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import com.zyapaar.commons.dto.NotificationFor;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.custom.OperationNotAllowedException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.feedservice.consumer.StateStores;
import com.zyapaar.feedservice.dto.BlockOrigin;
import com.zyapaar.feedservice.dto.BlockedStatus;
import com.zyapaar.feedservice.dto.IReactedUser;
import com.zyapaar.feedservice.dto.PostOrigin;
import com.zyapaar.feedservice.dto.Reaction;
import com.zyapaar.feedservice.dto.ReactionDto;
import com.zyapaar.feedservice.dto.ReactionUser;
import com.zyapaar.feedservice.entities.Feed;
import com.zyapaar.feedservice.entities.FeedComment;
import com.zyapaar.feedservice.mapper.ActivityMapper;
import com.zyapaar.feedservice.mapper.CommentReactionAvroMapper;
import com.zyapaar.feedservice.mapper.NotificationMapper;
import com.zyapaar.feedservice.mapper.PostReactionAvroMapper;
import com.zyapaar.feedservice.producer.Producer;
import com.zyapaar.feedservice.properties.B2bProperties;
import com.zyapaar.feedservice.repo.CommentReactionCountRepository;
import com.zyapaar.feedservice.repo.CommentReactionRepository;
import com.zyapaar.feedservice.repo.FeedCommentRepository;
import com.zyapaar.feedservice.repo.FeedRepository;
import com.zyapaar.feedservice.repo.PostReactionCountRepository;
import com.zyapaar.feedservice.repo.PostReactionRepository;
import com.zyapaar.feedservice.request.RequestReaction;
import com.zyapaar.feedservice.response.IReactionCountResponse;
import com.zyapaar.serde.CommentReactionAvro;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.PostReactionAvro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Reaction service impl
 * 
 * @author Uday Halpara
 * @author Neel Shah
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageReactionService implements ReactionService {

  private final Producer producer;
  private final PostReactionAvroMapper postReactionAvroMapper;
  private final CommentReactionAvroMapper commentReactionAvroMapper;
  private final B2bProperties b2bProperties;
  private final NotificationMapper notificationMapper;
  private final StateStores stateStores;
  private final FeedRepository feedRepository;
  private final PostReactionRepository postReactionRepository;
  private final PostReactionCountRepository postReactionCountRepository;
  private final FeedCommentRepository feedCommentRepository;
  private final CommentReactionRepository commentReactionRepository;
  private final CommentReactionCountRepository commentReactionCountRepository;
  private final ActivityMapper activityMapper;

  @Override
  public String submitPostReaction(String userId, String postId, ReactionDto reactionDto)
      throws InterruptedException, ExecutionException, TimeoutException {

    log.info("[submitPostReaction] submit post reaction by user: {}, for post: {}",userId, postId);

    long currentTime = DateTimeUtils.currentDateTimeUTC();
    long createdTime = currentTime;

    //if (reactionDao.isPostReactionExist(userId, postId) && reactionDto.getId() == null) {
    if (postReactionRepository.isPostReactionExist(userId, postId) && !StringUtils.hasText(reactionDto.getId())) {

      throw new OperationNotAllowedException("You have already reacted please update youp reaction");

    } else {

      reactionDto.setId(postId + "_" + userId);

      PostReactionAvro reactionAvro = postReactionAvroMapper.toPostReactionAvro(reactionDto,
          userId, postId, currentTime, createdTime);

      PostReactionAvro oldReaction = stateStores.getPostReaction(reactionDto.getId());

      if (oldReaction != null) {
        reactionAvro.setOldReaction(oldReaction.getNewReaction());
      }

      SendResult<String, PostReactionAvro> result = producer.producePostReaction(reactionAvro);

      if (result.getRecordMetadata() != null) {

        log.info("[submitPostReaction] send notification for post reaction");

        String postUserId = reactionDto.getPostUserId();

        Boolean status = (!reactionDto.getNewReaction().equals(Reaction.NONE)) && (reactionDto.getOldReaction().equals(Reaction.NONE));
        Boolean isSelfReaction = userId.equals(postUserId);

        if (!isSelfReaction && status) {

          Feed data = findFeedById(postId);
          // feedDao.getFeed(postId);

          NotificationFor for1 = NotificationFor.REQUEST;
          if(StringUtils.hasText(data.getPostOf())){
            for1 = NotificationFor.ACCEPT;
          }
          NotificationEventAvro eventAvro = null;

          if(data.getOrigin().equals(PostOrigin.PAGE.origin())){

            eventAvro = notificationMapper.buildNotificationEvent(
              postId + "_" + postUserId + "_" + NotificationTypes.PAGE_REACTION.types(), userId, postUserId,
              NotificationTypes.PAGE_REACTION, postId, for1);

            producer.produceNotificationEvent(eventAvro, b2bProperties.getTopic().getPageReactionEvent());

          }else{

            eventAvro = notificationMapper.buildNotificationEvent(
              postId + "_" + postUserId + "_" + NotificationTypes.POST_REACTION.types(), userId, postUserId,
              NotificationTypes.POST_REACTION, postId, for1);

            producer.produceNotificationEvent(eventAvro, b2bProperties.getTopic().getPostReactionEvent());
          }

           

        }

      }

      return reactionDto.getId();
    }
  }

  @Override
  public String submitcommentReaction(String userId, String commentId, String postId,
      ReactionDto reactionDto) throws InterruptedException, ExecutionException, TimeoutException {

    log.info("[submitcommentReaction] submit comment reaction user: {}, comment: {}", userId, commentId);

    long currentTime = DateTimeUtils.currentDateTimeUTC();
    long createdTime = currentTime;

    if (commentReactionRepository.isCommentReactionExist(userId, commentId, postId) && !StringUtils.hasText(reactionDto.getId())) {
      throw new OperationNotAllowedException("You have already reacted please update youp reaction");
    } else {

      // Post post = postRepository.findById(postId).orElseThrow(() -> new ResourceNotFoundException("post", "id", postId));
      Feed feed = findFeedById(postId);
      Boolean postOfPage = feed.getOrigin().equals(PostOrigin.PAGE.origin());


      reactionDto.setId(commentId + "_" + userId);

      long currnetTime = DateTimeUtils.currentDateTimeUTC();

      CommentReactionAvro reactionAvro = commentReactionAvroMapper.toCommentReactionAvro(
          reactionDto, userId, commentId, postId, currnetTime, createdTime);

      CommentReactionAvro oldReaction = stateStores.getCommentReaction(reactionDto.getId());

      if (oldReaction != null) {
        reactionAvro.setOldReaction(oldReaction.getNewReaction());
      }

      SendResult<String, CommentReactionAvro> result = producer.produceCommentReaction(reactionAvro);

      if (result.getRecordMetadata() != null) {

        log.info("[submitPostReaction] send notification for comment reaction");

        FeedComment comment = findFeedCommentById(commentId);
        // commentDao.getComment(commentId);
        String commentUserId = comment.getUserId();
        Boolean status = !reactionDto.getNewReaction().equals(Reaction.NONE);

        Boolean isSelfReaction = userId.equals(commentUserId);

        if (!isSelfReaction && status) {

          NotificationEventAvro eventAvro = null;

          if(postOfPage){
            
            eventAvro =  notificationMapper.buildNotificationEvent(
              commentId + "_" + commentUserId + "_" + NotificationTypes.PAGE_COMMENT_REACTION.types(), userId, commentUserId,
              NotificationTypes.PAGE_COMMENT_REACTION, postId);

            producer.produceNotificationEvent(eventAvro, b2bProperties.getTopic().getPageCommentReactionEvent());

          }else{

            eventAvro =  notificationMapper.buildNotificationEvent(
              commentId + "_" + commentUserId + "_" + NotificationTypes.COMMENT_REACTION.types(), userId, commentUserId,
              NotificationTypes.COMMENT_REACTION, postId);

            producer.produceNotificationEvent(eventAvro, b2bProperties.getTopic().getCommentReactionEvent());
          }
          

        }
      }

      return reactionDto.getId();
    }
  }

  @Override
  public IReactionCountResponse getReactionCount(String postId) {

    log.info("[getReactionCount] get post reaction count for post: {}",postId);
    IReactionCountResponse countData = postReactionCountRepository.getReactionCount(postId);
    //reactionDao.getReactionCount(postId);

    return countData;

    // return reactionMapper.toReactionCountResponse(countData);
  }

  @Override
  public ListingResponse getReacteduserListing(RequestReaction reaction, ListingRequest request, 
      String postId, String userId) {
    log.info("[getReacteduserListing] get post reacted user list");

    Pageable requestedPage =
        PageRequest.of(request.getPage(), b2bProperties.getPaging().getFeedSize());
        // Sort.by(Direction.DESC, "count"));
        
    List<IReactedUser> data = new ArrayList<>();
    if(reaction.equals(RequestReaction.ALL)){

      data = postReactionRepository.getReacteduserListingForAll(postId, userId,
          BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);
    }else{
      data = postReactionRepository.getReacteduserListing(reaction.reaction(),postId, 
        userId, BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);
    }

    List<ReactionUser> user = activityMapper.toReactionUser(data);
    

    return new ListingResponse(user, request.getPage());
  }

  @Override
  public IReactionCountResponse getCommentReactionCount(String commentId) {
    log.info("[getCommentReactionCount] get comment reaction count");
    IReactionCountResponse countData = commentReactionCountRepository.findByCommentId(commentId);

    return countData;
  }

  @Override
  public ListingResponse getCommentReacteduserListing(String userId, RequestReaction reaction, ListingRequest request,
      String commentId) {
    log.info("[getReacteduserListing] get comment reacted user list");
    Pageable requestedPage =
        PageRequest.of(request.getPage(), b2bProperties.getPaging().getFeedSize());
        // Sort.by(Direction.DESC, "count"));

    List<IReactedUser> data = new ArrayList<>();
    if(reaction.equals(RequestReaction.ALL)){
     
      data = commentReactionRepository.getReacteduserListingForAll(commentId, userId,
          BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);
    }else{
      data = commentReactionRepository.getReacteduserListing(reaction.reaction(),commentId, userId, 
          BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);
    }

    List<ReactionUser> user = activityMapper.toReactionUser(data);
    // List<ReactedUser> data = reactionDao.getCommentReacteduserListing(reaction, listingRequest, commentId);

    return new ListingResponse(user, request.getPage());
  }

  private Feed findFeedById(String postId) {
    return feedRepository.findById(postId)
        .orElseThrow(() -> new ResourceNotFoundException("post", "id", postId));
  }

  private FeedComment findFeedCommentById(String commentId) {
    return feedCommentRepository.findById(commentId)
        .orElseThrow(() -> new ResourceNotFoundException("comment", "id", commentId));
  }
}
