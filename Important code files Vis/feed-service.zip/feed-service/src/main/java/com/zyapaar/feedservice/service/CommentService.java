package com.zyapaar.feedservice.service;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.feedservice.dto.CommentDto;
import com.zyapaar.feedservice.dto.CommentUpdateDto;

/**
 * comment service interface
 * 
 * @author Uday Halpara
 */
public interface CommentService {

  String createComment(String userId, String postId, CommentDto commentDto)
      throws InterruptedException, ExecutionException, TimeoutException;

  ListingResponse getComment(String postId, ListingRequest request, String userId);

  ListingResponse getSubComment(String postId, String commentId, ListingRequest request, String userId);

  String updateComment(String userId, CommentUpdateDto commentDto)
      throws InterruptedException, ExecutionException, TimeoutException;

  void deleteComment(String userId, String commentId)
      throws InterruptedException, ExecutionException, TimeoutException;

}
