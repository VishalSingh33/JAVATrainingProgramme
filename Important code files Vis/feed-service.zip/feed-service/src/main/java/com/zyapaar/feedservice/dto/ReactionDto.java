package com.zyapaar.feedservice.dto;

import javax.validation.constraints.NotNull;

import com.zyapaar.feedservice.validation.ReactionValidation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Reaction dto class
 * 
 * @author Uday Halpara
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ReactionValidation(oldReaction = "oldReaction", id = "id")
public class ReactionDto {

  private String id;
  @NotNull(message = "Please select valid reaction")
  private Reaction oldReaction;
  @NotNull(message = "Please select valid reaction")
  private Reaction newReaction;
  @NotNull(message = "Please select post user")
  private String postUserId;

}
