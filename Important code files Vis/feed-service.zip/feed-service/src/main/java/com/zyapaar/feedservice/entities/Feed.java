package com.zyapaar.feedservice.entities;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import com.vladmihalcea.hibernate.type.array.ListArrayType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "feed")
@TypeDef(name = "list-array",typeClass = ListArrayType.class)
public class Feed {

	@Id
	private String id;

	@Column(name="about_user")
	private String aboutUser;

	@Column(name="comment_count")
	private Long commentCount;

	private String content;

	@Column(name="created_on")
	private Long createdOn;

	@Column(name="hash_tag")
	private String hashTag;

  @Column(name = "industries",columnDefinition = "text[]")
  @Type(type = "list-array")
	private List<String> industries;

	@Column(name="is_active")
	private Boolean isActive;

	@Column(name="is_hide")
	private Boolean isHide;

	@Column(name="media_url",columnDefinition = "text[]")
  @Type(type = "list-array")
	private List<String> mediaUrl;

	private String origin;

	@Column(name="origin_id")	
	private String originId;

	@Column(name="post_of")
	private String postOf;

	private String privacy;

	@Column(name="reaction_count")
	private Long reactionCount;

	@Column(name="send_to",columnDefinition = "text[]")
  @Type(type = "list-array")
	private List<String> sendTo;

	private String status;

	private String type;

	@Column(name="updated_on")
	private Long updatedOn;

	@Column(name="user_company")
	private String userCompany;

	@Column(name="user_designation")
	private String userDesignation;

	@Column(name="user_id")
	private String userId;

	@Column(name="user_name")
	private String userName;

	@Column(name="user_profile")
	private String userProfile;

	@Column(name="view_count")
	private Long viewCount;

}