package com.zyapaar.feedservice.controller;

import com.zyapaar.feedservice.service.FeedEmitterService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1")
@Tag(name = "FeedEmitter APIs")
@Slf4j
public class FeedEmitterController {

  private final FeedEmitterService feedEmitterService;
  @Operation(description = "This Feed Emitter Service work to send feed to user")
  @GetMapping("/emits/feeds")
  public SseEmitter subscribeToFeeds(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
          @RequestHeader("Z-AUTH-USERID") String userId) {
    log.info("[subscribeToFeeds] emit feeds");
    return feedEmitterService.createEmitter(userId);
  }

}
