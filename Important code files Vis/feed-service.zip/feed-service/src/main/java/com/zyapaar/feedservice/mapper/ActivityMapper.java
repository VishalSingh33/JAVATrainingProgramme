package com.zyapaar.feedservice.mapper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import com.zyapaar.commons.utils.TimeCount;
import com.zyapaar.feedservice.dto.ActivityList;
import com.zyapaar.feedservice.dto.FeedCommentDto;
import com.zyapaar.feedservice.dto.Feeds;
import com.zyapaar.feedservice.dto.IActivityList;
import com.zyapaar.feedservice.dto.IFeedCommentDto;
import com.zyapaar.feedservice.dto.IFeeds;
import com.zyapaar.feedservice.dto.IReactedUser;
import com.zyapaar.feedservice.dto.ReactionUser;
import com.zyapaar.feedservice.repo.UserRepository;

@Mapper(componentModel = "spring")
public abstract class ActivityMapper {

  @Autowired UserRepository userRepository;

  public abstract List<ActivityList> toActivityList(List<IActivityList> activity);
  
  @Mapping(target = "mediaUrl", source="mediaUrl")
  @Mapping(target = "ageOfPost", source = "updatedOn")
  public abstract ActivityList toActivityList(IActivityList activity);

  List<String> map(String mediaUrl) {

    if(StringUtils.hasText(mediaUrl)){
      
      List<String> items = (Arrays.asList(mediaUrl.split("##")));
      return items;
    } else{
      return new ArrayList<>();
    }

  }

  String map(Long updatedOn){
    return TimeCount.timeFromUpload(updatedOn);
  }

  public abstract List<Feeds> toFeeds(List<IFeeds> feeds);

  @Mapping(target = "mediaUrl", source="mediaUrl")
  @Mapping(target = "ageOfPost", source = "updatedOn")
  @Mapping(target = "userDesignation", expression = "java(getUserTitleFromIFeeds(feeds))")
  public abstract Feeds toFeeds(IFeeds feeds);

  @Mapping(target = "userDesignation", expression = "java(getUserTitleFromIFeedCommentDto(subCommentList))")
  public abstract FeedCommentDto toFeedCommentDto (IFeedCommentDto subCommentList);

  public abstract List<FeedCommentDto> toFeedCommentDto(List<IFeedCommentDto> subCommentList);

  String getUserTitleFromIFeedCommentDto(IFeedCommentDto user){
    if(StringUtils.hasText(user.getUserId()))
      return userRepository.getUserTitle(user.getUserId());
    else 
      return null;
    
  }

  String getUserTitleFromIFeeds(IFeeds user){
    if(StringUtils.hasText(user.getUserId()))
      return userRepository.getUserTitle(user.getUserId());
    else 
      return null;
    
  }

  String getUserTitleFromIReactedUser(IReactedUser user){
    if(StringUtils.hasText(user.getUserId()))
      return userRepository.getUserTitle(user.getUserId());
    else 
      return null;
    
  }

  @Mapping(target = "designation", expression = "java(getUserTitleFromIReactedUser(data))")
  public abstract ReactionUser toReactionUser(IReactedUser data);

  public abstract List<ReactionUser> toReactionUser(List<IReactedUser> data);
  
}
