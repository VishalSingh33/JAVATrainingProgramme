package com.zyapaar.feedservice.dto;

/**
 * Reaction enum
 * 
 * @author Uday Halpara
 */
public enum Reaction {

  NONE("0"),
  LIKE("1"),
  CELEBRATE("2"),
  INTEREST("3"),
  SHAKEHANDS("4"),
  SUPPORT("5");

  private final String reaction;

  Reaction(String reaction){
    this.reaction = reaction;
  }

  public String reaction(){
    return reaction;
  }
}
