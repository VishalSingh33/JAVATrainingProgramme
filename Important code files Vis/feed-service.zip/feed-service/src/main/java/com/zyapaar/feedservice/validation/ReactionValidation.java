package com.zyapaar.feedservice.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

import com.zyapaar.feedservice.dto.Reaction;
import com.zyapaar.feedservice.dto.ReactionDto;

/**
 * Validate reaction
 * 
 * @author Uday Halpara
 */
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ReactionValidation.Validators.class)
public @interface ReactionValidation {

  String message() default "This field Is Required";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  String id();

  String oldReaction();

  class Validators implements ConstraintValidator<ReactionValidation, ReactionDto> {

    private String id;
    private String oldReaction;

    @Override
    public void initialize(ReactionValidation requiredIfChecked) {

      id = requiredIfChecked.id();
      oldReaction = requiredIfChecked.oldReaction();

    }

    @Override
    public boolean isValid(ReactionDto value, ConstraintValidatorContext context) {

      boolean result = true;
      String template = null;

      if (value.getOldReaction() != null && value.getNewReaction() != null) {

        if (value.getOldReaction().equals(Reaction.NONE)
            && value.getOldReaction().equals(value.getNewReaction())) {

          template = "Please provide valid old reaction";
          context.disableDefaultConstraintViolation();
          context.buildConstraintViolationWithTemplate(template)
              .addPropertyNode(oldReaction)
              .addConstraintViolation();
          result = false;

        } else if (value.getId() == null && !value.getOldReaction().equals(Reaction.NONE)) {

          template = "Please provide reaction id";
          context.disableDefaultConstraintViolation();
          context.buildConstraintViolationWithTemplate(template)
              .addPropertyNode(id)
              .addConstraintViolation();
          result = false;
        }

      }

      return result;
    }

  }

}
