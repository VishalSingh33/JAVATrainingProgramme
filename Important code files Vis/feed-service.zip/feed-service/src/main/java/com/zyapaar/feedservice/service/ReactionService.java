package com.zyapaar.feedservice.service;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.feedservice.dto.ReactionDto;
import com.zyapaar.feedservice.request.RequestReaction;
import com.zyapaar.feedservice.response.IReactionCountResponse;

/**
 * Reaction service interface
 * 
 * @author Uday Halpara
 * @author Neel Shah
 */
public interface ReactionService {

  String submitPostReaction(String userId, String postId, ReactionDto reactionDto)
      throws InterruptedException, ExecutionException, TimeoutException;

  String submitcommentReaction(String userId, String commentId, String postId, ReactionDto reactionDto)
      throws InterruptedException, ExecutionException, TimeoutException;

  IReactionCountResponse getReactionCount(String postId);

  ListingResponse getReacteduserListing(RequestReaction reaction, ListingRequest listingRequest, 
      String postId, String userId);

  IReactionCountResponse getCommentReactionCount(String commentId);

  ListingResponse getCommentReacteduserListing(String userId, RequestReaction reaction, ListingRequest listingRequest,
      String commentId);

}
