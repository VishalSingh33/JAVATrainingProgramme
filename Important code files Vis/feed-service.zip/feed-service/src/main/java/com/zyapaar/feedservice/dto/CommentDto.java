package com.zyapaar.feedservice.dto;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * comment Dto class
 * 
 * @author Uday Halpara
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommentDto {

  private String id;
  @NotNull(message = "Please enter contant")
  private Content content;
  private String replyOf;
  @NotNull(message = "Please select post user")
  private String postUserId;

}
