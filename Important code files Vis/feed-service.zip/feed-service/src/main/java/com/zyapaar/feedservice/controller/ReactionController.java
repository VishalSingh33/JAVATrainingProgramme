package com.zyapaar.feedservice.controller;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import javax.validation.Valid;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.feedservice.dto.ReactionDto;
import com.zyapaar.feedservice.request.RequestReaction;
import com.zyapaar.feedservice.response.IReactionCountResponse;
import com.zyapaar.feedservice.service.ReactionService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * like controller
 * 
 * @author Uday Halpara
 */
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@CrossOrigin("*")
@Validated
@Tag(name = "Reaction APIs")
@Slf4j
public class ReactionController {

  private final ReactionService reactionService;

  @Operation(description = "This Reaction service works to submit Post Reaction. use Reaction service which "
      +"contains model class (ReactionDto), ReactionDto has id, reaction.",
      responses = {@ApiResponse(responseCode = "201" ,description = "reaction added successfully"),
      @ApiResponse(responseCode = "500" ,description = "Something went wrong"),
      @ApiResponse(responseCode = "400" ,description = "Bad request")
     })
  @PostMapping("/post/{postId}/reaction")
  public ResponseEntity<Response> submitPostReaction(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true)
          @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "The id of the post to which there is a reaction is the post id", required = true) 
          @PathVariable(name = "postId", required = true) String postId,
      @Valid @RequestBody ReactionDto reactionDto) throws InterruptedException, ExecutionException, TimeoutException {
        log.info("[submitPostReaction] create post reaction");
    String postReactionId = reactionService.submitPostReaction(userId, postId, reactionDto);

    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().data(postReactionId).message("reaction added successfully").build());
  }

  @Operation(description = "This Reaction service works to submit comment Reaction. use Reaction service which "
      +"contains model class (ReactionDto), ReactionDto has id, reaction.",
      responses = {@ApiResponse(responseCode = "201" ,description = "reaction added successfully"),
      @ApiResponse(responseCode = "500" ,description = "Something went wrong"),
      @ApiResponse(responseCode = "400" ,description = "Bad request")
     })
  @PostMapping("/comment/{postId}/{commentId}/reaction")
  public ResponseEntity<Response> submitCommentReaction(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true) 
          @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "The id of the comment to which there is a reaction is the commentId", required = true) 
          @PathVariable(name = "commentId", required = true) String commentId,
      @Parameter(description = "The id of the post to which there is a reaction is the postid", required = true) 
          @PathVariable(name = "postId", required = true) String postId,
      @Valid @RequestBody ReactionDto reactionDto) throws InterruptedException, ExecutionException, TimeoutException {
        log.info("[submitCommentReaction] create comment reaction");
    String commentReactionId = reactionService.submitcommentReaction(userId, commentId, postId, reactionDto);
    
    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().data(commentReactionId).message("reaction added successfully").build());
  }

  @GetMapping(value="/reaction/{postId}")
  public ResponseEntity<Response> getReactionCount(@PathVariable(name = "postId") String postId) {
    log.info("[getReactionCount] get post reaction count");
    IReactionCountResponse data = reactionService.getReactionCount(postId);
    
    return ResponseEntity.status(HttpStatus.OK)
          .body(Response.builder().message("found successfully").data(data).build());
  }

  @PostMapping(value = "/reaction/list/{postId}/{reaction}")
  public ResponseEntity<Response> getReacteduserListing(@Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true) 
  @RequestHeader("Z-AUTH-USERID") String userId,
  @PathVariable(name = "postId") String postId, 
      @PathVariable(name = "reaction") RequestReaction reaction,
      @RequestBody ListingRequest listingRequest) {
        log.info("[getReacteduserListing] get post reacted user listing");
    ListingResponse data = reactionService.getReacteduserListing(reaction, listingRequest, postId, userId);

    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().message("found successfully").data(data).build());
  }

  @GetMapping(value="/reaction/comment/{commentId}")
  public ResponseEntity<Response> getCommentReactionCount(@PathVariable(name = "commentId") String commentId) {
    log.info("[getReactionCount] get post reaction count");
    IReactionCountResponse data = reactionService.getCommentReactionCount(commentId);
    
    return ResponseEntity.status(HttpStatus.OK)
          .body(Response.builder().message("found successfully").data(data).build());
  }

  @PostMapping(value = "/reaction/list/comment/{commentId}/{reaction}")
  public ResponseEntity<Response> getCommentReacteduserListing(@Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true) 
  @RequestHeader("Z-AUTH-USERID") String userId,@PathVariable(name = "commentId") String commentId, 
      @PathVariable(name = "reaction") RequestReaction reaction,
      @RequestBody ListingRequest listingRequest) {
        log.info("[getReacteduserListing] get post reacted user listing");
    ListingResponse data = reactionService.getCommentReacteduserListing(userId, reaction, listingRequest, commentId);

    return ResponseEntity.status(HttpStatus.OK)
        .body(Response.builder().message("found successfully").data(data).build());
  }

}
