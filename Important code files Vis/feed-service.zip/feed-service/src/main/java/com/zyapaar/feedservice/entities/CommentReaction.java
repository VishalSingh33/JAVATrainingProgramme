package com.zyapaar.feedservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name="comment_reaction")
public class CommentReaction {

	@Id
	private String id;

	@Column(name="comment_id")
	private String commentId;

	@Column(name="created_on")
	private Long createdOn;

	@Column(name="new_reaction")
	private String newReaction;

	@Column(name="old_reaction")
	private String oldReaction;

	@Column(name="post_id")
	private String postId;

	@Column(name="updated_on")
	private Long updatedOn;

	@Column(name="user_id")
	private String userId;

}