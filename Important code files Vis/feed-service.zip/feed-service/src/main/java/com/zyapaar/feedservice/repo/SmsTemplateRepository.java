package com.zyapaar.feedservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.entities.SmsTemplate;

/**
 * Sms template repository
 * 
 * @author Uday Halpara
 */
@Repository
public interface SmsTemplateRepository extends JpaRepository<SmsTemplate, String> {

}
