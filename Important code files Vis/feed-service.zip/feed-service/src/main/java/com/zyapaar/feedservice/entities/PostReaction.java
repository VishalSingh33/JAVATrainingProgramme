package com.zyapaar.feedservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="post_reaction")
public class PostReaction {

	@Id
	private String id;

	@Column(name="created_on")
	private Long createdOn;

	@Column(name="new_reaction")
	private String newReaction;

	@Column(name="old_reaction")
	private String oldReaction;

	@Column(name="post_id")
	private String postId;

	@Column(name="updated_on")
	private Long updatedOn;

	@Column(name="user_id")
	private String userId;

}