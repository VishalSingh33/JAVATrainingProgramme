package com.zyapaar.feedservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import com.zyapaar.serde.CommentAvro;
import com.zyapaar.serde.FeedCommentAvro;

/**
 * feed comment mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface FeedCommentAvroMapper {

  FeedCommentAvro toFeedCommentAvro(CommentAvro commentAvro,String userName, String userProfile,
      String userDesignation);

  FeedCommentAvro toFeedCommentAvro(CommentAvro commentAvro, CharSequence userName, CharSequence userProfile, 
      CharSequence userDesignation);

  void updateComment(CommentAvro commentAvro, @MappingTarget FeedCommentAvro feedCommentAvro);
}
