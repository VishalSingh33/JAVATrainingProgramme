package com.zyapaar.feedservice.validation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

import com.zyapaar.feedservice.properties.B2bProperties;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * File Validation Custom Annotation
 * 
 * @author Uday Halpara
 */
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ValidateFile.Validators.class)
public @interface ValidateFile {
  String message() default "Invalid uploaded file";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  /**
   * validator class for File Validation
   * 
   * @author Uday Halpara
   */
  @Slf4j
  @RequiredArgsConstructor
  class Validators implements ConstraintValidator<ValidateFile, List<MultipartFile>> {
    private final B2bProperties b2bProperties;

    /**
     * file validation checking Method
     */
    @Override
    public boolean isValid(List<MultipartFile> file, ConstraintValidatorContext context) {

      log.info("[isValid] validate multipart file");
      boolean finalResult = true;
      String template = null;

      if (!CollectionUtils.isEmpty(file)) {
        if (isImage(StringUtils.getFilenameExtension(file.get(0).getOriginalFilename()))) {
          if (file.size() <= 10) {
            long size = 0L;
            for (MultipartFile multipartFile : file) {
              size += multipartFile.getSize();
              if (!isImage(StringUtils.getFilenameExtension(multipartFile.getOriginalFilename()))
                  || multipartFile.getSize() == 0) {
                template = "Please Attach Valid Media Type File";
                break;
              }
            }

            if (size > b2bProperties.getMediaSize().getImage()) {
              template = "Attachment size exceeds the allowable limit for IMAGE! (100MB)";
            }
          } else {
            template = "Max 10 attachment are allowed";
          }

        } else if (isVideo(StringUtils.getFilenameExtension(file.get(0).getOriginalFilename()))) {
          if (file.size() == 1) {
            if (file.get(0).getSize() > b2bProperties.getMediaSize().getVideo()) {
              template = "Attachment size exceeds the allowable limit for IMAGE! (100MB)";
            }
          } else {
            template = "Max 1 video can be uploaded";
          }

        } else if (isPdf(StringUtils.getFilenameExtension(file.get(0).getOriginalFilename()))) {
          if (file.size() == 1) {
            if (file.get(0).getSize() > b2bProperties.getMediaSize().getPdf()) {
              template = "Attachment size exceeds the allowable limit for PDF! (100MB)";
            }
          } else {
            template = "max 1 pdf file can be uploaded";
          }

        } else {
          template = "Please Attach Valid Media Type File";
        }
        if (template != null) {
          context.disableDefaultConstraintViolation();
          context.buildConstraintViolationWithTemplate(template)
              .addConstraintViolation();
          finalResult = false;
        }
      }
      return finalResult;
    }

    /**
     * Check for the valid PDF file
     * 
     * @param contentType {@link String}
     * @return {@link Boolean}
     */
    private boolean isPdf(String contentType) {
      return contentType.equalsIgnoreCase("pdf");
    }

    /**
     * Check for the valid IMAGE type
     * 
     * @param contentType {@link String}
     * @return {@link Boolean}
     */
    private boolean isImage(String contentType) {
      return contentType.equalsIgnoreCase("png")
          || contentType.equalsIgnoreCase("jpg")
          || contentType.equalsIgnoreCase("gif")
          || contentType.equalsIgnoreCase("jfif")
          || contentType.equalsIgnoreCase("jpeg");
    }

    /**
     * Check for the valid VIDEO type
     * 
     * @param contentType {@link String}
     * @return {@link Boolean}
     */
    private boolean isVideo(String contentType) {
      return contentType.equalsIgnoreCase("mp4")
          || contentType.equalsIgnoreCase("mov");
    }
  }
}
