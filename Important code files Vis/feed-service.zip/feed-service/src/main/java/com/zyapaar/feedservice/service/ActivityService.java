package com.zyapaar.feedservice.service;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.feedservice.dto.MessageDto;

/**
 * Activity service
 * 
 * @author Uday Halpara
 */
public interface ActivityService {

  ListingResponse getUserActivity(String userId, ListingRequest request, String id);

  void sendMessage(String userId, MessageDto messageDto) throws InterruptedException,
      ExecutionException, TimeoutException;

}
