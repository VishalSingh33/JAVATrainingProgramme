package com.zyapaar.feedservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="post_reaction_count")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PostReactionCount {

	@Id
	private String id;

	@Column(name="celebrate_count")
	private Long celebrateCount;

	private Long count;

	@Column(name="interest_count")
	private Long interestCount;

	@Column(name="like_count")
	private Long likeCount;

	@Column(name="post_id")
	private String postId;

	@Column(name="shake_hand_count")
	private Long shakeHandCount;

	@Column(name="support_count")
	private Long supportCount;

	@Column(name="view_count")
	private Long viewCount;
}
