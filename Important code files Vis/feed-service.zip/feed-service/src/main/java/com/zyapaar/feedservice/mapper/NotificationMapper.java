package com.zyapaar.feedservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyapaar.commons.dto.NotificationContent;
import com.zyapaar.commons.dto.NotificationFor;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.feedservice.dto.Activity;
import com.zyapaar.feedservice.dto.NotificationSettings;
import com.zyapaar.feedservice.dto.NotificationSettings.NetworkProfile;
import com.zyapaar.feedservice.dto.NotificationSettings.PostDelivery;
import com.zyapaar.serde.EmailNotificationAvro;
import com.zyapaar.serde.NotificationV2Avro;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.NotificationSettingsV2Avro;

/**
 * Notification mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface NotificationMapper {

  ObjectMapper objectMapper = new ObjectMapper();

  NotificationSettingsV2Avro toNotificationSettingsAvro(NotificationSettings notificationSettings,
      String userId);

  EmailNotificationAvro toEmailNotification(String id, CharSequence email, String subject,
      String content, String meta, Long createdOn);

  @Mapping(target = "postDelivery", source = "notificationSettingsAvro.postDelivery", qualifiedByName = "mapToPostDelivery")
  @Mapping(target = "networkProfile", source = "notificationSettingsAvro.networkProfile", qualifiedByName = "mapToNetworkProfile")
  NotificationSettings toNotificationSettings(NotificationSettingsV2Avro notificationSettingsAvro);

  // NotificationV2Avro toNotificationAvro(String id, Activity activity, NotificationContent content,
  //     Long createdOn, String userId, Boolean isActive);

  @Mapping(ignore = true, target = "attributes")
  @Mapping(ignore = true, target = "originId")
  NotificationV2Avro toNotificationV2Avro(String id, String userId, NotificationTypes type,
      NotificationContent content, long createdOn, long updatedOn);

  // @Mapping(target = "activity", source = "notificationAvro.activity", qualifiedByName = "mapToActivity")
  // Notification notificationAvroToNotification(NotificationV2Avro notificationAvro);

  default CharSequence map(Activity value) {
    return value.activity();
  }

  default CharSequence map(NotificationContent value) throws JsonProcessingException {
    return objectMapper.writeValueAsString(value);
  }

  default String map(NetworkProfile value) {
    return value.networkProfile();
  }

  default String map(PostDelivery value) {
    return value.postDelivery();
  }

  default String map(CharSequence value) {
    return value == null ? null : String.valueOf(value);
  }

  @Named("mapToNetworkProfile")
  default NetworkProfile mapToNetworkProfile(CharSequence value) {
    return NetworkProfile.fromString(String.valueOf(value));
  }

  @Named("mapToPostDelivery")
  default PostDelivery mapToPostDelivery(CharSequence value) {
    return PostDelivery.fromString(String.valueOf(value));
  }

  @Named("mapToActivity")
  default Activity mapToActivity(CharSequence value) {
    return Activity.fromString(String.valueOf(value));
  }

  NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor,
      NotificationTypes type, String originId);

  NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor,
      NotificationTypes type, String originId, NotificationFor requestType);

  NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor,
      NotificationTypes type, String originId, Boolean isActive);

  default int map(NotificationTypes value) {
    return value.types();
  }

  default int map(NotificationFor value) {
    return value.status();
  }

}
