package com.zyapaar.feedservice.consumer;

import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.springframework.cloud.stream.annotation.Input;

import com.zyapaar.serde.CommentAvro;
import com.zyapaar.serde.CommentCountAvro;
import com.zyapaar.serde.CommentReactionAvro;
import com.zyapaar.serde.CommentReactionCountAvro;
import com.zyapaar.serde.CommentReplyCountAvro;
import com.zyapaar.serde.FeedAvro;
import com.zyapaar.serde.FeedCommentAvro;
import com.zyapaar.serde.HashTagsAvro;
import com.zyapaar.serde.LastFeedViewCountAvro;
import com.zyapaar.serde.PostAvro;
import com.zyapaar.serde.PostReactionAvro;
import com.zyapaar.serde.PostReactionCountAvro;
import com.zyapaar.serde.UserIndustryAvro;
import com.zyapaar.serde.UserOverviewAvro;
import com.zyapaar.serde.UserRegistrationAvro;

/**
 * stream binding class
 * 
 * @author UDaY HaLPaRa
 */
public interface ConsumerBinding {

  @Input("user-channel")
  KTable<String, UserRegistrationAvro> userKTable();

  @Input("post-generate-channel")
  KStream<String, PostAvro> postProcess();

  @Input("feed-generate-channel")
  KTable<String, FeedAvro> feedKtable();

  @Input("feed-comment-generate-channel")
  KTable<String, FeedCommentAvro> feedCommentKtable();

  @Input("post-reaction-generate-channel")
  KStream<String, PostReactionAvro> postReactionStream();

  @Input("comment-reaction-generate-channel")
  KStream<String, CommentReactionAvro> commentReactionStream();

  @Input("comment-generate-channel")
  KStream<String, CommentAvro> commentKStream();

  @Input("comment-count-generate-channel")
  KStream<String, CommentCountAvro> commentCountProcess();

  @Input("post-reaction-count-generate-channel")
  KStream<String, PostReactionCountAvro> postReactionCountProcess();

  @Input("comment-reaction-count-generate-channel")
  KStream<String, CommentReactionCountAvro> commentReactionCountProcess();

  @Input("hash-tags-channel")
  KStream<String, HashTagsAvro> hashTagsStream();

  @Input("comment-reply-count-channel")
  KStream<String, CommentReplyCountAvro> commentReplyCountStream();

  @Input("user-overview-channel")
  KTable<String, UserOverviewAvro> userOverviewStream();

  @Input("users-wise-industry-channel")
  KTable<String, UserIndustryAvro> usersIndustryKTable();

  @Input("last-post-view-count-channel")
  KStream<String, LastFeedViewCountAvro> feedViewCount();

}
