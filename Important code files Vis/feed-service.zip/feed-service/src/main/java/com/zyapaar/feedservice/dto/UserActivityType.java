package com.zyapaar.feedservice.dto;

/**
 * User activity type
 * 
 * @author Uday Halpara
 */
public enum UserActivityType {

  POST("1"),
  POST_REACTION("2"),
  COMMENT("3"),
  COMMENT_REPLY("4"),
  COMMENT_REACTION("5"),
  POST_SHARE("6");

  private final String activity;

  UserActivityType(String activity) {
    this.activity = activity;
  }

  public String activity() {
    return activity;
  }

  public static UserActivityType fromString(String text) {
    for (UserActivityType b : UserActivityType.values()) {
      if (b.activity.equalsIgnoreCase(text)) {
        return b;
      }
    }
    return null;
  }

}
