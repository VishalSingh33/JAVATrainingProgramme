package com.zyapaar.feedservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReactionUser {
  
  private String postId;
  private String commentId;
  private String userName;
  private String profileImage;
  private String designation;
  private String reaction;
}
