package com.zyapaar.feedservice.repo;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.dto.IReactedUser;
import com.zyapaar.feedservice.entities.CommentReaction;


@Repository
public interface CommentReactionRepository extends JpaRepository<CommentReaction, String>{

  @Query(nativeQuery = true, 
  value = "SELECT * FROM comment_reaction WHERE "+
    "user_id = :userId  AND comment_id = :commentId  AND post_id = :postId")
  CommentReaction findByUserIdAndCommentIdAndPostId(String userId, String commentId, String postId); //notInUserAsPerZYPR-2970
  
  @Query(nativeQuery = true,
    value = "SELECT exists (select * from comment_reaction cr where "+
      "user_id = :userId and comment_id = :commentId and post_id = :postId)")
  Boolean isCommentReactionExist(String userId, String commentId, String postId);

  @Query(nativeQuery = true,
    value = "select null as postId, pr.comment_id  as commentId, u.full_name as userName, u.id as userId, " + 
      "u.img as profileImage, u.title as designation, pr.new_reaction as reaction " + 
      "from comment_reaction pr " + 
      "inner join users u on pr.user_id = u.id " + 
      "left join block_user bu on " + 
      "((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
      "or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
      "and bu.status = :status and bu.origin = :originBlock " + 
      "where bu.id is null " + 
      "and pr.comment_id = :commentId and pr.new_reaction <>'0' ")
  List<IReactedUser> getReacteduserListingForAll(String commentId, String userId, String status, 
      String originBlock, Pageable requestedPage); //done

  @Query(nativeQuery = true,
    value = "select null as postId, pr.comment_id  as commentId, u.full_name as userName, u.id as userId, " + 
      "u.img as profileImage, u.title as designation, pr.new_reaction as reaction " + 
      "from comment_reaction pr " + 
      "inner join users u on pr.user_id = u.id " + 
      "left join block_user bu on " + 
      "((bu.from_user_id = u.id and bu.to_user_id = :userId) " + 
      "or (bu.to_user_id = u.id and bu.from_user_id = :userId)) " + 
      "and bu.status = :status and bu.origin = :originBlock " + 
      "where bu.id is null " + 
      "and pr.new_reaction = :reaction and " + 
      "pr.comment_id = :commentId and pr.new_reaction <>'0' ")
  List<IReactedUser> getReacteduserListing(String reaction, String commentId, String userId, 
      String status, String originBlock,  Pageable requestedPage); //done



}
