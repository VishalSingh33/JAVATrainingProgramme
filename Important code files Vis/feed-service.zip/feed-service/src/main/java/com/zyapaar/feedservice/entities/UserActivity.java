package com.zyapaar.feedservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="user_activity")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserActivity {

	@Id
	private String id;

	@Column(name="created_on")
	private Long createdOn;

	@Column(name="feed_id")
	private String feedId;

	@Column(name="is_active")
	private Boolean isActive;

	private String reaction;

	private String type;

	@Column(name="updated_on")
	private Long updatedOn;

	@Column(name="user_id")
	private String userId;
}