package com.zyapaar.feedservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name="comment_reaction_count")
public class CommentReactionCount {

	@Id
	private String id;

	@Column(name="comment_id")
	private String commentId;

	@Column(name="count")
	private Long count;

	@Column(name="like_count")
	private String likeCount;

	@Column(name="celebrate_count")
	private String celebrateCount;

	@Column(name="interest_count")
	private String interestCount;

	@Column(name="shake_hand_count")
	private Long shakeHandCount;

	@Column(name="support_count")
	private String supportCount;
}