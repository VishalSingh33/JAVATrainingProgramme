package com.zyapaar.feedservice.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Activity dto
 * 
 * @author Uday Halpara
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActivityList {

  private String id; //activity.id
	private String feedId; //feed.userId
  private String userId; //activity.feedId
  private String postOf; //feed.postOf
  private String content; //feed.content 
  private String hashTag; //feed.hashtag
  private String type; //feed.type (buy/sell/general)
  private String privacy; //feed.privacy
  private String status; //feed.status
  private Long updatedOn; //activity.createdOn
  private String ageOfPost; //calculate
  private Long commentCount; //feed.commentCount
  private Long reactionCount; //feed.reactionCount
  private String userProfile; //feed.userId laine user.img
  private String userName; //feed.userId laine user.fullName
  private String userDesignation; //feed.userId laine user.title
  private String aboutUser; //feed.userId laine user.about
  private String reactionId; //database ni query after loop karine
  private String reaction; //database ni query after loop karine
  private Long viewCount; //feed.viewCount
  private String userReaction; //activity.reaction
  private String activityType; //activity.type
  private List<String> mediaUrl;
}
