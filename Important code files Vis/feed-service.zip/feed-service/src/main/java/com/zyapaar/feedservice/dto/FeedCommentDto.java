package com.zyapaar.feedservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FeedCommentDto {

  private String id;
  private String postId;
  private String userId;
  private String content;
  private String replyOf;
  private Long createdOn;
  private Long updatedOn;
  private Long reactionCount;
  private Long replyCount;
  private String userDesignation;
  private String userName;
  private String userProfile;
  private String ageOfComment;
  private String reactionId;
  private String reaction;
  Boolean isActive;
  
}
