package com.zyapaar.feedservice.dto;

/**
 * post origin enum
 * 
 * @author Uday Halpara
 */
public enum PostOrigin {

  USER("1"),
  PAGE("2"),
  GROUP("3");

  private final String origin;

  PostOrigin(String origin) {
    this.origin = origin;
  }

  public String origin() {
    return origin;
  }

}
