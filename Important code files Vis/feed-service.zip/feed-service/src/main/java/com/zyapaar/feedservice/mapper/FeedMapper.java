package com.zyapaar.feedservice.mapper;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import com.zyapaar.feedservice.dto.Feeds;
import com.zyapaar.feedservice.entities.Feed;
import com.zyapaar.feedservice.entities.User;
import com.zyapaar.serde.FeedAvro;
import com.zyapaar.serde.PostAvro;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import com.zyapaar.feedservice.repo.UserRepository;


/**
 * feed avro mapper
 * 
 * @author Uday Halpara
 */
@Mapper(componentModel = "spring")
public abstract class FeedMapper {

  @Autowired UserRepository userRepository;

  @Mapping(target = "originId", source = "postAvro.originId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "postOf", source = "postAvro.postOf", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "content", source = "postAvro.content", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "hashTag", source = "postAvro.hashTag", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "mediaUrl", source = "postAvro.mediaUrl", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  public abstract FeedAvro toFeedAvro(PostAvro postAvro, String userName, String userProfile,
  String userDesignation, String aboutUser, List<String> industries, List<String> sendTo);
  // "commentCount, isHide, reactionCount, userCompany, viewCount"

  //Feed toFeed(FeedAvro feedAvro);//"ageOfPost" where is the use?

  String map(CharSequence value) {
    return value == null ? null : String.valueOf(value);
  }

  long map(OffsetDateTime value) {
    return value == null ? null : value.toEpochSecond();
  }

  @Mapping(target = "postOf", source = "feed.postOf", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "content", source = "feed.content", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "hashTag", source = "feed.hashTag", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "mediaUrl", source = "feed.mediaUrl", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "sendTo", source = "feed.sendTo", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // @Mapping(target = "userProfile", source = "feed.userProfile", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // @Mapping(target = "userDesignation", source = "feed.userDesignation", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  // @Mapping(target = "aboutUser", source = "feed.aboutUser", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "userName", source = "user.fullName")
  @Mapping(target = "userDesignation",expression = "java(getUserTitle(user))")
  @Mapping(target = "userProfile", source = "user.img")
  @Mapping(target = "aboutUser", source = "user.aboutUs")
  @Mapping(target = "userId", source = "user.id")
  @Mapping(target = "userCompany", source = "feed.userCompany")
  @Mapping(target = "id", source = "feed.id")
  @Mapping(target = "createdOn", source = "feed.createdOn")
  @Mapping(target = "updatedOn", source = "feed.updatedOn")
  public abstract Feeds feedToFeeds(Feed feed, User user);//"products, reaction, reactionId"

  String getUserTitle(User user){
    return userRepository.getUserTitle(user.getId());
    
  }
  /*
   * userName
   * userProfile
   * userDesignation
   * aboutUser
   * userId
   * userCompany (feed)
   */


  @Mapping(target = "originId", source = "postAvro.originId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "postOf", source = "postAvro.postOf", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "content", source = "postAvro.content", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "hashTag", source = "postAvro.hashTag", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "mediaUrl", source = "postAvro.mediaUrl", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  public abstract FeedAvro toFeedAvro(PostAvro postAvro, CharSequence userName, CharSequence userProfile, CharSequence userDesignation, 
      CharSequence aboutUser, ArrayList<String> industries, ArrayList<String> sendTo);
      //"commentCount, isHide, reactionCount, userCompany, viewCount"
  
  public abstract void updateFeed(PostAvro postAvro, @MappingTarget FeedAvro feedAvro);
  //Unmapped target properties: "aboutUser, commentCount, industries, isHide, reactionCount, sendTo, 
  //userCompany, userDesignation, userName, userProfile, viewCount"
  
  @Mapping(target = "originId", source = "postAvro.originId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "postOf", source = "postAvro.postOf", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "content", source = "postAvro.content", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "hashTag", source = "postAvro.hashTag", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "mediaUrl", source = "postAvro.mediaUrl", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  public abstract FeedAvro toFeedAvro(PostAvro postAvro, CharSequence userName, CharSequence userProfile, CharSequence userDesignation, 
      CharSequence aboutUser, ArrayList<String> industries, ArrayList<String> sendTo, String userCompany);
      //"commentCount, isHide, reactionCount, viewCount"
}
