package com.zyapaar.feedservice.dto;

import java.util.List;

import lombok.Data;

@Data
public class UserIndustryAvroDto {

  private String id;

  private List<String> saleIndustry;

  private List<String> buyIndustry;

  private List<String> companies;

}
