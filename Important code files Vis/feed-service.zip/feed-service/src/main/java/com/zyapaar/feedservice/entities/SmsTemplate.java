package com.zyapaar.feedservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="sms_templates")
public class SmsTemplate{

	@Id
	private String id;

	@Column(name="entity_id")
	private String entityId;

	@Column(name="template_content")
	private String templateContent;

	@Column(name="template_id")
	private String templateId;

	@Column(name="template_name")
	private String templateName;

}
