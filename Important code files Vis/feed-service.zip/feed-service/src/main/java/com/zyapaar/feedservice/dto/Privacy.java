package com.zyapaar.feedservice.dto;

/**
 * Post Privacy enum
 * 
 * @author Uday Halpara
 */
public enum Privacy {
  ANYONE("1"),
  CONNECTION_ONLY("2");

  private final String privacy;

  Privacy(String privacy){
    this.privacy = privacy;
  }

  public String privacy(){
    return privacy;
  }
}
