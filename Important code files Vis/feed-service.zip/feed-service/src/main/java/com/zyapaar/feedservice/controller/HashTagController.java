package com.zyapaar.feedservice.controller;

import javax.validation.Valid;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.feedservice.service.HashTagService;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

/**
 * Hash tag controller
 * 
 * @author Uday Halpara
 */
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class HashTagController {

  private final HashTagService hashTagService;

  @PostMapping(value = "/hashTags")
  public ResponseEntity<Response> getHashTags(@RequestHeader("Z-AUTH-USERID") String userId,
      @Valid @RequestBody ListingRequest request) {

    ListingResponse response = hashTagService.getHashTags(request);

    return ResponseEntity.ok(Response.builder().data(response)
        .message("data found successfully").build());
  }

}
