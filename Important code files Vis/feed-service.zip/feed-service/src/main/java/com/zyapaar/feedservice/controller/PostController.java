package com.zyapaar.feedservice.controller;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import javax.validation.Valid;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.exceptionhandler.model.ApiError;
import com.zyapaar.feedservice.dto.PostDto;
import com.zyapaar.feedservice.dto.PostResponse;
import com.zyapaar.feedservice.dto.PostUpdateDto;
import com.zyapaar.feedservice.service.PostService;
import com.zyapaar.feedservice.validation.ValidateFile;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Post controller
 * 
 * @author Uday Halpara
 */
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@CrossOrigin("*")
@Validated
@Tag(name = "Post APIs")
@Slf4j
public class PostController {

  private final PostService postService;

  /**
   * create post method
   * 
   * @param userId
   * @param postDto
   * @param postFile
   */
  @Operation(description = "This psot service works to create posts.use post service which"
      +" contains model class (PostDto), PostDto has id, postoff, content, hashtag, type, privacy.",
      responses = {
        @ApiResponse(content = @Content(schema = @Schema(implementation = Response.class)),
            responseCode = "200",description = "post created successfully"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "500", description = "Something went wrong"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "400", description = "Bad request")
      })

  @PostMapping("/post")
  public ResponseEntity<Response> post(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true) 
          @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "The content under Post DTO is used to create the post", required = true) 
          @RequestParam("post") @Valid PostDto postDto,
      @ValidateFile @RequestParam(name = "media", required = false) List<MultipartFile> media)
      throws IOException, InterruptedException, ExecutionException, TimeoutException {
    log.info("[post] create post");

    PostResponse data = postService.createPost(postDto, userId, media);

    return ResponseEntity.status(HttpStatus.CREATED)
        .body(Response.builder().data(data).message("post created successfully").build());
  }

  @PutMapping("/post")
  public ResponseEntity<Response> updatePost(@RequestHeader("Z-AUTH-USERID") String userId,
      @RequestParam("post") @Valid PostUpdateDto postDto,
      @ValidateFile @RequestParam(name = "media", required = false) List<MultipartFile> media)
      throws IOException, InterruptedException, ExecutionException, TimeoutException {

    PostResponse data = postService.updatePost(postDto, userId, media);

    return ResponseEntity.status(HttpStatus.CREATED)
        .body(Response.builder().data(data).message("post created successfully").build());
  }



  @DeleteMapping("/post/{postId}")
  public ResponseEntity<Response> deletePost(@RequestHeader("Z-AUTH-USERID") String userId,
      @PathVariable("postId") String postId) throws InterruptedException, ExecutionException, 
      TimeoutException {

    postService.deletePost(userId, postId);

    return ResponseEntity.status(HttpStatus.CREATED)
        .body(Response.builder().message("post deleted successfully").build());
  }

}
