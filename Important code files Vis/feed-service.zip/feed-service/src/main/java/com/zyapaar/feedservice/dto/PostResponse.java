package com.zyapaar.feedservice.dto;

import java.util.List;

import lombok.Data;

/**
 * Post response
 * 
 * @author Uday Halpara
 */
@Data
public class PostResponse {

  private String id;
  private List<String> mediaUrl;

}
