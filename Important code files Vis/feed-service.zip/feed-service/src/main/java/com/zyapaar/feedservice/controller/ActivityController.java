package com.zyapaar.feedservice.controller;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import javax.validation.Valid;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.feedservice.dto.MessageDto;
import com.zyapaar.feedservice.service.ActivityService;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Activity controller
 * 
 * @author Uday Halpara
 */
@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class ActivityController {

  private final ActivityService activityService;

  @PostMapping("/user/activity")
  public ResponseEntity<Response> getUserActivity(@RequestHeader("Z-AUTH-USERID") String userId,
      @RequestParam(name = "userId", required = false) String id,
      @Valid @RequestBody ListingRequest request
  
  ){
    ListingResponse data = activityService.getUserActivity(userId, request, id);
    return ResponseEntity.ok().body(Response.builder().data(data).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }


  @PostMapping(value = "/message")
  public ResponseEntity<Response> sendMessage(@RequestHeader("Z-AUTH-USERID") String userId,
      @Valid @RequestBody MessageDto messageDto) throws InterruptedException, ExecutionException, 
      TimeoutException {

    log.info("[sendMessage] sent message to user : {}", messageDto.getUserId());

    activityService.sendMessage(userId, messageDto);

    return ResponseEntity.ok().body(Response.builder().message("Message sent sucess")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

}
