package com.zyapaar.feedservice.dto;

import org.springframework.stereotype.Component;

/**
 * Hash tag dto
 * 
 * @author Uday Halpara
 */
@Component
public interface IHashTagsDto {

  String getKey();
  Long getCount();

}
