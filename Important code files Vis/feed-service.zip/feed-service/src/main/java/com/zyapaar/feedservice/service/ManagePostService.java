package com.zyapaar.feedservice.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.zyapaar.commons.dto.Attribute;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.commons.response.FileUploadResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.feedservice.dto.PostDto;
import com.zyapaar.feedservice.dto.PostOrigin;
import com.zyapaar.feedservice.dto.PostResponse;
import com.zyapaar.feedservice.dto.PostUpdateDto;
import com.zyapaar.feedservice.dto.Status;
import com.zyapaar.feedservice.entities.Feed;
import com.zyapaar.feedservice.mapper.NotificationMapper;
import com.zyapaar.feedservice.mapper.PostAvroMapper;
import com.zyapaar.feedservice.producer.Producer;
import com.zyapaar.feedservice.properties.B2bProperties;
import com.zyapaar.feedservice.repo.FeedRepository;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.PostAvro;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * manage post service class
 * 
 * @author Uday Halpara
 * @author Neel Shah
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManagePostService implements PostService {

  private final Producer producer;
  private final B2bProperties b2bProperties;
  private final PostAvroMapper postAvroMapper;
  private final WebClient.Builder webClientBuilder;
  private final NotificationMapper notificationMapper;
  private final FeedRepository feedRepository;

  /**
   * create post method
   */
  @Override
  public PostResponse createPost(PostDto postDto, String userId, List<MultipartFile> mediaFiles)
      throws IOException, InterruptedException, ExecutionException, TimeoutException {
    log.info("[createPost] create post by user: {}", userId);

    postDto.setId(SequenceGenerator.getInstance().nextId());

    List<String> mediaUrls = new ArrayList<>();
    if (mediaFiles != null && mediaFiles.size() != 0) {
      mediaUrls = uploadFile(mediaFiles);
    }
    long currentTime = DateTimeUtils.currentDateTimeUTC();

    if (postDto.getHashTag() != null && !postDto.getHashTag().isEmpty()) {

      producer.produceHashTag(postDto.getHashTag().split("#"));

    }

    PostAvro postAvro = postAvroMapper.toPostAvro(postDto, userId, mediaUrls, currentTime,
        currentTime, Status.ACTIVE.status());

    if (Objects.nonNull(postDto.getPostOf()) && postDto.getOrigin().equals(PostOrigin.PAGE)
    // this will be normal reshare
    ) {
      postAvro.setOrigin(PostOrigin.USER.origin());
      postAvro.setOriginId("0");
    }

    producer.producePost(postAvro);
    PostResponse response = postAvroMapper.toPostResponse(postAvro);

    List<Attribute> attributes = postDto.getContent().getAttributes();

    log.info("[Post List of attributes] : {}", attributes);

    // Post tag notification
    if (!CollectionUtils.isEmpty(attributes)) {

      for (Attribute attribute : attributes) {

        log.info("[Post attribute] : {}", attribute);
        log.info("[Post USER-ID] : {}", userId);

        if (!(attribute.getId().equals(userId))) {

          if (postDto.getOrigin().equals(PostOrigin.PAGE)) {

            NotificationEventAvro eventAvro = notificationMapper.buildNotificationEvent(
                postDto.getId() + "_" + attribute.getId() + "_"
                    + NotificationTypes.PAGE_MENTION.types(),
                userId, attribute.getId(), NotificationTypes.PAGE_MENTION, postDto.getId());

            producer.produceNotificationEvent(eventAvro,
                b2bProperties.getTopic().getPageTagEvent());

          } else {

            NotificationEventAvro eventAvro = notificationMapper.buildNotificationEvent(
                postDto.getId() + "_" + attribute.getId() + "_"
                    + NotificationTypes.POST_MENTION.types(),
                userId, attribute.getId(), NotificationTypes.POST_MENTION, postDto.getId());

            producer.produceNotificationEvent(eventAvro,
                b2bProperties.getTopic().getPostTagEvent());

          }
        }
      }
    }

    // post share notification event
    if (Objects.nonNull(postDto.getPostOf())) {

      Feed feed = findFeedById(postDto.getPostOf());
      // feedDao.getFeed(postDto.getPostOf());

      if (!feed.getUserId().equals(userId)) {

        NotificationEventAvro eventAvro = notificationMapper.buildNotificationEvent(
            postDto.getId() + "_" + userId + "_" + NotificationTypes.POST_SHARE.types(), userId,
            feed.getUserId(), NotificationTypes.POST_SHARE, postDto.getId());

        producer.produceNotificationEvent(eventAvro, b2bProperties.getTopic().getPostShareEvent());

      }
    }

    return response;
  }

  /**
   * use for uplode file
   * 
   * @param file
   * @return
   * @throws IOException
   */
  private List<String> uploadFile(List<MultipartFile> files) throws IOException {
    
    log.info("[uploadFile] upload file");
    List<String> mediaUrls = new ArrayList<>();
    for(MultipartFile file : files){
      var fileToUpload = multiPartFileToFile(file);
      MultiValueMap<String, HttpEntity<?>> entity = fromFile(fileToUpload);

      FileUploadResponse result = webClientBuilder
          .build()
          .post()
          .uri(b2bProperties.getApi().getUserPostUpload())
          .body(BodyInserters.fromMultipartData(entity))
          .retrieve()
          .bodyToMono(FileUploadResponse.class)
          .block();

      fileToUpload.delete();
      mediaUrls.add(result.getFileUrl());
    }
    return mediaUrls;
  }

  /**
   * multi part body builder
   * 
   * @param file
   * @return
   */
  private MultiValueMap<String, HttpEntity<?>> fromFile(File file) {
    log.info("[fromFile] file to multivalue map");
    MultipartBodyBuilder builder = new MultipartBodyBuilder();
    builder.part("file", new FileSystemResource(file));
    return builder.build();
  }

  /**
   * convert multipartfile to file
   * 
   * @param file
   * @return
   * @throws IOException
   */
  private File multiPartFileToFile(MultipartFile file) throws IOException {
    log.info("[multiPartFileToFile] file to multivalue map");
    File convertedFile = new File(file.getOriginalFilename());
    try (FileOutputStream fos = new FileOutputStream(convertedFile)) {
      fos.write(file.getBytes());
    }
    return convertedFile;
  }

  @Override
  public void deletePost(String userId, String postId)
      throws InterruptedException, ExecutionException, TimeoutException {

        log.info("[deletePost] userId: {}, postId: {}", userId, postId);

    Feed feed = findFeedById(postId);
    // feedDao.getFeed(postId);

    // if (feed == null) {
    // throw new ResourceNotFoundException("Post", "postId", postId);
    // } else
    if (!feed.getUserId().equals(userId)) {

      log.info("[deletePost] userId: {} is not owner of postId: {}", userId, postId);
      throw new BadRequestException("This is not your post so you can not delete this post");

    }
    PostAvro postAvro = postAvroMapper.feedToPostAvro(feed, false);
    producer.producePost(postAvro);

    List<Feed> feeds = feedRepository.getSharedFeeds(postId);
    // feedDao.getSharedFeeds(postId);

    feeds.stream().forEach(feed1 -> {
      try {
        producer.producePost(postAvroMapper.feedToPostAvro(feed1, false));
      } catch (InterruptedException | ExecutionException | TimeoutException e) {
        e.printStackTrace();
      }
    });
  }

  @Override
  public PostResponse updatePost(PostUpdateDto postDto, String userId, List<MultipartFile> media)
      throws IOException, InterruptedException, ExecutionException, TimeoutException {

    log.info("[updatePost] userId: {}, postId: {}", userId, postDto.getId());

    Feed feed = findFeedById(postDto.getId());
    // feedDao.getFeed(postDto.getId());

    if (!userId.equals(feed.getUserId())) {

      log.info("[updatePost] User {} is not owner of postId: {}", userId, postDto.getId());
      throw new BadRequestException("This is not your post, you can not edit this post");
    }
    long currentTime = DateTimeUtils.currentDateTimeUTC();

    List<String> mediaUrls = new ArrayList<>();
    if (media != null && media.size() != 0) {
      mediaUrls = uploadFile(media);
    }

    mediaUrls.addAll(postDto.getMediaUrl());

    PostAvro post = postAvroMapper.toPostAvro(postDto, userId, mediaUrls,
        feed.getCreatedOn(), currentTime, feed.getStatus(),
        feed.getOriginId(), feed.getOrigin(), feed.getPostOf(), true);

    producer.producePost(post);
    return postAvroMapper.toPostResponse(post);


  }

  private Feed findFeedById(String postId) {
    return feedRepository.findById(postId)
        .orElseThrow(() -> new ResourceNotFoundException("post", "id", postId));
  }
}
