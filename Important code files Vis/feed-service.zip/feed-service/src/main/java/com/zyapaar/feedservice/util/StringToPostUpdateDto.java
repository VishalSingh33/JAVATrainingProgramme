package com.zyapaar.feedservice.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.feedservice.dto.PostUpdateDto;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Json string to PostUpdateDto
 * 
 * @author Uday Halpara
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StringToPostUpdateDto implements Converter<String, PostUpdateDto> {

  private final ObjectMapper objectMapper;

  @Override
  public PostUpdateDto convert(String source) {
    log.info("[convert] string to PostDto");
    try {
      return objectMapper.readValue(source, PostUpdateDto.class);
    } catch (JsonProcessingException e) {
      log.info("[convert] Malformed JSON exception");
      throw new BadRequestException("Malformed JSON", e);
    }

  }

}
