package com.zyapaar.feedservice.dto;

import java.util.List;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Post update dto model
 * 
 * @author Uday Halpara
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PostUpdateDto {

  private String id;

  private Content content;

  private String hashTag;

  @NotNull(message = "Please Select Post Type")
  private Type type;

  @NotNull(message = "Please Select Post Privacy")
  private Privacy privacy;

  List<String> mediaUrl;

}
