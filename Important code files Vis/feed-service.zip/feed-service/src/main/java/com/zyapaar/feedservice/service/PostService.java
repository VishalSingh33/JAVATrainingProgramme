package com.zyapaar.feedservice.service;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import com.zyapaar.feedservice.dto.PostDto;
import com.zyapaar.feedservice.dto.PostResponse;
import com.zyapaar.feedservice.dto.PostUpdateDto;

import org.springframework.web.multipart.MultipartFile;

/**
 * post service interface
 */
public interface PostService {

  PostResponse createPost(PostDto postDto, String userId, List<MultipartFile> mediaFiles)
      throws IOException, InterruptedException, ExecutionException, TimeoutException;

  void deletePost(String userId, String postId) throws InterruptedException, ExecutionException,
      TimeoutException;

  PostResponse updatePost(PostUpdateDto postDto, String userId, List<MultipartFile> media)
      throws IOException, InterruptedException, ExecutionException, TimeoutException;

}
