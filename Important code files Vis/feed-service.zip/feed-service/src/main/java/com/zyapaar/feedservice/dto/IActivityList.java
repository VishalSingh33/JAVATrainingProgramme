package com.zyapaar.feedservice.dto;

import org.springframework.stereotype.Component;

@Component
public interface IActivityList {

  String getId();
	String getFeedId();
  String getUserId();
  String getPostOf();
  String getContent();
  String getHashTag();
  String getMediaUrl();
  String getType();
  String getPrivacy();
  String getStatus();
  Long getUpdatedOn();
  Long getCommentCount();
  Long getReactionCount();
  String getUserProfile();
  String getUserName();
  String getUserDesignation();
  String getAboutUser();
  String getReactionId();
  String getReaction();
  Long getViewCount();
  String getUserReaction();
  String getActivityType();
  String getAgeOfPost();
  
}
