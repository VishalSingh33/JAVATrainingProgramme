package com.zyapaar.feedservice.consumer;

import java.util.ArrayList;
import java.util.Objects;
import org.apache.kafka.streams.KeyValue;
import org.springframework.stereotype.Service;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.feedservice.dto.Reaction;
import com.zyapaar.feedservice.dto.UserActivityType;
import com.zyapaar.feedservice.mapper.FeedCommentAvroMapper;
import com.zyapaar.feedservice.mapper.FeedMapper;
import com.zyapaar.feedservice.repo.EntitiesRepostiory;
import com.zyapaar.feedservice.repo.FeedCommentRepository;
import com.zyapaar.serde.CommentAvro;
import com.zyapaar.serde.CommentCountAvro;
import com.zyapaar.serde.CommentReactionAvro;
import com.zyapaar.serde.CommentReactionCountAvro;
import com.zyapaar.serde.CommentReplyCountAvro;
import com.zyapaar.serde.FeedAvro;
import com.zyapaar.serde.FeedCommentAvro;
import com.zyapaar.serde.LastFeedViewCountAvro;
import com.zyapaar.serde.PostAvro;
import com.zyapaar.serde.PostReactionAvro;
import com.zyapaar.serde.PostReactionCountAvro;
import com.zyapaar.serde.UserActivityAvro;
import com.zyapaar.serde.UserIndustryAvro;
import com.zyapaar.serde.UserOverviewAvro;
import com.zyapaar.serde.UserRegistrationAvro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * record builder
 * 
 * @author Uday Halpara
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RecordBuilder {

  private final FeedMapper feedMapper;
  private final FeedCommentAvroMapper feedCommentAvroMapper;
  private final EntitiesRepostiory entitiesRepostiory;
  private final FeedCommentRepository feedCommentRepository;

  public PostReactionCountAvro updatePostReactionCount(PostReactionAvro postReactionAvro,
      PostReactionCountAvro postReactionCountAvro) {
    log.info("[updatePostReactionCount] update post reaction count");
    // postReactionCountAvro.setPostId(postReactionAvro.getPostId());

    switch (String.valueOf(postReactionAvro.getNewReaction())) {
      case "1":
        log.info("[updatePostReactionCount] new like reaction");
        postReactionCountAvro.setLikeCount(postReactionCountAvro.getLikeCount() + 1);
        break;
      case "2":
        log.info("[updatePostReactionCount] new celebrate reaction");
        postReactionCountAvro.setCelebrateCount(postReactionCountAvro.getCelebrateCount() + 1);
        break;
      case "3":
        log.info("[updatePostReactionCount] new interest reaction");
        postReactionCountAvro.setInterestCount(postReactionCountAvro.getInterestCount() + 1);
        break;
      case "4":
        log.info("[updatePostReactionCount] new shackhand reaction");
        postReactionCountAvro.setShakeHandCount(postReactionCountAvro.getShakeHandCount() + 1);
        break;
      case "5":
        log.info("[updatePostReactionCount] new support reaction");
        postReactionCountAvro.setSupportCount(postReactionCountAvro.getSupportCount() + 1);
        break;
      default:
        break;
    }

    switch (String.valueOf(postReactionAvro.getOldReaction())) {
      case "1":
        log.info("[updatePostReactionCount] old like reaction");
        postReactionCountAvro.setLikeCount(postReactionCountAvro.getLikeCount() - 1);
        break;
      case "2":
        log.info("[updatePostReactionCount] old celebrate reaction");
        postReactionCountAvro.setCelebrateCount(postReactionCountAvro.getCelebrateCount() - 1);
        break;
      case "3":
        log.info("[updatePostReactionCount] old interest reaction");
        postReactionCountAvro.setInterestCount(postReactionCountAvro.getInterestCount() - 1);
        break;
      case "4":
        log.info("[updatePostReactionCount] old shackhand reaction");
        postReactionCountAvro.setShakeHandCount(postReactionCountAvro.getShakeHandCount() - 1);
        break;
      case "5":
        log.info("[updatePostReactionCount] old support reaction");
        postReactionCountAvro.setSupportCount(postReactionCountAvro.getSupportCount() - 1);
        break;
      default:
        break;
    }

    if (String.valueOf(postReactionAvro.getOldReaction()).equals(Reaction.NONE.reaction())
        && !String.valueOf(postReactionAvro.getNewReaction()).equals(Reaction.NONE.reaction())) {

      log.info("[updatePostReactionCount] only new reaction added");
      postReactionCountAvro.setCount(postReactionCountAvro.getCount() + 1);

    } else if (!String.valueOf(postReactionAvro.getOldReaction()).equals(Reaction.NONE.reaction())
        && String.valueOf(postReactionAvro.getNewReaction()).equals(Reaction.NONE.reaction())) {

      log.info("[updatePostReactionCount] only old reaction removed");
      postReactionCountAvro.setCount(postReactionCountAvro.getCount() - 1);

    }
    return postReactionCountAvro;
  }

  public CommentReactionCountAvro updateCommentReactionCount(
      CommentReactionAvro commentReactionAvro, CommentReactionCountAvro commentReactionCountAvro) {

    log.info("[updateCommentReactionCount] update post reaction count");
    // commentReactionCountAvro.setCommentId(commentReactionAvro.getCommentId());

    switch (String.valueOf(commentReactionAvro.getNewReaction())) {
      case "1":
        log.info("[updateCommentReactionCount] new like reaction");
        commentReactionCountAvro.setLikeCount(commentReactionCountAvro.getLikeCount() + 1);
        break;
      case "2":
        log.info("[updateCommentReactionCount] new celebrate reaction");
        commentReactionCountAvro
            .setCelebrateCount(commentReactionCountAvro.getCelebrateCount() + 1);
        break;
      case "3":
        log.info("[updateCommentReactionCount] new interest reaction");
        commentReactionCountAvro.setInterestCount(commentReactionCountAvro.getInterestCount() + 1);
        break;
      case "4":
        log.info("[updateCommentReactionCount] new shackhand reaction");
        commentReactionCountAvro
            .setShakeHandCount(commentReactionCountAvro.getShakeHandCount() + 1);
        break;
      case "5":
        log.info("[updateCommentReactionCount] new support reaction");
        commentReactionCountAvro.setSupportCount(commentReactionCountAvro.getSupportCount() + 1);
        break;
      default:
        break;
    }

    switch (String.valueOf(commentReactionAvro.getOldReaction())) {
      case "1":
        log.info("[updateCommentReactionCount] old like reaction");
        commentReactionCountAvro.setLikeCount(commentReactionCountAvro.getLikeCount() - 1);
        break;
      case "2":
        log.info("[updateCommentReactionCount] old celebrate reaction");
        commentReactionCountAvro
            .setCelebrateCount(commentReactionCountAvro.getCelebrateCount() - 1);
        break;
      case "3":
        log.info("[updateCommentReactionCount] old interest reaction");
        commentReactionCountAvro.setInterestCount(commentReactionCountAvro.getInterestCount() - 1);
        break;
      case "4":
        log.info("[updateCommentReactionCount] old shackhand reaction");
        commentReactionCountAvro
            .setShakeHandCount(commentReactionCountAvro.getShakeHandCount() - 1);
        break;
      case "5":
        log.info("[updateCommentReactionCount] old support reaction");
        commentReactionCountAvro.setSupportCount(commentReactionCountAvro.getSupportCount() - 1);
        break;
      default:
        break;
    }

    if (String.valueOf(commentReactionAvro.getOldReaction()).equals(Reaction.NONE.reaction())
        && !String.valueOf(commentReactionAvro.getNewReaction()).equals(Reaction.NONE.reaction())) {

      log.info("[updateCommentReactionCount] only new reaction added");
      commentReactionCountAvro.setCount(commentReactionCountAvro.getCount() + 1);

    } else if (!String.valueOf(commentReactionAvro.getOldReaction())
        .equals(Reaction.NONE.reaction())
        && String.valueOf(commentReactionAvro.getNewReaction()).equals(Reaction.NONE.reaction())) {

      log.info("[updateCommentReactionCount] only old reaction removed");
      commentReactionCountAvro.setCount(commentReactionCountAvro.getCount() - 1);

    }
    return commentReactionCountAvro;
  }

  public FeedCommentAvro updateFeedComment(CommentAvro comment, FeedCommentAvro feedComment) {

    feedCommentAvroMapper.updateComment(comment, feedComment);

    return feedComment;
  }

  public KeyValue<String, UserActivityAvro> buildPostActivity(PostAvro v) {

    Long time = DateTimeUtils.currentDateTimeUTC();

    String id = String.valueOf(v.getId()) + String.valueOf(v.getUserId());

    UserActivityType activityType = UserActivityType.POST_SHARE;
    if (Objects.isNull(v.getPostOf())) {
      activityType = UserActivityType.POST;
    }


    UserActivityAvro avro = UserActivityAvro
        .newBuilder()
        .setId(id)
        .setUserId(v.getUserId())
        .setFeedId(v.getId())
        .setType(activityType.activity())
        .setCreatedOn(time)
        .setUpdatedOn(time)
        .setIsActive(v.getIsActive())
        .build();

    return new KeyValue<String, UserActivityAvro>(id, avro);
  }

  public KeyValue<String, UserActivityAvro> buildPostReactionActivity(PostReactionAvro v) {

    Long time = DateTimeUtils.currentDateTimeUTC();

    String id = String.valueOf(v.getId()) + String.valueOf(v.getUserId());

    Boolean isActive = true;
    if (String.valueOf(v.getNewReaction()).equals("0")) {
      isActive = false;
    }

    UserActivityAvro avro = UserActivityAvro
        .newBuilder()
        .setId(id)
        .setUserId(v.getUserId())
        .setFeedId(v.getPostId())
        .setReaction(v.getNewReaction())
        .setType(UserActivityType.POST_REACTION.activity())
        .setCreatedOn(time)
        .setUpdatedOn(time)
        .setIsActive(isActive)
        .build();

    return new KeyValue<String, UserActivityAvro>(id, avro);
  }

  public KeyValue<String, UserActivityAvro> buildCommentActivity(CommentAvro v) {

    Long time = DateTimeUtils.currentDateTimeUTC();

    String id = String.valueOf(v.getId()) + String.valueOf(v.getUserId());

    String activityType;
    if (v.getReplyOf() == null || v.getReplyOf().length() == 0) {
      activityType = UserActivityType.COMMENT.activity();
    } else {
      activityType = UserActivityType.COMMENT_REPLY.activity();
    }

    UserActivityAvro avro = UserActivityAvro
        .newBuilder()
        .setId(id)
        .setUserId(v.getUserId())
        .setFeedId(v.getPostId())
        .setType(activityType)
        .setCreatedOn(time)
        .setUpdatedOn(time)
        .setIsActive(v.getIsActive())
        .build();

    return new KeyValue<String, UserActivityAvro>(id, avro);

  }

  public KeyValue<String, UserActivityAvro> buildCommentReactionActivity(CommentReactionAvro v) {

    Long time = DateTimeUtils.currentDateTimeUTC();

    String id = String.valueOf(v.getId()) + String.valueOf(v.getUserId());

    Boolean isActive = true;
    if (String.valueOf(v.getNewReaction()).equals("0")) {
      isActive = false;
    }

    UserActivityAvro avro = UserActivityAvro
        .newBuilder()
        .setId(id)
        .setUserId(v.getUserId())
        .setFeedId(v.getPostId())
        .setReaction(v.getNewReaction())
        .setType(UserActivityType.COMMENT_REACTION.activity())
        .setCreatedOn(time)
        .setUpdatedOn(time)
        .setIsActive(isActive)
        .build();

    return new KeyValue<String, UserActivityAvro>(id, avro);
  }

  public UserOverviewAvro buildUserOverView(PostAvro a, UserOverviewAvro b) {
    if (a.getIsActive()) {
      b.setPost(b.getPost() + 1);
    } else {
      b.setPost(b.getPost() - 1);
    }

    return b;
  }

  public FeedAvro buildFeed(PostAvro post, UserRegistrationAvro user) {

    // Company company = userDao.getCompany(user.getCompanies().get(0).toString());
    String companyName = entitiesRepostiory.getNameOfCompany(String.valueOf(user.getId()));

    return feedMapper.toFeedAvro(post, user.getFullName(), user.getProfileImg(),
        user.getProfileTitle(), user.getAboutUs(), new ArrayList<String>(), new ArrayList<String>(),
        companyName);
  }

  public FeedAvro addFeedIndustry(FeedAvro feed, UserIndustryAvro usersIndustry) {
    feed.setIndustries(usersIndustry.getSaleIndustry());
    return feed;
  }

  public FeedCommentAvro buildFeedComment(CommentAvro comment, UserRegistrationAvro user) {
    return feedCommentAvroMapper.toFeedCommentAvro(comment, user.getFullName(),
        user.getProfileImg(), user.getProfileTitle());
  }

  public FeedAvro updateFeed(CommentCountAvro commentCount, FeedAvro feed) {
    feed.setCommentCount(commentCount.getCount());
    return feed;
  }

  public FeedAvro updateFeed(PostReactionCountAvro postReactionCount, FeedAvro feed) {
    feed.setReactionCount(postReactionCount.getCount());
    feed.setViewCount(postReactionCount.getViewCount());
    return feed;
  }

  public FeedCommentAvro updateFeedComment(CommentReactionCountAvro commentReactionCount,
      FeedCommentAvro comment) {
    comment.setReactionCount(commentReactionCount.getCount());
    return comment;
  }

  public FeedCommentAvro updateFeedComment(CommentReplyCountAvro commentReplyCount,
      FeedCommentAvro comment) {
    comment.setReplyCount(commentReplyCount.getReplyCount());
    return comment;
  }

  public KeyValue<String, LastFeedViewCountAvro> buildFeedViewCount(PostAvro v) {

    var viewCount = LastFeedViewCountAvro.newBuilder()
        .setUserId(v.getUserId())
        .setPostId(v.getId())
        .setId(v.getUserId())
        .build();

    return new KeyValue<String, LastFeedViewCountAvro>(String.valueOf(viewCount.getUserId()), viewCount);
  }

  public LastFeedViewCountAvro updateFeedViewCount(PostReactionCountAvro postReactionCountAvro,
      LastFeedViewCountAvro viewCount) {

    viewCount.setCount(postReactionCountAvro.getViewCount());

    return viewCount;
  }

  public UserOverviewAvro updateUserOverView(LastFeedViewCountAvro feedView,
      UserOverviewAvro userOverView) {

    userOverView.setViewOnLastPost(feedView.getCount());

    return userOverView;
  }

  public FeedAvro updateFeed(PostAvro post, FeedAvro feed) {

    feedMapper.updateFeed(post, feed);
    feed.setUpdatedOn(DateTimeUtils.currentDateTimeUTC());

    return feed;
  }

  public CommentReplyCountAvro buildCommentReplyCount(CommentAvro comment,
      CommentReplyCountAvro commentRepplyCount) {

    if (commentRepplyCount == null) {

      return CommentReplyCountAvro.newBuilder().setCommentId(comment.getReplyOf()).setReplyCount(1).build();

    } else {

      if (comment.getIsActive()) {
        commentRepplyCount.setReplyCount(commentRepplyCount.getReplyCount() + 1);
      } else {
        commentRepplyCount.setReplyCount(commentRepplyCount.getReplyCount() - 1);
      }

    }

    return commentRepplyCount;
  }

  public CommentCountAvro updateCommentCount(CommentAvro comment, CommentCountAvro commentCount) {

    Long count = commentCount.getCount();

    if (comment.getIsActive()) {
      count ++;
    } else {
      Long replyCount = feedCommentRepository.countByReplyOfAndIsActiveTrue(String.valueOf(comment.getId()));
      // commentDao.getReplyCommentCount(comment.getId().toString());
      log.info("[updateCommentCount] commentCount : {}, replyCount : {}", commentCount, replyCount);
      count -= 1 + replyCount;
    }
    commentCount.setCount(count);
    return commentCount;

  }


  public FeedAvro updateTimeStamp(CommentAvro comment, FeedAvro feed) {
    feed.setUpdatedOn(DateTimeUtils.currentDateTimeUTC());
    return feed;
  }

  public FeedAvro updateTimeStamp(PostReactionAvro postReaction, FeedAvro feed) {
    feed.setUpdatedOn(DateTimeUtils.currentDateTimeUTC());
    return feed;
  }

  public FeedAvro updateTimeStamp(CommentReactionAvro commentReaction, FeedAvro feed) {
    feed.setUpdatedOn(DateTimeUtils.currentDateTimeUTC());
    return feed;
  }

}
