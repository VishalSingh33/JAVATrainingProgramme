package com.zyapaar.feedservice.util;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.zyapaar.commons.dto.Attribute;
import com.zyapaar.commons.dto.Mention;
import com.zyapaar.commons.dto.NotificationContent;

/**
 * Notification utils
 * 
 * @author Uday Halpara
 */
@Component
public class NotificationUtils {

  public NotificationContent getNotificationMessageContent(String messageFormat, String userId,
      String fullName, String userImg, String message) {

    String msg = MessageFormat.format(messageFormat, fullName, message);

    NotificationContent content = new NotificationContent();
    content.setText(msg);

    List<Attribute> attributes = new ArrayList<>();

    int firstVarIndex = msg.indexOf(fullName);
    int firstVarLength = fullName.length();

    attributes.add(new Attribute(firstVarIndex, firstVarLength, userId, Mention.PROFILE, userImg));

    content.setAttributes(attributes);

    return content;
  }

}
