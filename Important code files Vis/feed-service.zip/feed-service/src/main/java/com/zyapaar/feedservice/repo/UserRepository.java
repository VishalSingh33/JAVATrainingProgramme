package com.zyapaar.feedservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.entities.User;

@Repository
public interface UserRepository extends JpaRepository<User, String>{

  @Query(nativeQuery = true,
  value ="select " + 
    "concat( case e.nature_of_business  when 1 then 'Manufacturing' " + 
    "when 2 then 'Trader' " + 
    "when 3 then 'Service Provider' " + 
    "when 4 then 'Works Contract' " + 
    "when 5 then 'Freelancer' " + 
    "when 6 then 'Non-profit Organization' " + 
    "when 7 then 'Others' " + 
    "end,' - ', e.city) " + 
    "from users u " + 
    "left join entity_invite ei ON u.id = ei.user_id " + 
    "left join entities e on ei.entities_id = e.id " + 
    "where u.id = :userId and ei.status = 'accept' " + 
    "order by ei.is_admin desc, ei.updated_on asc limit 1 ")
  String getUserTitle(String userId);
  
}
