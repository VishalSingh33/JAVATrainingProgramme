package com.zyapaar.feedservice.consumer;

import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Materialized;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;

import com.zyapaar.feedservice.properties.B2bProperties;
import com.zyapaar.serde.CommentAvro;
import com.zyapaar.serde.CommentCountAvro;
import com.zyapaar.serde.CommentReactionAvro;
import com.zyapaar.serde.CommentReactionCountAvro;
import com.zyapaar.serde.CommentReplyCountAvro;
import com.zyapaar.serde.FeedAvro;
import com.zyapaar.serde.FeedCommentAvro;
import com.zyapaar.serde.HashTagCountAvro;
import com.zyapaar.serde.HashTagsAvro;
import com.zyapaar.serde.LastFeedViewCountAvro;
import com.zyapaar.serde.PostAvro;
import com.zyapaar.serde.PostReactionAvro;
import com.zyapaar.serde.PostReactionCountAvro;
import com.zyapaar.serde.UserIndustryAvro;
import com.zyapaar.serde.UserOverviewAvro;
import com.zyapaar.serde.UserRegistrationAvro;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * stream class
 * 
 * @author UDaY HaLPaRa
 */
@Component
@RequiredArgsConstructor
@EnableBinding(ConsumerBinding.class)
@Slf4j
public class Consumers {

  private final B2bProperties b2bProperties;
  private final RecordBuilder recordBuilder;

  /**
   * streams
   */
  @StreamListener
  public void process(
      @Input("user-channel") KTable<String, UserRegistrationAvro> userKTable,
      @Input("post-generate-channel") KStream<String, PostAvro> postProcess,
      @Input("feed-generate-channel") KTable<String, FeedAvro> feedKtable,
      @Input("feed-comment-generate-channel") KTable<String, FeedCommentAvro> feedCommentKtable,
      @Input("post-reaction-generate-channel") KStream<String, PostReactionAvro> postReactionStream,
      @Input("comment-reaction-generate-channel") KStream<String, CommentReactionAvro> commentReactionStream,
      @Input("comment-generate-channel") KStream<String, CommentAvro> commentKStream,
      @Input("comment-count-generate-channel") KStream<String, CommentCountAvro> commentCountProcess,
      @Input("post-reaction-count-generate-channel") KStream<String, PostReactionCountAvro> postReactionCountProcess,
      @Input("comment-reaction-count-generate-channel") KStream<String, CommentReactionCountAvro> commentReactionCountProcess,
      @Input("hash-tags-channel") KStream<String, HashTagsAvro> hashTagsStream,
      @Input("comment-reply-count-channel") KStream<String, CommentReplyCountAvro> commentReplyCountStream,
      @Input("user-overview-channel") KTable<String, UserOverviewAvro> userOverviewStream,
      @Input("users-wise-industry-channel") KTable<String, UserIndustryAvro> usersIndustryKTable,
      @Input("last-post-view-count-channel") KStream<String, LastFeedViewCountAvro> feedViewCount

  ) {

    log.info("[process] stream processing");

    // Create post user activity build
    postProcess
        .filter((k, v) -> Boolean.FALSE.equals(v.getIsUpdate()))
        .map((k, v) -> recordBuilder.buildPostActivity(v))
        .to(b2bProperties.getTopic().getUserActivity());

    // post user overview post count update
    postProcess
        .filter((k, v) -> Boolean.FALSE.equals(v.getIsUpdate()))
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getUserId()), v))
        .join(userOverviewStream, (a, b) -> recordBuilder.buildUserOverView(a, b))
        .to(b2bProperties.getTopic().getUserOverview());

    // post to feed
    postProcess
        .filter((k, v) -> Boolean.FALSE.equals(v.getIsUpdate()) && v.getIsActive())
        .peek((k, v) -> log.info("new post arrived : {}", v))
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getUserId()), v))
        .join(userKTable, 
            (post, user) -> recordBuilder.buildFeed(post, user))
        .peek((k, v) -> log.info("new post arrived after user data added : {}", v))
        .join(usersIndustryKTable,
            (feed, usersIndustry) -> recordBuilder.addFeedIndustry(feed, usersIndustry))
        .peek((k, v) -> log.info("new post arrived after user industry data added : {}", v))
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getId()), v))
        .to(b2bProperties.getTopic().getFeed());

    // Update feed content
    postProcess
        .filter((k, v) -> v.getIsUpdate() || Boolean.FALSE.equals(v.getIsActive()))
        .join(feedKtable,
            (post, feed) -> recordBuilder.updateFeed(post, feed))
        .to(b2bProperties.getTopic().getFeed());

    // Initialize the post reaction count
    postProcess
        .filter((k, v) -> Boolean.FALSE.equals(v.getIsUpdate()) && v.getIsActive())
        .map((k, v) -> new KeyValue<>(k, PostReactionCountAvro.newBuilder().setPostId(k).build()))
        .to(b2bProperties.getTopic().getPostReactionCount());

    // Initialize post comment count
    postProcess
        .filter((k, v) -> Boolean.FALSE.equals(v.getIsUpdate()) && v.getIsActive())
        .map((k, v) -> new KeyValue<>(k, CommentCountAvro.newBuilder().setPostId(k).build()))
        .to(b2bProperties.getTopic().getCommentCount());

    // Initialize last post view count
    postProcess
        .filter((k, v) -> v.getIsActive() && Boolean.FALSE.equals(v.getIsUpdate()))
        .map((k, v) -> recordBuilder.buildFeedViewCount(v))
        .to(b2bProperties.getTopic().getLastPostViewCount());

    // Update last post view count
    postReactionCountProcess
        .join(
            feedViewCount.map((k, v) -> new KeyValue<>(String.valueOf(v.getPostId()), v)).toTable(),
            (postReactionCount, viewCount) -> recordBuilder.updateFeedViewCount(postReactionCount,
                viewCount))
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getUserId()), v))
        .to(b2bProperties.getTopic().getLastPostViewCount());

    // User overview data update user last post view count
    feedViewCount
        .join(userOverviewStream,
            (feedView, userOverView) -> recordBuilder.updateUserOverView(feedView, userOverView))
        .to(b2bProperties.getTopic().getUserOverview());


    // Initialize comment reaction count
    commentKStream
        .filter((k, v) -> Boolean.FALSE.equals(v.getIsUpdate()) && v.getIsActive())
        .mapValues(v -> CommentReactionCountAvro.newBuilder().setCommentId(v.getId()).build())
        .to(b2bProperties.getTopic().getCommentReactionCount());

    // Post comment count
    commentKStream
        .filter((k, v) -> Boolean.FALSE.equals(v.getIsUpdate()))
        .map((key, value) -> new KeyValue<>(String.valueOf(value.getPostId()), value))
        .join(commentCountProcess.toTable(),
            (comment, commentCount) -> recordBuilder.updateCommentCount(comment, commentCount))
        .to(b2bProperties.getTopic().getCommentCount());

    // feed update dateTime for comment
    commentKStream
        .filter((key, value) -> value.getIsActive())
        .map((key, value) -> new KeyValue<>(String.valueOf(value.getPostId()), value))
        .join(feedKtable, (comment, feed) -> recordBuilder.updateTimeStamp(comment, feed))
        .to(b2bProperties.getTopic().getFeed());

    // feed update dateTime for post reaction
    postReactionStream
        .map((key, value) -> new KeyValue<>(String.valueOf(value.getPostId()), value))
        .join(feedKtable, (postReaction, feed) -> recordBuilder.updateTimeStamp(postReaction, feed))
        .to(b2bProperties.getTopic().getFeed());

    // feed update dateTime for post reaction
    commentReactionStream
        .map((key, value) -> new KeyValue<>(String.valueOf(value.getPostId()), value))
        .join(feedKtable,
            (commentReaction, feed) -> recordBuilder.updateTimeStamp(commentReaction, feed))
        .to(b2bProperties.getTopic().getFeed());

    // Comment to feed comment builder
    commentKStream
        .filter((k, v) -> Boolean.FALSE.equals(v.getIsUpdate()) && v.getIsActive())
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getUserId()), v))
        .join(userKTable, (comment, user) -> recordBuilder.buildFeedComment(comment, user))
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getId()), v))
        .to(b2bProperties.getTopic().getFeedComment());

    // Update feed comment
    commentKStream
        .filter((k, v) -> v.getIsUpdate() || Boolean.FALSE.equals(v.getIsActive()))
        .join(feedCommentKtable,
            (comment, feedComment) -> recordBuilder.updateFeedComment(comment, feedComment))
        .to(b2bProperties.getTopic().getFeedComment());

    // Comment reply count
    commentKStream
        .filter((k,v) -> (v.getReplyOf() != null && v.getReplyOf().length() != 0
                && Boolean.FALSE.equals(v.getIsUpdate())))
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getReplyOf()), v))
        .leftJoin(commentReplyCountStream.toTable(), 
            (comment, commentRepplyCount) -> recordBuilder
                .buildCommentReplyCount(comment, commentRepplyCount))
        .to(b2bProperties.getTopic().getCommentReplyCount());

    // comment reaction count
    commentReactionStream
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getCommentId()), v))
        .join(commentReactionCountProcess.toTable(),
            (reaction, count) -> recordBuilder.updateCommentReactionCount(reaction, count))
        .to(b2bProperties.getTopic().getCommentReactionCount());

    // comment count set to feed object
    commentCountProcess
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getPostId()), v))
        .join(feedKtable.filter((k, v) -> v.getIsActive()),
            (commentCount, feed) -> recordBuilder.updateFeed(commentCount, feed))
        .to(b2bProperties.getTopic().getFeed());

    // post reaction count set to feed object
    postReactionCountProcess
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getPostId()), v))
        .join(feedKtable.filter((k, v) -> v.getIsActive()),
            (postReactionCount, feed) -> recordBuilder.updateFeed(postReactionCount, feed))
        .to(b2bProperties.getTopic().getFeed());

    // comment reaction count set to feed comment object
    commentReactionCountProcess
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getCommentId()), v))
        .join(feedCommentKtable, (commentReactionCount, comment) -> recordBuilder
            .updateFeedComment(commentReactionCount, comment))
        .to(b2bProperties.getTopic().getFeedComment());

    // comment reply count to feed comment
    commentReplyCountStream
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getCommentId()), v))
        .join(feedCommentKtable, (commentReplyCount, comment) -> recordBuilder
            .updateFeedComment(commentReplyCount, comment))
        .to(b2bProperties.getTopic().getFeedComment());

    // For post reaction user activity
    postReactionStream
        .map((k, v) -> recordBuilder.buildPostReactionActivity(v))
        .to(b2bProperties.getTopic().getUserActivity());

    // For comment user activity
    commentKStream
        .filter((k, v) -> Boolean.FALSE.equals(v.getIsUpdate()))
        .map((k, v) -> recordBuilder.buildCommentActivity(v))
        .to(b2bProperties.getTopic().getUserActivity());

    // For comment reaction user activity
    commentReactionStream
        .map((k, v) -> recordBuilder.buildCommentReactionActivity(v))
        .to(b2bProperties.getTopic().getUserActivity());

    // Hashatag streams
    hashTagsStream
        .groupByKey()
        .count()
        .toStream()
        .map((k, v) -> new KeyValue<>(k, new HashTagCountAvro(k, v)))
        .to(b2bProperties.getTopic().getHashTagCount());

    // Post reaction count
    postReactionStream.map((k, v) -> new KeyValue<>(String.valueOf(v.getPostId()), v))
        .join(postReactionCountProcess.toTable(),
            (reaction, count) -> recordBuilder.updatePostReactionCount(reaction, count))
        .to(b2bProperties.getTopic().getPostReactionCount());

    postReactionStream
        .toTable(Materialized.as(b2bProperties.getStore().getPostReactionStore()));

    commentReactionStream
        .toTable(Materialized.as(b2bProperties.getStore().getCommentReactionStore()));

    postReactionCountProcess
        .toTable(Materialized.as(b2bProperties.getStore().getPostReactionCountStore()));

  }
}
