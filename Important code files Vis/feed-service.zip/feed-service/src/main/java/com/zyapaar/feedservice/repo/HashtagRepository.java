package com.zyapaar.feedservice.repo;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.dto.IHashTagsDto;
import com.zyapaar.feedservice.entities.Hashtag;

@Repository
public interface HashtagRepository extends JpaRepository<Hashtag, String> {

  @Query(nativeQuery = true, value = "select h.id as key, h.count as count from hashtag h")
  List<IHashTagsDto> getListOrderedBy(Pageable page);


}
