package com.zyapaar.feedservice.response;

import lombok.Data;

/**
 * Reaction count response
 * 
 * @author Uday Halpara
 */
@Data
public class ReactionCountResponse {

  private String postId;
  private String commentId;
  private Long count;
  private Long likeCount;
  private Long celebrateCount;
  private Long interestCount;
  private Long shakeHandCount;
  private Long supportCount;

}
