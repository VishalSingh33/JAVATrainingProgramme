package com.zyapaar.feedservice.model;

import java.util.List;

import org.springframework.data.annotation.Id;
// import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Builder;
import lombok.Data;

/**
 * Mongo db model class
 * 
 * @author Uday halpara
 */

@Builder
@Data
// @Document(collection = "feeds")
public class Feed {

  @Id
  private String id;
  private String userId;
  private String postOf;
  private String content;
  private String hashTag;
  private List<String> mediaUrl;
  private String type;
  private String privacy;
  private String status;
  private Long createdOn;
  private Long updatedOn;
  private String ageOfPost;
  private Long commentCount;
  private Long reactionCount;
  private String userProfile;
  private String userName;
  private String userDesignation;
  private List<String> sendTo;
  private String aboutUser;
  private Long viewCount;
  private Boolean isActive;
  private Boolean isHide;
  private List<String> industries;
  private String origin;
  private String originId;
  private String userCompany;
  
}
