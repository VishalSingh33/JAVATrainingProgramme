package com.zyapaar.feedservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * notification setting model
 * 
 * @author Uday Halpara
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationSettings {

  private GroupNotification groupNotification;
  private ProfileViewNotification profileViewNotification;
  private CommentNotification commentNotification;
  private TagNotification tagNotification;
  private MessageOfflineNotification messageOfflineNotification;
  private CompanyPageNotification companyPageNotification;
  private TeamMemberRequestNotification teamMemberRequestNotification;
  private BusinessPageNotification businessPageNotification;
  private GroupsNotification groupsNotification;
  private RecommendNotification recommendNotification;
  private EventNotification eventNotification;
  private LoginReminderNotification loginReminderNotification;
  private NetworkProfile networkProfile;
  private PostDelivery postDelivery;

  @Data
  public static class GroupNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class ProfileViewNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class CommentNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class TagNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class MessageOfflineNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class CompanyPageNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class TeamMemberRequestNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class BusinessPageNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class GroupsNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Getter
  @Setter
  public static class RecommendNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class EventNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  @Data
  public static class LoginReminderNotification {
    private Boolean isActive;
    private Boolean push;
    private Boolean email;
  }

  public static enum NetworkProfile {
    PUBLIC_PROFILE("1"),
    PRIVATE_PROFILE("2");

    private final String networkProfile;

    NetworkProfile(String networkProfile) {
      this.networkProfile = networkProfile;
    }

    public String networkProfile() {
      return networkProfile;
    }

    public static NetworkProfile fromString(String text) {
      for (NetworkProfile b : NetworkProfile.values()) {
        if (b.networkProfile.equalsIgnoreCase(text)) {
          return b;
        }
      }
      return null;
    }
  }

  public static enum PostDelivery {
    ANYONE("1"),
    CONNECTION_ONLY("2");

    private final String postDelivery;

    PostDelivery(String postDelivery) {
      this.postDelivery = postDelivery;
    }

    public String postDelivery() {
      return postDelivery;
    }

    public static PostDelivery fromString(String text) {
      for (PostDelivery b : PostDelivery.values()) {
        if (b.postDelivery.equalsIgnoreCase(text)) {
          return b;
        }
      }
      return null;
    }
  }
}
