package com.zyapaar.feedservice.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.feedservice.dto.PostDto;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Json String to PostDto converter
 * 
 * @author Uday Halpara
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StringToPostDto implements Converter<String, PostDto> {

  private final ObjectMapper objectMapper;

  @Override
  public PostDto convert(String source) {
    log.info("[convert] string to PostDto");
    try {
      return objectMapper.readValue(source, PostDto.class);
    } catch (JsonProcessingException e) {
      log.info("[convert] Malformed JSON exception");
      throw new BadRequestException("Malformed JSON", e);
    }
  }
}
