package com.zyapaar.feedservice.service;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.zyapaar.commons.dto.NotificationContent;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.feedservice.dto.BlockOrigin;
import com.zyapaar.feedservice.dto.BlockedStatus;
import com.zyapaar.feedservice.dto.IActivityList;
import com.zyapaar.feedservice.dto.MessageDto;
import com.zyapaar.feedservice.entities.User;
import com.zyapaar.feedservice.mapper.ActivityMapper;
import com.zyapaar.feedservice.mapper.NotificationMapper;
import com.zyapaar.feedservice.producer.Producer;
import com.zyapaar.feedservice.properties.B2bProperties;
import com.zyapaar.feedservice.repo.BlockUserRepository;
import com.zyapaar.feedservice.repo.UserActivityRepository;
import com.zyapaar.feedservice.repo.UserRepository;
import com.zyapaar.feedservice.util.NotificationUtils;
import com.zyapaar.serde.NotificationV2Avro;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Manage activity service
 * 
 * @author Uday Halpara
 * @author Neel Shah
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ManageActivityService implements ActivityService {

  private final NotificationUtils notificationUtils;
  private final Producer producer;
  private final B2bProperties b2bProperties;
  private final NotificationMapper notificationMapper;
  private final UserRepository userRepository;
  private final UserActivityRepository userActivityRepository;
  private final ActivityMapper activityMapper;
  private final BlockUserRepository blockUserRepository;

  @Override
  public ListingResponse getUserActivity(String userId, ListingRequest request, String id) {

    if (id == null) {
      id = userId;
    }else{
      
      if(blockUserRepository.isBlockedUser(userId, id, BlockedStatus.BLOCKED.status(), 
        BlockOrigin.USER.origin())){
        log.info("[getUserActivity] authUserId: {}, userId: {} is blocked", userId, id);
        throw new BadRequestException("User profile is blocked for you");
      }
    }

    log.info("[getUserActivity] request for activity list of user with id id {} by userId: {}",id, userId);

    Pageable requestedPage =
        PageRequest.of(request.getPage(), b2bProperties.getPaging().getActivitySize());
    // Sort.by(Direction.DESC, "createdOn"));
    List<IActivityList> activitys = userActivityRepository.getUserActivity(id, 
        BlockedStatus.BLOCKED.status(), BlockOrigin.USER.origin(), requestedPage);
    // activityDao.getUserActivity(id, request.getPage());

    // log.info



    // for (IActivityList feed : activitys) {
    // feed.setAgeOfPost(TimeCount.timeFromUpload(feed.getUpdatedOn()));
    // //feed.setAgeOfPost(TimeCount.timeFromUpload(feed.getUpdatedOn()));
    // // PostReaction postReaction = postReactionRepository.findByUserIdAndPostId(userId,
    // feed.getFeedId());
    // // // PostReaction postReaction = reactionDao.getPostReaction(userId, feed.getFeedId());
    // // // if (postReaction != null) {
    // // if (!ObjectUtils.isEmpty(postReaction)) {
    // // feed.setReaction(postReaction.getNewReaction());
    // // feed.setReactionId(postReaction.getId());
    // // }
    // }

    return new ListingResponse(activityMapper.toActivityList(activitys), request.getPage());
  }

  @Override
  public void sendMessage(String userId, MessageDto messageDto)
      throws InterruptedException, ExecutionException, TimeoutException {

    log.info("[sendMessage] userId: {}, messageDto: {}", userId, messageDto);

    if(blockUserRepository.isBlockedUser(userId, messageDto.getUserId(), BlockedStatus.BLOCKED.status(), 
        BlockOrigin.USER.origin())){
        log.info("[sendMessage] authUserId: {}, userId: {} is blocked", userId, messageDto.getUserId());
        throw new BadRequestException("User profile is blocked for you");
    }

    long currentTime = DateTimeUtils.currentDateTimeUTC();

    User user = findUserById(userId);
    // userDao.getUser(userId);


    NotificationContent content = notificationUtils.getNotificationMessageContent(
        b2bProperties.getNotificationMsg().getMessage(), userId, user.getFullName(), user.getImg(),
        messageDto.getMessage());

    NotificationV2Avro notification =
        notificationMapper.toNotificationV2Avro(SequenceGenerator.getInstance().nextId(),
            messageDto.getUserId(), NotificationTypes.MESSAGE, content, currentTime, currentTime);

    producer.produceNotificationV2(notification);

  }

  User findUserById(String userId) {
    User user = userRepository.findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException("user", "id", userId));
    return user;
  }

}
