package com.zyapaar.feedservice.repository;

import java.util.Optional;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

public interface EmitterRepository {

  void remove(String userId);

  void addOrReplaceEmitter(String userId, SseEmitter sseEmitter);

  Optional<SseEmitter> get(String userId);
  
}
