package com.zyapaar.feedservice.mapper;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyapaar.feedservice.dto.CommentDto;
import com.zyapaar.feedservice.dto.CommentUpdateDto;
import com.zyapaar.feedservice.dto.Content;
import com.zyapaar.feedservice.entities.FeedComment;
import com.zyapaar.serde.CommentAvro;

/**
 * commentAvro mapper class
 * 
 * @author Uday Halpara
 */
@Mapper
public interface CommentAvroMapper {

  ObjectMapper objectMapper = new ObjectMapper();

  CommentAvro toCommentAvro(CommentDto commentDto, String postId,
      String userId, long createdOn, long updatedOn);//isActive,isUpdate

  default CharSequence map(Content value) throws JsonProcessingException {
    return objectMapper.writeValueAsString(value);
  }

  CommentAvro toCommentAvro(CommentUpdateDto commentDto, String postId, String userId, String replyOf,
      Long createdOn, Long updatedOn, Boolean isUpdate); //isActive

  @Mapping(target = "isActive", constant = "false")
  CommentAvro feedToCommentAvro(FeedComment feed);//isUpdate


  List<CommentAvro> feedToCommentAvro(List<FeedComment> feed);


  @Mapping(target = "isActive", source = "isActive")//isUpdate
  CommentAvro feedToCommentAvro(FeedComment feed, Boolean isActive);

}
