package com.zyapaar.feedservice.service;

import com.zyapaar.feedservice.repository.EmitterRepository;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class ManageFeedEmitterService implements FeedEmitterService {

  private final long eventsTimeout = 1000000L;
  private final EmitterRepository emitterRepository;

  @Override
  public SseEmitter createEmitter(String userId) {

    log.info("[createEmitter] create emitor to produce data");

    SseEmitter sseEmitter = new SseEmitter(eventsTimeout);
    sseEmitter.onCompletion(() -> emitterRepository.remove(userId));
    sseEmitter.onTimeout(() -> emitterRepository.remove(userId));
    sseEmitter.onError(e -> {
      log.info("Create SseEitter exception", e);
      emitterRepository.remove(userId);
    });
    emitterRepository.addOrReplaceEmitter(userId, sseEmitter);
    return sseEmitter;
  }

}
