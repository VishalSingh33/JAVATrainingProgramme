package com.zyapaar.feedservice.repo;

import com.zyapaar.feedservice.entities.LeadsCount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LeadsCountRepostiory extends JpaRepository<LeadsCount, String>{
  
}
