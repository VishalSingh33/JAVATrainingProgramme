package com.zyapaar.feedservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="feed_comment")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FeedComment {

	@Id
	private String id;

	private String content;

	@Column(name="created_on")
	private Long createdOn;

	@Column(name="is_active")
	private Boolean isActive;

	@Column(name="is_hide")
	private Boolean isHide;

	@Column(name="post_id")
	private String postId;

	@Column(name="reaction_count")
	private Long reactionCount;

	@Column(name="reply_count")
	private Long replyCount;

	@Column(name="reply_of")
	private String replyOf;

	@Column(name="updated_on")
	private Long updatedOn;

	@Column(name="user_designation")
	private String userDesignation;

	@Column(name="user_id")
	private String userId;

	@Column(name="user_name")
	private String userName;

	@Column(name="user_profile")
	private String userProfile;

}