package com.zyapaar.feedservice.dto;

import org.springframework.stereotype.Component;

@Component
public interface IFeedCommentDto {

  String getId();
  String getPostId();
  String getUserId();
  String getContent();
  String getReplyOf();
  Long getCreatedOn();
  Long getUpdatedOn();
  Long getReactionCount();
  Long getReplyCount();
  String getUserDesignation();
  String getUserName();
  String getUserProfile();
  String getAgeOfComment();
  String getReactionId();
  String getReaction();
  Boolean getIsActive();
  
}
