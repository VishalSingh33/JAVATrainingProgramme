package com.zyapaar.feedservice.mapper;

import com.zyapaar.feedservice.dto.Reaction;
import com.zyapaar.feedservice.dto.ReactionDto;
import com.zyapaar.serde.PostReactionAvro;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;

/**
 * reaction avro mapper class
 * 
 * @author Uday Halpara
 */
@Mapper
public interface PostReactionAvroMapper {

  @Mapping(target = "oldReaction", source = "postReactionDto.oldReaction", 
      nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(target = "newReaction", source = "postReactionDto.newReaction", 
      nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  PostReactionAvro toPostReactionAvro(ReactionDto postReactionDto,String userId,String postId,
      long createdOn, long updatedOn);

  default CharSequence map(Reaction value) {
    return value.reaction();
  }
  
}
