package com.zyapaar.feedservice.request;

/**
 * RequestReaction enum
 * 
 * @author Uday Halpara
 */
public enum RequestReaction {

  ALL("0"),
  LIKE("1"),
  CELEBRATE("2"),
  INTEREST("3"),
  SHAKEHANDS("4"),
  SUPPORT("5");

  private final String reaction;

  RequestReaction(String reaction) {
    this.reaction = reaction;
  }

  public String reaction() {
    return reaction;
  }
}
