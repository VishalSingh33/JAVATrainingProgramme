package com.zyapaar.feedservice.service;

import java.util.List;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.feedservice.dto.IHashTagsDto;
import com.zyapaar.feedservice.properties.B2bProperties;
import com.zyapaar.feedservice.repo.HashtagRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Manage hash tag service
 * 
 * @author Uday Halpara
 * @author Neel Shah
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ManageHashTagService implements HashTagService {

  private final HashtagRepository hashtagRepository;
  private final B2bProperties b2bProperties;

  @Override
  public ListingResponse getHashTags(ListingRequest request) {

    log.info("[getHashTags]");

    // Page<HashTags> list = hashTagDao.getHashTags(request.getPage());
    Pageable requestedPage =
        PageRequest.of(request.getPage(), b2bProperties.getPaging().getHashTagSize(),
        Sort.by(Direction.DESC, "count"));

    List<IHashTagsDto> list = hashtagRepository.getListOrderedBy(requestedPage);

    // List<IHashTagsDto> data = hashTagMapper.toHashTagsDtos(list);
    // List<HashTagsDto> data = hashTagMapper.toHashTagsDtos(list.getContent());

    return new ListingResponse(list, request.getPage());
  }

}
