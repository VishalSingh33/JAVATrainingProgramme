package com.zyapaar.feedservice.controller;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import javax.validation.Valid;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.model.ApiError;
import com.zyapaar.feedservice.dto.CommentDto;
import com.zyapaar.feedservice.dto.CommentResponse;
import com.zyapaar.feedservice.dto.CommentUpdateDto;
import com.zyapaar.feedservice.service.CommentService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * comment controller
 * 
 * @author Uday Halpara
 */
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@CrossOrigin("*")
@Tag(name = "Comment APIs")
@Slf4j
public class CommentController {

  private final CommentService commentService;

  /**
   * create comment
   */
  @Operation(
    description = "This comments service works to create comment use comments service which"
        +" contains model class (CommentDto)CommentDto has id, content, replyOf",
    responses = {
        @ApiResponse(content = @Content(schema = @Schema(implementation = Response.class)),
            responseCode = "201", description = "comment added successfully"),
        @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
            responseCode = "400", description = "Bad request")
  })
  @PostMapping(value = "/post/{postId}/comments")
  public ResponseEntity<Response> createComment(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true) 
          @RequestHeader("Z-AUTH-USERID") String userId,
      @Parameter(description = "The id of the post to which there is a comment is the postid", required = true) 
          @PathVariable(name = "postId", required = true) String postId,
      @Valid @RequestBody CommentDto commentDto)
          throws InterruptedException, ExecutionException, TimeoutException {
    log.info("[createComment] add comment");

    String commentId = commentService.createComment(userId, postId, commentDto);

    return ResponseEntity.status(HttpStatus.CREATED)
          .body(Response.builder().data(new CommentResponse(commentId)).message("comment added successfully").build());
  }

  @PutMapping(value = "/post/comments")
  public ResponseEntity<Response> updateComment(
      @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true) @RequestHeader("Z-AUTH-USERID") String userId,
      @Valid @RequestBody CommentUpdateDto commentDto)
      throws InterruptedException, ExecutionException, TimeoutException {

    String commentId = commentService.updateComment(userId, commentDto);

    return ResponseEntity.status(HttpStatus.OK).body(Response.builder()
        .data(new CommentResponse(commentId)).message("comment updated successfully").build());
  }

  /**
   * get Comments
   */
  @Operation(description = "This comments service works to get Comments for special post ", responses = {
      @ApiResponse(content = @Content(schema = @Schema(implementation = ListingResponse.class)),
          responseCode = "200",description = "data found"),
      @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
          responseCode = "400", description = "Bad request")
  })
  @PostMapping(value = "/post/comments/{postId}")
  public ResponseEntity<Response> getComments(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true) 
          @RequestHeader("Z-AUTH-USERID") String userId,
    @Valid @RequestBody ListingRequest request,
      @Parameter(description = "The id of the post to which there is a comment is the postid", required = true) 
          @PathVariable(name = "postId", required = true) String postId) {
    log.info("[getComments] get comment list");
    ListingResponse data = commentService.getComment(postId, request, userId);
    return ResponseEntity.ok().body(Response.builder().data(data).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }

  /**
   * get Sub Comments
   */
  @Operation(description = "This comments service work to collect SubComments", responses = {
      @ApiResponse(content = @Content(schema = @Schema(implementation = ListingResponse.class)),
          responseCode = "200",description = "data found"),
      @ApiResponse(content = @Content(schema = @Schema(implementation = ApiError.class)),
          responseCode = "400", description = "Bad request")
  })
  @PostMapping(value = "/post/{postId}/comments/{commentId}")
  public ResponseEntity<Response> getSubComments(
    @Parameter(description = "Z-AUTH-USERID is the current login user ID", required = true) 
    @RequestHeader("Z-AUTH-USERID") String userId,	
  @Valid @RequestBody ListingRequest request,
      @Parameter(description = "The id of the comment to which there is a comment is the postid", required = true)
          @PathVariable(name = "commentId", required = true) String commentId,
      @Parameter(description = "The id of the post to which there is a comment is the postid", required = true)
          @PathVariable(name = "postId", required = true) String postId) {
    log.info("[getSubComments] get sub comment list");
    ListingResponse data = commentService.getSubComment(postId, commentId, request, userId);
    return ResponseEntity.ok().body(Response.builder().data(data).message("data found")
        .timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());
  }


  @DeleteMapping("/comment/{commentId}")
  public ResponseEntity<Response> deleteComment(@RequestHeader("Z-AUTH-USERID") String userId,
      @PathVariable("commentId") String commentId) throws InterruptedException, ExecutionException, 
      TimeoutException {

    commentService.deleteComment(userId, commentId);

    return ResponseEntity.status(HttpStatus.CREATED)
        .body(Response.builder().message("Comment deleted successfully").build());
  }


}
