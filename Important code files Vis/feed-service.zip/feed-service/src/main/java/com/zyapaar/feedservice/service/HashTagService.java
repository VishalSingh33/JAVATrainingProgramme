package com.zyapaar.feedservice.service;

import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.commons.response.ListingResponse;

/**
 * Hash tag service
 * 
 * @author Uday Halpara
 */
public interface HashTagService {

  ListingResponse getHashTags(ListingRequest request);

}
