package com.zyapaar.feedservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.feedservice.entities.CommentReactionCount;
import com.zyapaar.feedservice.response.IReactionCountResponse;

@Repository
public interface CommentReactionCountRepository
    extends JpaRepository<CommentReactionCount, String> {

  @Query(nativeQuery = true,
    value = "select crc.comment_id as commentId, fc.post_id as postId, " + 
      "crc.count as count, crc.like_count as likeCount, " + 
      "crc.celebrate_count as celebrateCount, crc.interest_count as interestCount, " + 
      "crc.shake_hand_count as shakeHandCount, crc.support_count as supportCount " + 
      "from comment_reaction_count crc " + 
      "inner join feed_comment fc on crc.comment_id = fc.id where fc.id = :commentId")
  IReactionCountResponse  findByCommentId(String commentId);

}
