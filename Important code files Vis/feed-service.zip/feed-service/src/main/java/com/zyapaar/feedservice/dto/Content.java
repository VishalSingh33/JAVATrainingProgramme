package com.zyapaar.feedservice.dto;

import java.util.List;

import com.zyapaar.commons.dto.Attribute;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Content
 * 
 * @author Uday Halpara
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Content {

  private String text;
  private List<Attribute> attributes;

}
