package com.zyapaar.feedservice.producer;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.springframework.kafka.support.SendResult;

import com.zyapaar.serde.CommentAvro;
import com.zyapaar.serde.CommentReactionAvro;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.NotificationV2Avro;
import com.zyapaar.serde.PostAvro;
import com.zyapaar.serde.PostReactionAvro;
import com.zyapaar.serde.PostReactionCountAvro;
import com.zyapaar.serde.SmsNotificationAvro;

/**
 * producer interface
 * 
 * @author Uday Halpara
 */
public interface Producer {

  SendResult<String, PostAvro> producePost(PostAvro postAvro)
      throws InterruptedException, ExecutionException, TimeoutException;

  SendResult<String, CommentAvro> produceComment(CommentAvro commentAvro)
      throws InterruptedException, ExecutionException, TimeoutException;

  SendResult<String, PostReactionAvro> producePostReaction(PostReactionAvro postReactionAvro)
      throws InterruptedException, ExecutionException, TimeoutException;

  SendResult<String, CommentReactionAvro> produceCommentReaction(CommentReactionAvro commentreactionAvroR)
      throws InterruptedException, ExecutionException, TimeoutException;

  SendResult<String, NotificationV2Avro> produceNotification(NotificationV2Avro notification)
      throws InterruptedException, ExecutionException, TimeoutException;

  void producePostReactionCount(PostReactionCountAvro post);

  void produceHashTag(String[] hashTags);

  void produceNotificationEvent(NotificationEventAvro eventAvro, String topic);

  void produceNotificationV2(NotificationV2Avro notificationAvro);

  void produceSmsNotification(SmsNotificationAvro smsNotificationAvro);

}
