package com.zyapaar.feedservice.dto;

/**
 * Post Status enum
 * 
 * @author Uday Halpara
 */
public enum Status {
  ACTIVE("1"),
  INACTIVE("2"),
  ARCHIVED("3");

  private final String status;

  Status(String status){
    this.status = status;
  }

  public String status(){
    return status;
  }
}
