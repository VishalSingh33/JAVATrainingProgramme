package com.zyapaar.feedservice.response;

import org.springframework.stereotype.Component;

/**
 * Reaction count response
 * 
 * @author Uday Halpara
 */
@Component
public interface IReactionCountResponse {

  String getPostId();
  String getCommentId();
  Long getCount();
  Long getLikeCount();
  Long getCelebrateCount();
  Long getInterestCount();
  Long getShakeHandCount();
  Long getSupportCount();

}
