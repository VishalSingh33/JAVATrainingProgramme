package com.zyapaar.feedservice.dto;

import org.springframework.stereotype.Component;


/**
 * Reacted User Dto
 * 
 * @author Uday Halpara
 */
@Component
public interface IReactedUser {

  String getPostId();
  String getCommentId();
  String getUserName();
  String getProfileImage();
  String getDesignation();
  String getReaction();
  String getUserId(); //added when doing profile. before it was not there

}
