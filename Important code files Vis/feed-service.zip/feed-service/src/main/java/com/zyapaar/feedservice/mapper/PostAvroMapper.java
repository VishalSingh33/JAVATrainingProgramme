package com.zyapaar.feedservice.mapper;

import java.time.OffsetDateTime;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyapaar.feedservice.dto.Content;
import com.zyapaar.feedservice.dto.PostDto;
import com.zyapaar.feedservice.dto.PostOrigin;
import com.zyapaar.feedservice.dto.PostResponse;
import com.zyapaar.feedservice.dto.PostUpdateDto;
import com.zyapaar.feedservice.dto.Privacy;
import com.zyapaar.feedservice.dto.Type;
import com.zyapaar.feedservice.entities.Feed;
import com.zyapaar.serde.PostAvro;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;

/**
 * post avro mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface PostAvroMapper {

  ObjectMapper objectMapper = new ObjectMapper();

  @Mapping(target = "originId", source = "postDto.originId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  PostAvro toPostAvro(PostDto postDto, String userId, List<String> mediaUrl, long createdOn,
      long updatedOn, String status);//isActive, isUpdate

  PostAvro toPostAvro(PostUpdateDto dto, String userId, List<String> mediaUrl, long createdOn,
  long updatedOn, String status, String originId, String origin, String postOf ,Boolean isUpdate);//isActive

  PostResponse toPostResponse(PostAvro postAvro);

  @Mapping(target = "isActive", source = "isActive")
  // @Mapping(target = "createdOn", expression = "java(mapToLong(createdOn))")
  // @Mapping(target = "updatedOn", expression = "java(mapToLong(updatedOn))")
  PostAvro feedToPostAvro(Feed feed, Boolean isActive);//isUpdate

  default long map(OffsetDateTime value) {
    return value == null ? null : value.toEpochSecond();
  }

  default CharSequence map(Privacy value) {
    return value.privacy();
  }

  default CharSequence map(Type value) {
    return value.type();
  }

  default CharSequence map(Content value) throws JsonProcessingException {
    return objectMapper.writeValueAsString(value);
  }

  default CharSequence map(PostOrigin value){
    return value.origin();
  }

  default String map(CharSequence value){
    return value != null ? String.valueOf(value) : null;
  }
}
