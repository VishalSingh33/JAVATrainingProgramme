package com.zyapaar.feedservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.zyapaar.feedservice.entities.SmsTemplate;
import com.zyapaar.serde.SmsNotificationAvro;

@Mapper
public interface SmsMapper {

  @Mapping(source = "id", target = "id")
  SmsNotificationAvro toSmsNotificationAvro(SmsTemplate template, String id, String text,
      String phoneNumber);
  
}
