package com.zyapaar.feedservice.component;

import java.util.List;

import com.zyapaar.feedservice.dto.UserIndustryAvroDto;
import com.zyapaar.feedservice.dto.UserRegistrationAvroDto;
import com.zyapaar.feedservice.properties.B2bProperties;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * State store component
 * 
 * @author Uday Halpara
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StateStoreComponent {

  private final B2bProperties b2bProperties;
  private final WebClient.Builder webClientBuilder;

  public String getUsername(String userId) {

    log.info("[getUsername] get username by userId : {}", userId);

    return webClientBuilder
        .build()
        .get()
        .uri(b2bProperties.getApi().getUserName())
        .header("Z-AUTH-USERID", userId)
        .retrieve()
        .bodyToMono(String.class)
        .block();

  }

  public UserRegistrationAvroDto getUserData(String userId) {

    log.info("[getUserDate] get user data : {}", userId);

    return webClientBuilder
        .build()
        .patch()
        .uri(b2bProperties.getApi().getUser())
        .header("Z-AUTH-USERID", userId)
        .retrieve()
        .bodyToMono(UserRegistrationAvroDto.class)
        .block();

  }

  public UserIndustryAvroDto getUserIndustryAvro(String userId) {

    log.info("[getUserIndustryAvro] get user industry data : {}", userId);

    return webClientBuilder
        .build()
        .get()
        .uri(b2bProperties.getApi().getUserIndustry())
        .header("Z-AUTH-USERID", userId)
        .retrieve()
        .bodyToMono(UserIndustryAvroDto.class)
        .block();

  }

  public List<String> getIndustryUserList(String userId, List<String> industryList) {

    log.info("[getIndustryUserList] get industry user list by industry list : {}", industryList);

    return webClientBuilder
        .build()
        .post()
        .uri(b2bProperties.getApi().getIndustryUsers())
        .bodyValue(industryList)
        .header("Z-AUTH-USERID", userId)
        .retrieve()
        .bodyToMono(new ParameterizedTypeReference<List<String>>() {

        })
        .block();

  }

}
