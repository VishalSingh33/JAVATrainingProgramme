package com.zyapaar.feedservice.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "hashtag")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Hashtag {

	@Id
	private String id;

	private Long count;
}
