// package com.zyapaar.analytics.service;

// import java.io.IOException;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.TimeoutException;
// import com.zyapaar.commons.request.ListingRequest;
// import com.zyapaar.commons.response.ListingResponse;
// import com.zyapaar.analytics.dto.RegistrationDto;
// import com.zyapaar.analytics.dto.ResponseDto;
// import com.zyapaar.analytics.dto.UserDetails;
// import com.zyapaar.analytics.dto.UserPersonalDetails;
// import com.zyapaar.analytics.dto.UserRegistrationDto;

// /**
//  * A service class for the user registration
//  * 
//  * @author CHiRAG RATHOD
//  */
// public interface UserService {

//   ResponseDto createUser(String mobileNo, RegistrationDto registrationDto);

//   public Boolean updateUser(UserRegistrationDto userRegistrationDto, String userId)
//      throws InterruptedException, ExecutionException, TimeoutException, IOException;

//   public UserPersonalDetails getUserData(String userId, String id)
//       throws InterruptedException, ExecutionException, TimeoutException;

//   public UserDetails getUserPersonalData(String userId);

//   UserRegistrationDto getUser(String userId);

//   public ListingResponse getProfileViewer(String userId, ListingRequest request);

// }
