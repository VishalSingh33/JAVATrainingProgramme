package com.zyapaar.analytics.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.analytics.dto.HalfFullRegDto;

@Validated
@CrossOrigin("*")
@RequestMapping("/api/v1.1")
public interface RegisteredUsersMisController {

	@PostMapping(value = "/registeredMis")
	public ResponseEntity<Response> getRegisteredUsers(@RequestBody CommonSearch commonSearch);
	// ,	@RequestBody ListingRequest listingRequest);


	
//user & comapny
	@PostMapping(value = "/getAllReg")
	public ResponseEntity<Response>  getAllReg(@RequestBody CommonSearch commonSearch);
	

}