package com.zyapaar.analytics.service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Timestamp;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.zyapaar.analytics.dto.ProfileCompletionFormulaDto;
import com.zyapaar.analytics.entities.ProfileCompleteSummary;
import com.zyapaar.analytics.entities.ProfileCompletionFormula;
import com.zyapaar.analytics.entities.UserEntity;
import com.zyapaar.analytics.mapper.ProfileCompletionFormulaMapper;
import com.zyapaar.analytics.mapper.ProfileCsvCompletionMapper;
import com.zyapaar.analytics.mapper.ProfileUsersExcelCompletionMapper;
import com.zyapaar.analytics.mapper.UnfinishedProfileUsersMapper;
import com.zyapaar.analytics.properties.B2bProperties;
import com.zyapaar.analytics.repository.ProfileCompleteSummaryRepo;
import com.zyapaar.analytics.repository.ProfileCompletionFormulaRepo;
import com.zyapaar.analytics.repository.UserRepository;
import com.zyapaar.analytics.repository.UserWiseConnectionRepository;
import com.zyapaar.analytics.request.ExcelHelper;
import com.zyapaar.analytics.request.ListingRequest;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class ManageVendorPaymentService implements VendorPaymentService {

	private final ProfileCompleteSummaryRepo profileCompleteSummaryRepo;
	private final ProfileCompletionFormulaRepo profileCompletionFormulaRepo;
	private final UserWiseConnectionRepository userWiseConnectionRepository;
	private final UserRepository userRepository;
	private final B2bProperties b2bProperties;
	private final UnfinishedProfileUsersMapper unfinishedProfileUsersMapper;
	private final ProfileUsersExcelCompletionMapper profileUsersExcelCompletionMapper;
	private final ProfileCompletionFormulaMapper profileCompletionFormulaMapper;
	private final ProfileCsvCompletionMapper profileCsvCompletionMapper;


	@Override
	@Transactional(rollbackOn = Exception.class)
	public ResponseEntity<Response> payment() {

		List<ProfileCompleteSummary> paymentList = profileCompleteSummaryRepo.checkforValue();
		OffsetDateTime loacalTime = OffsetDateTime.now().toInstant().atOffset(ZoneOffset.UTC);
    ProfileCompletionFormula vendor = profileCompletionFormulaRepo.findActiveVendorByID();
		log.info("vendor : {}", vendor);
		for (ProfileCompleteSummary user : paymentList) {
			log.info("User : {}", user);

			Integer proportionPercentage =  user.getProportionPercentage();
			if(user.getProportionPercentage() == null)
			{
				 proportionPercentage = 0;
			}
			boolean flag = true;

			if (ObjectUtils.isEmpty(user.getDownload())) {
				Timestamp timestamp = profileCompleteSummaryRepo.findByDowlaodNativeQuery(user.getId());
				log.info("user.getDownload() timestamp : {}", timestamp);
				
				OffsetDateTime offsetDateTime = (timestamp != null) ? timestamp.toLocalDateTime().atOffset(ZoneOffset.UTC) : null;
				log.info("user.getDownload() offsetDateTime : {}", offsetDateTime);

				if (!ObjectUtils.isEmpty(offsetDateTime)) {
					user.setDownload(offsetDateTime);
					proportionPercentage = proportionPercentage + vendor.getDownloadPr();
					log.info("user.getDownload() proportionPercentage : {}", proportionPercentage);
					flag = false;
				}

			}

			if (ObjectUtils.isEmpty(user.getRegistration())) {
				Timestamp timestamp = profileCompleteSummaryRepo.findByRegistrationNativeQuery(user.getId());
				log.info("user.getRegistration() timestamp : {}", timestamp);

				OffsetDateTime offsetDateTime = (timestamp != null) ? timestamp.toLocalDateTime().atOffset(ZoneOffset.UTC) : null;
				log.info("user.getRegistration() offsetDateTime : {}", offsetDateTime);

				if (!ObjectUtils.isEmpty(offsetDateTime)) {
					user.setRegistration(offsetDateTime);
					proportionPercentage = proportionPercentage + vendor.getRegistrationPr();
					log.info("user.getRegistration() proportionPercentage : {}", proportionPercentage);
					flag = false;
				}

			}

			if (ObjectUtils.isEmpty(user.getUserLogo())) {
				Timestamp timestamp = profileCompleteSummaryRepo.findByUserLogoNativeQuery(user.getId());
				log.info("user.getUserLogo() timestamp : {}", timestamp);

				OffsetDateTime offsetDateTime = (timestamp != null) ? timestamp.toLocalDateTime().atOffset(ZoneOffset.UTC) : null;
				log.info("user.getUserLogo() offsetDateTime : {}", offsetDateTime);
				
				if (!ObjectUtils.isEmpty(offsetDateTime)) {
					user.setUserLogo(offsetDateTime);
					proportionPercentage = proportionPercentage + vendor.getUserLogoPr();
					log.info("user.getUserLogo() proportionPercentage : {}", proportionPercentage);
					flag = false;
				}

			}

			// entityLogo list type
			if (ObjectUtils.isEmpty(user.getEntityLogo())) {
				List<String> entitiesList = profileCompleteSummaryRepo.findByEntityLogoNativeQuery(user.getId());
				log.info("user.getEntityLogo() entitiesList : {}", entitiesList);

				for (String logo : entitiesList) {
					if (StringUtils.hasText(logo)) {
						user.setEntityLogo(loacalTime);
						proportionPercentage = proportionPercentage + vendor.getEntityLogoPr();
						log.info("user.getEntityLogo() proportionPercentage : {}", proportionPercentage);
						flag = false;
						break;
					}
				}
			}
			// product list type
			if (ObjectUtils.isEmpty(user.getProduct())) {
				boolean product = profileCompleteSummaryRepo.findByProductNativeQuery(user.getId());
				log.info("user.getProduct() product : {}", product);

				if (product) {
					user.setProduct(loacalTime);
					proportionPercentage = proportionPercentage + vendor.getProductPr();
					log.info("user.getProduct() proportionPercentage : {}", proportionPercentage);
					flag = false;
				}
			}

			if (ObjectUtils.isEmpty(user.getBuyPost())) {
				if (profileCompleteSummaryRepo.findByBuyNativeQuery(user.getId())) {
					user.setBuyPost(loacalTime);
					proportionPercentage = proportionPercentage + vendor.getBuyPostPr();
					log.info("user.getBuyPost() proportionPercentage : {}", proportionPercentage);
					flag = false;
				}
			}

			if (ObjectUtils.isEmpty(user.getSellPost())) {
				if (profileCompleteSummaryRepo.findBySellNativeQuery(user.getId())) {
					user.setSellPost(loacalTime);
					proportionPercentage = proportionPercentage + vendor.getSellPostPr();
					log.info("user.getSellPost() proportionPercentage : {}", proportionPercentage);
					flag = false;
				}
			}

			if (ObjectUtils.isEmpty(user.getConnection())) {
				if (userWiseConnectionRepository.findByConnectionNativeQuery(user.getId()).getUserIds().size() > 2) {
					user.setConnection(loacalTime);
					proportionPercentage = proportionPercentage + vendor.getConnectionPr();
					log.info("user.getConnection() proportionPercentage : {}", proportionPercentage);
					flag = false;
				}
			}

			if (!flag) {
				user.setUpdatedOn(loacalTime);
				// user.setComplete(true);
			}

			if (user.getDownload() != null && user.getRegistration() != null && user.getEntityLogo() != null
					&& user.getUserLogo() != null &&
					user.getProduct() != null && user.getBuyPost() != null && user.getConnection() != null
					&& user.getSellPost() != null) {
				user.setComplete(true);
			}

			user.setProportionPercentage(proportionPercentage);
 			profileCompleteSummaryRepo.save(user);
			log.info("[save] Profile Summary table info: {}", user);
		}
		try {
			// profileCompleteSummaryRepo.saveAll(paymentList);
			// log.info("[paymentList] Profile Summary table info: {}", paymentList);
			profileCompleteSummaryRepo.upadteCompleteValue();
			return ResponseEntity.status(HttpStatus.OK)
					.body(Response.builder().data(paymentList).message("Summary updated sucessfully").build());

		} catch (Exception e) {
			throw new RuntimeException("Summary not found", e);
		}
	}

	@Override
	public void paymentCompleteSummaryInput() {
		try {
			
			List<UserEntity> unfinishedProfileUsers = userRepository.getUnfinishedProfileUsers();
			log.info("[paymentCompleteSummaryInput] Profile Summary userId, MobileNO, createdOn");
			List<ProfileCompleteSummary> summaryUserList = new ArrayList<>();
			for (UserEntity user : unfinishedProfileUsers) {

				ProfileCompleteSummary profileCompleteSummary = unfinishedProfileUsersMapper.setData(user.getId(),
						user.getMobileNo(), user.getCreatedOn());
				summaryUserList.add(profileCompleteSummary);
			}
			log.info("[summaryUserList] Profile Summary list from Users: {}", summaryUserList);
			profileCompleteSummaryRepo.saveAll(summaryUserList);

		} catch (NullPointerException e) {
			log.error("error while upadating prfile summary data", e);
		}

	}

	@Override
	public ResponseEntity<Response> paymentCompletionFormula(String authUserId, ListingRequest listingRequest) {

		userRepository.findById(authUserId)
				.orElseThrow(() -> new ResourceNotFoundException("user", "id", authUserId));

		log.info("{}", listingRequest.getPage());
		Pageable paging = PageRequest.of(listingRequest.getPage(), b2bProperties.getPaging().getFollowySize());
		// , Sort.by(Direction.DESC, "u.updated_on"));

		List<ProfileCompleteSummary> paymentCompletionList = profileCompleteSummaryRepo.findByWeekNativeQuery(paging);
		List<ProfileCompletionFormulaDto> responseList = new ArrayList<ProfileCompletionFormulaDto>();

		ProfileCompletionFormula vendor = profileCompletionFormulaRepo.findActiveVendorByID();

		for (ProfileCompleteSummary userPayment : paymentCompletionList) {

			ProfileCompletionFormulaDto profileCompletionFormulaDto = profileCompletionFormulaMapper.setData(
					userPayment.getId(),
					userPayment.getMobileNo(), userPayment.getCreatedOn(), userPayment.getUpdatedOn());

			Long totalAmount = 0l;
			Long ProportionPercentage = 0l;

			if (userPayment.getDownload() != null) {
				profileCompletionFormulaDto.setDownload(userPayment.getDownload());
				totalAmount = totalAmount + vendor.getDownloadAmt();
				ProportionPercentage = ProportionPercentage + vendor.getDownloadPr();

			}
			if (userPayment.getEntityLogo() != null) {
				profileCompletionFormulaDto.setEntityLogo(userPayment.getEntityLogo());
				totalAmount = totalAmount + vendor.getEntityLogoAmt();
				ProportionPercentage = ProportionPercentage + vendor.getEntityLogoPr();

			}
			if (userPayment.getBuyPost() != null) {
				profileCompletionFormulaDto.setBuyPost(userPayment.getBuyPost());
				totalAmount = totalAmount + vendor.getBuyPostAmt();
				ProportionPercentage = ProportionPercentage + vendor.getBuyPostPr();

			}
			if (userPayment.getSellPost() != null) {
				profileCompletionFormulaDto.setSellPost(userPayment.getSellPost());
				totalAmount = totalAmount + vendor.getSellPostAmt();
				ProportionPercentage = ProportionPercentage + vendor.getSellPostPr();

			}
			if (userPayment.getRegistration() != null) {
				// profileCompletionFormulaDto.setRegistration("Yes");
				profileCompletionFormulaDto.setRegistration(userPayment.getRegistration());
				totalAmount = totalAmount + vendor.getRegistrationAmt();
				ProportionPercentage = ProportionPercentage + vendor.getRegistrationPr();

			}
			if (userPayment.getUserLogo() != null) {
				profileCompletionFormulaDto.setUserLogo(userPayment.getUserLogo());
				totalAmount = totalAmount + vendor.getUserLogoAmt();
				ProportionPercentage = ProportionPercentage + vendor.getUserLogoPr();

			}
			if (userPayment.getConnection() != null) {
				profileCompletionFormulaDto.setConnection(userPayment.getConnection());
				totalAmount = totalAmount + vendor.getConnectionAmt();
				ProportionPercentage = ProportionPercentage + vendor.getConnectionPr();

			}
			if (userPayment.getProduct() != null) {
				profileCompletionFormulaDto.setProduct(userPayment.getProduct());
				totalAmount = totalAmount + vendor.getProductAmt();
				ProportionPercentage = ProportionPercentage + vendor.getProductPr();

			}

			profileCompletionFormulaDto.setTotalAmount(totalAmount);
			profileCompletionFormulaDto.setProportionPercentage(ProportionPercentage);
			responseList.add(profileCompletionFormulaDto);

		}

		ResponseEntity amountCalculated = new ResponseEntity(responseList, HttpStatus.OK);
		return amountCalculated;

	}

	// ExcelFile Downloader
	@Override
	public InputStream loadPaymentExcel() {

		List<ProfileCompleteSummary> excelCompletionList = profileCompleteSummaryRepo.findByExcelWeekNativeQuery();
		List<ProfileCompletionFormulaDto> excelList = new ArrayList<ProfileCompletionFormulaDto>();

		ProfileCompletionFormula vendor = profileCompletionFormulaRepo.findActiveVendorByID();

		for (ProfileCompleteSummary excelPayment : excelCompletionList) {

			ProfileCompletionFormulaDto profileCompletionFormulaDto = profileUsersExcelCompletionMapper.setData(
					excelPayment.getId(),
					excelPayment.getMobileNo(), excelPayment.getCreatedOn(), excelPayment.getUpdatedOn(),
					excelPayment.getDownload(), excelPayment.getEntityLogo(), excelPayment.getBuyPost(),
					excelPayment.getSellPost(), excelPayment.getRegistration(), excelPayment.getUserLogo(),
					excelPayment.getConnection(), excelPayment.getProduct());

			Long totalAmount = 0l;
			Long ProportionPercentage = 0l;

			if (excelPayment.getDownload() != null) {
				totalAmount = totalAmount + vendor.getDownloadAmt();
				ProportionPercentage = ProportionPercentage + vendor.getDownloadPr();

			}
			if (excelPayment.getEntityLogo() != null) {
				totalAmount = totalAmount + vendor.getEntityLogoAmt();
				ProportionPercentage = ProportionPercentage + vendor.getEntityLogoPr();

			}
			if (excelPayment.getBuyPost() != null) {
				totalAmount = totalAmount + vendor.getBuyPostAmt();
				ProportionPercentage = ProportionPercentage + vendor.getBuyPostPr();

			}
			if (excelPayment.getSellPost() != null) {
				totalAmount = totalAmount + vendor.getSellPostAmt();
				ProportionPercentage = ProportionPercentage + vendor.getSellPostPr();

			}
			if (excelPayment.getRegistration() != null) {
				totalAmount = totalAmount + vendor.getRegistrationAmt();
				ProportionPercentage = ProportionPercentage + vendor.getRegistrationPr();

			}
			if (excelPayment.getUserLogo() != null) {
				totalAmount = totalAmount + vendor.getUserLogoAmt();
				ProportionPercentage = ProportionPercentage + vendor.getUserLogoPr();

			}
			if (excelPayment.getConnection() != null) {
				totalAmount = totalAmount + vendor.getConnectionAmt();
				ProportionPercentage = ProportionPercentage + vendor.getConnectionPr();

			}
			if (excelPayment.getProduct() != null) {
				totalAmount = totalAmount + vendor.getProductAmt();
				ProportionPercentage = ProportionPercentage + vendor.getProductPr();

			}

			profileCompletionFormulaDto.setTotalAmount(totalAmount);
			profileCompletionFormulaDto.setProportionPercentage(ProportionPercentage);
			excelList.add(profileCompletionFormulaDto);
		}

		ByteArrayInputStream in = ExcelHelper.paymentToExcel(excelList);
		return in;
	}

	@Override
	public ResponseEntity<Response> getCsvFileData(List<String> mobileNo, com.zyapaar.commons.request.ListingRequest listingRequest) {

		Pageable paging = PageRequest.of(listingRequest.getPage(), 10);
		Integer listSize = mobileNo.size();

		List<ProfileCompleteSummary> csvCompletionList = profileCompleteSummaryRepo.findByMobileNo(mobileNo, paging);

	return ResponseEntity.status(HttpStatus.OK).body(
		Response.builder().data(csvCompletionList).message(listSize.toString()).build());
	}

}