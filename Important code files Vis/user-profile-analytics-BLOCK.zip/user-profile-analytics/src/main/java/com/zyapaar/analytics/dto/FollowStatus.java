package com.zyapaar.analytics.dto;

public enum FollowStatus {
  ACTIVE,
  INACTIVE;
}
