package com.zyapaar.analytics.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BlockUserDto {

  private String originId;

  private BlockOrigin origin;

	private String toUserId;

}
