package com.zyapaar.analytics.request;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.zyapaar.analytics.dto.ProfileCompletionFormulaDto;


public class ExcelHelper {
  public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  static String[] HEADERs = { "userId", "mobileNo", "updatedOn", "createOn","download", "registration", "userLogo", "buyPost" , 
	                            "connection", "entityLogo", "product","sellPost", "proportionPercentage", "totalAmount"};
  static String SHEET = "Vendor Payment List";

  public static ByteArrayInputStream paymentToExcel(List<ProfileCompletionFormulaDto> paymentProfile) {

    try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
      Sheet sheet = workbook.createSheet(SHEET);

      // headerExcel
      Row headerRow = sheet.createRow(0);

      for (int col = 0; col < HEADERs.length; col++) {
        Cell cell = headerRow.createCell(col);
        cell.setCellValue(HEADERs[col]);
      }

      int rowIdx = 1;
      for (ProfileCompletionFormulaDto exceldownlaod : paymentProfile) {
        Row row = sheet.createRow(rowIdx++);

        row.createCell(0).setCellValue(String.valueOf(exceldownlaod.getUserId()));
        row.createCell(1).setCellValue(String.valueOf(exceldownlaod.getMobileNo()));
        row.createCell(2).setCellValue(String.valueOf(exceldownlaod.getUpdatedOn()));
        row.createCell(3).setCellValue(String.valueOf(exceldownlaod.getCreatedOn()));
				row.createCell(4).setCellValue(String.valueOf(exceldownlaod.getDownload()));
        row.createCell(5).setCellValue(String.valueOf(exceldownlaod.getRegistration()));
        row.createCell(6).setCellValue(String.valueOf(exceldownlaod.getUserLogo()));
        row.createCell(7).setCellValue(String.valueOf(exceldownlaod.getEntityLogo()));
				row.createCell(8).setCellValue(String.valueOf(exceldownlaod.getBuyPost()));
        row.createCell(9).setCellValue(String.valueOf(exceldownlaod.getSellPost()));
        row.createCell(10).setCellValue(String.valueOf(exceldownlaod.getConnection()));
        row.createCell(11).setCellValue(String.valueOf(exceldownlaod.getProduct()));
        row.createCell(12).setCellValue((exceldownlaod.getProportionPercentage()==null)?0L:exceldownlaod.getProportionPercentage());
        row.createCell(13).setCellValue((exceldownlaod.getTotalAmount()==null)?0L:exceldownlaod.getProportionPercentage());
      }

      workbook.write(out);
      return new ByteArrayInputStream(out.toByteArray());
    } catch (IOException e) {
      throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
    }
  }
}

