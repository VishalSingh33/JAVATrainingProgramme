package com.zyapaar.analytics.entities;

import java.io.Serializable;
import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.DayOfWeek;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * The persistent class for the profile_complete_summary database table.
 * 
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "profile_complete_summary")
public class ProfileCompleteSummary {

	// private static final long serialVersionUID = 1L;

	@Id
	private String id;

	@Column(name = "buy_post")
	private OffsetDateTime buyPost;

	private Boolean complete;

	private OffsetDateTime connection;

	@Column(name = "created_on")
	private OffsetDateTime createdOn;

	private OffsetDateTime download;

	@Column(name = "entity_logo")
	private OffsetDateTime entityLogo;

	@Column(name = "mobile_no")
	private String mobileNo;

	private OffsetDateTime product;

	@Column(name = "proportion_percentage")
	private Integer proportionPercentage;

	private OffsetDateTime registration;

	@Column(name = "sell_post")
	private OffsetDateTime sellPost;

	@Column(name = "updated_on")
	private OffsetDateTime updatedOn;

	@Column(name = "user_logo")
	private OffsetDateTime userLogo;

}