package com.zyapaar.analytics.controller;

import com.zyapaar.commons.dto.Response;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.analytics.service.ManageRegisteredUsersMisService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequiredArgsConstructor
public class ManageRegisteredUsersMisController implements RegisteredUsersMisController {

	private final ManageRegisteredUsersMisService manageRegisteredUsersMisService;

	@Override
	public ResponseEntity<Response> getRegisteredUsers(CommonSearch commonSearch) {

		return manageRegisteredUsersMisService.getRegisteredUsers(commonSearch);
	}



	@Override
	public ResponseEntity<Response> getAllReg(CommonSearch commonSearch) {
	
		return manageRegisteredUsersMisService.getAllReg(commonSearch);
	}

}