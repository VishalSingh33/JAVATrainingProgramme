package com.zyapaar.analytics.repository;

import com.zyapaar.analytics.entities.AllRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AllRequestRepository extends JpaRepository<AllRequest, String>{

}

