package com.zyapaar.analytics.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.zyapaar.analytics.entities.ProfileCompletionFormula;

@Repository
public interface ProfileCompletionFormulaRepo extends JpaRepository<ProfileCompletionFormula, String>{

	// select * from profile_completion_formula where vendor_id = :vendor and is_active= true
	@Query(
		value = "SELECT * FROM profile_completion_formula WHERE is_active = true LIMIT 1", 
		nativeQuery = true
	)
	ProfileCompletionFormula findActiveVendorByID();
	
}
