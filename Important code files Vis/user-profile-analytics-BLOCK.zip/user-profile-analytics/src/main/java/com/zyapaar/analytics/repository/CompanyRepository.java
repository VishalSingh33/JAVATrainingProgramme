package com.zyapaar.analytics.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.zyapaar.analytics.entities.Entities;

@Repository
public interface CompanyRepository extends JpaRepository<Entities,String>{

  @Query(
    nativeQuery = true,
    value = "SELECT EXISTS(SELECT id FROM entities WHERE identity_number =:identityNumber)"
  )
  Boolean existsByIdentityNumber(String identityNumber);

  @Query(
    nativeQuery = true,
    value = "SELECT * from entities e"
    +" INNER JOIN entity_invite ei ON e.id = ei.entities_id"
    +" WHERE ei.user_id=:userId AND ei.status=:status AND ei.is_admin=true LIMIT 1"
  )
  Optional<Entities> getCompanyIdByUserAdmin(String userId, String status);  //Accept,isAdmin,CompanyId

  @Query(
    nativeQuery = true,
    value = "SELECT e.* FROM entities e"
    +" INNER JOIN entity_invite ei ON ei.entities_id = e.id"
    +" WHERE ei.user_id =:userId AND ei.status = 'accept' ORDER BY created_on ASC LIMIT 1"
  )
  Entities findEntityByUserId(String userId);



	// SELECT identity_number  FROM entities e WHERE identity_number  = :identity_number
	
	@Query(nativeQuery = true, value = "	SELECT *  FROM entities e WHERE identity_number  = :identity_number ")
  Entities getByIdentityNo(String identity_number);

}
