package com.zyapaar.analytics.controller;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.analytics.dto.BlockUserDto;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

@Validated
@CrossOrigin("*")
@RequestMapping("/api/v1.1")
public interface BlockController {

  @GetMapping(value = "/block")
	public ResponseEntity<Response> blockUser(@RequestHeader("Z-AUTH-USERID") String fromUserId, @RequestBody BlockUserDto blockUserDto);

	@GetMapping(value = "/unblock")
	public ResponseEntity<Response> unBlockUser(@RequestHeader("Z-AUTH-USERID") String fromUserId, @RequestBody BlockUserDto blockUserDto);

	@GetMapping(value = "/blocked/users")
	public ResponseEntity<Response> blockedUserList(@RequestHeader("Z-AUTH-USERID") String fromUserId,
			@RequestBody ListingRequest listingRequest);
	
}
