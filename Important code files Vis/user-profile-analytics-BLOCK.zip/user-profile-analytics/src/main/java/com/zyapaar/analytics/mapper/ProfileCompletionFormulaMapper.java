package com.zyapaar.analytics.mapper;

import java.time.OffsetDateTime;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.zyapaar.analytics.dto.ProfileCompletionFormulaDto;

@Mapper
public interface ProfileCompletionFormulaMapper {

	@Mapping(target = "userId", source = "id")
	
	ProfileCompletionFormulaDto setData(String id, String mobileNo, OffsetDateTime createdOn, OffsetDateTime updatedOn);

}
