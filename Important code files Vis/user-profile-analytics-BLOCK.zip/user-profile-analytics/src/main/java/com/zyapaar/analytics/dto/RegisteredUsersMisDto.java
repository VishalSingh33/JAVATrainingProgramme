package com.zyapaar.analytics.dto;

import java.time.OffsetDateTime;

import lombok.Data;

@Data
public class RegisteredUsersMisDto {

	
	private String userId;
	private String mobileNo;
	private OffsetDateTime updatedOn;
	private OffsetDateTime createdOn;
	private OffsetDateTime download;
	private OffsetDateTime registration;
	private OffsetDateTime userLogo;
	private OffsetDateTime buyPost;
	private OffsetDateTime connection;
	private OffsetDateTime entityLogo;
	private OffsetDateTime product;
	private OffsetDateTime sellPost;
	private Long proportionPercentage;
	private Long totalAmount;
	
}


