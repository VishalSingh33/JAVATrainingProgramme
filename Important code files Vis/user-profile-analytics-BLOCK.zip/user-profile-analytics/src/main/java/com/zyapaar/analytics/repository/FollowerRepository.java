package com.zyapaar.analytics.repository;

import com.zyapaar.analytics.entities.Follower;
import com.zyapaar.analytics.entities.UserWiseConnection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FollowerRepository extends JpaRepository<Follower, String> {

  @Query(
    nativeQuery = true,
    value = "SELECT id FROM follower WHERE follower_user=:userId"
    )
  String findByFollowerUser(String userId);

  // @Transactional
  @Modifying
  @Query(
    nativeQuery = true,
    value = "UPDATE follower SET status = :status where status = 'ACTIVE'"
    + " AND follower_user = :followId AND user_follower_id = :followingId"
  )
  void unFollowUser(String status, String followId, String followingId);

  @Query(
    nativeQuery = true,
    value = "SELECT id FROM follower WHERE user_follower_id=:userId"
    +" AND follower_user=:authUserId AND status='ACTIVE'"
  )
  Optional<String> checkIsFollowing(String authUserId, String userId);

  @Query(nativeQuery= true,
          value= "select * from follower f where follower_user = :fd and " +
                  " user_follower_id = :ud and status = 'ACTIVE' ")
  boolean checkFromFollower(String fd, String ud);

  
}
