package com.zyapaar.analytics.repository;

import com.zyapaar.analytics.entities.UserOverView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserOverViewRepository extends JpaRepository<UserOverView,String>{

  @Query(
    nativeQuery = true,
    value = "SELECT * FROM user_overview WHERE user_id=:userId"
  )
  UserOverView findByUserId(String userId);

  @Modifying
  @Query(
    nativeQuery = true,
    value = "UPDATE user_overview SET connections = (connections -1)"
    +" WHERE user_id IN (:userId,:toUserId)"
  )
  void decreaseConnectionCount(String userId, String toUserId);
  

  @Modifying
  @Query(
    nativeQuery = true,
    value = "UPDATE user_overview SET connections = (connections +1)"
    +" WHERE user_id IN (:userId,:toUserId)"
  )
  void increaseConnectionCount(String userId, String toUserId);

  @Modifying
  @Query(
    nativeQuery = true,
    value = "UPDATE user_overview SET views = (views +1)"
     + " WHERE user_id=:userId"
  )
  void increaseViewCount(String userId);

  @Modifying
  @Query(
    nativeQuery = true,
    value = "UPDATE user_overview SET followings = (followings +1)"
    + " WHERE user_id=:userId"
  )
  void increaseFollowingsCount(String userId);

  @Modifying
  @Query(
    nativeQuery = true,
    value = "UPDATE user_overview SET followers = (followers +1)"
    + " WHERE user_id=:id"
  )
  void increaseFollowersCount(String id);

  @Modifying
  @Query(
    nativeQuery = true,
    value = "UPDATE user_overview SET followers = (followers -1)"
    + " WHERE user_id=:userId"
  )
  void decreaseFollowersCount(String userId);

  @Modifying
  @Query(
    nativeQuery = true,
    value = "UPDATE user_overview SET followings = (followings -1)"
    + " WHERE user_id=:id"
  )
  void decreaseFollowingsCount(String id);
  
}
