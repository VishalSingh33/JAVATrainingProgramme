package com.zyapaar.analytics.service;

import java.util.List;
import java.util.Optional;
import java.util.ArrayList;
import java.util.Collections;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.exceptionhandler.custom.BadRequestException;
import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.analytics.dto.HalfFullRegDto;
import com.zyapaar.analytics.dto.ProfileCompletionFormulaDto;
import com.zyapaar.analytics.entities.Entities;
import com.zyapaar.analytics.entities.ProfileCompleteSummary;
import com.zyapaar.analytics.mapper.ProfileUsersExcelCompletionMapper;
import com.zyapaar.analytics.properties.B2bProperties;
import com.zyapaar.analytics.repository.CompanyRepository;
import com.zyapaar.analytics.repository.ProfileCompleteSummaryRepo;
import com.zyapaar.analytics.repository.SignupStatusRepository;
import com.zyapaar.analytics.repository.UserRepository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class ManageRegisteredUsersMisService implements RegisteredUsersMisService {

	private final UserRepository userRepository;
	private final CompanyRepository companyRepository;
	private final B2bProperties b2bProperties;
	private final SignupStatusRepository signupStatusRepository;
	private final ProfileCompleteSummaryRepo profileCompleteSummaryRepo;
	private final ProfileUsersExcelCompletionMapper profileUsersExcelCompletionMapper;

	@Override
	public ResponseEntity<Response> getRegisteredUsers(CommonSearch commonSearch) {

		// Pageable paging = PageRequest.of(listingRequest.getPage(), 10);

		List<ProfileCompleteSummary> registeredUserEntity = profileCompleteSummaryRepo.findAll();
		List<ProfileCompletionFormulaDto> registeredList = new ArrayList<>(); // ye responce milega through frontend/postman
		boolean flag = false, present = false;
		for (ProfileCompleteSummary user : registeredUserEntity) {
			ProfileCompletionFormulaDto regUsersMisDto = new ProfileCompletionFormulaDto();

			if (commonSearch.getSearch().equals(user.getId())) // id beja kisi ne
			{
				present = true;
				Optional<String> signupStatus = signupStatusRepository.findByMobileNo(user.getMobileNo());
				if (signupStatus.isPresent()) {
					if (commonSearch.getType().equals(signupStatus.get())) {
						flag = true;
						regUsersMisDto = profileUsersExcelCompletionMapper.setData(
								user.getId(),
								user.getMobileNo(), user.getCreatedOn(), user.getUpdatedOn(),
								user.getDownload(), user.getEntityLogo(), user.getBuyPost(),
								user.getSellPost(), user.getRegistration(), user.getUserLogo(),
								user.getConnection(), user.getProduct());
					}
				}

			} else if (commonSearch.getSearch().equals(user.getMobileNo())) // mobileNo
			{
				present = true;
				Optional<String> signupStatus1 = signupStatusRepository.findByMobileNo(user.getMobileNo());
				if (signupStatus1.isPresent()) {
					if (commonSearch.getType().equals(signupStatus1.get())) {
						flag = true;
						regUsersMisDto = profileUsersExcelCompletionMapper.setData(
								user.getId(),
								user.getMobileNo(), user.getCreatedOn(), user.getUpdatedOn(),
								user.getDownload(), user.getEntityLogo(), user.getBuyPost(),
								user.getSellPost(), user.getRegistration(), user.getUserLogo(),
								user.getConnection(), user.getProduct());
					}
				}
			}
			if (flag) {
				registeredList.add(regUsersMisDto);
				flag = false;
			}

		}
		if (registeredList.size() == 0 && !present) {
			Entities entities = companyRepository.getByIdentityNo(commonSearch.getSearch());

			Optional<ProfileCompleteSummary> profileCompleteSummary = profileCompleteSummaryRepo.findById(entities.getUser());
			if (profileCompleteSummary.isPresent()) {
				Optional<String> signupStatus1 = signupStatusRepository.findByMobileNo(profileCompleteSummary.get().getMobileNo());
				ProfileCompletionFormulaDto regUsersMisDto = new ProfileCompletionFormulaDto();
				if (commonSearch.getType().equals(signupStatus1.get())) {
					flag = true;
					regUsersMisDto = profileUsersExcelCompletionMapper.setData(
							profileCompleteSummary.get().getId(),
							profileCompleteSummary.get().getMobileNo(), profileCompleteSummary.get().getCreatedOn(),
							profileCompleteSummary.get().getUpdatedOn(),
							profileCompleteSummary.get().getDownload(), profileCompleteSummary.get().getEntityLogo(),
							profileCompleteSummary.get().getBuyPost(),
							profileCompleteSummary.get().getSellPost(), profileCompleteSummary.get().getRegistration(),
							profileCompleteSummary.get().getUserLogo(),
							profileCompleteSummary.get().getConnection(), profileCompleteSummary.get().getProduct());
				}
				if (flag == true)
					registeredList.add(regUsersMisDto);
			}
		}
		ResponseEntity filteredUsers = new ResponseEntity(registeredList, HttpStatus.OK);
		return filteredUsers;

	}



	@Override
	public ResponseEntity<Response> getAllReg(CommonSearch commonSearch) {

		String type = (commonSearch.getType() == null || commonSearch.getType().equals("") ) ? null: commonSearch.getType();
		String search = (commonSearch.getSearch() == null || commonSearch.getSearch().equals("") ) ? null: commonSearch.getSearch();

		Pageable paging = PageRequest.of(commonSearch.getPage(), b2bProperties.getPaging().getFollowySize());
		                    // , Sort.by(Direction.DESC, "u.updated_on"));
		List<HalfFullRegDto> registeredUserEntity = null;
		String regCount = null;
	
			if(type == null && search == null)
		{
			try {
			      //  registeredUserEntity = userRepository.getReg(paging);
			     //  throw new BadRequestException("Enter any Input to get Result");
			} catch (Exception e) {
				log.info("create : {}", e);
				throw new BadRequestException("Error during getAll company", e);
			}
		}
		else if(type == null && search != null)
		{
			 registeredUserEntity = userRepository.getRegBySearch(search, paging);
			  regCount = userRepository.getRegBySearchCount(search);
		}
		else if(type != null && search == null)
		{
			if(type.equals("FULL")){
				registeredUserEntity = userRepository.getRegByType(type, paging);
				regCount = userRepository.getRegByTypeCount(type);
			}
			else 
			{
        registeredUserEntity = userRepository.getRegByTypeAll(type, paging);
				regCount = userRepository.getRegByTypeAllCount(type);
			}
		}
		else
		{
			 registeredUserEntity = userRepository.getReg(search, type, paging);
			 regCount = userRepository.getRegCount(search, type);
		}

		return ResponseEntity.status(HttpStatus.OK).body(
			Response.builder().data(registeredUserEntity).message(regCount)
			.timestamp(DateTimeUtils.currentDateTimeUTCInString()).build());

	// ResponseEntity filteredUsers = new ResponseEntity(registeredUserEntity, HttpStatus.OK);
	// return filteredUsers;

	}

}
