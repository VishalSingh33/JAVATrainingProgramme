package com.zyapaar.analytics.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.zyapaar.commons.dto.Response;
import com.zyapaar.commons.request.ListingRequest;
import com.zyapaar.analytics.dto.CommonSearch;
import com.zyapaar.analytics.dto.RegisteredUsersMisDto;

public interface RegisteredUsersMisService {

  public ResponseEntity<Response> getRegisteredUsers(CommonSearch commonSearch);


	public ResponseEntity<Response>  getAllReg(CommonSearch commonSearch);



}
