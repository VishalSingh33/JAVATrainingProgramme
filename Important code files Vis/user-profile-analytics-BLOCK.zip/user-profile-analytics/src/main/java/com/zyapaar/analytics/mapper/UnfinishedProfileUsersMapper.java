package com.zyapaar.analytics.mapper;

import java.time.OffsetDateTime;

import javax.validation.constraints.NotNull;

import org.mapstruct.Mapper;
import com.zyapaar.analytics.entities.ProfileCompleteSummary;

@Mapper
public interface UnfinishedProfileUsersMapper {

	ProfileCompleteSummary setData(@NotNull String id, String mobileNo, @NotNull OffsetDateTime createdOn);
	
}
