package com.zyapaar.analytics.repository;

import com.zyapaar.analytics.entities.UserFollower;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserFollowerRepository extends JpaRepository<UserFollower, String>{
  
}
