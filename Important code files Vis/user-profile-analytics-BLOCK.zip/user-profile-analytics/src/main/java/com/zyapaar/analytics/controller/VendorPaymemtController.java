package com.zyapaar.analytics.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.zyapaar.analytics.properties.B2bProperties;
import com.zyapaar.analytics.request.ListingRequest;
import com.zyapaar.commons.dto.Response;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import lombok.RequiredArgsConstructor;

@Validated
@EnableScheduling
@CrossOrigin
@RequestMapping("/api/v1.1")
public interface VendorPaymemtController {


	// to get fields(id,mobileNo,createdOn)
	@GetMapping(value = "/schduler2")
	public void paymentCompleteSummaryInput();

	// to get timestamp fields for schduler2
	@GetMapping(value = "/paymentSummary")
	public ResponseEntity<Response> payment();

	@GetMapping(value = "/schduler3")
	public ResponseEntity<Response> paymentCompletionFormula(@RequestHeader("Z-AUTH-USERID") String authUserId,
			@RequestBody ListingRequest listingRequest);

	@GetMapping("/excelDownload")
	public ResponseEntity<InputStreamResource> downlaodUserPaymentExcel();

	@PostMapping("/csvFileData")
	public ResponseEntity<Response> getCsvFileData(@RequestParam List<String> mobileNo, @RequestBody com.zyapaar.commons.request.ListingRequest listingRequest );
}
