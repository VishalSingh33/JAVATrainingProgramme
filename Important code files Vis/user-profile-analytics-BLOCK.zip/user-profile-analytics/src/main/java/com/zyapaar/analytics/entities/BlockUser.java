package com.zyapaar.analytics.entities;

import com.vladmihalcea.hibernate.type.array.ListArrayType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.time.OffsetDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@TypeDef(
    name = "list-array",
    typeClass = ListArrayType.class
)
@Table(name = "block_user")
public class BlockUser{

	@Id
	@NotNull
	@Column(name = "id")
	private String id;

	@Column(name = "from_user_id")
	private String fromUserId;

	@Column(name = "to_user_id")
	private String toUserId;

	@NotNull
	private String status;

	private String origin;

	@Column(name = "origin_id") 
	private String originId;

	@NotNull
	@Column(name = "created_on", nullable = false)
	private OffsetDateTime createdOn;

	@Column(name = "updated_on")
	private OffsetDateTime updatedOn;
   
}
