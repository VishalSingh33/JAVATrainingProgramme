package com.zyapaar.analytics.dto;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommonSearch {

	private String type; //yahan pe status hoga ki registration full h ya half
	private String search; // kis basis pe hoga search hoga sb, (usersId phoneNo identityNo)
	
	@NotNull(message = "Please provide page number")
	@Range(min = 0, message = "Please provide valid page number")
	private Integer page;
	
}
