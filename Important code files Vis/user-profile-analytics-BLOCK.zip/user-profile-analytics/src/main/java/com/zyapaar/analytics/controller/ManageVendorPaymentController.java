package com.zyapaar.analytics.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.commons.dto.Response;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.zyapaar.analytics.properties.B2bProperties;
import com.zyapaar.analytics.request.ListingRequest;
import com.zyapaar.analytics.service.VendorPaymentService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequiredArgsConstructor
@EnableScheduling
public class ManageVendorPaymentController implements VendorPaymemtController {

	private final VendorPaymentService vendorPaymentService;
	private final B2bProperties b2bProperties;

	// @Scheduled(cron = "0 30 17 * * ?")
//	@Scheduled(cron = "${app.scheduler.cron}")
	@Override
	public void paymentCompleteSummaryInput() {

		vendorPaymentService.paymentCompleteSummaryInput();
	}

	// @Scheduled(cron = "0 40 17 * * ?")
//	@Scheduled(cron = "${app.scheduler.cronPayment}")
	@Override
	public ResponseEntity<Response> payment() {

		return vendorPaymentService.payment();
	}

	@Override
	public ResponseEntity<Response> paymentCompletionFormula(String authUserId, ListingRequest listingRequest) {

		ResponseEntity<Response> listingResponse = vendorPaymentService.paymentCompletionFormula(authUserId,
				listingRequest);

		return ResponseEntity.ok(Response.builder().data(listingResponse)
				.message("Data found").build());
	}

	@Override
	public ResponseEntity<InputStreamResource> downlaodUserPaymentExcel() {

		LocalDateTime localDateTime =  LocalDateTime.now();
		String filename = "user_payment_record_" + localDateTime + ".xlsx";

		InputStreamResource file = new InputStreamResource(vendorPaymentService.loadPaymentExcel());

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
				.body(file);

	}

	@Override
	public ResponseEntity<Response> getCsvFileData(List<String> mobileNo, com.zyapaar.commons.request.ListingRequest listingRequest) 
	{
		
		return vendorPaymentService.getCsvFileData(mobileNo, listingRequest);
	}


}