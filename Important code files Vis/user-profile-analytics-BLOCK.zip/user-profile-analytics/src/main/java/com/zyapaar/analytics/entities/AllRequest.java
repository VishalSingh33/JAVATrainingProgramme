package com.zyapaar.analytics.entities;

import com.vladmihalcea.hibernate.type.array.ListArrayType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.time.OffsetDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@TypeDef(name = "list-array",typeClass = ListArrayType.class)
@Table(name = "all_request")
public class AllRequest {

  @Id
  @NotNull
  @Column(name = "id", nullable = false)
  private String id;

  @NotNull
  @Column(name = "type")
  private String type;

  @Column(name = "status")
  private String status;

  @Column(name = "request_id")
  private String requestId;  //connection table pk
  
  @Column(name = "origin_id")
  private String originId;  //type wise pk id(company,user)

  @Column(name = "from_user_id")
  private String fromUserId;

  @Column(name = "to_user_id",columnDefinition = "text[]")
  @Type(type = "list-array")
  private List<String> toUserId;

  @Column(name = "created_on")
  private OffsetDateTime createdOn;

  @Column(name = "is_active")
  private Boolean isActive;

}

