package com.zyapaar.zypaar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZypaarApplicationTests {

	@Test
	void contextLoads() {
	}

}
