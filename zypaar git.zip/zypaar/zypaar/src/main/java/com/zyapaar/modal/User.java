package com.zyapaar.modal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Users")
public class User {
	@Id
	private long id;
	private String name;
	private String descrpition;
	
	
	
//	public User() {
//		super();
//		this.id = id;
//		this.name = name;
//		this.descrpition = descrpition;
//		// TODO Auto-generated constructor stub
//	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescrpition() {
		return descrpition;
	}

	public void setDescrpition(String descrpition) {
		this.descrpition = descrpition;
	}
	
}


//Rest API:- Employee Registration
//-ok Create Employee
//-ok Employee Update
//- Employee Delete l
//-ok Employee List
