package com.zyapaar.UserService;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.zyapaar.modal.User;

public interface UserService {

	public List<User> getUser();
	
	public User getUser(long userId);
	
	public User addUser (User user);
	
	ResponseEntity<User> updateUser(Long id, User ur);
	
	public User deleteUser(Long userId);

}
 