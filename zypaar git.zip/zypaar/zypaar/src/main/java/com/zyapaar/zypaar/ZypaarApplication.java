package com.zyapaar.zypaar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZypaarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZypaarApplication.class, args);
	}

}
