package com.zyapaar.UserRepositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.zyapaar.modal.User;


@Repository
public interface UserDaoRepo extends JpaRepository<User, Long> {

}
