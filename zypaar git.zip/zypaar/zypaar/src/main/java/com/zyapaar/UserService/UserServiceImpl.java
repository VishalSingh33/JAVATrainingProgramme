package com.zyapaar.UserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.zyapaar.UserRepositary.UserDaoRepo;
import com.zyapaar.modal.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDaoRepo userDaoRepo;
	
	@Override
	public List<User> getUser() {
		
		return this.userDaoRepo.findAll();
	}

//	@Override
//	public User getUser(long userId) {
//		User c = null;
//		for(User user: userList)
//		{
//			if(user.getId( == userId))
//			{
//				c = user;
//				break;
//		}
//		return this.userDaoRepo.getById(long id);
//	}
	
	@Override
	public User getUser(long userId) {
		
		return null;
	}

	@Override
	public User addUser(User user) {
		userDaoRepo.save(user);
		return user;
	}

	@Override
	public ResponseEntity<User> updateUser(Long id, User ur) {
		userDaoRepo.save(ur);
		return updateUser(id, ur);
	}

	@Override
	public User deleteUser(Long userId) {
		this.userDaoRepo.deleteById(userId);
		return null;
	}
	

	
	
	

}
 
