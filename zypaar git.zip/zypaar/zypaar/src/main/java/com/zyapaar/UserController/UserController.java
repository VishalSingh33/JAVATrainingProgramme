package com.zyapaar.UserController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zyapaar.UserService.UserService;
import com.zyapaar.modal.User;


@RestController
public class UserController {
	
	@Autowired
	private UserService userRepositary;
	
	@GetMapping("/user")
	public List<User> getUser()
	{
		return this.userRepositary.getUser();
	}

	@GetMapping("/user/{userId}")
	public User getUser(@PathVariable String userId)
	{
		return this.userRepositary.getUser(Long.parseLong(userId)); 
	}
	
	@PostMapping("/user")
	public User addUser(@RequestBody User user) {
		return this.userRepositary.addUser(user);
	}
	
	@PutMapping("/user/{id}")
	public ResponseEntity<User> updateUsers(@PathVariable("id") Long id , @RequestBody User ur)
	{
		Optional<User> userss= this.userRepositary.findById(id);
		if(userss.isPresent())
		{
			User=userss.get();
		}
		
		user.setName(ur.getName());
		user.setId(ur.getId());
		user.setDescription(ur.getDescrpition());
		
		return new ResponseEntity<>(userRepositary.save(user).HttpsStatus.OK);
		
	}
	
	@DeleteMapping("/user/{userId}")
	public void deleteUser(@PathVariable("userId")Long userId)
	{
		this.userRepositary.deleteUser(userId);
	}
	
	}
	

	

