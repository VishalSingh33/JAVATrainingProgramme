package com.zyapaar.userstreamservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main class
 * 
 * @author Uday Halpara
 */
@SpringBootApplication
public class UserStreamServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(UserStreamServiceApplication.class, args);
  }

}
