package com.zyapaar.userstreamservice.entities;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "keyword")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Keyword {

  @Id
  @NotNull
  @Column(name = "id", nullable = false, length = 19)
  private String id;

  @Column(name = "name")
  private String name;

  @ManyToOne(fetch = FetchType.LAZY, optional = true, targetEntity = SubIndustry.class)
  @PrimaryKeyJoinColumn(name = "sub_industry_id", referencedColumnName = "id")
  private SubIndustry subIndustry;

  @Column(name = "keyword_id", length = 39)
  private String keywordId;

  @NotNull
  @Column(name = "created_on", nullable = false)
  private OffsetDateTime createdOn;

  @NotNull
  @Column(name = "created_by", nullable = false, length = 19)
  private String createdBy;

  @Column(name = "updated_on")
  private OffsetDateTime updatedOn;

  @Column(name = "updated_by", length = 19)
  private String updatedBy;

}
