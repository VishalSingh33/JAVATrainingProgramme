package com.zyapaar.userstreamservice.entities;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Master email template
 * 
 * @author Uday Halpara
 */
@Data
@Entity
@Table(name = "master_email_template")
@AllArgsConstructor
@NoArgsConstructor
public class MasterEmailTemplate {

  @Id
  private String id;
  
  private String title;
  
  private String type;
  
  private String meta;
  
  private String subject;
  
  private String content;
  
  private String version;

  @Column(name = "is_active")
  private Boolean isActive;

  @Column(name = "created_on")
  private Timestamp createdOn;

  @Column(name = "updated_on")
  private Timestamp updatedOn;

  @Column(name = "created_by")
  private String createdBy;

  @Column(name = "updated_by")
  private String updatedBy;

  private Integer variable;

}

