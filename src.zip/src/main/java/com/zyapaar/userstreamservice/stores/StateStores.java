package com.zyapaar.userstreamservice.stores;

import org.apache.kafka.streams.errors.StateStoreMigratedException;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.springframework.cloud.stream.binder.kafka.streams.InteractiveQueryService;
import org.springframework.stereotype.Component;

import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.serde.UserIndustryCountAvro;
import com.zyapaar.userstreamservice.properties.B2bProperties;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * State stores class
 * 
 * @author UDaY HaLPaRa
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StateStores {

  private final InteractiveQueryService interactiveQueryService;
  private final B2bProperties b2bProperties;

  public UserIndustryCountAvro getUserIndustryCount(String userId) {

    log.info("[getUserIndustryCount] get User ind : {}", userId);
    try {
      ReadOnlyKeyValueStore<String, UserIndustryCountAvro> keyValueStore = interactiveQueryService
          .getQueryableStore(
              b2bProperties.getStore().getUserIndustryCountStore(),
              QueryableStoreTypes.keyValueStore());

      return keyValueStore.get(userId);

    } catch (StateStoreMigratedException e) {

      log.error(e.getMessage());
      throw new ResourceNotFoundException("user", "", userId);

    }
  }

}
