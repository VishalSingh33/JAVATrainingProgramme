package com.zyapaar.userstreamservice.producer;

import com.zyapaar.serde.UserIndustryCountAvro;

/**
 * Producer interface
 * 
 * @author Uday Halpara
 */
public interface Producer {

  public void produceUserIndustryCount(UserIndustryCountAvro industryCountAvro);

}
