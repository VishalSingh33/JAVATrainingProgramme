package com.zyapaar.userstreamservice.producer;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.zyapaar.serde.UserIndustryCountAvro;
import com.zyapaar.userstreamservice.properties.B2bProperties;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Producer
 * 
 * @author Uday Halpara
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ManageProducer implements Producer {

  private final B2bProperties b2bProperties;
  private final KafkaTemplate<String, UserIndustryCountAvro> kafkaTemplate;

  @Override
  public void produceUserIndustryCount(UserIndustryCountAvro industryCountAvro) {

    log.info("[produceUserIndustryCount] produce User Industry Count");
    String key = String.valueOf(industryCountAvro.getId());

    ProducerRecord<String, UserIndustryCountAvro> producerRecord = new ProducerRecord<>(
        b2bProperties.getTopic().getUserIndustryCount(),
        key,
        industryCountAvro);

    kafkaTemplate.send(producerRecord);

  }

}
