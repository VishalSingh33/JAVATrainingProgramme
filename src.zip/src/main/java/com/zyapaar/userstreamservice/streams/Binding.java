package com.zyapaar.userstreamservice.streams;

import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.springframework.cloud.stream.annotation.Input;

import com.zyapaar.serde.EmailVerificationStatusAvro;
import com.zyapaar.serde.RawFollower;
import com.zyapaar.serde.RawUser;
import com.zyapaar.serde.RawUserIndustry;
import com.zyapaar.serde.RawUserConnection;
import com.zyapaar.serde.UserConnectionAvro;
import com.zyapaar.serde.UserIndustryCountAvro;
import com.zyapaar.serde.UserOverviewAvro;

/**
 * Stream binding
 * 
 * @author Uday Halpara
 */
public interface Binding {

  /**
   * User registration source connector topic data stream
   */
  @Input("raw-user-data-channel")
  KStream<String, RawUser> rawUser();

  /**
   * User industry source connector topic data stream
   */
  @Input("raw-user-ind-data-channel")
  KStream<String, RawUserIndustry> rawUserInd();

  /**
   * User connection count industry wise
   */
  @Input("user-industry-count-channel")
  KTable<String, UserIndustryCountAvro> userIndustryCount();

  /**
   * User connection source connection topic data stream
   */
  @Input("user-connection-channel")
  KStream<String, RawUserConnection> userConnection();

  /**
   * User connection list table
   */
  @Input("user-connection-list-channel")
  KTable<String, UserConnectionAvro> userConnectionList();

  /**
   * User over view data table
   */
  @Input("user-overview-channel")
  KTable<String, UserOverviewAvro> userOverviewTable();

  /**
   * User follower source connection topic data stream
   */
  @Input("user-follower-channel")
  KStream<String, RawFollower> userFollower();

  /**
   * Email verification status data
   */
  @Input("email-status-channel")
  KTable<String, EmailVerificationStatusAvro> emailStatusTable();

}
