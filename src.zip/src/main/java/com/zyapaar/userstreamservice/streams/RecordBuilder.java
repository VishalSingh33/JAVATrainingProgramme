package com.zyapaar.userstreamservice.streams;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.kafka.streams.KeyValue;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import com.zyapaar.commons.utils.DateTimeUtils;
import com.zyapaar.commons.utils.SequenceGenerator;
import com.zyapaar.exceptionhandler.custom.ResourceNotFoundException;
import com.zyapaar.serde.EmailNotificationAvro;
import com.zyapaar.serde.EmailVerificationStatusAvro;
import com.zyapaar.serde.IndustryCount;
import com.zyapaar.serde.RawFollower;
import com.zyapaar.serde.RawUser;
import com.zyapaar.serde.RawUserConnection;
import com.zyapaar.serde.RawUserIndustry;
import com.zyapaar.serde.UserConnectionAvro;
import com.zyapaar.serde.UserIndustryCountAvro;
import com.zyapaar.serde.UserOverviewAvro;
import com.zyapaar.serde.UserRegistrationAvro;
import com.zyapaar.userstreamservice.entities.MasterEmailTemplate;
import com.zyapaar.userstreamservice.entities.SubIndustry;
import com.zyapaar.userstreamservice.mapper.EmailMapper;
import com.zyapaar.userstreamservice.mapper.UserMapper;
import com.zyapaar.userstreamservice.producer.Producer;
import com.zyapaar.userstreamservice.properties.B2bProperties;
import com.zyapaar.userstreamservice.repository.MasterEmailTemplateRepository;
import com.zyapaar.userstreamservice.repository.SubIndustryRepo;
import com.zyapaar.userstreamservice.stores.StateStores;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Record builder
 * 
 * @author Uday Halpara
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class RecordBuilder {

  private final UserMapper userMapper;
  private final SubIndustryRepo subIndustryRepo;
  private final StateStores stateStores;
  private final Producer producer;
  private final B2bProperties b2bProperties;
  private final EmailMapper emailMapper;
  private final MasterEmailTemplateRepository masterEmailTemplateRepository;

  /**
   * build user reg data from raw user data
   * 
   * @param value
   * @return
   */
  public KeyValue<String, UserRegistrationAvro> buildUserData(RawUser value) {

    UserRegistrationAvro registrationAvro = userMapper.toRegistrationAvro(value.getAfter());

    if (String.valueOf(value.getOp()).equalsIgnoreCase("c")) {

      registrationAvro.setIsNew(true);
      return new KeyValue<>(value.getAfter().getId().toString(), registrationAvro);

    } else if (String.valueOf(value.getOp()).equalsIgnoreCase("u")) {

      registrationAvro.setIsNew(false);
      return new KeyValue<>(value.getAfter().getId().toString(), registrationAvro);

    } else if (String.valueOf(value.getOp()).equalsIgnoreCase("d")) {

      log.info("[buildUserData] delete event in user data : {}", value);

    } else {

      log.info("[buildUserData] event in user data : {}", value);

    }

    return new KeyValue<>(value.getAfter().getId().toString(), null);
  }

  /**
   * build user industry connection count
   * 
   * @param value
   * @return
   */
  public KeyValue<String, UserIndustryCountAvro> buildUserCountData(RawUser value) {

    Map<CharSequence, IndustryCount> map = new HashMap<>();

    UserIndustryCountAvro countAvro = new UserIndustryCountAvro(value.getAfter().getId(), map);

    return new KeyValue<>(String.valueOf(value.getAfter().getId()), countAvro);

  }

  /**
   * update user own industry count
   * 
   * @param value
   * @param industryCount
   * @return
   */
  public UserIndustryCountAvro updateIndustryCount(RawUserIndustry value,
      UserIndustryCountAvro industryCount) {

    Set<String> industrySet = new HashSet<>();
    value.getAfter().getKeywordBuysSellsId().stream()
        .forEach(ind -> industrySet.add(String.valueOf(ind)));
    List<SubIndustry> subIndustryList = subIndustryRepo.findNames(industrySet);

    if (Objects.nonNull(industryCount)) {

      Map<CharSequence, IndustryCount> allIndustryMap = industryCount.getIndustryCount();

      subIndustryList.stream().forEach(subIndustry -> {

        if (!allIndustryMap.containsKey(subIndustry.getId())) {
          allIndustryMap.put(subIndustry.getId(),
              IndustryCount.newBuilder().setName(subIndustry.getName()).build());
        }

      });

      industryCount.setIndustryCount(allIndustryMap);

      return industryCount;
    } else {
      Map<CharSequence, IndustryCount> map = new HashMap<>();

      subIndustryList.stream().forEach(subIndustry -> map.put(subIndustry.getId(),
          IndustryCount.newBuilder().setName(subIndustry.getName()).build())

      );

      return new UserIndustryCountAvro(value.getAfter().getUserId(), map);

    }

  }

  /**
   * Update user connection list for FOR user
   * 
   * @param userConReq
   * @param userConList
   * @return
   */
  public UserConnectionAvro updateUserFromConnectionList(RawUserConnection userConReq,
      UserConnectionAvro userConList) {

    Set<CharSequence> users = new HashSet<>(userConList.getUserIds());

    if (String.valueOf(userConReq.getAfter().getStatus()).equals("remove")) {

      users.removeIf(user -> String.valueOf(user).equals(userConReq.getAfter().getFromUserId()));

    } else {

      users.add(userConReq.getAfter().getFromUserId());
    }

    userConList.setUserIds(new ArrayList<>(users));
    return userConList;
  }

  /**
   * Update user connection list for TO user
   * 
   * @param userConReq
   * @param userConList
   * @return
   */
  public UserConnectionAvro updateUserToConnectionList(RawUserConnection userConReq,
      UserConnectionAvro userConList) {

    Set<CharSequence> users = new HashSet<>(userConList.getUserIds());

    if (String.valueOf(userConReq.getAfter().getStatus()).equals("remove")) {

      users.removeIf(user -> String.valueOf(user).equals(userConReq.getAfter().getToUserId()));

    } else {

      users.add(userConReq.getAfter().getToUserId());
    }

    userConList.setUserIds(new ArrayList<>(users));
    return userConList;
  }

  public Object updateUserConnectionIndustryCount(RawUserIndustry rawUserIndustry,
      UserConnectionAvro userConList) {

    List<CharSequence> newIndustry =
        new ArrayList<>(rawUserIndustry.getAfter().getKeywordBuysSellsId());
    List<CharSequence> oldIndustry =
        new ArrayList<>(rawUserIndustry.getBefore().getKeywordBuysSellsId());

    newIndustry.removeAll(rawUserIndustry.getBefore().getKeywordBuysSellsId());
    oldIndustry.removeAll(rawUserIndustry.getAfter().getKeywordBuysSellsId());

    Set<String> newIndustrySet = new HashSet<>();
    newIndustry.stream().forEach(ind -> newIndustrySet.add(String.valueOf(ind)));

    List<SubIndustry> newUserIndustryNameList = subIndustryRepo.findNames(newIndustrySet);


    userConList.getUserIds().stream().forEach(userId -> {

      UserIndustryCountAvro industryCount =
          stateStores.getUserIndustryCount(String.valueOf(userId));

      Map<CharSequence, IndustryCount> allIndustryMap = industryCount.getIndustryCount();

      newUserIndustryNameList.stream().forEach(subIndustry -> {

        if (allIndustryMap.containsKey(subIndustry.getId())) {
          IndustryCount object = allIndustryMap.get(subIndustry.getId());
          object.setCount(object.getCount() + 1);
          allIndustryMap.put(subIndustry.getId(), object);
        } else {
          allIndustryMap.put(subIndustry.getId(),
              IndustryCount.newBuilder().setCount(1).setName(subIndustry.getName()).build());
        }

      });

      oldIndustry.stream().forEach(subIndustry -> {

        if (allIndustryMap.containsKey(subIndustry)) {

          IndustryCount object = allIndustryMap.get(subIndustry);
          object.setCount(object.getCount() - 1);
          allIndustryMap.put(subIndustry, object);


        }

      });

      producer.produceUserIndustryCount(industryCount);

    });

    return null;
  }

  /**
   * update user industry for users
   * 
   * @param value
   * @param userIndCount
   * @return
   */
  public UserIndustryCountAvro updateForAcceptUserIndustryCount(CharSequence userID,
      RawUserIndustry userInd) {

    List<CharSequence> saleBuyIndustryList = userInd.getAfter().getKeywordBuysSellsId();

    Set<String> newIndustrySet = new HashSet<>();
    saleBuyIndustryList.stream().forEach(ind -> newIndustrySet.add(String.valueOf(ind)));

    UserIndustryCountAvro userIndCount = stateStores.getUserIndustryCount(String.valueOf(userID));

    Map<CharSequence, IndustryCount> allIndustryMap = userIndCount.getIndustryCount();

    subIndustryRepo.findNames(newIndustrySet).stream().forEach(subIndustry -> {

      if (allIndustryMap.containsKey(subIndustry.getId())) {
        IndustryCount object = allIndustryMap.get(subIndustry.getId());
        object.setCount(object.getCount() + 1);
        allIndustryMap.put(subIndustry.getId(), object);
      } else {
        allIndustryMap.put(subIndustry.getId(),
            IndustryCount.newBuilder().setCount(1).setName(subIndustry.getName()).build());
      }

    });

    userIndCount.setIndustryCount(allIndustryMap);

    return userIndCount;

  }

  /**
   * update user industry for users
   * 
   * @param value
   * @param userIndCount
   * @return
   */
  public UserIndustryCountAvro updateForRemoveUserIndustryCount(CharSequence userID,
      RawUserIndustry userInd) {
    List<CharSequence> saleBuyIndustryList = userInd.getAfter().getKeywordBuysSellsId();

    Set<String> newIndustrySet = new HashSet<>();
    saleBuyIndustryList.stream().forEach(ind -> newIndustrySet.add(String.valueOf(ind)));

    UserIndustryCountAvro userIndCount = stateStores.getUserIndustryCount(String.valueOf(userID));

    Map<CharSequence, IndustryCount> allIndustryMap = userIndCount.getIndustryCount();

    saleBuyIndustryList.stream().forEach(subIndustry -> {

      if (allIndustryMap.containsKey(subIndustry)) {

        IndustryCount object = allIndustryMap.get(subIndustry);
        object.setCount(object.getCount() - 1);
        allIndustryMap.put(subIndustry, object);

      }

    });

    userIndCount.setIndustryCount(allIndustryMap);

    return userIndCount;
  }

  /**
   * Update user connection count
   * 
   * @param userCon
   * @param userOver
   * @return
   */
  public UserOverviewAvro updateUserConnectionCount(RawUserConnection userCon,
      UserOverviewAvro userOver) {

    if (String.valueOf(userCon.getAfter().getStatus()).equals("remove")) {
      userOver.setConnections(userOver.getConnections() - 1);
    } else {
      userOver.setConnections(userOver.getConnections() + 1);
    }

    return userOver;
  }

  /**
   * Update user following count follwer user
   * 
   * @param userFollower
   * @param userOverView
   * @return
   */
  public UserOverviewAvro updateByUserFollowRecord(RawFollower userFollower,
      UserOverviewAvro userOverView) {

    if (String.valueOf(userFollower.getAfter().getStatus()).equals("ACTIVE")) {

      userOverView.setFollowing(userOverView.getFollowing() + 1);

    } else if (String.valueOf(userFollower.getAfter().getStatus()).equals("INACTIVE")
        && Objects.nonNull(userFollower.getBefore())
        && String.valueOf(userFollower.getBefore().getStatus()).equals("ACTIVE")) {

      userOverView.setFollowing(userOverView.getFollowing() - 1);

    }

    return userOverView;
  }

  /**
   * Update user follow count follwer user
   * 
   * @param userFollower
   * @param userOverView
   * @return
   */
  public UserOverviewAvro updateForUserFollowRecord(RawFollower userFollower,
      UserOverviewAvro userOverView) {

    if (String.valueOf(userFollower.getAfter().getStatus()).equals("ACTIVE")) {

      userOverView.setFollower(userOverView.getFollower() + 1);

    } else if (String.valueOf(userFollower.getAfter().getStatus()).equals("INACTIVE")
        && Objects.nonNull(userFollower.getBefore())
        && String.valueOf(userFollower.getBefore().getStatus()).equals("ACTIVE")) {

      userOverView.setFollower(userOverView.getFollower() - 1);

    }

    return userOverView;
  }

  /**
   * Email verification status
   * 
   * @param user
   * @param emailStatus
   * @return
   */
  public EmailVerificationStatusAvro buildEmailStatus(RawUser user,
      EmailVerificationStatusAvro emailStatus) {

    EmailVerificationStatusAvro.Builder builder =
        EmailVerificationStatusAvro.newBuilder().setId(user.getAfter().getId());

    if (Objects.nonNull(emailStatus)
        && emailStatus.getEmail().equals(user.getAfter().getEmailId())) {

      return null;

    } else {

      if (StringUtils.hasText(user.getAfter().getEmailId())) {

        builder.setEmail(user.getAfter().getEmailId())
            .setVerificationCode(SequenceGenerator.getInstance().nextId());

      }

    }

    return builder.build();

  }

  public EmailNotificationAvro getWelcomeMail(RawUser value) {
    try {

      MasterEmailTemplate template =
          masterEmailTemplateRepository.findById(b2bProperties.getTemplate().getWelcome())
            .orElseThrow(() -> new ResourceNotFoundException("template", "id", b2bProperties.getTemplate().getWelcome()));;

      String profileTitle = value.getAfter().getTitle() == null ? "Team Member"
          : value.getAfter().getTitle().toString();

      String emailContent = MessageFormat.format(template.getContent(),
          b2bProperties.getUrl().getBaseUrl(), value.getAfter().getFullName(), profileTitle);

      return emailMapper.toEmailNotification(SequenceGenerator.getInstance().nextId(),
          value.getAfter().getEmailId(), template.getSubject(), emailContent, template.getMeta(),
          DateTimeUtils.currentDateTimeUTC());

    } catch (Exception ex) {
      log.info("[Email Notification error : {}]", ex.getMessage());
    }
    return null;
  }

}
