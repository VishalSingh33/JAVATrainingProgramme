package com.zyapaar.userstreamservice.streams;

import java.util.Objects;
import org.apache.kafka.streams.KeyValue;
import org.springframework.stereotype.Component;
import com.zyapaar.commons.dto.NotificationFor;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.RawUserConnection;
import com.zyapaar.userstreamservice.dto.ConnectionStatus;
import com.zyapaar.userstreamservice.mapper.NotificationMapper;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class NotificationBuilder {

  private final NotificationMapper notificationMapper;

  public KeyValue<String, NotificationEventAvro> buildNotification(RawUserConnection v) {

    String status = v.getAfter().getStatus().toString();
    NotificationEventAvro eventAvro = null;
    CharSequence fromUserId = v.getAfter().getFromUserId();
    CharSequence toUserId = v.getAfter().getToUserId();
    CharSequence requestId;
    CharSequence id = v.getAfter().getId();
    // = v.getAfter().getFromUserId() + "_" + v.getAfter().getToUserId();

    if (Long.parseLong(fromUserId.toString()) < Long.parseLong(toUserId.toString())) {
      requestId = fromUserId + "_" + toUserId;
    } else {
      requestId = toUserId + "_" + fromUserId;
    }

    if (status.equals(ConnectionStatus.INITIATE.connectionStatus())) { // "initiate"

      eventAvro = notificationMapper.buildNotificationEvent(
          requestId + "_" + NotificationTypes.CONNECTION_REQUEST.types(), fromUserId, toUserId,
          NotificationTypes.CONNECTION_REQUEST, id, NotificationFor.REQUEST);
    }

    else if (status.equals(ConnectionStatus.ACCEPT.connectionStatus())) { // "accept"

      eventAvro = notificationMapper.buildNotificationEvent(
          requestId + "_" + NotificationTypes.CONNECTION_REQUEST.types(), toUserId, fromUserId,
          NotificationTypes.CONNECTION_REQUEST, id, NotificationFor.ACCEPT);

    } else if (status.equals(ConnectionStatus.REJECT.connectionStatus())
        || status.equals(ConnectionStatus.CANCEL.connectionStatus())) { // "reject" "cancle"


      eventAvro = notificationMapper.buildNotificationEvent(
          requestId + "_" + NotificationTypes.CONNECTION_REQUEST.types(), toUserId, fromUserId,
          NotificationTypes.CONNECTION_REQUEST, id, false);

    }

    if (Objects.nonNull(eventAvro))
      return new KeyValue<String, NotificationEventAvro>(eventAvro.getId().toString(), eventAvro);
    else
      return new KeyValue<String, NotificationEventAvro>("key", null);
  }

}
