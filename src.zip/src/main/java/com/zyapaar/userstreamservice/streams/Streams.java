package com.zyapaar.userstreamservice.streams;

import java.util.ArrayList;
import java.util.Objects;

import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Materialized;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.zyapaar.serde.EmailVerificationStatusAvro;
import com.zyapaar.serde.NotificationSettingsV2Avro;
import com.zyapaar.serde.RawFollower;
import com.zyapaar.serde.RawUser;
import com.zyapaar.serde.RawUserIndustry;
import com.zyapaar.serde.RawUserConnection;
import com.zyapaar.serde.UserConnectionAvro;
import com.zyapaar.serde.UserIndustryCountAvro;
import com.zyapaar.serde.UserOverviewAvro;
import com.zyapaar.userstreamservice.dto.ConnectionStatus;
import com.zyapaar.userstreamservice.mapper.UserIndustryMapper;
import com.zyapaar.userstreamservice.properties.B2bProperties;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Stream class
 * 
 * @author Uday Halpara
 */
@Slf4j
@Component
@RequiredArgsConstructor
@EnableBinding(Binding.class)
public class Streams {

  private final B2bProperties b2bProperties;
  private final RecordBuilder recordBuilder;
  private final UserIndustryMapper industryMapper;
  private final NotificationBuilder notificationBuilder;

  @StreamListener
  public void process(

      // User registration source connector topic data stream
      @Input("raw-user-data-channel") KStream<String, RawUser> rawUser,

      // User industry source connector topic data stream
      @Input("raw-user-ind-data-channel") KStream<String, RawUserIndustry> rawUserInd,

      // User connection count industry wise
      @Input("user-industry-count-channel") KTable<String, UserIndustryCountAvro> userIndustryCount,

      // User connection source connection topic data stream
      @Input("user-connection-channel") KStream<String, RawUserConnection> userConnection,

      // User connection list table
      @Input("user-connection-list-channel") KTable<String, UserConnectionAvro> userConnectionList,

      // user over view table
      @Input("user-overview-channel") KTable<String, UserOverviewAvro> userOverviewTable,

      // User follower source connection topic data stream
      @Input("user-follower-channel") KStream<String, RawFollower> userFollower,

      // User email verification status
      @Input("email-status-channel") KTable<String, EmailVerificationStatusAvro> emailStatusTable

  ) {

    log.info("[streams] streams");

    /**
     * User industry count store build
     */
    userIndustryCount.toStream()
        .toTable(Materialized.as(b2bProperties.getStore().getUserIndustryCountStore()));


    rawUser.filter((key, value) -> String.valueOf(value.getOp()).equals("c"))
        .mapValues((value) -> recordBuilder.getWelcomeMail(value)).filter((k, v) -> v != null)
        .to(b2bProperties.getTopic().getEmailNotification());

    /**
     * Raw user to user reg data : -> from raw data to User avro data transform
     */
    rawUser
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("r")
            && !String.valueOf(value.getOp()).equalsIgnoreCase("d"))
        .map((key, value) -> recordBuilder.buildUserData(value))
        .filter((k, v) -> Objects.nonNull(v)).to(b2bProperties.getTopic().getUser());

    /**
     * Raw user industry to update user industry data : -> join with user industry in update user
     * industry data
     */
    rawUserInd
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("r")
            && !String.valueOf(value.getOp()).equalsIgnoreCase("d"))
        .map((key, value) -> new KeyValue<>(String.valueOf(value.getAfter().getUserId()),
            industryMapper.toUserIndustryAvro(value.getAfter())))
        .to(b2bProperties.getTopic().getUserIndustry());

    /**
     * add User own industy initial data add or update user industry count for user own data
     */
    rawUserInd
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("r")
            && !String.valueOf(value.getOp()).equalsIgnoreCase("d"))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getUserId()))
        .leftJoin(userIndustryCount, (rawUserData, industryCount) -> recordBuilder
            .updateIndustryCount(rawUserData, industryCount))
        .to(b2bProperties.getTopic().getUserIndustryCount());

    /**
     * user to user connection list data : -> for every new user generate user connection list
     * default data
     */
    rawUser.filter((key, value) -> String.valueOf(value.getOp()).equalsIgnoreCase("c"))
        .map((k, v) -> new KeyValue<>(String.valueOf(v.getAfter().getId()),
            UserConnectionAvro.newBuilder().setId(v.getAfter().getId())
                .setUserIds(new ArrayList<CharSequence>()).build()))
        .to(b2bProperties.getTopic().getUserConnectionList());

    /**
     * update user connection list for FROM userid user connection to update user connection list
     * for user accept or reject we update user connection list
     */
    userConnection
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("d")
            && (String.valueOf(value.getAfter().getStatus()).equals("accept")
                || String.valueOf(value.getAfter().getStatus()).equals("remove")))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getFromUserId()))
        .join(userConnectionList, (userConReq, userConList) -> recordBuilder
            .updateUserFromConnectionList(userConReq, userConList))
        .to(b2bProperties.getTopic().getUserConnectionList());

    /**
     * update user connection list for TO userid user connection to update user connection list for
     * user accept or reject we update user connection list
     */
    userConnection
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("d")
            && (String.valueOf(value.getAfter().getStatus()).equals("accept")
                || String.valueOf(value.getAfter().getStatus()).equals("remove")))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getToUserId()))
        .join(userConnectionList, (userConReq, userConList) -> recordBuilder
            .updateUserToConnectionList(userConReq, userConList))
        .to(b2bProperties.getTopic().getUserConnectionList());

    /**
     * user industry join with user connection and update user connection industry count
     */
    rawUserInd.filter((key, value) -> String.valueOf(value.getOp()).equalsIgnoreCase("u"))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getUserId()))
        .join(userConnectionList, (rawUserIndustry, userConList) -> recordBuilder
            .updateUserConnectionIndustryCount(rawUserIndustry, userConList));

    /**
     * update user industry connection count for FROM userid for accept user connection with accept
     * status join with second user user Industry and update industry count
     */
    userConnection
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("d")
            && String.valueOf(value.getAfter().getStatus()).equals("accept"))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getToUserId()))
        .join(
            rawUserInd.selectKey((key, value) -> String.valueOf(value.getAfter().getUserId()))
                .toTable(),
            (userCon, userInd) -> recordBuilder
                .updateForAcceptUserIndustryCount(userCon.getAfter().getFromUserId(), userInd))
        .to(b2bProperties.getTopic().getUserIndustryCount());

    /**
     * update user industry connection count for TO userid for accept user connection with accept
     * status join with second user user Industry and update industry count
     */
    userConnection
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("d")
            && String.valueOf(value.getAfter().getStatus()).equals("accept"))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getFromUserId()))
        .join(
            rawUserInd.selectKey((key, value) -> String.valueOf(value.getAfter().getUserId()))
                .toTable(),
            (userCon, userInd) -> recordBuilder
                .updateForAcceptUserIndustryCount(userCon.getAfter().getToUserId(), userInd))
        .to(b2bProperties.getTopic().getUserIndustryCount());

    /**
     * update user industry connection count for FROM userid for remove user connection with remove
     * status join with second user user Industry and update industry count
     */
    userConnection
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("d")
            && String.valueOf(value.getAfter().getStatus()).equals("remove"))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getFromUserId()))
        .join(
            rawUserInd.selectKey((key, value) -> String.valueOf(value.getAfter().getUserId()))
                .toTable(),
            (userCon, userInd) -> recordBuilder
                .updateForRemoveUserIndustryCount(userCon.getAfter().getToUserId(), userInd))
        .to(b2bProperties.getTopic().getUserIndustryCount());

    /**
     * update user industry connection count for TO userid for remove user connection with remove
     * status join with second user user Industry and update industry count
     */
    userConnection
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("d")
            && String.valueOf(value.getAfter().getStatus()).equals("remove"))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getToUserId()))
        .join(
            rawUserInd.selectKey((key, value) -> String.valueOf(value.getAfter().getUserId()))
                .toTable(),
            (userCon, userInd) -> recordBuilder
                .updateForRemoveUserIndustryCount(userCon.getAfter().getFromUserId(), userInd))
        .to(b2bProperties.getTopic().getUserIndustryCount());

    /**
     * For new user user over view default data generate
     */
    rawUser.filter((key, value) -> String.valueOf(value.getOp()).equalsIgnoreCase("c"))
        .map((key, value) -> new KeyValue<>(String.valueOf(value.getAfter().getId()),
            UserOverviewAvro.newBuilder().setUserId(value.getAfter().getId()).build()))
        .to(b2bProperties.getTopic().getUserOverview());

    /**
     * user connection for TO to user over view data connection count update
     */
    userConnection
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("d")
            && (String.valueOf(value.getAfter().getStatus()).equals("remove")
                || String.valueOf(value.getAfter().getStatus()).equals("accept")))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getToUserId()))
        .join(userOverviewTable,
            (userCon, userOver) -> recordBuilder.updateUserConnectionCount(userCon, userOver))
        .to(b2bProperties.getTopic().getUserOverview());

    /**
     * user connection for FROM to user over view data connection count update
     */
    userConnection
        .filter((key, value) -> !String.valueOf(value.getOp()).equalsIgnoreCase("d")
            && (String.valueOf(value.getAfter().getStatus()).equals("remove")
                || String.valueOf(value.getAfter().getStatus()).equals("accept")))
        .selectKey((key, value) -> String.valueOf(value.getAfter().getFromUserId()))
        .join(userOverviewTable,
            (userCon, userOver) -> recordBuilder.updateUserConnectionCount(userCon, userOver))
        .to(b2bProperties.getTopic().getUserOverview());

    /**
     * user follower vount update for following user
     */
    userFollower.selectKey((k, v) -> String.valueOf(v.getAfter().getFollowerUser()))
        .join(userOverviewTable,
            (userFollowerData, userOverView) -> recordBuilder
                .updateByUserFollowRecord(userFollowerData, userOverView))
        .to(b2bProperties.getTopic().getUserOverview());

    /**
     * user follower vount update for follower user
     */
    userFollower.selectKey((k, v) -> String.valueOf(v.getAfter().getUserFollowerId()))
        .join(userOverviewTable,
            (userFollowerData, userOverView) -> recordBuilder
                .updateForUserFollowRecord(userFollowerData, userOverView))
        .to(b2bProperties.getTopic().getUserOverview());

    /**
     * raw user to email status : -> for user data update email status data if email update then
     * update email status data
     */
    rawUser.selectKey((k, v) -> String.valueOf(v.getAfter().getId()))
        .leftJoin(emailStatusTable,
            (user, emailStatus) -> recordBuilder.buildEmailStatus(user, emailStatus))
        .filter((k, v) -> Objects.nonNull(v)).to(b2bProperties.getTopic().getEmailStatus());


    /**
     * For new user generate notification setting default entry
     */
    rawUser.filter((key, value) -> String.valueOf(value.getOp()).equalsIgnoreCase("c"))
        .map(
            (key, v) -> new KeyValue<>(String.valueOf(v.getAfter().getId()),
                NotificationSettingsV2Avro.newBuilder().setUserId(v.getAfter().getId()).setEmailId(
                    StringUtils.hasText(v.getAfter().getEmailId()) ? v.getAfter().getEmailId() : "")
                    .setNetworkProfile("1").setPostDelivery("1").build()))
        .to(b2bProperties.getTopic().getNotificationSettingsV2());


    /**
     * user industry count to flat industry count
     */
    userIndustryCount.toStream()
        .mapValues(ind -> (industryMapper
            .toUserIndustryCountFlatAvro(industryMapper.toUserIndustryCountDto(ind))))
        .to(b2bProperties.getTopic().getUserIndustryCountFlat());

    /*
     * Generate notification from user connection.
     */
    userConnection.peek((k, v) -> log.info("ConnectionRequest: Key: {} Value: {}", k, v))
        .filter((k,
            v) -> !String.valueOf(v.getOp()).equalsIgnoreCase("d") && !v.getAfter().getStatus()
                .toString().equals(ConnectionStatus.REMOVE.connectionStatus())) // remove
        .map((k, v) -> notificationBuilder.buildNotification(v))
        .filter((k, v) -> Objects.nonNull(v))
        .to(b2bProperties.getTopic().getUserConnectionRequestEventPg());
  }

}
