package com.zyapaar.userstreamservice.dto;

import java.util.Map;

import lombok.Data;

@Data
public class UserIndustryCountDto {

  private String id;
  private Map<String, IndustryCountDto> industryCount;

}
