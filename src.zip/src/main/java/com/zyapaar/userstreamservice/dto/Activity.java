package com.zyapaar.userstreamservice.dto;

/**
 * activity enum
 * 
 * @author Uday Halpara
 */
public enum Activity {

  POST("1"),
  COMMENT("2"),
  REACTION("3"),
  VIEW("4"),
  REQUEST("5");

  private final String acivity;

  Activity(String acivity) {
    this.acivity = acivity;
  }

  public String activity() {
    return acivity;
  }

  public static Activity fromString(String text) {
    for (Activity b : Activity.values()) {
      if (b.acivity.equalsIgnoreCase(text)) {
        return b;
      }
    }
    return null;
  }

}
