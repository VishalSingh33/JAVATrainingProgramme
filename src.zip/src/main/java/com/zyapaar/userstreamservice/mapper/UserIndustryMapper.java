package com.zyapaar.userstreamservice.mapper;

import java.util.Map;
import java.util.Objects;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyapaar.serde.UserIndustryAvro;
import com.zyapaar.serde.UserIndustryCountAvro;
import com.zyapaar.serde.UserIndustryCountCompactAvro;
import com.zyapaar.userstreamservice.dto.IndustryCountDto;
import com.zyapaar.userstreamservice.dto.UserIndustryCountDto;

import UserInd.pgdb.user_industry.Value;

/**
 * User industry mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface UserIndustryMapper {

  ObjectMapper mapper = new ObjectMapper();

  @Mapping(source = "keywordBuysId", target = "buyIndustry")
  @Mapping(source = "keywordSellsId", target = "saleIndustry")
  @Mapping(target = "companies", ignore = true)
  UserIndustryAvro toUserIndustryAvro(Value value);

  UserIndustryCountDto toUserIndustryCountDto(UserIndustryCountAvro avro);

  UserIndustryCountCompactAvro toUserIndustryCountFlatAvro(UserIndustryCountDto countDto);

  default String toString(CharSequence value) {
    return Objects.nonNull(value) ? String.valueOf(value) : null;
  }

  default CharSequence mapToString(Map<String, IndustryCountDto> map) {
    try {
      return mapper.writeValueAsString(map);
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }
    return null;
  }

}
