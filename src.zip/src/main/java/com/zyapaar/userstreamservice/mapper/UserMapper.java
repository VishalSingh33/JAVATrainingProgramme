package com.zyapaar.userstreamservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;

import com.zyapaar.serde.UserRegistrationAvro;

import User.pgdb.users.Value;

/**
 * User mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface UserMapper {

  @Mapping(source = "user.title", target = "profileTitle", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(source = "user.img", target = "profileImg", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(source = "user.aboutUs", target = "aboutUs", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  @Mapping(source = "user.emailId", target = "emailId", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
  UserRegistrationAvro toRegistrationAvro(Value user);

}
