package com.zyapaar.userstreamservice.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zyapaar.commons.dto.NotificationContent;
import com.zyapaar.commons.dto.NotificationFor;
import com.zyapaar.commons.dto.NotificationStatus;
import com.zyapaar.commons.dto.NotificationTypes;
import com.zyapaar.serde.EmailNotificationAvro;
import com.zyapaar.serde.NotificationEventAvro;
import com.zyapaar.serde.SmsNotificationAvro;
import com.zyapaar.userstreamservice.dto.Activity;
import com.zyapaar.userstreamservice.entities.SmsTemplate;

/**
 * Notification mapper
 * 
 * @author Uday Halpara
 */
@Mapper
public interface NotificationMapper {

  ObjectMapper objectMapper = new ObjectMapper();

  NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor,
      NotificationTypes type, String requestId, NotificationFor requestType);

  NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor,
      NotificationTypes type, CharSequence requestId, NotificationStatus requestType);

  NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor,
      NotificationTypes type, String originId);

  NotificationEventAvro buildNotificationEvent(String id, String actionBy, NotificationTypes type,
      String originId, String requestId);

  NotificationEventAvro buildNotificationEvent(String id, String actionBy, String generatedFor,
      NotificationTypes type, String requestId, Boolean isActive);

  NotificationEventAvro buildNotificationEvent(String id, String actionBy, NotificationTypes type,
      String originId, String requestId, NotificationFor requestType);

  NotificationEventAvro buildNotificationEvent(CharSequence id, CharSequence actionBy,
      CharSequence generatedFor, NotificationTypes type, CharSequence requestId,
      NotificationFor requestType);

  NotificationEventAvro buildNotificationEvent(CharSequence id, CharSequence actionBy,
      CharSequence generatedFor, NotificationTypes type, CharSequence requestId, Boolean isActive);

  default int map(NotificationTypes value) {
    return value.types();
  }

  default int map(NotificationStatus value) {
    return value.status();
  }

  default int map(NotificationFor value) {
    return value.status();
  }

  default CharSequence map(NotificationContent content) throws JsonProcessingException {
    return objectMapper.writeValueAsString(content);
  }

  default CharSequence map(Activity value) {
    return value.activity();
  }


  @Mapping(source = "id", target = "id")
  SmsNotificationAvro toSmsNotificationAvro(SmsTemplate template, String id, String text,
      String phoneNumber);

  EmailNotificationAvro toEmailNotification(String id, CharSequence email, String subject,
      String content, String meta, Long createdOn);

}
