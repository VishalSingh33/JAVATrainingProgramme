package com.zyapaar.userstreamservice.mapper;

import org.mapstruct.Mapper;
import com.zyapaar.serde.EmailNotificationAvro;

@Mapper
public interface EmailMapper {

  EmailNotificationAvro toEmailNotification(String id, CharSequence email, String subject,
      String content, String meta, Long createdOn);

}
