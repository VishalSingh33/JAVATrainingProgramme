package com.zyapaar.userstreamservice.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.zyapaar.userstreamservice.entities.SubIndustry;

/**
 * Sub industry repo
 */
@Repository
public interface SubIndustryRepo extends JpaRepository<SubIndustry, String> {

	@Query(nativeQuery = true, value = "select * from sub_industry where id IN(:ids)")
	List<SubIndustry> findNames(Set<String> ids);

}
