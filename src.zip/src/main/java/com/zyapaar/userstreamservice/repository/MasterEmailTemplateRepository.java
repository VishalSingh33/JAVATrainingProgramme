package com.zyapaar.userstreamservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.zyapaar.userstreamservice.entities.MasterEmailTemplate;
/**
 * Master email template repository
 * 
 * @author Uday Halpara
 */
@Repository
public interface MasterEmailTemplateRepository extends JpaRepository<MasterEmailTemplate, String> {


}
