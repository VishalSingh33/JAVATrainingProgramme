package com.zyapaar.userstreamservice.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

/**
 * Property class
 * 
 * @author UDaY HaLPaRa
 */
@Getter
@Component
@ConfigurationProperties(prefix = "app")
public class B2bProperties {

  private Topic topic = new Topic();
  private Store store = new Store();
  private Url url = new Url();
  private Template template = new Template();
  @Getter
  @Setter
  public static class Topic {

    private String rawUser;
    private String rawUserIndustry;
    private String user;
    private String userIndustry;
    private String userIndustryCount;
    private String userConnectionList;
    private String userOverview;
    private String emailStatus;
    private String notificationSettingsV2;
    private String userIndustryCountFlat;
    private String emailNotification;
    private String userConnectionRequestEventPg;
    
    
  }

  @Getter
  @Setter
  public static class Store {

    private String userIndustryCountStore;

  }
  @Getter
  @Setter
  public static class Url {

    private String verificationUrl;
    private String baseUrl;

  }

  @Getter
  @Setter
  public static class Template {

    private String welcome;

  }
}
