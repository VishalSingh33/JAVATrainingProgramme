package com.zyapaar.userstreamservice;

import org.springframework.boot.test.context.SpringBootTest;

/**
 * Application Tests
 * 
 * @author Uday Halpara
 */
@SpringBootTest
public class ApplicationTests {

}
