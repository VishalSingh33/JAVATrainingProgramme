package com.example.multiplefetch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultipleFetchApplicationTests {

	@Test
	void contextLoads() {
	}

}
