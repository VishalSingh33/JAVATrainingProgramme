package com.example.multiplefetch.service;

// @Service
public class UserService {
	
	}