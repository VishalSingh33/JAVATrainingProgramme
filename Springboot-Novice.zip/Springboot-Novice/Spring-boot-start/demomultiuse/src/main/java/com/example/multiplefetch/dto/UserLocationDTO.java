package com.example.multiplefetch.dto;


// @Data
public class UserLocationDTO {

	private long userId;
	private String email;
	private String name;
	private String place;
	private double longitude;
	private double latitude;

}