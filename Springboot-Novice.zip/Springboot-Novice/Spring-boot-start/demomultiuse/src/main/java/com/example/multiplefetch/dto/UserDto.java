package com.example.multiplefetch.dto;


public class UserDto{
	
}
