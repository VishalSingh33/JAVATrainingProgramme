package com.example.multiplefetch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipleFetchApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultipleFetchApplication.class, args);
	}

}
