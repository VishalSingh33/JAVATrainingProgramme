package com.example.multiplefetch.converter;


// @Component
public class StudentConverter {
	
}