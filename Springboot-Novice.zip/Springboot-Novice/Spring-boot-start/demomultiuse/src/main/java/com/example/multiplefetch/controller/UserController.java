package com.example.multiplefetch.controller;


public class UserController  {

	
}