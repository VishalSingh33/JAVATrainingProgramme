package com.example.multiplefetch.entites;


// @Entity
public class User {

	private long id;
	private String email;
  private String password;

	// @ManyToOne(fetch = FetchType.EAGER, optional = false)
	// @JoinColumn(name= "location_id")

}
