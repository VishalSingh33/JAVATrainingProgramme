package com.example.multiplefetch.repo;

import javax.tools.DocumentationTool.Location;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepoistary extends JpaRepository<Location, Long> {
	
}
