package com.example.multiplefetch.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.multiplefetch.entites.User;

public interface UserRepository extends JpaRepository<User, Long>{

}
